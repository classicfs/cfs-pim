import { dbReady } from "../server/db";
import { sql } from "drizzle-orm";

async function main() {
  const db = await dbReady;
  
  console.log("Adding columns to pim.alumio_sync_log...");
  
  await db.execute(sql`ALTER TABLE pim.alumio_sync_log ADD COLUMN IF NOT EXISTS error_source text`);
  console.log("  added error_source");
  
  await db.execute(sql`ALTER TABLE pim.alumio_sync_log ADD COLUMN IF NOT EXISTS task_id text`);
  console.log("  added task_id");
  
  await db.execute(sql`ALTER TABLE pim.alumio_sync_log ADD COLUMN IF NOT EXISTS duration real`);
  console.log("  added duration");
  
  await db.execute(sql`ALTER TABLE pim.alumio_sync_log ADD COLUMN IF NOT EXISTS retry_number integer`);
  console.log("  added retry_number");
  
  console.log("Done!");
  process.exit(0);
}

main().catch((e) => {
  console.error("Migration failed:", e);
  process.exit(1);
});
