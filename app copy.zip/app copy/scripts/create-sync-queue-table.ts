import { dbReady } from "../server/db";
import { sql } from "drizzle-orm";

async function main() {
  const db = await dbReady;
  
  console.log("Creating pim.alumio_sync_queue table...");
  
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS pim.alumio_sync_queue (
      id BIGSERIAL PRIMARY KEY,
      product_id BIGINT NOT NULL REFERENCES pim.product(product_id),
      product_variant_id BIGINT REFERENCES pim.product_variant(product_variant_id),
      operation_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      processed_at TIMESTAMP
    )
  `);
  console.log("  table created");
  
  await db.execute(sql`
    CREATE INDEX IF NOT EXISTS alumio_sync_queue_status_idx ON pim.alumio_sync_queue(status)
  `);
  console.log("  status index created");
  
  await db.execute(sql`
    CREATE INDEX IF NOT EXISTS alumio_sync_queue_product_idx ON pim.alumio_sync_queue(product_id)
  `);
  console.log("  product index created");
  
  console.log("Done!");
  process.exit(0);
}

main().catch((e) => {
  console.error("Migration failed:", e);
  process.exit(1);
});
