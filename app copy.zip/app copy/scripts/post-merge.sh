#!/bin/bash
set -e
npm install --prefer-offline --no-audit --no-fund

for i in 1 2 3; do
  npm run db:push && break
  echo "db:push attempt $i failed, retrying in 5s..."
  sleep 5
done
