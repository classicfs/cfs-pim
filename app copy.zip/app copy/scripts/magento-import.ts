import "dotenv/config";
import * as readline from "node:readline";
import { dbReady, pool } from "../server/db";
import { eq, sql, and } from "drizzle-orm";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import type { PgTransaction } from "drizzle-orm/pg-core";
import * as schema from "../shared/schema";

const {
  product,
  productVariant,
  productCategory,
  productColour,
  productSizes,
  gender,
  brands,
  productType,
  condition,
  taxClass,
  category,
  imageAsset,
  attributeDef,
  productAttributeVal,
  variantAttributeVal,
  variantPrice,
  currency,
} = schema;

type DB = NodePgDatabase<typeof schema>;
type Tx = Parameters<Parameters<DB["transaction"]>[0]>[0];

interface MagentoConfig {
  baseUrl: string;
  token: string;
}

interface MagentoProduct {
  id: number;
  sku: string;
  name: string;
  type_id: string;
  status: number;
  attribute_set_id: number;
  price?: number;
  weight?: number;
  custom_attributes?: Array<{ attribute_code: string; value: string | number | boolean | object }>;
  extension_attributes?: {
    configurable_product_links?: number[];
    configurable_product_options?: Array<{
      id: number;
      attribute_id: string;
      label: string;
      values: Array<{ value_index: number }>;
    }>;
    category_links?: Array<{ category_id: string; position: number }>;
  };
  media_gallery_entries?: Array<{
    id: number;
    media_type: string;
    label: string | null;
    position: number;
    disabled: boolean;
    file: string;
    types: string[];
  }>;
}

interface MagentoCategory {
  id: number;
  parent_id: number;
  name: string;
  is_active: boolean;
  level: number;
  children_data?: MagentoCategory[];
  path?: string;
}

interface MagentoAttribute {
  attribute_id: string;
  attribute_code: string;
  frontend_label: string;
  frontend_input: string;
  options?: Array<{ label: string; value: string }>;
}

interface MagentoStoreConfig {
  id: number;
  code: string;
  base_currency_code: string;
}

interface ImportCounters {
  importedProducts: number;
  reconciledProducts: number;
  errorProducts: number;
  importedVariants: number;
  importedImages: number;
  importedAttrs: number;
  importedCategories: number;
}

interface ImportMaps {
  colourMap: Map<string, number>;
  sizeMap: Map<number, number>;
  genderMap: Map<string, number>;
  brandMap: Map<string, number>;
  productTypeMap: Map<string, number>;
  conditionMap: Map<string, number>;
  taxClassMap: Map<string, number>;
  categoryIdMap: Map<number, number>;
  attributeDefMap: Map<string, number>;
  attrDataTypeMap: Map<string, string | null>;
  currencyIdMap: Map<string, number>;
  magentoAttrOptionsMap: Map<string, Map<string, string>>;
  baseUrl: string;
}

class MagentoClient {
  private baseUrl: string;
  private token: string;
  private requestDelay: number;
  private lastRequestTime = 0;

  constructor(config: MagentoConfig) {
    this.baseUrl = config.baseUrl.replace(/\/$/, "");
    this.token = config.token;
    this.requestDelay = parseInt(process.env.MAGENTO_RATE_LIMIT_MS || "200", 10);
  }

  private async throttle(): Promise<void> {
    const now = Date.now();
    const elapsed = now - this.lastRequestTime;
    if (elapsed < this.requestDelay) {
      await new Promise((resolve) => setTimeout(resolve, this.requestDelay - elapsed));
    }
    this.lastRequestTime = Date.now();
  }

  async get<T>(endpoint: string, params?: Record<string, string>): Promise<T> {
    await this.throttle();
    const url = new URL(`${this.baseUrl}/rest/V1/${endpoint}`);
    if (params) {
      for (const [key, value] of Object.entries(params)) {
        url.searchParams.set(key, value);
      }
    }

    const response = await fetch(url.toString(), {
      headers: {
        Authorization: `Bearer ${this.token}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`Magento API error ${response.status} for ${endpoint}: ${text}`);
    }

    return response.json() as Promise<T>;
  }

  async getAllProducts(pageSize = 100): Promise<MagentoProduct[]> {
    const allProducts: MagentoProduct[] = [];
    let currentPage = 1;
    let totalCount = Infinity;

    while (allProducts.length < totalCount) {
      const params: Record<string, string> = {
        "searchCriteria[pageSize]": String(pageSize),
        "searchCriteria[currentPage]": String(currentPage),
      };

      const result = await this.get<{
        items: MagentoProduct[];
        total_count: number;
      }>("products", params);

      totalCount = result.total_count;
      allProducts.push(...result.items);
      console.log(`  Fetched page ${currentPage}, ${allProducts.length}/${totalCount} products`);
      currentPage++;

      if (result.items.length === 0) break;
    }

    return allProducts;
  }

  async getProductById(id: number): Promise<MagentoProduct | null> {
    try {
      const params: Record<string, string> = {
        "searchCriteria[filterGroups][0][filters][0][field]": "entity_id",
        "searchCriteria[filterGroups][0][filters][0][value]": String(id),
        "searchCriteria[filterGroups][0][filters][0][conditionType]": "eq",
      };
      const result = await this.get<{ items: MagentoProduct[] }>("products", params);
      return result.items[0] ?? null;
    } catch {
      return null;
    }
  }

  async getCategories(): Promise<MagentoCategory> {
    return this.get<MagentoCategory>("categories");
  }

  async getProductAttributes(): Promise<MagentoAttribute[]> {
    const allAttrs: MagentoAttribute[] = [];
    let currentPage = 1;
    let totalCount = Infinity;

    while (allAttrs.length < totalCount) {
      const params: Record<string, string> = {
        "searchCriteria[pageSize]": "100",
        "searchCriteria[currentPage]": String(currentPage),
      };

      const result = await this.get<{
        items: MagentoAttribute[];
        total_count: number;
      }>("products/attributes", params);

      totalCount = result.total_count;
      allAttrs.push(...result.items);
      currentPage++;
      if (result.items.length === 0) break;
    }

    return allAttrs;
  }

  async getAttributeOptions(attributeCode: string): Promise<Array<{ label: string; value: string }>> {
    try {
      return await this.get<Array<{ label: string; value: string }>>(
        `products/attributes/${attributeCode}/options`
      );
    } catch {
      return [];
    }
  }

  async getStoreConfigs(): Promise<MagentoStoreConfig[]> {
    try {
      return await this.get<MagentoStoreConfig[]>("store/storeConfigs");
    } catch {
      return [];
    }
  }

  async getProductForStoreView(sku: string, storeCode: string): Promise<MagentoProduct | null> {
    try {
      await this.throttle();
      const url = new URL(`${this.baseUrl}/rest/${storeCode}/V1/products/${encodeURIComponent(sku)}`);
      const response = await fetch(url.toString(), {
        headers: {
          Authorization: `Bearer ${this.token}`,
          "Content-Type": "application/json",
        },
      });
      if (!response.ok) return null;
      return response.json() as Promise<MagentoProduct>;
    } catch {
      return null;
    }
  }
}

function getCustomAttr(prod: MagentoProduct, code: string): string | number | boolean | null {
  const val = prod.custom_attributes?.find((a) => a.attribute_code === code)?.value ?? null;
  if (val === null || typeof val === "object") return null;
  return val;
}

function getCustomAttrRaw(prod: MagentoProduct, code: string): string | number | boolean | object | null {
  return prod.custom_attributes?.find((a) => a.attribute_code === code)?.value ?? null;
}

function toNumber(val: unknown): number | null {
  if (val === null || val === undefined || val === "") return null;
  const n = Number(val);
  return isNaN(n) ? null : n;
}

function normalizeAttrCode(code: string): string {
  return code.replace(/[^a-z0-9_]/gi, "_").toLowerCase();
}

function mapDataType(frontendInput: string): string {
  switch (frontendInput) {
    case "text":
    case "textarea":
    case "select":
    case "multiselect":
      return "text";
    case "price":
    case "weight":
      return "number";
    case "boolean":
      return "boolean";
    case "date":
      return "text";
    default:
      return "text";
  }
}

const KNOWN_SYSTEM_ATTRS = new Set([
  "name", "sku", "price", "special_price", "weight", "status", "visibility",
  "tax_class_id", "description", "short_description", "meta_title",
  "meta_keyword", "meta_description", "image", "small_image", "thumbnail",
  "swatch_image", "media_gallery", "url_key", "url_path", "category_ids",
  "color", "size", "gender", "manufacturer", "country_of_manufacture",
  "quantity_and_stock_status", "cost", "msrp", "news_from_date",
  "news_to_date", "special_from_date", "special_to_date",
  "options_container", "required_options", "has_options",
  "created_at", "updated_at", "condition",
]);

function coerceAttributeValue(
  value: unknown,
  dataType: string | null
): { valueText: string | null; valueNum: string | null; valueBool: boolean | null; valueJson: unknown } {
  if (typeof value === "object" && value !== null) {
    return { valueText: null, valueNum: null, valueBool: null, valueJson: value };
  }
  if (typeof value === "boolean") {
    return { valueText: null, valueNum: null, valueBool: value, valueJson: null };
  }
  const strVal = String(value);
  if (dataType === "number") {
    const num = toNumber(value);
    if (num !== null) {
      return { valueText: null, valueNum: String(num), valueBool: null, valueJson: null };
    }
  }
  if (dataType === "boolean") {
    const boolVal = strVal === "1" || strVal === "true";
    return { valueText: null, valueNum: null, valueBool: boolVal, valueJson: null };
  }
  const numericCheck = toNumber(value);
  if (numericCheck !== null && typeof value === "number") {
    return { valueText: null, valueNum: String(numericCheck), valueBool: null, valueJson: null };
  }
  return { valueText: strVal, valueNum: null, valueBool: null, valueJson: null };
}

async function importProductCategories(
  tx: Tx,
  mProd: MagentoProduct,
  productId: number,
  categoryIdMap: Map<number, number>
): Promise<void> {
  const categoryLinks = mProd.extension_attributes?.category_links ?? [];
  for (const link of categoryLinks) {
    const magentoCatId = parseInt(link.category_id, 10);
    const pimCatId = categoryIdMap.get(magentoCatId);
    if (pimCatId) {
      await tx
        .insert(productCategory)
        .values({ productId, categoryId: pimCatId })
        .onConflictDoNothing();
    }
  }
}

async function importProductImages(
  tx: Tx,
  mProd: MagentoProduct,
  productId: number,
  baseUrl: string
): Promise<number> {
  const entries = mProd.media_gallery_entries ?? [];
  let count = 0;
  for (const entry of entries) {
    if (entry.disabled) continue;

    const url = entry.file.startsWith("http")
      ? entry.file
      : `${baseUrl}/pub/media/catalog/product${entry.file}`;

    const roles = entry.types ?? [];
    const role = roles.includes("image")
      ? "base"
      : roles.includes("small_image")
        ? "small"
        : roles.includes("thumbnail")
          ? "thumbnail"
          : roles.includes("swatch_image")
            ? "swatch"
            : "additional";

    const [existing] = await tx
      .select({ imageId: imageAsset.imageId })
      .from(imageAsset)
      .where(and(eq(imageAsset.productId, productId), eq(imageAsset.url, url)))
      .limit(1);

    if (!existing) {
      await tx.insert(imageAsset).values({
        productId,
        url,
        role,
        label: entry.label || null,
        sortOrder: entry.position ?? 1,
      });
      count++;
    }
  }
  return count;
}

async function importProductLevelAttributes(
  tx: Tx,
  mProd: MagentoProduct,
  productId: number,
  attributeDefMap: Map<string, number>,
  attrDataTypeMap: Map<string, string | null>,
  magentoAttrOptionsMap: Map<string, Map<string, string>>
): Promise<void> {
  const customAttrs = mProd.custom_attributes ?? [];
  for (const attr of customAttrs) {
    if (KNOWN_SYSTEM_ATTRS.has(attr.attribute_code)) continue;

    const code = normalizeAttrCode(attr.attribute_code);
    const attrId = attributeDefMap.get(code);
    if (!attrId) continue;

    let value: unknown = attr.value;
    if (value === null || value === undefined || value === "") continue;

    const optionsMap = magentoAttrOptionsMap.get(attr.attribute_code);
    if (optionsMap && typeof value === "string") {
      const resolved = optionsMap.get(value);
      if (resolved) value = resolved;
    }

    const dataType = attrDataTypeMap.get(code) ?? null;
    const coerced = coerceAttributeValue(value, dataType);

    await tx
      .insert(productAttributeVal)
      .values({
        productId,
        attributeId: attrId,
        valueText: coerced.valueText,
        valueNum: coerced.valueNum,
        valueBool: coerced.valueBool,
        valueJson: coerced.valueJson,
      })
      .onConflictDoUpdate({
        target: [productAttributeVal.productId, productAttributeVal.attributeId],
        set: {
          valueText: coerced.valueText,
          valueNum: coerced.valueNum,
          valueBool: coerced.valueBool,
          valueJson: coerced.valueJson,
        },
      });
  }
}

async function importVariantLevelAttributes(
  tx: Tx,
  mProd: MagentoProduct,
  variantId: number,
  attributeDefMap: Map<string, number>,
  attrDataTypeMap: Map<string, string | null>,
  magentoAttrOptionsMap: Map<string, Map<string, string>>
): Promise<void> {
  const customAttrs = mProd.custom_attributes ?? [];
  for (const attr of customAttrs) {
    if (KNOWN_SYSTEM_ATTRS.has(attr.attribute_code)) continue;

    const code = normalizeAttrCode(attr.attribute_code);
    const attrId = attributeDefMap.get(code);
    if (!attrId) continue;

    let value: unknown = attr.value;
    if (value === null || value === undefined || value === "") continue;

    const optionsMap = magentoAttrOptionsMap.get(attr.attribute_code);
    if (optionsMap && typeof value === "string") {
      const resolved = optionsMap.get(value);
      if (resolved) value = resolved;
    }

    const dataType = attrDataTypeMap.get(code) ?? null;
    const coerced = coerceAttributeValue(value, dataType);

    await tx
      .insert(variantAttributeVal)
      .values({
        productVariantId: variantId,
        attributeId: attrId,
        valueText: coerced.valueText,
        valueNum: coerced.valueNum,
        valueBool: coerced.valueBool,
        valueJson: coerced.valueJson,
      })
      .onConflictDoUpdate({
        target: [variantAttributeVal.productVariantId, variantAttributeVal.attributeId],
        set: {
          valueText: coerced.valueText,
          valueNum: coerced.valueNum,
          valueBool: coerced.valueBool,
          valueJson: coerced.valueJson,
        },
      });
  }
}

async function importVariantPricing(
  tx: Tx,
  productVariantId: number,
  mProd: MagentoProduct,
  currencyId: number
): Promise<void> {
  const retailPrice = mProd.price != null ? String(mProd.price) : null;
  const specialPrice = getCustomAttr(mProd, "special_price");
  const costPrice = getCustomAttr(mProd, "cost");

  const [existing] = await tx
    .select({ variantPriceId: variantPrice.variantPriceId })
    .from(variantPrice)
    .where(
      and(
        eq(variantPrice.productVariantId, productVariantId),
        eq(variantPrice.currencyId, currencyId)
      )
    )
    .limit(1);

  if (existing) {
    await tx
      .update(variantPrice)
      .set({
        retailPrice,
        specialRetailPrice: specialPrice != null ? String(specialPrice) : null,
        costPrice: costPrice != null ? String(costPrice) : null,
      })
      .where(eq(variantPrice.variantPriceId, existing.variantPriceId));
  } else {
    await tx
      .insert(variantPrice)
      .values({
        productVariantId,
        currencyId,
        retailPrice,
        specialRetailPrice: specialPrice != null ? String(specialPrice) : null,
        costPrice: costPrice != null ? String(costPrice) : null,
      });
  }
}

async function importMultiCurrencyPricing(
  tx: Tx,
  productVariantId: number,
  mProd: MagentoProduct,
  client: MagentoClient,
  storeConfigs: MagentoStoreConfig[],
  currencyIdMap: Map<string, number>
): Promise<void> {
  const processedCurrencies = new Set<number>();

  for (const store of storeConfigs) {
    const cId = currencyIdMap.get(store.base_currency_code);
    if (!cId || processedCurrencies.has(cId)) continue;

    const storeProduct = await client.getProductForStoreView(mProd.sku, store.code);
    if (!storeProduct) continue;

    processedCurrencies.add(cId);
    await importVariantPricing(tx, productVariantId, storeProduct, cId);
  }

  if (processedCurrencies.size === 0) {
    const firstCurrencyId = currencyIdMap.values().next().value;
    if (firstCurrencyId) {
      await importVariantPricing(tx, productVariantId, mProd, firstCurrencyId);
    }
  }
}

function extractDimensions(mProd: MagentoProduct): {
  widthCm: number | null;
  lengthCm: number | null;
  depth: string | null;
} {
  const width = toNumber(getCustomAttr(mProd, "width") ?? getCustomAttr(mProd, "ts_dimensions_width"));
  const length = toNumber(getCustomAttr(mProd, "length") ?? getCustomAttr(mProd, "ts_dimensions_length") ?? getCustomAttr(mProd, "height"));
  const depthVal = toNumber(getCustomAttr(mProd, "depth") ?? getCustomAttr(mProd, "ts_dimensions_depth"));

  return {
    widthCm: width !== null ? Math.round(width) : null,
    lengthCm: length !== null ? Math.round(length) : null,
    depth: depthVal !== null ? String(depthVal) : null,
  };
}

async function importConfigurableProduct(
  db: DB,
  mProd: MagentoProduct,
  allMagentoProducts: MagentoProduct[],
  client: MagentoClient,
  storeConfigs: MagentoStoreConfig[],
  maps: ImportMaps,
  counters: ImportCounters
): Promise<"imported" | "reconciled" | "error"> {
  const {
    colourMap, sizeMap, genderMap, brandMap, productTypeMap, taxClassMap,
    conditionMap, categoryIdMap, attributeDefMap, attrDataTypeMap,
    currencyIdMap, magentoAttrOptionsMap, baseUrl,
  } = maps;

  try {
    await db.transaction(async (tx: Tx) => {
      const [existingProduct] = await tx
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, mProd.sku))
        .limit(1);

      let pId: number;
      let isNew = false;

      if (existingProduct) {
        pId = existingProduct.productId;
      } else {
        isNew = true;
        const colourVal = getCustomAttr(mProd, "color");
        const genderVal = getCustomAttr(mProd, "gender");
        const manufacturerVal = getCustomAttr(mProd, "manufacturer");
        const countryVal = getCustomAttr(mProd, "country_of_manufacture");
        const descriptionVal = getCustomAttr(mProd, "description") || getCustomAttr(mProd, "short_description") || mProd.name;

        const colourId = colourVal ? (colourMap.get(String(colourVal)) ?? null) : null;
        const gId = genderVal ? (genderMap.get(String(genderVal)) ?? null) : null;
        const bId = manufacturerVal ? (brandMap.get(String(manufacturerVal)) ?? null) : null;
        const ptId = productTypeMap.get("configurable") ?? null;
        const now = new Date();

        const [createdProduct] = await tx
          .insert(product)
          .values({
            productSku: mProd.sku,
            productDescription: typeof descriptionVal === "string" ? descriptionVal : String(descriptionVal),
            productColourId: colourId,
            genderId: gId,
            brandId: bId,
            productTypeId: ptId,
            countryOfManufacture: typeof countryVal === "string" ? countryVal : null,
            composition: (() => { const v = getCustomAttr(mProd, "composition"); return typeof v === "string" ? v : null; })(),
            enabled: mProd.status === 1,
            sync: false,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ productId: product.productId });

        pId = createdProduct.productId;
      }

      await importProductCategories(tx, mProd, pId, categoryIdMap);
      counters.importedImages += await importProductImages(tx, mProd, pId, baseUrl);
      await importProductLevelAttributes(tx, mProd, pId, attributeDefMap, attrDataTypeMap, magentoAttrOptionsMap);

      const childLinks = mProd.extension_attributes?.configurable_product_links ?? [];
      for (const childMagentoId of childLinks) {
        const childProduct = allMagentoProducts.find((p) => p.id === childMagentoId);
        let childData: MagentoProduct | null = childProduct ?? null;
        if (!childData) {
          childData = await client.getProductById(childMagentoId);
        }
        if (!childData) {
          console.warn(`    WARNING: Child product ${childMagentoId} not found for configurable ${mProd.sku}`);
          continue;
        }

        const [existingVariant] = await tx
          .select({ productVariantId: productVariant.productVariantId })
          .from(productVariant)
          .where(eq(productVariant.productVariantSku, childData.sku))
          .limit(1);

        if (existingVariant) {
          const [variantRow] = await tx
            .select({ currentProductId: productVariant.productId })
            .from(productVariant)
            .where(eq(productVariant.productVariantId, existingVariant.productVariantId))
            .limit(1);
          if (variantRow && variantRow.currentProductId !== pId) {
            await tx
              .update(productVariant)
              .set({ productId: pId, updatedAt: new Date() })
              .where(eq(productVariant.productVariantId, existingVariant.productVariantId));
          }
          await importVariantLevelAttributes(tx, childData, existingVariant.productVariantId, attributeDefMap, attrDataTypeMap, magentoAttrOptionsMap);
          const hasPricing = childData.price != null || getCustomAttr(childData, "special_price") != null;
          if (hasPricing && storeConfigs.length > 0) {
            await importMultiCurrencyPricing(tx, existingVariant.productVariantId, childData, client, storeConfigs, currencyIdMap);
          } else if (hasPricing) {
            const firstCurrencyId = currencyIdMap.values().next().value;
            if (firstCurrencyId) {
              await importVariantPricing(tx, existingVariant.productVariantId, childData, firstCurrencyId);
            }
          }
          continue;
        }

        const childSizeVal = getCustomAttr(childData, "size");
        const childTaxVal = getCustomAttr(childData, "tax_class_id");
        const childConditionVal = getCustomAttr(childData, "condition");
        const childBarcode = getCustomAttr(childData, "barcode") || getCustomAttr(childData, "ean") || null;

        let sizeId: number | null = null;
        if (childSizeVal !== null) {
          const sizeNum = toNumber(childSizeVal);
          if (sizeNum !== null) sizeId = sizeMap.get(sizeNum) ?? null;
        }

        let taxClassId: number | null = null;
        if (childTaxVal !== null) taxClassId = taxClassMap.get(String(childTaxVal)) ?? null;

        let conditionId: number | null = null;
        if (childConditionVal !== null) {
          conditionId = conditionMap.get(String(childConditionVal)) ?? conditionMap.get(String(childConditionVal).toLowerCase()) ?? null;
        }

        const dims = extractDimensions(childData);
        const now = new Date();
        const [createdVariant] = await tx
          .insert(productVariant)
          .values({
            productId: pId,
            productVariantSku: childData.sku,
            sizeId,
            taxClassId,
            conditionId,
            barcode: typeof childBarcode === "string" ? childBarcode : null,
            weight: childData.weight ? String(childData.weight) : null,
            costPrice: (() => { const v = getCustomAttr(childData!, "cost"); return v != null ? String(v) : null; })(),
            magentoProductId: childData.id,
            widthCm: dims.widthCm,
            lengthCm: dims.lengthCm,
            depth: dims.depth,
            enabled: childData.status === 1,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ productVariantId: productVariant.productVariantId });

        counters.importedVariants++;

        await importVariantLevelAttributes(tx, childData, createdVariant.productVariantId, attributeDefMap, attrDataTypeMap, magentoAttrOptionsMap);

        const hasPricing = childData.price != null || getCustomAttr(childData, "special_price") != null;
        if (hasPricing && storeConfigs.length > 0) {
          await importMultiCurrencyPricing(tx, createdVariant.productVariantId, childData, client, storeConfigs, currencyIdMap);
        } else if (hasPricing) {
          const firstCurrencyId = currencyIdMap.values().next().value;
          if (firstCurrencyId) {
            await importVariantPricing(tx, createdVariant.productVariantId, childData, firstCurrencyId);
          }
        }
      }

      if (isNew) {
        counters.importedProducts++;
      } else {
        counters.reconciledProducts++;
      }
    });

    return "imported";
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  ERROR importing configurable ${mProd.sku}: ${msg}`);
    counters.errorProducts++;
    return "error";
  }
}

async function importSimpleProduct(
  db: DB,
  mProd: MagentoProduct,
  client: MagentoClient,
  storeConfigs: MagentoStoreConfig[],
  maps: ImportMaps,
  counters: ImportCounters
): Promise<"imported" | "reconciled" | "error"> {
  const {
    colourMap, sizeMap, genderMap, brandMap, productTypeMap, taxClassMap,
    conditionMap, categoryIdMap, attributeDefMap, attrDataTypeMap,
    currencyIdMap, magentoAttrOptionsMap, baseUrl,
  } = maps;

  try {
    await db.transaction(async (tx: Tx) => {
      const [existingProduct] = await tx
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, mProd.sku))
        .limit(1);

      let pId: number;
      let isNew = false;

      if (existingProduct) {
        pId = existingProduct.productId;
      } else {
        isNew = true;
        const colourVal = getCustomAttr(mProd, "color");
        const genderVal = getCustomAttr(mProd, "gender");
        const manufacturerVal = getCustomAttr(mProd, "manufacturer");
        const countryVal = getCustomAttr(mProd, "country_of_manufacture");
        const descriptionVal = getCustomAttr(mProd, "description") || getCustomAttr(mProd, "short_description") || mProd.name;

        const colourId = colourVal ? (colourMap.get(String(colourVal)) ?? null) : null;
        const gId = genderVal ? (genderMap.get(String(genderVal)) ?? null) : null;
        const bId = manufacturerVal ? (brandMap.get(String(manufacturerVal)) ?? null) : null;
        const ptId = productTypeMap.get("simple") ?? null;
        const now = new Date();

        const [createdProduct] = await tx
          .insert(product)
          .values({
            productSku: mProd.sku,
            productDescription: typeof descriptionVal === "string" ? descriptionVal : String(descriptionVal),
            productColourId: colourId,
            genderId: gId,
            brandId: bId,
            productTypeId: ptId,
            countryOfManufacture: typeof countryVal === "string" ? countryVal : null,
            composition: (() => { const v = getCustomAttr(mProd, "composition"); return typeof v === "string" ? v : null; })(),
            enabled: mProd.status === 1,
            sync: false,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ productId: product.productId });

        pId = createdProduct.productId;
      }

      const [existingVariant] = await tx
        .select({ productVariantId: productVariant.productVariantId })
        .from(productVariant)
        .where(eq(productVariant.productVariantSku, mProd.sku))
        .limit(1);

      let vId: number;

      if (existingVariant) {
        vId = existingVariant.productVariantId;
        const hasPricing = mProd.price != null || getCustomAttr(mProd, "special_price") != null;
        if (hasPricing && storeConfigs.length > 0) {
          await importMultiCurrencyPricing(tx, vId, mProd, client, storeConfigs, currencyIdMap);
        } else if (hasPricing) {
          const firstCurrencyId = currencyIdMap.values().next().value;
          if (firstCurrencyId) {
            await importVariantPricing(tx, vId, mProd, firstCurrencyId);
          }
        }
      } else {
        const sizeVal = getCustomAttr(mProd, "size");
        const taxVal = getCustomAttr(mProd, "tax_class_id");
        const conditionVal = getCustomAttr(mProd, "condition");
        const barcodeVal = getCustomAttr(mProd, "barcode") || getCustomAttr(mProd, "ean") || null;

        let sizeId: number | null = null;
        if (sizeVal !== null) {
          const sizeNum = toNumber(sizeVal);
          if (sizeNum !== null) sizeId = sizeMap.get(sizeNum) ?? null;
        }

        let taxClassId: number | null = null;
        if (taxVal !== null) taxClassId = taxClassMap.get(String(taxVal)) ?? null;

        let conditionId: number | null = null;
        if (conditionVal !== null) {
          conditionId = conditionMap.get(String(conditionVal)) ?? conditionMap.get(String(conditionVal).toLowerCase()) ?? null;
        }

        const dims = extractDimensions(mProd);
        const now = new Date();
        const [createdVariant] = await tx
          .insert(productVariant)
          .values({
            productId: pId,
            productVariantSku: mProd.sku,
            sizeId,
            taxClassId,
            conditionId,
            barcode: typeof barcodeVal === "string" ? barcodeVal : null,
            weight: mProd.weight ? String(mProd.weight) : null,
            costPrice: (() => { const v = getCustomAttr(mProd, "cost"); return v != null ? String(v) : null; })(),
            magentoProductId: mProd.id,
            widthCm: dims.widthCm,
            lengthCm: dims.lengthCm,
            depth: dims.depth,
            enabled: mProd.status === 1,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ productVariantId: productVariant.productVariantId });

        vId = createdVariant.productVariantId;
        counters.importedVariants++;

        const hasPricing = mProd.price != null || getCustomAttr(mProd, "special_price") != null;
        if (hasPricing && storeConfigs.length > 0) {
          await importMultiCurrencyPricing(tx, vId, mProd, client, storeConfigs, currencyIdMap);
        } else if (hasPricing) {
          const firstCurrencyId = currencyIdMap.values().next().value;
          if (firstCurrencyId) {
            await importVariantPricing(tx, vId, mProd, firstCurrencyId);
          }
        }
      }

      await importProductCategories(tx, mProd, pId, categoryIdMap);
      counters.importedImages += await importProductImages(tx, mProd, pId, baseUrl);
      await importProductLevelAttributes(tx, mProd, pId, attributeDefMap, attrDataTypeMap, magentoAttrOptionsMap);
      await importVariantLevelAttributes(tx, mProd, vId, attributeDefMap, attrDataTypeMap, magentoAttrOptionsMap);

      if (isNew) {
        counters.importedProducts++;
      } else {
        counters.reconciledProducts++;
      }
    });

    return "imported";
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  ERROR importing simple product ${mProd.sku}: ${msg}`);
    counters.errorProducts++;
    return "error";
  }
}

function promptUser(question: string): Promise<string> {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

async function main() {
  let baseUrl = process.env.MAGENTO_BASE_URL || "";
  let token = process.env.MAGENTO_API_TOKEN || "";

  if (!baseUrl) {
    baseUrl = await promptUser("Magento base URL (e.g. https://your-store.com): ");
  }
  if (!token) {
    token = await promptUser("Magento API token (admin integration access token): ");
  }

  if (!baseUrl || !token) {
    console.error("ERROR: Magento base URL and API token are required.");
    console.error("  You can also set MAGENTO_BASE_URL and MAGENTO_API_TOKEN environment variables.");
    console.error("  MAGENTO_RATE_LIMIT_MS (optional) - Delay between API calls in ms (default: 200)");
    process.exit(1);
  }

  const startTime = Date.now();
  console.log("=== Magento Product Data Import ===");
  console.log(`  Base URL: ${baseUrl}`);
  console.log(`  Started at: ${new Date().toISOString()}`);

  const db = await dbReady;
  const client = new MagentoClient({ baseUrl, token });

  const colourMap = new Map<string, number>();
  const sizeMap = new Map<number, number>();
  const genderMap = new Map<string, number>();
  const brandMap = new Map<string, number>();
  const productTypeMap = new Map<string, number>();
  const conditionMap = new Map<string, number>();
  const taxClassMap = new Map<string, number>();
  const categoryIdMap = new Map<number, number>();
  const attributeDefMap = new Map<string, number>();
  const attrDataTypeMap = new Map<string, string | null>();
  const currencyIdMap = new Map<string, number>();
  const magentoAttrOptionsMap = new Map<string, Map<string, string>>();

  const counters: ImportCounters = {
    importedProducts: 0,
    reconciledProducts: 0,
    errorProducts: 0,
    importedVariants: 0,
    importedImages: 0,
    importedAttrs: 0,
    importedCategories: 0,
  };

  console.log("\n--- Step 1: Loading existing PIM reference data ---");

  const existingBrands = await db.select().from(brands);
  for (const b of existingBrands) {
    if (b.brandName) brandMap.set(b.brandName.toLowerCase(), b.brandId);
  }
  console.log(`  Loaded ${existingBrands.length} existing brands`);

  const existingGenders = await db.select().from(gender);
  for (const g of existingGenders) {
    if (g.genderName) genderMap.set(g.genderName.toLowerCase(), g.genderId);
  }
  console.log(`  Loaded ${existingGenders.length} existing genders`);

  const existingProductTypes = await db.select().from(productType);
  for (const pt of existingProductTypes) {
    if (pt.productTypeName) productTypeMap.set(pt.productTypeName.toLowerCase(), pt.productTypeId);
  }
  console.log(`  Loaded ${existingProductTypes.length} existing product types`);

  const existingConditions = await db.select().from(condition);
  for (const c of existingConditions) {
    if (c.conditionName) {
      conditionMap.set(c.conditionName.toLowerCase(), c.conditionId);
      conditionMap.set(String(c.conditionId), c.conditionId);
    }
  }
  console.log(`  Loaded ${existingConditions.length} existing conditions`);

  const existingTaxClasses = await db.select().from(taxClass);
  for (const tc of existingTaxClasses) {
    if (tc.taxClassName) taxClassMap.set(tc.taxClassName.toLowerCase(), tc.taxClassId);
  }
  console.log(`  Loaded ${existingTaxClasses.length} existing tax classes`);

  const existingColours = await db.select().from(productColour);
  for (const c of existingColours) {
    if (c.magentoColourId) colourMap.set(c.magentoColourId, c.productColourId);
  }
  console.log(`  Loaded ${existingColours.length} existing colours`);

  const existingSizes = await db.select().from(productSizes);
  for (const s of existingSizes) {
    if (s.magentoSizeId) sizeMap.set(s.magentoSizeId, s.sizeId);
  }
  console.log(`  Loaded ${existingSizes.length} existing sizes`);

  const existingCategories = await db.select().from(category);
  console.log(`  Loaded ${existingCategories.length} existing categories`);

  const existingAttrDefs = await db.select().from(attributeDef);
  for (const ad of existingAttrDefs) {
    attributeDefMap.set(ad.code, ad.attributeId);
    attrDataTypeMap.set(ad.code, ad.dataType);
  }
  console.log(`  Loaded ${existingAttrDefs.length} existing attribute definitions`);

  const existingCurrencies = await db.select().from(currency);
  for (const c of existingCurrencies) {
    currencyIdMap.set(c.code, c.currencyId);
  }
  console.log(`  Loaded ${existingCurrencies.length} existing currencies`);

  console.log("\n--- Step 2: Fetching Magento store configurations ---");
  let storeConfigs: MagentoStoreConfig[] = [];
  try {
    storeConfigs = await client.getStoreConfigs();
    const uniqueCurrencies = new Set(storeConfigs.map((s) => s.base_currency_code));
    console.log(`  Found ${storeConfigs.length} store views with ${uniqueCurrencies.size} unique currencies: ${[...uniqueCurrencies].join(", ")}`);

    for (const currencyCode of uniqueCurrencies) {
      if (!currencyIdMap.has(currencyCode)) {
        const [existing] = await db
          .select()
          .from(currency)
          .where(eq(currency.code, currencyCode))
          .limit(1);
        if (existing) {
          currencyIdMap.set(currencyCode, existing.currencyId);
        } else {
          const [created] = await db
            .insert(currency)
            .values({
              code: currencyCode,
              name: currencyCode,
              enabled: true,
            })
            .returning();
          currencyIdMap.set(currencyCode, created.currencyId);
          console.log(`  Created missing currency record: ${currencyCode}`);
        }
      }
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.warn(`  WARNING: Could not fetch store configs, using default currency: ${msg}`);
  }

  console.log("\n--- Step 3: Importing Magento categories ---");
  try {
    const rootCategory = await client.getCategories();
    const flattenCategories = (
      cat: MagentoCategory,
      parentPath: string
    ): Array<{ id: number; name: string; pathKey: string; parentPath: string | null }> => {
      const result: Array<{ id: number; name: string; pathKey: string; parentPath: string | null }> = [];
      if (cat.level > 0 && cat.name) {
        const pathKey = parentPath ? `${parentPath}/${cat.name}` : cat.name;
        result.push({ id: cat.id, name: cat.name, pathKey, parentPath: parentPath || null });
      }
      if (cat.children_data) {
        for (const child of cat.children_data) {
          const currentPath = cat.level > 0 && cat.name
            ? (parentPath ? `${parentPath}/${cat.name}` : cat.name)
            : parentPath;
          result.push(...flattenCategories(child, currentPath));
        }
      }
      return result;
    };

    const flatCats = flattenCategories(rootCategory, "");
    console.log(`  Found ${flatCats.length} Magento categories`);

    for (const fc of flatCats) {
      const [existing] = await db
        .select()
        .from(category)
        .where(eq(category.pathKey, fc.pathKey))
        .limit(1);

      if (existing) {
        categoryIdMap.set(fc.id, existing.categoryId);
      } else {
        let parentId: number | null = null;
        if (fc.parentPath) {
          const [parent] = await db
            .select()
            .from(category)
            .where(eq(category.pathKey, fc.parentPath))
            .limit(1);
          if (parent) parentId = parent.categoryId;
        }

        const [created] = await db
          .insert(category)
          .values({ name: fc.name, pathKey: fc.pathKey, parentId })
          .returning();
        categoryIdMap.set(fc.id, created.categoryId);
        counters.importedCategories++;
      }
    }
    console.log(`  Imported ${counters.importedCategories} new categories`);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  ERROR importing categories: ${msg}`);
  }

  console.log("\n--- Step 4: Importing Magento attributes and reference data ---");
  try {
    const magentoAttrs = await client.getProductAttributes();
    console.log(`  Found ${magentoAttrs.length} Magento product attributes`);

    for (const attr of magentoAttrs) {
      const code = attr.attribute_code;

      if (attr.options && attr.options.length > 0) {
        const optMap = new Map<string, string>();
        for (const opt of attr.options) {
          if (opt.value && opt.label) {
            optMap.set(opt.value, opt.label);
          }
        }
        if (optMap.size > 0) {
          magentoAttrOptionsMap.set(code, optMap);
        }
      }

      if (code === "color" || code === "colour") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          if (!colourMap.has(opt.value)) {
            const [existing] = await db
              .select()
              .from(productColour)
              .where(eq(productColour.magentoColourId, opt.value))
              .limit(1);
            if (existing) {
              colourMap.set(opt.value, existing.productColourId);
            } else {
              const [created] = await db
                .insert(productColour)
                .values({ magentoColourId: opt.value, magentoColourName: opt.label })
                .returning();
              colourMap.set(opt.value, created.productColourId);
            }
          }
        }
        console.log(`  Imported/mapped ${colourMap.size} colours`);
      }

      if (code === "size") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          const magentoSizeId = toNumber(opt.value);
          if (magentoSizeId !== null && !sizeMap.has(magentoSizeId)) {
            const [existing] = await db
              .select()
              .from(productSizes)
              .where(eq(productSizes.magentoSizeId, magentoSizeId))
              .limit(1);
            if (existing) {
              sizeMap.set(magentoSizeId, existing.sizeId);
            } else {
              const [created] = await db
                .insert(productSizes)
                .values({
                  magentoSizeId,
                  magentoSizeShortName: opt.label,
                  magentoSizeLongName: opt.label,
                })
                .returning();
              sizeMap.set(magentoSizeId, created.sizeId);
            }
          }
        }
        console.log(`  Imported/mapped ${sizeMap.size} sizes`);
      }

      if (code === "gender") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          const key = opt.label.toLowerCase();
          if (!genderMap.has(key)) {
            const [existing] = await db
              .select()
              .from(gender)
              .where(sql`lower(${gender.genderName}) = ${key}`)
              .limit(1);
            if (existing) {
              genderMap.set(key, existing.genderId);
            } else {
              const [created] = await db
                .insert(gender)
                .values({ genderName: opt.label })
                .returning();
              genderMap.set(key, created.genderId);
            }
          }
          genderMap.set(opt.value, genderMap.get(key)!);
        }
        console.log(`  Imported/mapped genders`);
      }

      if (code === "manufacturer") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          const key = opt.label.toLowerCase();
          if (!brandMap.has(key)) {
            const [existing] = await db
              .select()
              .from(brands)
              .where(sql`lower(${brands.brandName}) = ${key}`)
              .limit(1);
            if (existing) {
              brandMap.set(key, existing.brandId);
            } else {
              const [maxRow] = await db
                .select({ maxId: sql<number>`COALESCE(MAX(${brands.brandId}), 0)::int` })
                .from(brands);
              const newId = (maxRow?.maxId ?? 0) + 1;
              const [created] = await db
                .insert(brands)
                .values({ brandId: newId, brandName: opt.label })
                .returning();
              brandMap.set(key, created.brandId);
            }
          }
          brandMap.set(opt.value, brandMap.get(key)!);
        }
        console.log(`  Imported/mapped brands`);
      }

      if (code === "tax_class_id") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          const key = opt.label.toLowerCase();
          if (!taxClassMap.has(key)) {
            const [existing] = await db
              .select()
              .from(taxClass)
              .where(sql`lower(${taxClass.taxClassName}) = ${key}`)
              .limit(1);
            if (existing) {
              taxClassMap.set(key, existing.taxClassId);
            } else {
              const [created] = await db
                .insert(taxClass)
                .values({ taxClassName: opt.label })
                .returning();
              taxClassMap.set(key, created.taxClassId);
            }
          }
          taxClassMap.set(opt.value, taxClassMap.get(key)!);
        }
        console.log(`  Imported/mapped tax classes`);
      }

      if (code === "condition") {
        const options = await client.getAttributeOptions(code);
        for (const opt of options) {
          if (!opt.value || opt.value === "" || opt.label === " ") continue;
          const key = opt.label.toLowerCase();
          if (!conditionMap.has(key)) {
            const [existing] = await db
              .select()
              .from(condition)
              .where(sql`lower(${condition.conditionName}) = ${key}`)
              .limit(1);
            if (existing) {
              conditionMap.set(key, existing.conditionId);
            } else {
              const [maxRow] = await db
                .select({ maxId: sql<number>`COALESCE(MAX(${condition.conditionId}), 0)::int` })
                .from(condition);
              const newId = (maxRow?.maxId ?? 0) + 1;
              const [created] = await db
                .insert(condition)
                .values({ conditionId: newId, conditionName: opt.label })
                .returning();
              conditionMap.set(key, created.conditionId);
            }
          }
          conditionMap.set(opt.value, conditionMap.get(key)!);
        }
        console.log(`  Imported/mapped conditions`);
      }

      if (!KNOWN_SYSTEM_ATTRS.has(code)) {
        const normalizedCode = normalizeAttrCode(code);
        if (!attributeDefMap.has(normalizedCode)) {
          try {
            const dataType = mapDataType(attr.frontend_input);
            const [created] = await db
              .insert(attributeDef)
              .values({
                code: normalizedCode,
                label: attr.frontend_label || normalizedCode,
                dataType,
                scope: "Parent",
                magentoSync: false,
                magentoScope: "global",
              })
              .returning();
            attributeDefMap.set(normalizedCode, created.attributeId);
            attrDataTypeMap.set(normalizedCode, dataType);
            counters.importedAttrs++;
          } catch (attrErr: unknown) {
            const msg = attrErr instanceof Error ? attrErr.message : String(attrErr);
            console.warn(`    WARNING: Could not create attribute '${normalizedCode}': ${msg}`);
            const [existing] = await db
              .select()
              .from(attributeDef)
              .where(eq(attributeDef.code, normalizedCode))
              .limit(1);
            if (existing) {
              attributeDefMap.set(normalizedCode, existing.attributeId);
              attrDataTypeMap.set(normalizedCode, existing.dataType);
            }
          }
        }
      }
    }

    if (!productTypeMap.has("configurable")) {
      const [maxRow] = await db
        .select({ maxId: sql<number>`COALESCE(MAX(${productType.productTypeId}), 0)::int` })
        .from(productType);
      const newId = (maxRow?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(productType)
        .values({ productTypeId: newId, productTypeName: "Configurable" })
        .returning();
      productTypeMap.set("configurable", created.productTypeId);
    }
    if (!productTypeMap.has("simple")) {
      const [maxRow] = await db
        .select({ maxId: sql<number>`COALESCE(MAX(${productType.productTypeId}), 0)::int` })
        .from(productType);
      const newId = (maxRow?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(productType)
        .values({ productTypeId: newId, productTypeName: "Simple" })
        .returning();
      productTypeMap.set("simple", created.productTypeId);
    }

    console.log(`  Imported ${counters.importedAttrs} new attribute definitions`);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  ERROR importing attributes: ${msg}`);
  }

  console.log("\n--- Step 5: Fetching all Magento products ---");
  let magentoProducts: MagentoProduct[] = [];
  try {
    magentoProducts = await client.getAllProducts();
    console.log(`  Total products fetched: ${magentoProducts.length}`);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`  FATAL ERROR fetching products: ${msg}`);
    process.exit(1);
  }

  const configurables = magentoProducts.filter((p) => p.type_id === "configurable");
  const simples = magentoProducts.filter((p) => p.type_id === "simple");
  const childIds = new Set<number>();
  for (const cfg of configurables) {
    const links = cfg.extension_attributes?.configurable_product_links ?? [];
    for (const linkId of links) {
      childIds.add(linkId);
    }
  }
  const standaloneSimples = simples.filter((p) => !childIds.has(p.id));

  console.log(`  Configurable products: ${configurables.length}`);
  console.log(`  Simple products (children): ${childIds.size}`);
  console.log(`  Standalone simple products: ${standaloneSimples.length}`);

  const sharedMaps: ImportMaps = {
    colourMap, sizeMap, genderMap, brandMap, productTypeMap, taxClassMap,
    conditionMap, categoryIdMap, attributeDefMap, attrDataTypeMap,
    currencyIdMap, magentoAttrOptionsMap, baseUrl,
  };

  console.log("\n--- Step 6: Importing configurable products ---");
  for (let i = 0; i < configurables.length; i++) {
    await importConfigurableProduct(db, configurables[i], magentoProducts, client, storeConfigs, sharedMaps, counters);

    if ((i + 1) % 10 === 0) {
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`  Progress: ${i + 1}/${configurables.length} configurables (${elapsed}s elapsed)`);
    }
  }

  console.log("\n--- Step 7: Importing standalone simple products ---");
  for (let i = 0; i < standaloneSimples.length; i++) {
    await importSimpleProduct(db, standaloneSimples[i], client, storeConfigs, sharedMaps, counters);

    if ((i + 1) % 10 === 0) {
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`  Progress: ${i + 1}/${standaloneSimples.length} standalone simples (${elapsed}s elapsed)`);
    }
  }

  const totalElapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  console.log("\n=== Import Complete ===");
  console.log(`  Products imported: ${counters.importedProducts}`);
  console.log(`  Products reconciled (existing, associations refreshed): ${counters.reconciledProducts}`);
  console.log(`  Products with errors: ${counters.errorProducts}`);
  console.log(`  Variants imported: ${counters.importedVariants}`);
  console.log(`  Categories imported: ${counters.importedCategories}`);
  console.log(`  Attribute definitions imported: ${counters.importedAttrs}`);
  console.log(`  Images imported: ${counters.importedImages}`);
  console.log(`  Total time: ${totalElapsed}s`);

  await pool.end();
  process.exit(0);
}

main().catch((err) => {
  console.error("Import failed:", err);
  process.exit(1);
});
