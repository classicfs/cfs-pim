# Product Inventory Management System - Design Guidelines

## Design Approach
**Selected System**: Material Design + Linear-inspired aesthetics
**Justification**: This inventory management system requires efficient data handling, clear information hierarchy, and professional utility-focused design. Material Design provides robust patterns for data-dense applications, while Linear's clean aesthetics ensure modern visual appeal.

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary)**
- Background Primary: 220 15% 10%
- Background Secondary: 220 15% 14%
- Background Tertiary: 220 15% 18%
- Primary Brand: 217 91% 60% (Blue - trust, professionalism)
- Success: 142 76% 45% (Green - completeness indicators)
- Warning: 38 92% 50% (Amber - pending imports)
- Error: 0 72% 51% (Red - data issues)
- Text Primary: 0 0% 98%
- Text Secondary: 220 9% 65%
- Border: 220 13% 25%

**Light Mode**
- Background Primary: 0 0% 100%
- Background Secondary: 220 13% 97%
- Background Tertiary: 220 13% 94%
- (Same accent colors with adjusted saturation for light backgrounds)

### B. Typography
**Font Family**: Inter (Google Fonts) for all text
- Headings: 600-700 weight, tight tracking (-0.02em)
- Body: 400 weight, normal line-height (1.6)
- Data/Tables: 500 weight, tabular numbers
- Labels: 500 weight, 0.75rem, uppercase, 0.05em tracking

**Scale**
- Page Title: text-2xl md:text-3xl (30-36px)
- Section Headers: text-xl (24px)
- Card Titles: text-lg (20px)
- Body: text-sm to text-base (14-16px)
- Captions/Meta: text-xs (12px)

### C. Layout System
**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4 to p-6
- Section spacing: space-y-6 to space-y-8
- Card margins: gap-4 to gap-6
- Page margins: px-6 md:px-8 lg:px-12

**Grid System**
- Dashboard: 12-column responsive grid
- Sidebar: Fixed 240px (lg:256px) on desktop, collapsible on mobile
- Content area: max-w-screen-2xl with responsive padding

### D. Component Library

**Navigation**
- Fixed sidebar navigation with icon + label pattern
- Active state: Primary color background with subtle glow
- Collapsed state on mobile with hamburger menu
- Top bar: Breadcrumbs, search, user profile

**Data Tables**
- Zebra striping with subtle background alternation
- Sticky header with sort indicators
- Row hover: Background tertiary with smooth transition
- Pagination: Bottom-aligned with page numbers + prev/next
- Column resizing: Drag handles on headers
- Dense mode toggle for compact view

**Cards & Metrics**
- Rounded corners: rounded-lg (8px)
- Subtle shadow: shadow-sm with border
- Metric cards: Large number display with trend indicators
- Data completeness: Progress bars with percentage labels

**Forms & Inputs**
- Input fields: Dark mode aware with focus ring (primary color)
- File upload: Drag-and-drop zone with dashed border
- CSV import: Preview table before confirmation
- Select/Dropdowns: Custom styled with search capability
- Validation: Inline error messages with error color

**Filters & Search**
- Filter panel: Collapsible sidebar or drawer
- Multi-select chips with remove action
- Search: Debounced with loading state
- Applied filters: Chip display with clear all option

**Data Visualization**
- Completeness charts: Horizontal bar charts with color coding
- Progress rings: Circular indicators for percentage completion
- Color scale: Red (0-40%) → Amber (41-70%) → Green (71-100%)
- Tooltips: On hover with detailed breakdowns

**Import Queue**
- Status badges: Color-coded (Queued/Processing/Complete/Failed)
- Timeline view with expandable details
- Action buttons: Retry, Cancel, View Details
- File preview modal for CSV imports

**Buttons**
- Primary: Filled with primary color, medium rounded (rounded-md)
- Secondary: Outline with border color
- Ghost: Transparent hover state
- Icon buttons: Consistent 40px hit area
- Loading states: Spinner with disabled appearance

**Modals & Overlays**
- Backdrop: Semi-transparent dark overlay (bg-black/50)
- Modal: Centered, max-w-2xl, rounded-lg with shadow-2xl
- Slide-over panels: For filters and detailed views
- Toast notifications: Top-right stacked with auto-dismiss

### E. Interactions
**Animations**: Minimal, functional only
- Transitions: 150-200ms ease-in-out for state changes
- Micro-interactions: Checkbox checks, toggle switches
- Loading: Skeleton screens for table data
- Page transitions: None (instant navigation)

## Dashboard-Specific Guidelines

**Layout Structure**
- Top: Key metrics in 3-4 card grid (Products count, Import queue, Completeness average)
- Middle: Product catalog table with integrated search/filters
- Sidebar: Quick actions (New Product, Import CSV, Export Data)

**Product Creation Modal**
- Tabs: "Manual Entry" and "CSV Upload"
- Manual: Multi-step form with validation
- CSV: Drag-drop zone → Preview → Confirm → Queue

**Data Completeness Section**
- Horizontal bar chart showing % complete per product
- Sort by completeness level
- Click to view missing attributes
- Aggregate stats at top

## Import Feed Page

**Queue Display**
- Table view with columns: Filename, Date, Status, Products, Actions
- Status filter chips at top
- Expandable rows showing individual product import status
- Bulk actions: Cancel all, Retry failed

## No Hero Images
This is a utility application - no hero sections needed. Focus on functional layouts with clear information hierarchy.