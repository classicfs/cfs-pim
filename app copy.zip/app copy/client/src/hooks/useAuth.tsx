import { useCallback, useEffect, useMemo, useState, createContext, useContext, type ReactNode } from "react";

type UserRoleAssignment = {
  roleId: number;
  assignedBy: number | null;
  assignedAt: string | null;
};

type User = {
  id: number;
  username?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  displayName: string;
  email: string;
  photo?: string;
  domain?: string;
  role?: string | null;
  roles?: UserRoleAssignment[];
  departmentId?: number | null;
  isActive?: boolean;
};

type AuthContextValue = {
  user: User | null;
  loading: boolean;
  login: (nextPath?: string) => void;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function fetchCurrentUser(): Promise<User | null> {
  const res = await fetch("/api/auth/me", { credentials: "include" });
  if (res.ok) {
    return res.json();
  }
  return null;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const currentUser = await fetchCurrentUser();
      setUser(currentUser);
    } catch (error) {
      console.warn("Unable to refresh session", error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const login = useCallback((nextPath?: string) => {
    const params = new URLSearchParams();
    if (nextPath && nextPath.startsWith("/")) {
      params.set("next", nextPath);
    }
    const query = params.toString();
    window.location.href = `/auth/google${query ? `?${query}` : ""}`;
  }, []);

  const logout = useCallback(async () => {
    await fetch("/api/auth/logout", {
      method: "POST",
      credentials: "include",
    });
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      logout,
      refresh,
    }),
    [user, loading, login, logout, refresh],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}
