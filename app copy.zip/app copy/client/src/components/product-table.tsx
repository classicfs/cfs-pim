import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpDown } from "lucide-react";

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  price: number;
  stock: number;
  completeness: number;
}

interface ProductTableProps {
  products: Product[];
}

type SortKey = keyof Product;
type SortOrder = "asc" | "desc";

export function ProductTable({ products }: ProductTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortOrder, setSortOrder] = useState<SortOrder>("asc");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("asc");
    }
  };

  const sortedProducts = [...products].sort((a, b) => {
    const aVal = a[sortKey];
    const bVal = b[sortKey];
    const modifier = sortOrder === "asc" ? 1 : -1;

    if (typeof aVal === "string" && typeof bVal === "string") {
      return aVal.localeCompare(bVal) * modifier;
    }
    return ((aVal as number) - (bVal as number)) * modifier;
  });

  const getCompletenessVariant = (percentage: number) => {
    if (percentage >= 71) return "default";
    if (percentage >= 41) return "secondary";
    return "destructive";
  };

  return (
    <div className="border rounded-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("name")}
                className="-ml-3 h-8"
                data-testid="button-sort-name"
              >
                Name
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("sku")}
                className="-ml-3 h-8"
                data-testid="button-sort-sku"
              >
                SKU
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("category")}
                className="-ml-3 h-8"
                data-testid="button-sort-category"
              >
                Category
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="text-right">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("price")}
                className="-mr-3 h-8"
                data-testid="button-sort-price"
              >
                Price
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="text-right">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("stock")}
                className="-mr-3 h-8"
                data-testid="button-sort-stock"
              >
                Stock
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="text-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("completeness")}
                className="-mx-3 h-8"
                data-testid="button-sort-completeness"
              >
                Completeness
                <ArrowUpDown className="ml-2 h-3 w-3" />
              </Button>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedProducts.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="h-24 text-center">
                <p className="text-muted-foreground" data-testid="text-no-products">
                  No products found.
                </p>
              </TableCell>
            </TableRow>
          ) : (
            sortedProducts.map((product) => (
              <TableRow key={product.id} className="hover-elevate" data-testid={`row-product-${product.id}`}>
                <TableCell className="font-medium" data-testid={`text-name-${product.id}`}>
                  {product.name}
                </TableCell>
                <TableCell className="text-muted-foreground" data-testid={`text-sku-${product.id}`}>
                  {product.sku}
                </TableCell>
                <TableCell data-testid={`text-category-${product.id}`}>
                  {product.category}
                </TableCell>
                <TableCell className="text-right" data-testid={`text-price-${product.id}`}>
                  ${product.price ? parseFloat(product.price.toString()).toFixed(2) : '0.00'}
                </TableCell>
                <TableCell className="text-right" data-testid={`text-stock-${product.id}`}>
                  {product.stock}
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant={getCompletenessVariant(product.completeness)} data-testid={`badge-completeness-${product.id}`}>
                    {product.completeness}%
                  </Badge>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
