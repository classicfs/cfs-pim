import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Settings2 } from "lucide-react";
import { useState, useEffect } from "react";

export type ColumnConfig = {
  id: string;
  label: string;
  defaultVisible: boolean;
};

export function getInitialVisibility(columns: ColumnConfig[], storageKey: string): Record<string, boolean> {
  if (typeof window !== 'undefined') {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        const result: Record<string, boolean> = {};
        columns.forEach((col) => {
          result[col.id] = parsed[col.id] !== undefined ? parsed[col.id] : col.defaultVisible;
        });
        return result;
      } catch {
      }
    }
  }
  const defaults: Record<string, boolean> = {};
  columns.forEach((col) => {
    defaults[col.id] = col.defaultVisible;
  });
  return defaults;
}

interface ColumnVisibilitySelectorProps {
  columns: ColumnConfig[];
  storageKey: string;
  visibility: Record<string, boolean>;
  onVisibilityChange: (visibility: Record<string, boolean>) => void;
}

export function ColumnVisibilitySelector({
  columns,
  storageKey,
  visibility,
  onVisibilityChange,
}: ColumnVisibilitySelectorProps) {
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(storageKey, JSON.stringify(visibility));
    }
  }, [visibility, storageKey]);

  const toggleColumn = (columnId: string) => {
    const updated = { ...visibility, [columnId]: !visibility[columnId] };
    onVisibilityChange(updated);
  };

  const showAll = () => {
    const allVisible: Record<string, boolean> = {};
    columns.forEach((col) => {
      allVisible[col.id] = true;
    });
    onVisibilityChange(allVisible);
  };

  const hideAll = () => {
    const allHidden: Record<string, boolean> = {};
    columns.forEach((col) => {
      allHidden[col.id] = false;
    });
    onVisibilityChange(allHidden);
  };

  const resetDefaults = () => {
    const defaults: Record<string, boolean> = {};
    columns.forEach((col) => {
      defaults[col.id] = col.defaultVisible;
    });
    onVisibilityChange(defaults);
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          data-testid="button-column-visibility"
          className="gap-2"
        >
          <Settings2 className="h-4 w-4" />
          Columns
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm">Column Visibility</h4>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={showAll}
                data-testid="button-show-all-columns"
              >
                Show All
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={hideAll}
                data-testid="button-hide-all-columns"
              >
                Hide All
              </Button>
            </div>
          </div>
          <div className="max-h-96 overflow-y-auto space-y-3">
            {columns.map((column) => (
              <div key={column.id} className="flex items-center gap-2">
                <Checkbox
                  id={`column-${column.id}`}
                  checked={visibility[column.id] ?? column.defaultVisible}
                  onCheckedChange={() => toggleColumn(column.id)}
                  data-testid={`checkbox-column-${column.id}`}
                />
                <Label
                  htmlFor={`column-${column.id}`}
                  className="text-sm cursor-pointer flex-1"
                >
                  {column.label}
                </Label>
              </div>
            ))}
          </div>
          <div className="flex justify-end pt-2 border-t">
            <Button
              variant="outline"
              size="sm"
              onClick={resetDefaults}
              data-testid="button-reset-columns"
            >
              Reset to Defaults
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
