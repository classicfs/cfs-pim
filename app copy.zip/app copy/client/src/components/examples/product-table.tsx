import { ProductTable } from "../product-table";

const mockProducts = [
  { id: "1", name: "Wireless Headphones", sku: "WH-001", category: "Electronics", price: 129.99, stock: 45, completeness: 95 },
  { id: "2", name: "Smart Watch", sku: "SW-002", category: "Wearables", price: 299.99, stock: 23, completeness: 72 },
  { id: "3", name: "USB-C Cable", sku: "UC-003", category: "Accessories", price: 19.99, stock: 150, completeness: 45 },
  { id: "4", name: "Bluetooth Speaker", sku: "BS-004", category: "Electronics", price: 79.99, stock: 67, completeness: 88 },
  { id: "5", name: "Phone Case", sku: "PC-005", category: "Accessories", price: 24.99, stock: 200, completeness: 30 },
];

export default function ProductTableExample() {
  return (
    <div className="w-full max-w-6xl">
      <ProductTable products={mockProducts} />
    </div>
  );
}
