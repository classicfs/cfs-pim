import { ProductCreationDialog } from "../product-creation-dialog";
import { Toaster } from "@/components/ui/toaster";

export default function ProductCreationDialogExample() {
  return (
    <>
      <ProductCreationDialog />
      <Toaster />
    </>
  );
}
