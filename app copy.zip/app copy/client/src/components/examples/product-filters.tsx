import { useState } from "react";
import { ProductFiltersPanel, ProductFilters } from "../product-filters";

export default function ProductFiltersExample() {
  const [filters, setFilters] = useState<ProductFilters>({
    category: "",
    minPrice: "",
    maxPrice: "",
    minStock: "",
    minCompleteness: "",
  });

  return <ProductFiltersPanel filters={filters} onFiltersChange={setFilters} />;
}
