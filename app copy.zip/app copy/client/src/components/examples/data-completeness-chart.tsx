import { DataCompletenessChart } from "../data-completeness-chart";

const mockProducts = [
  { id: "1", name: "Premium Wireless Headphones", completeness: 95 },
  { id: "2", name: "Smart Watch Pro", completeness: 72 },
  { id: "3", name: "USB-C Charging Cable", completeness: 45 },
  { id: "4", name: "Bluetooth Speaker", completeness: 88 },
  { id: "5", name: "Phone Case", completeness: 30 },
];

export default function DataCompletenessChartExample() {
  return (
    <div className="w-96">
      <DataCompletenessChart products={mockProducts} />
    </div>
  );
}
