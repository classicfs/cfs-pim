import { MetricCard } from "../metric-card";
import { Package } from "lucide-react";

export default function MetricCardExample() {
  return (
    <div className="w-80">
      <MetricCard
        title="Total Products"
        value="1,234"
        subtitle="+12% from last month"
        icon={Package}
      />
    </div>
  );
}
