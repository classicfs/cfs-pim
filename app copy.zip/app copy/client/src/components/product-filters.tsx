import { useState } from "react";
import { Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";

export interface ProductFilters {
  category: string;
  minPrice: string;
  maxPrice: string;
  minStock: string;
  minCompleteness: string;
}

interface ProductFiltersProps {
  filters: ProductFilters;
  onFiltersChange: (filters: ProductFilters) => void;
}

export function ProductFiltersPanel({ filters, onFiltersChange }: ProductFiltersProps) {
  const [open, setOpen] = useState(false);
  const [localFilters, setLocalFilters] = useState(filters);

  const handleApply = () => {
    onFiltersChange(localFilters);
    setOpen(false);
    console.log("Filters applied:", localFilters);
  };

  const handleReset = () => {
    const emptyFilters: ProductFilters = {
      category: "",
      minPrice: "",
      maxPrice: "",
      minStock: "",
      minCompleteness: "",
    };
    setLocalFilters(emptyFilters);
    onFiltersChange(emptyFilters);
    console.log("Filters reset");
  };

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" data-testid="button-filters">
          <Filter className="h-4 w-4" />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="default" className="ml-2 h-5 px-1 text-xs">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Filter Products</SheetTitle>
          <SheetDescription>
            Apply filters to narrow down your product search.
          </SheetDescription>
        </SheetHeader>
        <div className="space-y-4 pt-6">
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              placeholder="e.g., Electronics"
              value={localFilters.category}
              onChange={(e) =>
                setLocalFilters({ ...localFilters, category: e.target.value })
              }
              data-testid="input-filter-category"
            />
          </div>
          <div className="space-y-2">
            <Label>Price Range</Label>
            <div className="grid grid-cols-2 gap-2">
              <Input
                placeholder="Min"
                type="number"
                step="0.01"
                value={localFilters.minPrice}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, minPrice: e.target.value })
                }
                data-testid="input-filter-min-price"
              />
              <Input
                placeholder="Max"
                type="number"
                step="0.01"
                value={localFilters.maxPrice}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, maxPrice: e.target.value })
                }
                data-testid="input-filter-max-price"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="minStock">Minimum Stock</Label>
            <Input
              id="minStock"
              type="number"
              placeholder="0"
              value={localFilters.minStock}
              onChange={(e) =>
                setLocalFilters({ ...localFilters, minStock: e.target.value })
              }
              data-testid="input-filter-min-stock"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="minCompleteness">Minimum Completeness (%)</Label>
            <Input
              id="minCompleteness"
              type="number"
              placeholder="0"
              min="0"
              max="100"
              value={localFilters.minCompleteness}
              onChange={(e) =>
                setLocalFilters({
                  ...localFilters,
                  minCompleteness: e.target.value,
                })
              }
              data-testid="input-filter-min-completeness"
            />
          </div>
          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              onClick={handleReset}
              className="flex-1"
              data-testid="button-reset-filters"
            >
              <X className="h-4 w-4" />
              Reset
            </Button>
            <Button onClick={handleApply} className="flex-1" data-testid="button-apply-filters">
              Apply Filters
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
