import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";


interface ProductCreationDialogProps {
  onCreateProduct?: (data: any) => void;
  isCreating?: boolean;
  categories?: Array<{ categoryId: number; name: string; pathKey?: string }>;
  brands?: Array<{ brandId: number; brandName: string | null }>;
  productTypes?: Array<{ productTypeId: number; productTypeName: string | null }>;
  productColours?: Array<{ productColourId: number; magentoColourName: string | null; brandColourName: string | null; brandName?: string | null; brandId?: number | null }>;
  genders?: Array<{ genderId: number; genderName: string | null }>;
  clubs?: Array<{ clubId: number; name: string }>;
  taxClasses?: Array<{ taxClassId: number; taxClassName: string | null }>;
  sizes?: Array<{ sizeId: number; magentoSizeLongName: string | null; magentoSizeShortName: string | null }>;
  conditions?: Array<{ conditionId: number; conditionName: string | null }>;
}

function getColourDisplayName(colour: { magentoColourName: string | null; brandColourName: string | null; brandName?: string | null; productColourId: number }): string {
  const name = colour.magentoColourName || colour.brandColourName || `Colour ${colour.productColourId}`;
  if (colour.brandName) {
    return `${name} (${colour.brandName})`;
  }
  return name;
}

export function ProductCreationDialog({ 
  onCreateProduct, 
  isCreating = false,
  categories = [],
  brands = [],
  productTypes = [],
  productColours = [],
  genders = [],
  clubs = [],
  taxClasses = [],
  sizes = [],
  conditions = [],
}: ProductCreationDialogProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [categorySelectValue, setCategorySelectValue] = useState<string>("none");
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCategoryParentId, setNewCategoryParentId] = useState<string>("none");
  const [productColourId, setProductColourId] = useState<string>("none");
  const [genderId, setGenderId] = useState<string>("none");
  const [brandId, setBrandId] = useState<string>("none");
  const [productTypeId, setProductTypeId] = useState<string>("none");
  const [productStyleId, setProductStyleId] = useState<string>("");
  const [clubId, setClubId] = useState<string>("none");
  const [enabled, setEnabled] = useState(true);
  const [sizeId, setSizeId] = useState<string>("none");
  const [taxClassId, setTaxClassId] = useState<string>("none");
  const [conditionId, setConditionId] = useState<string>("none");

  const asNumberOrNull = (value: string) => (value !== "none" ? Number(value) : null);

  const selectedType = productTypes.find(t => String(t.productTypeId) === productTypeId);
  const isSimpleProduct = selectedType?.productTypeName?.toLowerCase() === "simple";

  const selectedBrandId = brandId !== "none" ? Number(brandId) : null;
  const filteredColours = selectedBrandId
    ? productColours.filter(c => c.brandId === selectedBrandId || !c.brandId)
    : productColours;

  const createCategoryMutation = useMutation({
    mutationFn: async ({ name, parentId }: { name: string; parentId: number | null }) => {
      const body: Record<string, any> = { name };
      if (parentId !== null) {
        body.parentId = parentId;
      }
      const res = await apiRequest("POST", "/api/categories", body);
      return await res.json();
    },
    onSuccess: (created: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setSelectedCategoryIds(prev => [...prev, Number(created.categoryId)]);
      setNewCategoryName("");
      setNewCategoryParentId("none");
      toast({ title: "Category created", description: `"${created.name}" has been created and selected.` });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create category", description: error.message, variant: "destructive" });
    },
  });

  const handleAddCategory = (catId: string) => {
    if (catId === "none") return;
    const id = Number(catId);
    if (!selectedCategoryIds.includes(id)) {
      setSelectedCategoryIds(prev => [...prev, id]);
    }
    setCategorySelectValue("none");
  };

  const handleRemoveCategory = (catId: number) => {
    setSelectedCategoryIds(prev => prev.filter(id => id !== catId));
  };

  const handleManualSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data: Record<string, any> = {
      productSku: (formData.get("productSku") as string) || "",
      articleNumber: (formData.get("articleNumber") as string) || "",
      productDescription: (formData.get("productDescription") as string) || "",
      productColourId: asNumberOrNull(productColourId),
      genderId: asNumberOrNull(genderId),
      brandId: asNumberOrNull(brandId),
      productTypeId: asNumberOrNull(productTypeId),
      clubId: asNumberOrNull(clubId),
      productStyle: productStyleId.trim() || null,
      composition: (formData.get("composition") as string) || "",
      countryOfManufacture: (formData.get("countryOfManufacture") as string) || "",
      commodityCode: (formData.get("commodityCode") as string) || "",
      imageCode: (formData.get("imageCode") as string) || "",
      enabled,
      sync: true,
      categoryId: selectedCategoryIds.length > 0 ? selectedCategoryIds[0] : null,
      categoryIds: selectedCategoryIds.length > 0 ? selectedCategoryIds : undefined,
    };

    if (isSimpleProduct) {
      data.variantSku = (formData.get("variantSku") as string) || "";
      data.sizeId = asNumberOrNull(sizeId);
      data.taxClassId = asNumberOrNull(taxClassId);
      data.conditionId = asNumberOrNull(conditionId);
      data.barcode = (formData.get("barcode") as string) || "";
      data.weight = formData.get("weight") ? Number(formData.get("weight")) : null;
      data.costPrice = formData.get("costPrice") ? Number(formData.get("costPrice")) : null;
      data.retailPrice = formData.get("retailPrice") ? Number(formData.get("retailPrice")) : null;
      data.specialRetailPrice = formData.get("specialRetailPrice") ? Number(formData.get("specialRetailPrice")) : null;

    }
    
    if (onCreateProduct) {
      onCreateProduct(data);
      setOpen(false);
      e.currentTarget.reset();
      setSelectedCategoryIds([]);
      setCategorySelectValue("none");
      setNewCategoryName("");
      setNewCategoryParentId("none");
      setProductColourId("none");
      setGenderId("none");
      setBrandId("none");
      setProductTypeId("none");
      setProductStyleId("");
      setClubId("none");
      setEnabled(true);
      setSizeId("none");
      setTaxClassId("none");
      setConditionId("none");
    }
  };

  const availableCategories = categories.filter(c => !selectedCategoryIds.includes(c.categoryId));

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-create-product">
          <Plus className="h-4 w-4" />
          Create Product
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Product</DialogTitle>
          <DialogDescription>
            Add a new product directly to the catalog.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleManualSubmit} className="space-y-6 pt-4">
          <div className="space-y-2">
            <Label htmlFor="productSku">Product SKU</Label>
            <Input
              id="productSku"
              name="productSku"
              placeholder="SKU-001"
              required
              data-testid="input-product-sku"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="articleNumber">Article Number</Label>
            <Input
              id="articleNumber"
              name="articleNumber"
              placeholder="ART-001"
              data-testid="input-article-number"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="productDescription">Product Description</Label>
            <Textarea
              id="productDescription"
              name="productDescription"
              placeholder="Product description"
              rows={3}
              required
              data-testid="input-product-description"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="brand">Brand</Label>
              <Select value={brandId} onValueChange={(value) => {
                setBrandId(value);
                const newBrandId = value !== "none" ? Number(value) : null;
                if (productColourId !== "none") {
                  const currentColour = productColours.find(c => c.productColourId === Number(productColourId));
                  if (currentColour && currentColour.brandId && currentColour.brandId !== newBrandId) {
                    setProductColourId("none");
                  }
                }
              }}>
                <SelectTrigger data-testid="select-brand">
                  <SelectValue placeholder="Select brand" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No brand</SelectItem>
                  {brands.map((brand) => (
                    <SelectItem key={brand.brandId} value={String(brand.brandId)}>
                      {brand.brandName || `Brand ${brand.brandId}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="productColour">Product Colour</Label>
              <Select value={productColourId} onValueChange={setProductColourId}>
                <SelectTrigger data-testid="select-product-colour">
                  <SelectValue placeholder="Select colour" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No colour</SelectItem>
                  {filteredColours.map((colour) => (
                    <SelectItem key={colour.productColourId} value={String(colour.productColourId)}>
                      {getColourDisplayName(colour)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="gender">Gender</Label>
              <Select value={genderId} onValueChange={setGenderId}>
                <SelectTrigger data-testid="select-gender">
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No gender</SelectItem>
                  {genders.map((gender) => (
                    <SelectItem key={gender.genderId} value={String(gender.genderId)}>
                      {gender.genderName || `Gender ${gender.genderId}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="productType">Product Type</Label>
              <Select value={productTypeId} onValueChange={setProductTypeId}>
                <SelectTrigger data-testid="select-product-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No type</SelectItem>
                  {productTypes.map((type) => (
                    <SelectItem key={type.productTypeId} value={String(type.productTypeId)}>
                      {type.productTypeName || `Type ${type.productTypeId}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="productStyle">Product Style</Label>
              <Input
                id="productStyle"
                data-testid="input-product-style"
                value={productStyleId}
                onChange={(e) => setProductStyleId(e.target.value)}
                placeholder="e.g. Home, Away, Third"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="team">Team</Label>
              <Select value={clubId} onValueChange={setClubId}>
                <SelectTrigger data-testid="select-team">
                  <SelectValue placeholder="Select team" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No team</SelectItem>
                  {clubs.map((club) => (
                    <SelectItem key={club.clubId} value={String(club.clubId)}>
                      {club.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Categories</Label>
            {selectedCategoryIds.length > 0 && (
              <div className="flex flex-wrap gap-1 mb-2">
                {selectedCategoryIds.map(catId => {
                  const cat = categories.find(c => c.categoryId === catId);
                  return (
                    <Badge key={catId} variant="secondary" className="gap-1">
                      {cat?.name || `Category ${catId}`}
                      <button
                        type="button"
                        onClick={() => handleRemoveCategory(catId)}
                        className="ml-1"
                        data-testid={`button-remove-category-${catId}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
            <Select value={categorySelectValue} onValueChange={handleAddCategory}>
              <SelectTrigger data-testid="select-category">
                <SelectValue placeholder="Add a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Select a category to add</SelectItem>
                {availableCategories.map((category) => (
                  <SelectItem key={category.categoryId} value={String(category.categoryId)}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="space-y-2 mt-2 rounded-md border p-3">
              <p className="text-xs text-muted-foreground">Create new category</p>
              <div className="flex items-center gap-2">
                <Input
                  placeholder="New category name"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  data-testid="input-new-category"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    if (newCategoryName.trim()) {
                      const parentId = newCategoryParentId !== "none" ? Number(newCategoryParentId) : null;
                      createCategoryMutation.mutate({ name: newCategoryName.trim(), parentId });
                    }
                  }}
                  disabled={!newCategoryName.trim() || createCategoryMutation.isPending}
                  data-testid="button-create-category"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Parent category (optional)</Label>
                <Select value={newCategoryParentId} onValueChange={setNewCategoryParentId}>
                  <SelectTrigger data-testid="select-new-category-parent">
                    <SelectValue placeholder="No parent (root level)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No parent (root level)</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.categoryId} value={String(category.categoryId)}>
                        {category.pathKey || category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="composition">Composition</Label>
              <Input
                id="composition"
                name="composition"
                placeholder="100% Cotton"
                data-testid="input-composition"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="countryOfManufacture">Country of Manufacture</Label>
              <Input
                id="countryOfManufacture"
                name="countryOfManufacture"
                placeholder="United Kingdom"
                data-testid="input-country"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="commodityCode">Commodity Code</Label>
              <Input
                id="commodityCode"
                name="commodityCode"
                placeholder="1234.56"
                data-testid="input-commodity-code"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="imageCode">Image Code</Label>
              <Input
                id="imageCode"
                name="imageCode"
                placeholder="IMG-001"
                data-testid="input-image-code"
              />
            </div>
          </div>

          {isSimpleProduct && (
            <>
              <div className="border-t pt-4 mt-4">
                <h4 className="text-sm font-medium mb-4">Variant Details (Simple Product)</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="variantSku">Variant SKU (optional)</Label>
                      <Input
                        id="variantSku"
                        name="variantSku"
                        placeholder="Leave blank to use Product SKU"
                        data-testid="input-variant-sku"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="barcode">Barcode</Label>
                      <Input
                        id="barcode"
                        name="barcode"
                        placeholder="EAN/UPC"
                        data-testid="input-barcode"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="size">Size</Label>
                      <Select value={sizeId} onValueChange={setSizeId}>
                        <SelectTrigger data-testid="select-size">
                          <SelectValue placeholder="Select size" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No size</SelectItem>
                          {sizes.map((size) => (
                            <SelectItem key={size.sizeId} value={String(size.sizeId)}>
                              {size.magentoSizeLongName || size.magentoSizeShortName || `Size ${size.sizeId}`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="taxClass">Tax Class</Label>
                      <Select value={taxClassId} onValueChange={setTaxClassId}>
                        <SelectTrigger data-testid="select-tax-class">
                          <SelectValue placeholder="Select tax class" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No tax class</SelectItem>
                          {taxClasses.map((tc) => (
                            <SelectItem key={tc.taxClassId} value={String(tc.taxClassId)}>
                              {tc.taxClassName || `Tax Class ${tc.taxClassId}`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="condition">Condition</Label>
                      <Select value={conditionId} onValueChange={setConditionId}>
                        <SelectTrigger data-testid="select-condition">
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">No condition</SelectItem>
                          {conditions.map((cond) => (
                            <SelectItem key={cond.conditionId} value={String(cond.conditionId)}>
                              {cond.conditionName || `Condition ${cond.conditionId}`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight">Weight (kg)</Label>
                      <Input
                        id="weight"
                        name="weight"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        data-testid="input-weight"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="costPrice">Cost Price</Label>
                      <Input
                        id="costPrice"
                        name="costPrice"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        data-testid="input-cost-price"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="retailPrice">Retail Price</Label>
                      <Input
                        id="retailPrice"
                        name="retailPrice"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        data-testid="input-retail-price"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialRetailPrice">Special Price</Label>
                      <Input
                        id="specialRetailPrice"
                        name="specialRetailPrice"
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        data-testid="input-special-price"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          <div className="flex items-center gap-2">
            <Checkbox
              checked={enabled}
              onCheckedChange={(value) => setEnabled(value === true)}
              id="enabled"
              data-testid="checkbox-enabled"
            />
            <Label htmlFor="enabled">Enabled</Label>
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel"
              disabled={isCreating}
            >
              Cancel
            </Button>
            <Button type="submit" data-testid="button-submit-manual" disabled={isCreating}>
              {isCreating ? "Creating..." : "Create Product"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
