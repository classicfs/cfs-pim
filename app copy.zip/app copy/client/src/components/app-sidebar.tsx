import {
  LayoutDashboard,
  Upload,
  Package,
  Download,
  Users,
  FolderKanban,
  Languages,
  SlidersHorizontal,
  Store,
  Eye,
  List,
  Coins,
  ChevronLeft,
  ChevronRight,
  LifeBuoy,
  Swords,
  Database,
  Image,
  FolderTree,
  ArrowLeftRight,
  CalendarClock,
  KeyRound,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import appLogo from "@/assets/app-logo.png";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const items = [
  {
    title: "Rivalries",
    url: "/rivalries",
    icon: Swords,
  },
  {
    title: "Groups",
    url: "/groups",
    icon: FolderKanban,
  },
  {
    title: "Attributes",
    url: "/attributes",
    icon: SlidersHorizontal,
  },
  {
    title: "Translations",
    url: "/translations",
    icon: Languages,
  },
];

const catalogItems = [
  {
    title: "Product Catalog",
    url: "/catalog",
    icon: Package,
  },
  {
    title: "Supplier Catalog",
    url: "/supplier-catalog",
    icon: Users,
  },
  {
    title: "Categories",
    url: "/categories",
    icon: FolderTree,
  },
  {
    title: "Images",
    url: "/images",
    icon: Image,
  },
];

const feedItems = [
  {
    title: "Import",
    url: "/import-feed",
    icon: Upload,
  },
  {
    title: "Export",
    url: "/export",
    icon: Download,
  },
  {
    title: "Reference Data",
    url: "/reference-data",
    icon: Database,
  },
];

const storeItems = [
  {
    title: "Store views",
    url: "/stores/views",
    icon: Eye,
  },
  {
    title: "Store products",
    url: "/stores/products",
    icon: List,
  },
  {
    title: "Store currency",
    url: "/stores/currency",
    icon: Coins,
  },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { state, toggleSidebar } = useSidebar();
  const isDashboard = location === "/";
  const isProductCatalog = location === "/catalog";
  const isSupplierCatalog = location.startsWith("/supplier-catalog");
  const isCategories = location === "/categories";
  const isImages = location === "/images";
  const isCatalogsActive = isProductCatalog || isSupplierCatalog || isCategories || isImages;
  const isImportFeed = location === "/import-feed";
  const isReferenceData = location === "/reference-data";
  const isExportFeed = location === "/export";
  const isSyncLogs = location === "/sync-logs";
  const isScheduledChanges = location === "/scheduled-changes";
  const isApiKeys = location === "/api-keys";
  const isFeedsActive = isImportFeed || isReferenceData || isExportFeed;
  const isStoresActive = location.startsWith("/stores");

  const displayName = user?.displayName || "Workspace user";
  const userRole = user?.role || "Role pending assignment";
  const initials = displayName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        <div className="flex items-center justify-between gap-3 px-4 py-2 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0">
          <div className="flex items-center gap-2 group-data-[collapsible=icon]:hidden">
            <img
              src={appLogo}
              alt="App logo"
              className="h-8 w-8 rounded-xl border border-border bg-white p-1 shadow-sm dark:bg-background"
            />
            <span className="text-sm font-semibold text-sidebar-foreground group-data-[collapsible=icon]:hidden">
              CFS Product
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 rounded-full border border-border bg-background text-foreground transition-colors hover:bg-muted group-data-[collapsible=icon]:mx-auto group-data-[collapsible=icon]:h-8 group-data-[collapsible=icon]:w-8"
            onClick={toggleSidebar}
            aria-label={state === "expanded" ? "Collapse sidebar" : "Expand sidebar"}
          >
            {state === "expanded" ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </Button>
        </div>
        <SidebarMenu className="px-2">
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={isDashboard} tooltip="Dashboard" data-testid="link-dashboard">
              <Link href="/">
                <LayoutDashboard />
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <Collapsible defaultOpen={isCatalogsActive} className="group/menu-collapsible">
              <CollapsibleTrigger asChild>
                <SidebarMenuButton isActive={isCatalogsActive} tooltip="Catalogs" data-testid="button-catalogs">
                  <Package />
                  <span>Catalogs</span>
                  <ChevronRight className="ml-auto transition-transform group-data-[state=open]/menu-collapsible:rotate-90 group-data-[collapsible=icon]:hidden" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarMenuSub>
                  {catalogItems.map((item) => {
                    let isActive = false;
                    if (item.url === "/catalog") isActive = isProductCatalog;
                    else if (item.url === "/supplier-catalog") isActive = isSupplierCatalog;
                    else if (item.url === "/categories") isActive = isCategories;
                    else if (item.url === "/images") isActive = isImages;
                    return (
                      <SidebarMenuSubItem key={item.title}>
                        <SidebarMenuSubButton asChild isActive={isActive}>
                          <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(" ", "-")}`}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    );
                  })}
                </SidebarMenuSub>
              </CollapsibleContent>
            </Collapsible>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <Collapsible defaultOpen={isFeedsActive} className="group/menu-collapsible">
              <CollapsibleTrigger asChild>
                <SidebarMenuButton isActive={isFeedsActive} tooltip="Feeds" data-testid="button-feeds">
                  <Upload />
                  <span>Feeds</span>
                  <ChevronRight className="ml-auto transition-transform group-data-[state=open]/menu-collapsible:rotate-90 group-data-[collapsible=icon]:hidden" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarMenuSub>
                  {feedItems.map((item) => {
                    const isActive = location === item.url;
                    return (
                      <SidebarMenuSubItem key={item.title}>
                        <SidebarMenuSubButton asChild isActive={isActive}>
                          <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(" ", "-")}`}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    );
                  })}
                </SidebarMenuSub>
              </CollapsibleContent>
            </Collapsible>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <Collapsible defaultOpen={isStoresActive} className="group/menu-collapsible">
              <CollapsibleTrigger asChild>
                <SidebarMenuButton isActive={isStoresActive} tooltip="Stores" data-testid="button-stores">
                  <Store />
                  <span>Stores</span>
                  <ChevronRight className="ml-auto transition-transform group-data-[state=open]/menu-collapsible:rotate-90 group-data-[collapsible=icon]:hidden" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarMenuSub>
                  {storeItems.map((item) => {
                    const isActive = location === item.url || (location === "/stores" && item.url === "/stores/views");
                    return (
                      <SidebarMenuSubItem key={item.title}>
                        <SidebarMenuSubButton asChild isActive={isActive}>
                          <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(" ", "-")}`}>
                            <item.icon />
                            <span>{item.title}</span>
                          </Link>
                        </SidebarMenuSubButton>
                      </SidebarMenuSubItem>
                    );
                  })}
                </SidebarMenuSub>
              </CollapsibleContent>
            </Collapsible>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={isSyncLogs} tooltip="Sync Logs">
              <Link href="/sync-logs" data-testid="link-sync-logs">
                <ArrowLeftRight />
                <span>Sync Logs</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={isScheduledChanges} tooltip="Scheduled Changes">
              <Link href="/scheduled-changes" data-testid="link-scheduled-changes">
                <CalendarClock />
                <span>Scheduled Changes</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={isApiKeys} tooltip="API Keys">
              <Link href="/api-keys" data-testid="link-api-keys">
                <KeyRound />
                <span>API Keys</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          {items.map((item) => (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton asChild isActive={location === item.url} tooltip={item.title}>
                <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(" ", "-")}`}>
                  <item.icon />
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t border-border">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              variant="ghost"
              className="text-sm font-medium"
              tooltip="Help & Support"
              data-testid="button-help"
            >
              <a
                href="https://www.notion.so/PIM-Help-Center-2edfa04321af809f9daed90865758b71?source=copy_link"
                target="_blank"
                rel="noreferrer"
                className="flex w-full items-center gap-2"
              >
                <LifeBuoy className="text-muted-foreground" />
                <span className="group-data-[collapsible=icon]:hidden">Help Center</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              isActive={location === "/settings"}
              data-testid="button-account-settings"
              className="font-semibold h-auto p-0 overflow-visible"
              variant="ghost"
              size="lg"
            >
              <Link href="/settings" className="w-full" title={userRole} aria-label="Open Settings">
                <div className="flex w-full items-center gap-4 rounded-2xl border border-border/60 bg-muted/70 px-4 py-3 shadow-sm transition-colors hover:bg-muted group-data-[collapsible=icon]:h-12 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:gap-0 group-data-[collapsible=icon]:rounded-full group-data-[collapsible=icon]:border-transparent group-data-[collapsible=icon]:bg-transparent group-data-[collapsible=icon]:px-0 group-data-[collapsible=icon]:py-0 group-data-[collapsible=icon]:shadow-none group-data-[collapsible=icon]:hover:bg-transparent">
                  <Avatar className="h-12 w-12 border border-border rounded-full group-data-[collapsible=icon]:h-9 group-data-[collapsible=icon]:w-9">
                    <AvatarImage src={user?.photo} alt={displayName} />
                    <AvatarFallback>{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col items-center text-center leading-tight group-data-[collapsible=icon]:hidden">
                    <span className="text-sm font-semibold text-foreground">{displayName}</span>
                    <span className="text-xs text-muted-foreground">{userRole}</span>
                  </div>
                </div>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
