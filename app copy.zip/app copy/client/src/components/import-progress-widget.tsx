import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, Loader2, X, ChevronDown, ChevronUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

interface ProgressEntry {
  sku: string;
  status: "success" | "error";
  message?: string;
  timestamp: number;
}

interface ImportProgress {
  batchId: string;
  totalRows: number;
  processedRows: number;
  appliedRows: number;
  errorRows: number;
  status: "processing" | "completed" | "failed";
  entries: ProgressEntry[];
}

interface ProgressResponse {
  active: string[];
  all: Record<string, ImportProgress>;
}

export function ImportProgressWidget() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [completedBatches, setCompletedBatches] = useState<Set<string>>(new Set());

  const { data } = useQuery<ProgressResponse>({
    queryKey: ["/api/imports/progress"],
    refetchInterval: 1500,
    staleTime: 0,
    enabled: !!user,
  });

  const activeBatches = data?.all
    ? Object.entries(data.all).filter(([id]) => !dismissed.has(id))
    : [];

  useEffect(() => {
    if (!data?.all) return;
    for (const [batchId, progress] of Object.entries(data.all)) {
      if ((progress.status === "completed" || progress.status === "failed") && !completedBatches.has(batchId)) {
        setCompletedBatches(prev => new Set(prev).add(batchId));

        queryClient.invalidateQueries({ queryKey: ["/api/import-feed"] });
        queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
        queryClient.invalidateQueries({ queryKey: ["/api/product-colours"] });

        const errorCount = progress.errorRows;
        const successCount = progress.appliedRows;

        if (progress.status === "completed") {
          toast({
            title: "Import completed",
            description: `${successCount} rows applied${errorCount > 0 ? `, ${errorCount} errors` : ""}`,
          });
        } else {
          toast({
            title: "Import failed",
            description: `${successCount} rows applied, ${errorCount} errors`,
            variant: "destructive",
          });
        }
      }
    }
  }, [data, completedBatches, toast]);

  if (activeBatches.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm" data-testid="import-progress-widget">
      {activeBatches.map(([batchId, progress]) => {
        const pct = progress.totalRows > 0
          ? Math.round((progress.processedRows / progress.totalRows) * 100)
          : 0;
        const isExpanded = expanded.has(batchId);
        const isActive = progress.status === "processing";
        const isDone = progress.status === "completed" || progress.status === "failed";
        const recentEntries = progress.entries.slice(-8);

        return (
          <Card key={batchId} className="shadow-lg" data-testid={`progress-card-${batchId}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 p-3 pb-1">
              <div className="flex items-center gap-2 min-w-0 flex-1">
                {isActive && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground shrink-0" />}
                {progress.status === "completed" && <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />}
                {progress.status === "failed" && <XCircle className="h-4 w-4 text-destructive shrink-0" />}
                <CardTitle className="text-sm truncate">
                  {isActive ? "Importing..." : progress.status === "completed" ? "Import complete" : "Import failed"}
                </CardTitle>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    setExpanded(prev => {
                      const n = new Set(prev);
                      isExpanded ? n.delete(batchId) : n.add(batchId);
                      return n;
                    });
                  }}
                  data-testid={`toggle-expand-${batchId}`}
                >
                  {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
                </Button>
                {isDone && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setDismissed(prev => new Set(prev).add(batchId))}
                    data-testid={`dismiss-progress-${batchId}`}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-3 pt-1">
              <div className="flex items-center gap-2 mb-1">
                <Progress value={pct} className="flex-1 h-2" />
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {progress.processedRows}/{progress.totalRows}
                </span>
              </div>
              {isExpanded && recentEntries.length > 0 && (
                <div className="mt-2 max-h-40 overflow-y-auto space-y-1" data-testid="progress-entries">
                  {recentEntries.map((entry, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs">
                      {entry.status === "success" ? (
                        <CheckCircle className="h-3 w-3 text-green-500 shrink-0" />
                      ) : (
                        <XCircle className="h-3 w-3 text-destructive shrink-0" />
                      )}
                      <span className="truncate font-mono">{entry.sku}</span>
                      {entry.message && (
                        <Badge variant="destructive" className="text-[10px] shrink-0">
                          {entry.message.substring(0, 30)}
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
