import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ProductCompleteness {
  id: string;
  name: string;
  completeness: number;
}

interface DataCompletenessChartProps {
  products: ProductCompleteness[];
}

export function DataCompletenessChart({ products }: DataCompletenessChartProps) {
  const averageCompleteness = products.length > 0
    ? Math.round(products.reduce((acc, p) => acc + p.completeness, 0) / products.length)
    : 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between gap-2">
          <span>Data Completeness</span>
          <span className="text-sm font-normal text-muted-foreground" data-testid="text-average-completeness">
            Avg: {averageCompleteness}%
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {products.map((product) => {
            const getColor = (percentage: number) => {
              if (percentage >= 71) return "bg-chart-2";
              if (percentage >= 41) return "bg-chart-3";
              return "bg-chart-5";
            };

            return (
              <div key={product.id} className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="font-medium truncate" data-testid={`text-product-${product.id}`}>
                    {product.name}
                  </span>
                  <span className="text-muted-foreground shrink-0" data-testid={`text-completeness-${product.id}`}>
                    {product.completeness}%
                  </span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className={`h-full transition-all ${getColor(product.completeness)}`}
                    style={{ width: `${product.completeness}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
