import { Switch, Route, useLocation } from "wouter";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { ImportProgressWidget } from "@/components/import-progress-widget";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, ChevronDown, Search, Loader2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import Dashboard from "@/pages/dashboard";
import Catalog from "@/pages/catalog";
import Groups from "@/pages/groups";
import SupplierCatalogDashboard from "@/pages/supplier-catalog-dashboard";
import SupplierCatalog from "@/pages/supplier-catalog";
import ProductDetail from "@/pages/product-detail";
import ImportFeed from "@/pages/import-feed";
import Export from "@/pages/export";
import Translations from "@/pages/translations";
import AdminTools from "@/pages/admin-tools";
import Attributes from "@/pages/attributes";
import SettingsPage from "@/pages/settings";
import StoresPage from "@/pages/stores";
import Rivalries from "@/pages/rivalries";
import ReferenceData from "@/pages/reference-data";
import Images from "@/pages/images";
import Categories from "@/pages/categories";
import SyncLogs from "@/pages/sync-logs";
import ScheduledChanges from "@/pages/scheduled-changes";
import ApiKeysPage from "@/pages/api-keys";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import { AuthProvider, useAuth } from "@/hooks/useAuth";

function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/catalog" component={Catalog} />
      <Route path="/groups" component={Groups} />
      <Route path="/supplier-catalog" component={SupplierCatalog} />
      <Route path="/supplier-catalog/dashboard" component={SupplierCatalogDashboard} />
      <Route path="/product/:id" component={ProductDetail} />
      <Route path="/import-feed" component={ImportFeed} />
      <Route path="/export" component={Export} />
      <Route path="/attributes" component={Attributes} />
      <Route path="/translations" component={Translations} />
      <Route path="/stores" component={StoresPage} />
      <Route path="/stores/views" component={StoresPage} />
      <Route path="/stores/products" component={StoresPage} />
      <Route path="/stores/currency" component={StoresPage} />
      <Route path="/rivalries" component={Rivalries} />
      <Route path="/reference-data" component={ReferenceData} />
      <Route path="/images" component={Images} />
      <Route path="/categories" component={Categories} />
      <Route path="/admin-tools" component={AdminTools} />
      <Route path="/sync-logs" component={SyncLogs} />
      <Route path="/scheduled-changes" component={ScheduledChanges} />
      <Route path="/api-keys" component={ApiKeysPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function UserMenu() {
  const { user, logout } = useAuth();

  if (!user) return null;

  const initials = user.displayName
    ? user.displayName.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
    : user.email.slice(0, 2).toUpperCase();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="flex items-center gap-2 rounded-full border border-border px-1.5 py-1 focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          aria-label="Open user menu"
        >
          <Avatar className="h-9 w-9">
            <AvatarImage src={user.photo} alt={user.displayName} />
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col leading-tight">
            <span className="text-sm font-semibold">{user.displayName || "Workspace user"}</span>
            <span className="text-xs text-muted-foreground">{user.email}</span>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="cursor-pointer">Profile Settings</DropdownMenuItem>
        <DropdownMenuItem className="cursor-pointer">Preferences</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          className="cursor-pointer text-destructive focus:text-destructive"
          onSelect={(event) => {
            event.preventDefault();
            void logout();
          }}
        >
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface SearchResult {
  id: number | string;
  name: string;
  type: string;
  url: string;
}

interface SearchResults {
  products: SearchResult[];
  clubs: SearchResult[];
  brands: SearchResult[];
  productTypes: SearchResult[];
  groups: SearchResult[];
  genders: SearchResult[];
  colours: SearchResult[];
}

function SearchDropdown({
  query,
  results,
  isLoading,
  onResultClick,
  isOpen,
}: {
  query: string;
  results: SearchResults | null;
  isLoading: boolean;
  onResultClick: (url: string) => void;
  isOpen: boolean;
}) {
  const sections: Array<{ title: string; items: SearchResult[] }> = [];

  if (results) {
    if (results.products.length > 0) sections.push({ title: "Products", items: results.products });
    if (results.clubs.length > 0) sections.push({ title: "Teams", items: results.clubs });
    if (results.brands.length > 0) sections.push({ title: "Brands", items: results.brands });
    if (results.productTypes.length > 0) sections.push({ title: "Product Types", items: results.productTypes });
    if (results.groups.length > 0) sections.push({ title: "Groups", items: results.groups });
    if (results.genders.length > 0) sections.push({ title: "Genders", items: results.genders });
    if (results.colours.length > 0) sections.push({ title: "Colours", items: results.colours });
  }

  const hasResults = sections.length > 0;

  if (!isOpen || !query) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-md shadow-lg z-50 max-h-96 overflow-y-auto">
      {isLoading ? (
        <div className="flex items-center justify-center p-4 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin mr-2" />
          Searching...
        </div>
      ) : !hasResults ? (
        <div className="p-4 text-sm text-muted-foreground text-center">
          No results found for "{query}"
        </div>
      ) : (
        <div>
          {sections.map((section, idx) => (
            <div key={idx}>
              {idx > 0 && <div className="border-t border-border" />}
              <div className="px-3 py-2">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  {section.title}
                </h3>
                {section.items.map((item) => (
                  <button
                    key={`${item.type}-${item.id}`}
                    onClick={() => onResultClick(item.url)}
                    className="w-full text-left px-3 py-2 rounded-sm hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring text-sm transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-foreground truncate">{item.name}</span>
                      <span className="text-xs text-muted-foreground ml-2 shrink-0 bg-muted px-2 py-1 rounded">
                        {item.type}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProtectedApp() {
  const { user, loading } = useAuth();
  const [location, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  const historyStackRef = useRef<string[]>([]);
  const historyIndexRef = useRef(-1);
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);

  // Debounced search query for API
  const [debouncedQuery, setDebouncedQuery] = useState("");

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: searchResults, isLoading: isSearchLoading } = useQuery<SearchResults>({
    queryKey: ["search", debouncedQuery],
    queryFn: async () => {
      if (!debouncedQuery.trim()) {
        return {
          products: [],
          clubs: [],
          brands: [],
          productTypes: [],
          groups: [],
          genders: [],
          colours: [],
        };
      }
      const response = await fetch(`/api/search?q=${encodeURIComponent(debouncedQuery)}`);
      if (!response.ok) throw new Error("Search failed");
      return response.json();
    },
    enabled: !!debouncedQuery,
  });

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    };

    if (isSearchOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      return () => document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [isSearchOpen]);

  useEffect(() => {
    if (!loading && !user && location !== "/login") {
      const search = `?next=${encodeURIComponent(location || "/")}`;
      navigate(`/login${search}`);
    }
  }, [loading, user, location, navigate]);

  useEffect(() => {
    if (!loading && user && location === "/login") {
      navigate("/");
    }
  }, [loading, user, location, navigate]);

  useEffect(() => {
    const stack = historyStackRef.current;
    const currentIndex = historyIndexRef.current;

    if (currentIndex === -1) {
      stack.push(location);
      historyIndexRef.current = 0;
    } else if (stack[currentIndex] === location) {
      // no-op
    } else if (currentIndex < stack.length - 1 && stack[currentIndex + 1] === location) {
      historyIndexRef.current = currentIndex + 1;
    } else if (currentIndex > 0 && stack[currentIndex - 1] === location) {
      historyIndexRef.current = currentIndex - 1;
    } else {
      stack.splice(currentIndex + 1);
      stack.push(location);
      historyIndexRef.current = stack.length - 1;
    }

    const nextIndex = historyIndexRef.current;
    setCanGoBack(nextIndex > 0);
    setCanGoForward(nextIndex < stack.length - 1);
  }, [location]);

  if (loading || (!user && location !== "/login")) {
    return (
      <div className="flex h-screen items-center justify-center text-muted-foreground">
        Checking your session...
      </div>
    );
  }

  if (!user) return null;

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  const handleSearchSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSubmitting(true);
    setIsSearchOpen(false);
    const params = new URLSearchParams({ search: searchQuery.trim() });
    navigate(`/catalog?${params.toString()}`);
    setTimeout(() => setIsSubmitting(false), 300);
  };

  const handleSearchResultClick = (url: string) => {
    setIsSearchOpen(false);
    setSearchQuery("");
    navigate(url);
  };

  return (
    <SidebarProvider style={style as CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center justify-between gap-2 p-4 border-b sticky top-0 z-50 bg-background">
            <div className="flex items-center gap-3 flex-1">
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => window.history.back()}
                  disabled={!canGoBack}
                  aria-label="Go back"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => window.history.forward()}
                  disabled={!canGoForward}
                  aria-label="Go forward"
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
              <div ref={searchContainerRef} className="relative flex-1 max-w-xl">
                <form onSubmit={handleSearchSubmit} className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  <Input
                    type="search"
                    placeholder="Search by SKU, product name, team..."
                    className="pl-9 w-full"
                    value={searchQuery}
                    onChange={(event) => {
                      setSearchQuery(event.target.value);
                      setIsSearchOpen(true);
                    }}
                    onFocus={() => searchQuery && setIsSearchOpen(true)}
                    disabled={isSubmitting}
                    data-testid="input-global-search"
                  />
                </form>
                <SearchDropdown
                  query={searchQuery}
                  results={searchResults || null}
                  isLoading={isSearchLoading}
                  onResultClick={handleSearchResultClick}
                  isOpen={isSearchOpen}
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <ThemeToggle />
              <UserMenu />
            </div>
          </header>
          <main className="flex-1 overflow-y-auto overflow-x-hidden">
            <AppRoutes />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider defaultTheme="dark">
          <TooltipProvider>
            <Switch>
              <Route path="/login" component={Login} />
              <Route component={ProtectedApp} />
            </Switch>
            <Toaster />
            <ImportProgressWidget />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}
