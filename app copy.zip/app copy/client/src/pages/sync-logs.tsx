import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ChevronDown,
  ChevronRight,
  Search,
  RefreshCw,
  ChevronLeft,
  Check,
} from "lucide-react";
import type { AlumioSyncLog } from "@shared/schema_v2";
import { queryClient } from "@/lib/queryClient";

const PAGE_SIZE = 25;

function StatusBadge({ code }: { code: number }) {
  const isSuccess = code >= 200 && code < 300;
  return (
    <Badge
      variant={isSuccess ? "default" : "destructive"}
      data-testid={`badge-status-${code}`}
    >
      {code}
    </Badge>
  );
}

function formatDate(date: string | Date | null) {
  if (!date) return "—";
  const d = new Date(date);
  return d.toLocaleString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function JsonViewer({ data, label }: { data: unknown; label: string }) {
  if (data === null || data === undefined) {
    return <span className="text-muted-foreground text-sm">No {label.toLowerCase()}</span>;
  }
  return (
    <pre className="text-xs bg-muted rounded-md p-3 overflow-auto max-h-64 whitespace-pre-wrap break-all">
      {typeof data === "string" ? data : JSON.stringify(data, null, 2)}
    </pre>
  );
}

function ExpandedRow({ log }: { log: AlumioSyncLog }) {
  return (
    <TableRow data-testid={`row-expanded-${log.id}`}>
      <TableCell colSpan={10} className="bg-muted/30 p-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <h4 className="text-sm font-medium mb-2">Request Data</h4>
            <JsonViewer data={log.requestData} label="Request data" />
          </div>
          <div>
            <h4 className="text-sm font-medium mb-2">Response Data</h4>
            <JsonViewer data={log.responseData} label="Response data" />
          </div>
        </div>
        {log.responseMessage && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Response Message</h4>
            <p className="text-sm text-muted-foreground">{log.responseMessage}</p>
          </div>
        )}
      </TableCell>
    </TableRow>
  );
}

export default function SyncLogs() {
  const [page, setPage] = useState(0);
  const [operationType, setOperationType] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [skuSearch, setSkuSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [refreshState, setRefreshState] = useState<"idle" | "refreshing" | "done">("idle");
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const wasRefreshing = useRef(false);
  const successTimeout = useRef<ReturnType<typeof setTimeout>>();

  const queryParams = new URLSearchParams();
  queryParams.set("limit", String(PAGE_SIZE));
  queryParams.set("offset", String(page * PAGE_SIZE));
  if (operationType !== "all") queryParams.set("operationType", operationType);
  if (statusFilter !== "all") queryParams.set("statusFilter", statusFilter);
  if (skuSearch) queryParams.set("skuSearch", skuSearch);

  const queryUrl = `/api/alumio/sync-logs?${queryParams.toString()}`;

  const { data, isLoading, isFetching } = useQuery<{ logs: AlumioSyncLog[]; total: number }>({
    queryKey: ["/api/alumio/sync-logs", { page, operationType, statusFilter, skuSearch }],
    queryFn: async () => {
      const res = await fetch(queryUrl, { credentials: "include" });
      if (!res.ok) {
        const text = (await res.text()) || res.statusText;
        throw new Error(`${res.status}: ${text}`);
      }
      return res.json();
    },
  });

  useEffect(() => {
    if (refreshState === "refreshing" && isFetching) {
      wasRefreshing.current = true;
    }
    if (wasRefreshing.current && !isFetching) {
      wasRefreshing.current = false;
      setRefreshState("done");
      setLastRefreshed(new Date());
      if (successTimeout.current) clearTimeout(successTimeout.current);
      successTimeout.current = setTimeout(() => setRefreshState("idle"), 2000);
    }
  }, [isFetching, refreshState]);

  useEffect(() => {
    return () => {
      if (successTimeout.current) clearTimeout(successTimeout.current);
    };
  }, []);

  const handleRefresh = useCallback(() => {
    setRefreshState("refreshing");
    queryClient.invalidateQueries({ queryKey: ["/api/alumio/sync-logs"] });
  }, []);

  const logs = data?.logs ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  const toggleExpanded = (id: number) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSearch = () => {
    setSkuSearch(searchInput);
    setPage(0);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  return (
    <div className="flex flex-col h-full overflow-auto">
      <div className="p-6 space-y-4">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <h1 className="text-2xl font-semibold" data-testid="text-page-title">
            Sync Logs
          </h1>
          <div className="flex items-center gap-3">
            {lastRefreshed && (
              <span className="text-xs text-muted-foreground" data-testid="text-last-refreshed">
                Last refreshed: {lastRefreshed.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </span>
            )}
            <Button
              variant="outline"
              size="sm"
              disabled={refreshState === "refreshing"}
              onClick={handleRefresh}
              className={refreshState === "done" ? "border-green-500 bg-green-50 text-green-700 hover:bg-green-50 hover:text-green-700 dark:bg-green-950 dark:text-green-400 dark:border-green-700" : ""}
              data-testid="button-refresh-logs"
            >
              {refreshState === "done" ? (
                <Check className="h-4 w-4 mr-2" />
              ) : (
                <RefreshCw className={`h-4 w-4 mr-2 ${refreshState === "refreshing" ? "animate-spin" : ""}`} />
              )}
              {refreshState === "refreshing" ? "Refreshing..." : refreshState === "done" ? "Refreshed" : "Refresh"}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap items-end gap-4">
              <div className="space-y-1.5">
                <label className="text-sm text-muted-foreground">Operation</label>
                <Select
                  value={operationType}
                  onValueChange={(v) => {
                    setOperationType(v);
                    setPage(0);
                  }}
                >
                  <SelectTrigger className="w-[140px]" data-testid="select-operation-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" data-testid="select-operation-all">All</SelectItem>
                    <SelectItem value="create" data-testid="select-operation-create">Create</SelectItem>
                    <SelectItem value="update" data-testid="select-operation-update">Update</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm text-muted-foreground">Status</label>
                <Select
                  value={statusFilter}
                  onValueChange={(v) => {
                    setStatusFilter(v);
                    setPage(0);
                  }}
                >
                  <SelectTrigger className="w-[140px]" data-testid="select-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" data-testid="select-status-all">All</SelectItem>
                    <SelectItem value="success" data-testid="select-status-success">Success</SelectItem>
                    <SelectItem value="error" data-testid="select-status-error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 flex-1 min-w-[200px]">
                <label className="text-sm text-muted-foreground">SKU Search</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Search by SKU..."
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    data-testid="input-sku-search"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={handleSearch}
                    data-testid="button-search-sku"
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10"></TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Operation</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Error Source</TableHead>
                  <TableHead>Task ID</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Retries</TableHead>
                  <TableHead>SKU(s)</TableHead>
                  <TableHead>Message</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8 text-muted-foreground">
                      Loading sync logs...
                    </TableCell>
                  </TableRow>
                ) : logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8 text-muted-foreground">
                      No sync logs found
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => {
                    const isExpanded = expandedIds.has(log.id);
                    return (
                      <>
                        <TableRow
                          key={log.id}
                          className="cursor-pointer"
                          onClick={() => toggleExpanded(log.id)}
                          data-testid={`row-sync-log-${log.id}`}
                        >
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              data-testid={`button-expand-${log.id}`}
                            >
                              {isExpanded ? (
                                <ChevronDown className="h-4 w-4" />
                              ) : (
                                <ChevronRight className="h-4 w-4" />
                              )}
                            </Button>
                          </TableCell>
                          <TableCell className="text-sm whitespace-nowrap" data-testid={`text-date-${log.id}`}>
                            {formatDate(log.createdAt)}
                          </TableCell>
                          <TableCell data-testid={`text-operation-${log.id}`}>
                            {Array.isArray(log.operationType) && log.operationType.length > 0 ? (
                              <div className="flex flex-col gap-1">
                                {log.operationType.map((entry: { sku: string; operationType: string }, i: number) => (
                                  <div key={i} className="flex items-center gap-1.5">
                                    <Badge variant="outline" className="shrink-0">{entry.operationType}</Badge>
                                    <span className="text-xs text-muted-foreground font-mono truncate max-w-[140px]" title={entry.sku}>{entry.sku}</span>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <StatusBadge code={log.httpStatusCode} />
                          </TableCell>
                          <TableCell className="text-sm" data-testid={`text-error-source-${log.id}`}>
                            {log.errorSource ? (
                              <Badge variant={log.errorSource === "Magento" ? "destructive" : "outline"}>
                                {log.errorSource}
                              </Badge>
                            ) : "—"}
                          </TableCell>
                          <TableCell className="text-sm font-mono max-w-[180px] truncate" data-testid={`text-task-id-${log.id}`}>
                            {log.taskId || "—"}
                          </TableCell>
                          <TableCell className="text-sm whitespace-nowrap" data-testid={`text-duration-${log.id}`}>
                            {log.duration != null ? `${log.duration.toFixed(0)} ms` : "—"}
                          </TableCell>
                          <TableCell className="text-sm" data-testid={`text-retry-number-${log.id}`}>
                            {log.retryNumber != null ? log.retryNumber : "—"}
                          </TableCell>
                          <TableCell className="max-w-[200px]" data-testid={`text-skus-${log.id}`}>
                            <div className="flex flex-wrap gap-1">
                              {log.skus?.slice(0, 3).map((sku, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {sku}
                                </Badge>
                              ))}
                              {log.skus && log.skus.length > 3 && (
                                <Badge variant="secondary" className="text-xs">
                                  +{log.skus.length - 3} more
                                </Badge>
                              )}
                              {(!log.skus || log.skus.length === 0) && (
                                <span className="text-muted-foreground text-sm">—</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[300px] truncate text-sm" data-testid={`text-message-${log.id}`}>
                            {log.responseMessage || "—"}
                          </TableCell>
                        </TableRow>
                        {isExpanded && <ExpandedRow key={`expanded-${log.id}`} log={log} />}
                      </>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground" data-testid="text-pagination-info">
              Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, total)} of{" "}
              {total} logs
            </span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 0}
                onClick={() => setPage((p) => p - 1)}
                data-testid="button-prev-page"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages - 1}
                onClick={() => setPage((p) => p + 1)}
                data-testid="button-next-page"
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
