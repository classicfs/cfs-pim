import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatDistanceToNow } from "date-fns";
import { Loader2, CheckCircle, XCircle, Clock, Upload, X, ChevronLeft, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface ImportBatch {
  batchId: string;
  fileNames: string;
  uploadedAt: string;
  status: string;
  totalRows: number;
  appliedRows: number;
  invalidRows: number;
  errorMessage: string | null;
  startedAt: string | null;
  completedAt: string | null;
  uploadedBy: string | null;
}

interface StagingSummary {
  counts: {
    totalRows: number;
    validRows: number;
    invalidRows: number;
    newRows: number;
    updatedRows: number;
  };
  sampleRows: any[];
  columnOrder?: string[];
}

interface StagingRow {
  rowNumber: number;
  rowStatus: string;
  data: Record<string, any>;
  rawData?: Record<string, any>;
  errors: Array<{ fieldKey: string; errorCode: string; errorMessage: string }>;
}

interface StagingRowsResponse {
  rows: StagingRow[];
  columnOrder?: string[];
}

interface ImportAttributeOption {
  key: string;
  label: string;
  aliases?: string[];
}

const normalizeAttributeCode = (value: string) => {
  const trimmed = value.trim().replace(/\*+$/g, "");
  if (!trimmed) return trimmed;
  const cleaned = trimmed.replace(/[^\w]+/g, "_");
  return cleaned.replace(/_([a-zA-Z0-9])/g, (_, ch) => ch.toUpperCase());
};

export default function ImportFeed() {
  const { toast } = useToast();
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [queuedFiles, setQueuedFiles] = useState<File[]>([]);
  const [activeFile, setActiveFile] = useState<File | null>(null);
  const [initialQueueCount, setInitialQueueCount] = useState(0);
  const [isQueueUploading, setIsQueueUploading] = useState(false);
  const [isDragActive, setIsDragActive] = useState(false);
  const [currentBatchId, setCurrentBatchId] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [stagingRows, setStagingRows] = useState<StagingRow[]>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [columnMappings, setColumnMappings] = useState<Record<string, string | null>>({});
  const [ignoredColumns, setIgnoredColumns] = useState<string[]>([]);
  const [columnOrder, setColumnOrder] = useState<string[]>([]);
  const lastAppliedMappingRef = useRef<string>("");
  const uploadAbortRef = useRef<AbortController | null>(null);
  const uploadCancelledRef = useRef(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 25;

  const { data: batches, isLoading } = useQuery<ImportBatch[]>({
    queryKey: ["/api/import-feed"],
    refetchInterval: (query) => {
      const data = query.state.data;
      const hasActiveJobs = data?.some((b: ImportBatch) => b.status === 'pending' || b.status === 'processing');
      return hasActiveJobs ? 3000 : false;
    },
  });

  const { data: attributeOptions } = useQuery<ImportAttributeOption[]>({
    queryKey: ["/api/imports/attribute-options"],
    enabled: showPreview,
  });

  const { data: stagingSummary, isLoading: isLoadingSummary } = useQuery<StagingSummary>({
    queryKey: ["/api/imports", currentBatchId, "summary"],
    enabled: !!currentBatchId && showPreview,
  });

  useEffect(() => {
    setIgnoredColumns([]);
    setColumnOrder([]); // Reset columnOrder when batch changes
  }, [currentBatchId]);

  useEffect(() => {
    // Capture columnOrder from staging summary if not already set
    if (stagingSummary?.columnOrder && !columnOrder.length) {
      setColumnOrder(stagingSummary.columnOrder);
    }
  }, [stagingSummary]);

  const {
    data: stagingRowsResponse,
    isLoading: isLoadingRows,
    error: stagingRowsError,
    refetch: refetchStagingRows,
  } = useQuery<StagingRowsResponse>({
    queryKey: ["/api/imports", currentBatchId, "rows"],
    enabled: !!currentBatchId && showPreview,
    queryFn: async () => {
      const response = await fetch(`/api/imports/${currentBatchId}/rows?limit=200&offset=0`);
      if (!response.ok) {
        throw new Error("Failed to fetch staging rows");
      }
      return response.json();
    },
  });

  useEffect(() => {
    if (stagingRowsResponse?.rows) {
      setStagingRows(stagingRowsResponse.rows);
    }
    // Also capture columnOrder from the API response if not already set
    if (stagingRowsResponse?.columnOrder && !columnOrder.length) {
      setColumnOrder(stagingRowsResponse.columnOrder);
    }
  }, [stagingRowsResponse]);

  const previewColumns = useMemo(() => {
    if (stagingRows.length === 0) return [];

    const firstRow = stagingRows[0];
    const sourceData = firstRow.rawData ?? firstRow.data ?? {};
    const allColumns = new Set<string>(Object.keys(sourceData));

    // Collect all columns from all rows
    const orderedColumns: string[] = [];
    for (const row of stagingRows) {
      const rowData = row.rawData ?? row.data ?? {};
      Object.keys(rowData).forEach((key) => {
        if (!allColumns.has(key)) {
          allColumns.add(key);
        }
      });
    }

    // Use columnOrder from the CSV if available, otherwise fall back to first row keys
    if (columnOrder.length > 0) {
      // Start with the CSV column order
      for (const col of columnOrder) {
        if (allColumns.has(col)) {
          orderedColumns.push(col);
        }
      }
      // Add any additional columns found in later rows that weren't in the original CSV
      for (const col of Array.from(allColumns)) {
        if (!orderedColumns.includes(col)) {
          orderedColumns.push(col);
        }
      }
    } else {
      // Fallback: use the first row's keys and then add any additional columns
      for (const key of Object.keys(sourceData)) {
        orderedColumns.push(key);
      }
      for (const row of stagingRows.slice(1)) {
        const rowData = row.rawData ?? row.data ?? {};
        Object.keys(rowData).forEach((key) => {
          if (!orderedColumns.includes(key)) {
            orderedColumns.push(key);
          }
        });
      }
    }

    const hasVariantSku = allColumns.has("productVariantSku");
    const hasSku = allColumns.has("sku");
    const hasProductSku = allColumns.has("productSku");

    let finalColumns = orderedColumns;
    if (hasVariantSku && hasSku) {
      finalColumns = finalColumns.filter((col) => col !== "sku");
    }
    const hasAnyProductSku = allColumns.has("productSku") || allColumns.has("productSKU");
    if (!hasVariantSku && !hasSku && !hasAnyProductSku) {
      finalColumns = ["productVariantSku", ...finalColumns];
    }

    return finalColumns;
  }, [stagingRows, columnOrder]);

  const normalizedAttributeOptions = useMemo(() => {
    return (attributeOptions ?? []).map((option) => ({
      ...option,
      normalizedKey: option.key.toLowerCase(),
      normalizedCode: normalizeAttributeCode(option.key).toLowerCase(),
      normalizedAliases: (option.aliases ?? []).map((alias) => alias.toLowerCase()),
    }));
  }, [attributeOptions]);

  useEffect(() => {
    if (!normalizedAttributeOptions.length || previewColumns.length === 0) {
      return;
    }
    setColumnMappings((prev) => {
      let changed = false;
      const next: Record<string, string | null> = { ...prev };
      for (const column of previewColumns) {
        if (column in next) continue;
        const normalizedColumn = column.toLowerCase();
        const normalizedCode = normalizeAttributeCode(column).toLowerCase();
        const match = normalizedAttributeOptions.find(
          (option) =>
            option.normalizedKey === normalizedColumn ||
            option.normalizedCode === normalizedCode ||
            option.normalizedAliases.includes(normalizedColumn),
        );
        next[column] = match ? match.key : null;
        changed = true;
      }
      for (const column of Object.keys(next)) {
        if (!previewColumns.includes(column)) {
          delete next[column];
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [previewColumns, normalizedAttributeOptions]);

  const hasUnmappedColumns = useMemo(
    () =>
      previewColumns.some(
        (column) => !ignoredColumns.includes(column) && !columnMappings[column],
      ),
    [columnMappings, ignoredColumns, previewColumns],
  );

  const totalPages = useMemo(() => {
    if (!batches) return 1;
    return Math.ceil(batches.length / itemsPerPage);
  }, [batches, itemsPerPage]);

  const paginatedBatches = useMemo(() => {
    if (!batches) return [];
    const startIndex = (currentPage - 1) * itemsPerPage;
    return batches.slice(startIndex, startIndex + itemsPerPage);
  }, [batches, currentPage, itemsPerPage]);

  const buildMappedData = (
    rawData: Record<string, any>,
    mapping: Record<string, string | null>,
  ) => {
    const mapped: Record<string, any> = {};
    for (const [sourceKey, targetKey] of Object.entries(mapping)) {
      if (!targetKey) continue;
      if (!Object.prototype.hasOwnProperty.call(rawData, sourceKey)) continue;
      const value = rawData[sourceKey];
      if (value === undefined) continue;
      mapped[targetKey] = value;
    }
    return mapped;
  };

  const uploadListingSheetsMutation = useMutation({
    mutationFn: async (file: File) => {
      setUploadError(null);
      const formData = new FormData();
      formData.append("file", file);
      const controller = new AbortController();
      uploadAbortRef.current = controller;

      try {
        const response = await fetch("/api/imports/upload-listing-sheets", {
          method: "POST",
          body: formData,
          signal: controller.signal,
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Upload failed');
        }

        return response.json();
      } catch (error: any) {
        if (error?.name === "AbortError") {
          throw new Error("Upload cancelled");
        }
        throw error;
      } finally {
        if (uploadAbortRef.current === controller) {
          uploadAbortRef.current = null;
        }
      }
    },
    onSuccess: (data: { batchId: string; columnOrder?: string[]; counts: any; fileNames: string }) => {
      if (uploadCancelledRef.current) {
        uploadCancelledRef.current = false;
        return;
      }
      setCurrentBatchId(data.batchId);
      if (data.columnOrder) {
        setColumnOrder(data.columnOrder);
      }
      setShowPreview(true);
      setIsQueueUploading(false);
      setUploadError(null);
      toast({
        title: "Files uploaded successfully",
        description: `Ready to review ${data.counts.totalRows} rows`,
      });
    },
    onError: (error: Error) => {
      if (uploadCancelledRef.current || error.message === "Upload cancelled") {
        uploadCancelledRef.current = false;
        setIsQueueUploading(false);
        return;
      }
      setIsQueueUploading(false);
      setShowPreview(true);
      setCurrentBatchId(null);
      setStagingRows([]);
      setUploadError(error.message);
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const confirmImportMutation = useMutation({
    mutationFn: async (data: { batchId: string; fileNames: string }) => {
      const response = await fetch(`/api/imports/${data.batchId}/confirm`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileNames: data.fileNames }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Import confirmation failed');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/import-feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/product-colours"] });
      toast({
        title: "Import queued successfully",
        description: "Your import is now processing in the background",
      });

      advanceQueue();
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const applyColumnMappingMutation = useMutation({
    mutationFn: async (payload: { batchId: string; mapping: Record<string, string | null> }) => {
      const response = await fetch(`/api/imports/${payload.batchId}/column-mapping`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mapping: payload.mapping }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to apply column mapping");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/imports", currentBatchId, "summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/imports", currentBatchId, "rows"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Column mapping failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateRowMutation = useMutation({
    mutationFn: async (payload: {
      rowNumber: number;
      data: Record<string, any>;
      rawData?: Record<string, any>;
    }) => {
      if (!currentBatchId) {
        throw new Error("No active batch");
      }
      const response = await fetch(`/api/imports/${currentBatchId}/rows/${payload.rowNumber}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: payload.data, rawData: payload.rawData }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to update row");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/imports", currentBatchId, "summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/imports", currentBatchId, "rows"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Row update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!currentBatchId || !showPreview) {
      return;
    }
    if (Object.keys(columnMappings).length === 0) {
      return;
    }
    const serialized = `${currentBatchId}:${JSON.stringify(columnMappings)}`;
    if (lastAppliedMappingRef.current === serialized) {
      return;
    }
    lastAppliedMappingRef.current = serialized;
    applyColumnMappingMutation.mutate({ batchId: currentBatchId, mapping: columnMappings });
  }, [applyColumnMappingMutation, columnMappings, currentBatchId, showPreview]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge variant="default" className="bg-green-600 hover:bg-green-700" data-testid={`badge-status-completed`}>
            <CheckCircle className="w-3 h-3 mr-1" />
            Completed
          </Badge>
        );
      case 'processing':
        return (
          <Badge variant="default" className="bg-blue-600 hover:bg-blue-700" data-testid={`badge-status-processing`}>
            <Loader2 className="w-3 h-3 mr-1 animate-spin" />
            Processing
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive" data-testid={`badge-status-failed`}>
            <XCircle className="w-3 h-3 mr-1" />
            Failed
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="secondary" data-testid={`badge-status-pending`}>
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const handleFilesAdded = (files: FileList | File[]) => {
    const incoming = Array.from(files);
    if (incoming.length === 0) {
      return;
    }

    const csvFiles = incoming.filter((file) => file.name.toLowerCase().endsWith(".csv"));
    if (csvFiles.length === 0) {
      toast({
        title: "Invalid file type",
        description: "Please upload CSV files only.",
        variant: "destructive",
      });
      return;
    }

    if (csvFiles.length !== incoming.length) {
      toast({
        title: "Some files skipped",
        description: "Only CSV files were added to the queue.",
      });
    }

    setQueuedFiles((prev) => [...prev, ...csvFiles]);
  };

  const handleRemoveQueuedFile = (index: number) => {
    setQueuedFiles((prev) => prev.filter((_, fileIndex) => fileIndex !== index));
  };

  const handleUpload = () => {
    if (queuedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select one or more CSV files to upload",
        variant: "destructive",
      });
      return;
    }
    uploadCancelledRef.current = false;
    setInitialQueueCount(queuedFiles.length);
    setActiveFile(queuedFiles[0]);
    setCurrentBatchId(null);
    setStagingRows([]);
    setShowPreview(true);
    setUploadError(null);
    setColumnMappings({});
    lastAppliedMappingRef.current = "";
    setIsQueueUploading(true);
    uploadListingSheetsMutation.mutate(queuedFiles[0]);
  };

  const handleConfirm = () => {
    if (currentBatchId) {
      const fileNamesList = activeFile?.name || "";

      confirmImportMutation.mutate({ 
        batchId: currentBatchId,
        fileNames: fileNamesList || 'Listing sheets'
      });
    }
  };

  const handleCellChange = (rowNumber: number, column: string, value: string) => {
    setStagingRows((prev) =>
      prev.map((row) =>
        row.rowNumber === rowNumber
          ? (() => {
              const nextRawData = { ...(row.rawData ?? row.data ?? {}), [column]: value };
              const nextData = buildMappedData(nextRawData, columnMappings);
              return { ...row, rawData: nextRawData, data: nextData };
            })()
          : row,
      ),
    );
  };

  const handleRowSave = (rowNumber: number) => {
    const row = stagingRows.find((item) => item.rowNumber === rowNumber);
    if (row) {
      updateRowMutation.mutate({
        rowNumber,
        data: row.data,
        rawData: row.rawData ?? row.data,
      });
    }
  };

  const handleColumnMappingChange = (column: string, value: string) => {
    if (value === "__ignored__") {
      return;
    }
    const nextValue = value === "__unmapped__" ? null : value;
    setColumnMappings((prev) => {
      return { ...prev, [column]: nextValue };
    });
  };

  const handleIgnoreColumn = (column: string) => {
    setIgnoredColumns((prev) => (prev.includes(column) ? prev : [...prev, column]));
    setColumnMappings((prev) => {
      if (!(column in prev)) return prev;
      const next = { ...prev };
      next[column] = null;
      return next;
    });
  };

  const handleRestoreColumn = (column: string) => {
    setIgnoredColumns((prev) => prev.filter((item) => item !== column));
  };

  const resetQueueState = () => {
    uploadCancelledRef.current = false;
    uploadAbortRef.current = null;
    setIsQueueUploading(false);
    setShowPreview(false);
    setCurrentBatchId(null);
    setUploadDialogOpen(false);
    setQueuedFiles([]);
    setActiveFile(null);
    setInitialQueueCount(0);
    setStagingRows([]);
    setUploadError(null);
    setColumnMappings({});
    lastAppliedMappingRef.current = "";
  };

  const advanceQueue = () => {
    if (queuedFiles.length > 1) {
      const remainingFiles = queuedFiles.slice(1);
      setQueuedFiles(remainingFiles);
      setActiveFile(remainingFiles[0] || null);
      setCurrentBatchId(null);
      setStagingRows([]);
      setShowPreview(true);
      setUploadError(null);
      setColumnMappings({});
      lastAppliedMappingRef.current = "";
      if (remainingFiles[0]) {
        uploadCancelledRef.current = false;
        setIsQueueUploading(true);
        uploadListingSheetsMutation.mutate(remainingFiles[0]);
      }
    } else {
      resetQueueState();
    }
  };

  const handleCancelStaging = async () => {
    if (currentBatchId) {
      try {
        const response = await fetch(`/api/imports/${currentBatchId}/staging`, {
          method: 'DELETE',
        });
        
        if (response.ok) {
          resetQueueState();
          toast({
            title: "Import cancelled",
            description: "Staging data has been cleared",
          });
        }
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to cancel staging",
          variant: "destructive",
        });
      }
    }
  };

  const handleHardCancelUpload = async () => {
    uploadCancelledRef.current = true;
    if (uploadAbortRef.current) {
      uploadAbortRef.current.abort();
    }
    if (currentBatchId) {
      try {
        await fetch(`/api/imports/${currentBatchId}/staging`, {
          method: "DELETE",
        });
      } catch (error) {
        // Best-effort cleanup only.
      }
    }
    resetQueueState();
    toast({
      title: "Import cancelled",
      description: "Upload has been cancelled and staging cleared.",
    });
  };

  const handleSkipSheet = async () => {
    if (currentBatchId) {
      try {
        await fetch(`/api/imports/${currentBatchId}/staging`, {
          method: "DELETE",
        });
      } catch (error) {
        toast({
          title: "Skip failed",
          description: "Unable to clear staging data for this sheet.",
          variant: "destructive",
        });
      }
    }
    advanceQueue();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-import-feed">Import Feed</h1>
            <p className="text-muted-foreground mt-1">
              Track the status of your listing sheet imports
            </p>
          </div>
          <Button onClick={() => setUploadDialogOpen(true)} data-testid="button-upload-listing-sheets">
            <Upload className="h-4 w-4 mr-2" />
            Upload Listing Sheets
          </Button>
        </div>

        {!batches || batches.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-12 text-muted-foreground">
                <p>No imports yet</p>
                <p className="text-sm mt-2">Upload and confirm listing sheets to see import jobs here</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>File Names</TableHead>
                  <TableHead>Uploaded By</TableHead>
                  <TableHead>Uploaded</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Rows</TableHead>
                  <TableHead>Applied</TableHead>
                  <TableHead>Errors</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedBatches.map((batch) => (
                  <TableRow key={batch.batchId} data-testid={`row-import-${batch.batchId}`}>
                    <TableCell className="font-medium" data-testid={`text-filename-${batch.batchId}`}>
                      {batch.fileNames}
                    </TableCell>
                    <TableCell data-testid={`text-uploadedby-${batch.batchId}`} className="text-muted-foreground">
                      {batch.uploadedBy || "—"}
                    </TableCell>
                    <TableCell data-testid={`text-uploaded-${batch.batchId}`}>
                      {formatDistanceToNow(new Date(batch.uploadedAt), { addSuffix: true })}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(batch.status)}
                    </TableCell>
                    <TableCell data-testid={`text-row-count-${batch.batchId}`}>
                      {batch.status === 'processing' && batch.appliedRows > 0
                        ? `${batch.appliedRows} / ${batch.totalRows}`
                        : batch.totalRows}
                    </TableCell>
                    <TableCell data-testid={`text-applied-${batch.batchId}`}>
                      {batch.appliedRows}
                    </TableCell>
                    <TableCell data-testid={`text-errors-${batch.batchId}`} className={batch.invalidRows > 0 ? "text-destructive" : ""}>
                      {batch.invalidRows || 0}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {batches && batches.length > itemsPerPage && (
          <div className="flex items-center justify-between border-t pt-4">
            <span className="text-sm text-muted-foreground">
              Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, batches.length)} of {batches.length} imports
            </span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                data-testid="button-prev-page"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-muted-foreground px-2">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                data-testid="button-next-page"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

        <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
          <DialogContent
            className={
              showPreview
                ? "w-[96vw] max-w-[96vw] max-h-[94vh] flex flex-col overflow-hidden"
                : "max-w-2xl max-h-[85vh] flex flex-col overflow-hidden"
            }
          >
            <DialogHeader>
              <DialogTitle>Upload Listing Sheets</DialogTitle>
              <DialogDescription>
                {showPreview ? 
                  "Review the imported data before confirming" : 
                  "Upload one or more CSV files for listing sheet data (optional type column: products, categories, images, listings)"
                }
              </DialogDescription>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto overflow-x-auto min-h-0">

            {!showPreview ? (
              <div className="space-y-4">
                <FileUploadInput 
                  label="Listing Sheet CSV"
                  files={queuedFiles}
                  onFilesAdded={handleFilesAdded}
                  onRemoveFile={handleRemoveQueuedFile}
                  isDragActive={isDragActive}
                  onDragStateChange={setIsDragActive}
                  testId="listing-sheet"
                />
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium truncate max-w-[360px]">
                    {activeFile?.name || "Listing sheet"}
                  </span>
                  {initialQueueCount > 1 && (
                    <span className="text-muted-foreground">
                      Sheet {Math.max(1, initialQueueCount - queuedFiles.length + 1)} of {initialQueueCount}
                    </span>
                  )}
                </div>
                {isQueueUploading ? (
                  <div className="p-8 text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                    <p className="text-muted-foreground">Uploading next listing sheet...</p>
                  </div>
                ) : uploadError ? (
                  <Alert variant="destructive">
                    <AlertTitle>Upload failed</AlertTitle>
                    <AlertDescription>{uploadError}</AlertDescription>
                  </Alert>
                ) : isLoadingSummary ? (
                  <div className="p-8 text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
                    <p className="text-muted-foreground">Loading preview...</p>
                  </div>
                ) : stagingSummary && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Total:</span>
                        <span className="font-semibold" data-testid="text-preview-total">{stagingSummary.counts.totalRows}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">New:</span>
                        <span className="font-semibold" data-testid="text-preview-new">{stagingSummary.counts.newRows}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Updated:</span>
                        <span className="font-semibold" data-testid="text-preview-updated">{stagingSummary.counts.updatedRows}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Invalid:</span>
                        <span className={`font-semibold ${stagingSummary.counts.invalidRows > 0 ? "text-destructive" : ""}`} data-testid="text-preview-invalid">{stagingSummary.counts.invalidRows}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium">Staging Sheet</h4>
                        <span className="text-xs text-muted-foreground">
                          Edit cells to update staging data.
                        </span>
                      </div>
                      {ignoredColumns.length > 0 && (
                        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          <span>Ignored columns (not imported):</span>
                          {ignoredColumns.map((column) => (
                            <Button
                              key={column}
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => handleRestoreColumn(column)}
                              className="h-7 px-2"
                            >
                              {column}
                              <span className="ml-2 text-[10px] uppercase tracking-wide">Restore</span>
                            </Button>
                          ))}
                        </div>
                      )}
                      {hasUnmappedColumns && (
                        <Alert variant="destructive">
                          <AlertTitle>Unmapped columns</AlertTitle>
                          <AlertDescription>
                            Columns highlighted in red are missing an attribute mapping. Select an attribute from the dropdown to continue.
                          </AlertDescription>
                        </Alert>
                      )}
                      {isLoadingRows ? (
                        <div className="p-6 text-center">
                          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
                          <p className="text-muted-foreground text-sm">Loading rows...</p>
                        </div>
                      ) : stagingRowsError ? (
                        <Alert variant="destructive">
                          <AlertTitle>Failed to load staging rows</AlertTitle>
                          <AlertDescription>
                            Please try again. If this keeps happening, the upload may not have staged any rows.
                          </AlertDescription>
                          <div className="mt-3">
                            <Button variant="outline" onClick={() => refetchStagingRows()}>
                              Retry load
                            </Button>
                          </div>
                        </Alert>
                      ) : stagingRows.length === 0 ? (
                        <div className="p-6 text-center text-sm text-muted-foreground">
                          No staging rows available.
                        </div>
                      ) : (
                        <div className="border rounded-md relative">
                          <div className="overflow-x-auto">
                          <div className="overflow-y-auto max-h-[50vh]">
                          <Table>
                            <TableHeader className="sticky top-0 z-10 bg-background">
                              <TableRow>
                                <TableHead className="w-[80px]">Row</TableHead>
                                <TableHead className="w-[120px]">Status</TableHead>
                                {previewColumns.map((column) => (
                                <TableHead
                                  key={column}
                                  className={
                                    ignoredColumns.includes(column)
                                      ? "bg-muted/60 text-muted-foreground"
                                      : columnMappings[column]
                                        ? ""
                                        : "bg-destructive/10 text-destructive"
                                  }
                                >
                                    <div className="flex flex-col gap-2 min-w-[200px]">
                                      <div className="flex items-center justify-between gap-2">
                                        <span className="text-xs font-semibold">{column}</span>
                                        {ignoredColumns.includes(column) ? (
                                          <Button
                                            type="button"
                                            variant="ghost"
                                            size="sm"
                                            className="h-6 px-2 text-[10px] uppercase tracking-wide"
                                            onClick={() => handleRestoreColumn(column)}
                                          >
                                            Restore
                                          </Button>
                                        ) : (
                                          <Button
                                            type="button"
                                            variant="ghost"
                                            size="sm"
                                            className="h-6 px-2 text-[10px] uppercase tracking-wide"
                                            onClick={() => handleIgnoreColumn(column)}
                                          >
                                            Ignore
                                          </Button>
                                        )}
                                      </div>
                                      <Select
                                        value={
                                          ignoredColumns.includes(column)
                                            ? "__ignored__"
                                            : columnMappings[column] ?? "__unmapped__"
                                        }
                                        onValueChange={(value) => handleColumnMappingChange(column, value)}
                                        disabled={ignoredColumns.includes(column)}
                                      >
                                        <SelectTrigger className="h-8 text-xs">
                                          <SelectValue placeholder="Select attribute" />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="__ignored__">Ignored</SelectItem>
                                          <SelectItem value="__unmapped__">Null</SelectItem>
                                          {(attributeOptions ?? []).map((option) => (
                                            <SelectItem key={option.key} value={option.key}>
                                              {option.label}
                                            </SelectItem>
                                          ))}
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </TableHead>
                                ))}
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {stagingRows.map((row) => (
                                <TableRow key={row.rowNumber}>
                                  <TableCell className="text-xs text-muted-foreground">
                                    {row.rowNumber}
                                  </TableCell>
                                  <TableCell>
                                    <Badge
                                      variant={row.rowStatus === "invalid" ? "destructive" : "secondary"}
                                    >
                                      {row.rowStatus}
                                    </Badge>
                                  </TableCell>
                                  {previewColumns.map((column) => {
                                    const mappedKey = columnMappings[column] ?? column;
                                    const cellError = row.errors.find((error) => error.fieldKey === mappedKey);
                                    const isUnmapped = !columnMappings[column];
                                    const isIgnored = ignoredColumns.includes(column);
                                    const sourceData = row.rawData ?? row.data ?? {};
                                    return (
                                      <TableCell
                                        key={`${row.rowNumber}-${column}`}
                                        className={
                                          isIgnored
                                            ? "bg-muted/60 text-muted-foreground"
                                            : isUnmapped
                                              ? "bg-destructive/5"
                                              : ""
                                        }
                                      >
                                        <Input
                                          value={sourceData?.[column] ?? ""}
                                          onChange={(event) =>
                                            handleCellChange(row.rowNumber, column, event.target.value)
                                          }
                                          onBlur={() => handleRowSave(row.rowNumber)}
                                          disabled={isIgnored}
                                          className={
                                            cellError
                                              ? "border-destructive focus-visible:ring-destructive min-w-[160px] w-[220px]"
                                              : isIgnored
                                                ? "min-w-[160px] w-[220px] opacity-60"
                                                : isUnmapped
                                                  ? "border-destructive/60 focus-visible:ring-destructive min-w-[160px] w-[220px]"
                                                  : "min-w-[160px] w-[220px]"
                                          }
                                        />
                                        {cellError && (
                                          <p className="text-xs text-destructive mt-1">
                                            {cellError.errorMessage}
                                          </p>
                                        )}
                                      </TableCell>
                                    );
                                  })}
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                        </div>
                        </div>
                      )}
                    </div>
                    {(stagingSummary?.counts.invalidRows ?? 0) > 0 && (
                      <p className="text-sm text-destructive">
                        Fix rows missing product_variant_sku or product_sku before confirming the import.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            </div>
            <DialogFooter>
              {!showPreview ? (
                <>
                  <Button 
                    variant="outline" 
                    onClick={() => setUploadDialogOpen(false)}
                    data-testid="button-cancel-upload"
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleUpload}
                    disabled={uploadListingSheetsMutation.isPending || queuedFiles.length === 0}
                    data-testid="button-submit-upload"
                  >
                    {uploadListingSheetsMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      'Upload CSV'
                    )}
                  </Button>
                </>
              ) : (
                <>
                  {(applyColumnMappingMutation.isPending || isLoadingRows || isLoadingSummary) && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mr-auto">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      {applyColumnMappingMutation.isPending
                        ? "Applying column mappings..."
                        : isLoadingRows
                          ? "Loading preview rows..."
                          : "Loading summary..."}
                    </div>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSkipSheet}
                    disabled={isQueueUploading}
                    data-testid="button-skip-sheet"
                  >
                    Skip Sheet
                  </Button>
                  <Button 
                    variant="outline"
                    size="sm"
                    onClick={handleCancelStaging}
                    disabled={isQueueUploading}
                    data-testid="button-cancel-staging"
                  >
                    Cancel Import
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleConfirm}
                    disabled={
                      isQueueUploading ||
                      !currentBatchId ||
                      confirmImportMutation.isPending ||
                      (stagingSummary?.counts.invalidRows ?? 0) > 0 ||
                      hasUnmappedColumns ||
                      applyColumnMappingMutation.isPending
                    }
                    data-testid="button-confirm-import"
                  >
                    {confirmImportMutation.isPending ? (
                      <>
                        <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        Confirming...
                      </>
                    ) : (
                      'Confirm Import'
                    )}
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}

interface FileUploadInputProps {
  label: string;
  files: File[];
  onFilesAdded: (files: FileList | File[]) => void;
  onRemoveFile: (index: number) => void;
  isDragActive: boolean;
  onDragStateChange: (isActive: boolean) => void;
  testId: string;
}

function FileUploadInput({
  label,
  files,
  onFilesAdded,
  onRemoveFile,
  isDragActive,
  onDragStateChange,
  testId,
}: FileUploadInputProps) {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition ${
          isDragActive ? "border-primary bg-primary/5" : "border-muted-foreground/30"
        }`}
        onDragOver={(event) => {
          event.preventDefault();
          onDragStateChange(true);
        }}
        onDragLeave={() => onDragStateChange(false)}
        onDrop={(event) => {
          event.preventDefault();
          onDragStateChange(false);
          onFilesAdded(event.dataTransfer.files);
        }}
      >
        <input
          type="file"
          accept=".csv"
          multiple
          onChange={(event) => {
            if (event.target.files) {
              onFilesAdded(event.target.files);
              event.target.value = "";
            }
          }}
          className="hidden"
          id={`file-input-${testId}`}
          data-testid={`input-file-${testId}`}
        />
        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
        <p className="text-sm font-medium">Drag and drop listing sheets here</p>
        <p className="text-xs text-muted-foreground mt-1">CSV files only. You can add multiple files.</p>
        <Button
          variant="outline"
          onClick={() => document.getElementById(`file-input-${testId}`)?.click()}
          className="mt-4"
          data-testid={`button-select-${testId}`}
        >
          Choose files
        </Button>
      </div>
      {files.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            {files.length} file{files.length === 1 ? "" : "s"} queued
          </p>
          <div className="border rounded-md divide-y">
            {files.map((file, index) => (
              <div key={`${file.name}-${file.lastModified}-${index}`} className="flex items-center gap-2 px-3 py-2">
                <span className="text-sm truncate flex-1">{file.name}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemoveFile(index)}
                  data-testid={`button-remove-${testId}-${index}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
