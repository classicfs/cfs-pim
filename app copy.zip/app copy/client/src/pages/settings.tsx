import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PlusCircle, RefreshCw, CheckCircle2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

const timezoneOptions = ["UTC", "Europe/London", "Europe/Paris", "America/New_York", "Asia/Tokyo"];
const languageOptions = ["English", "French", "Spanish", "German", "Japanese"];
const currencies = ["GBP", "EUR", "USD"];
const dateFormats = ["DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD"];

type WorkspaceUser = {
  id: number;
  name: string;
  email: string;
  department: string | null;
  roles: string[];
  status: string | null;
  lastLogin: string | null;
};

type WorkspaceRole = {
  id: string;
  name: string;
  description: string;
  permissions: Array<{
    id: number;
    code: string;
    name: string;
    description: string;
  }>;
};

type WorkspacePermission = {
  id: number;
  code: string;
  name: string | null;
  description: string | null;
};

type PermissionDomainGroup = {
  domain: string;
  label: string;
  permissions: WorkspacePermission[];
};

const domainLabels: Record<string, string> = {
  catalog: "Products & Catalog",
  import: "Imports",
  category: "Categories",
  pricing: "Pricing",
  stock: "Inventory / Stock",
  store: "Stores & Currencies",
  image: "Images",
  refdata: "Reference Data",
  user: "User Management",
  role: "Role Management",
};

const domainOrder = Object.keys(domainLabels);

function titleize(value: string) {
  return value
    .replace(/[-_.:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function getPermissionDomainGroups(permissions: WorkspacePermission[]): PermissionDomainGroup[] {
  const groups = new Map<string, PermissionDomainGroup>();

  for (const permission of permissions) {
    const separatorIndex = permission.code.indexOf(":");
    const domain = separatorIndex > 0 ? permission.code.slice(0, separatorIndex) : permission.code;
    const key = domain.toLowerCase();

    if (!groups.has(key)) {
      groups.set(key, {
        domain: key,
        label: domainLabels[key] || titleize(key),
        permissions: [],
      });
    }

    groups.get(key)!.permissions.push(permission);
  }

  return Array.from(groups.values()).sort((a, b) => {
    const aIndex = domainOrder.indexOf(a.domain);
    const bIndex = domainOrder.indexOf(b.domain);
    const aOrder = aIndex >= 0 ? aIndex : 999;
    const bOrder = bIndex >= 0 ? bIndex : 999;
    if (aOrder !== bOrder) return aOrder - bOrder;
    return a.label.localeCompare(b.label);
  });
}

function getActionLabel(code: string): string {
  const separatorIndex = code.indexOf(":");
  if (separatorIndex < 0) return code;
  const action = code.slice(separatorIndex + 1);
  return titleize(action.replace(/_/g, " "));
}


type ConversionRateRecord = {
  conversionRateId: number;
  fromCurrencyId: number;
  toCurrencyId: number;
  fromCurrencyCode: string | null;
  toCurrencyCode: string | null;
  rate: string;
  updatedAt: string | null;
};

type CurrencyRecord = {
  currencyId: number;
  code: string;
  name: string | null;
  symbol: string | null;
  enabled: boolean;
};

function GeneralSettingsTab() {
  const { data: conversionRates = [], isLoading: ratesLoading } = useQuery<ConversionRateRecord[]>({
    queryKey: ["/api/conversion-rates"],
  });

  const { data: allCurrencies = [] } = useQuery<CurrencyRecord[]>({
    queryKey: ["/api/currencies"],
  });

  const gbpCurrency = allCurrencies.find(c => c.code === "GBP");

  const [draftRates, setDraftRates] = useState<Record<string, string>>({});

  useEffect(() => {
    if (conversionRates.length > 0) {
      const draft: Record<string, string> = {};
      for (const rate of conversionRates) {
        if (rate.toCurrencyCode) {
          draft[rate.toCurrencyCode] = rate.rate;
        }
      }
      setDraftRates(prev => {
        const merged = { ...draft };
        for (const key of Object.keys(prev)) {
          if (!(key in merged)) {
            merged[key] = prev[key];
          }
        }
        return merged;
      });
    }
  }, [conversionRates]);

  const targetCurrencies = allCurrencies.filter(c => c.code !== "GBP" && c.enabled);

  const saveRatesMutation = useMutation({
    mutationFn: async () => {
      if (!gbpCurrency) throw new Error("GBP currency not found");
      const rates = targetCurrencies
        .filter(c => draftRates[c.code] && Number(draftRates[c.code]) > 0)
        .map(c => ({
          fromCurrencyId: gbpCurrency.currencyId,
          toCurrencyId: c.currencyId,
          rate: draftRates[c.code],
        }));
      const response = await fetch("/api/conversion-rates", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rates }),
      });
      if (!response.ok) throw new Error("Failed to save rates");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversion-rates"] });
    },
  });

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Regional settings</CardTitle>
          <CardDescription>Customize the defaults for timezone, currency, and locale.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Timezone</Label>
            <Select defaultValue="Europe/London">
              <SelectTrigger>
                <SelectValue placeholder="Select timezone" />
              </SelectTrigger>
              <SelectContent>
                {timezoneOptions.map((tz) => (
                  <SelectItem key={tz} value={tz}>
                    {tz}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Primary currency</Label>
            <Select defaultValue="GBP">
              <SelectTrigger>
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((cur) => (
                  <SelectItem key={cur} value={cur}>
                    {cur}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Date format</Label>
            <Select defaultValue={dateFormats[0]}>
              <SelectTrigger>
                <SelectValue placeholder="Select date format" />
              </SelectTrigger>
              <SelectContent>
                {dateFormats.map((format) => (
                  <SelectItem key={format} value={format}>
                    {format}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Language</Label>
            <Select defaultValue="English">
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {languageOptions.map((language) => (
                  <SelectItem key={language} value={language}>
                    {language}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notification preferences</CardTitle>
          <CardDescription>Decide how StockFlow keeps you up to date.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <Label>Email notifications</Label>
              <p className="text-sm text-muted-foreground">Important alerts and escalations to your inbox.</p>
            </div>
            <Switch defaultChecked />
          </div>
          <Separator />
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <Label>In-app notifications</Label>
              <p className="text-sm text-muted-foreground">Show toast and inbox updates inside the workspace.</p>
            </div>
            <Switch defaultChecked />
          </div>
          <Separator />
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <Label>Daily summary email</Label>
              <p className="text-sm text-muted-foreground">Digest of assignments, approvals, and SLA flags.</p>
            </div>
            <Switch />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Currency conversion rates</CardTitle>
          <CardDescription>
            Set GBP conversion rates for other currencies. When a product is uploaded with only a GBP price,
            these rates will be used to automatically calculate prices in other currencies.
            Manually overridden prices on individual variants will not be affected.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          {ratesLoading ? (
            <p className="text-sm text-muted-foreground md:col-span-2">Loading rates...</p>
          ) : targetCurrencies.length === 0 ? (
            <p className="text-sm text-muted-foreground md:col-span-2">No target currencies configured. Enable currencies in the Stores section.</p>
          ) : (
            targetCurrencies.map(tc => (
              <div key={tc.currencyId} className="space-y-2">
                <Label htmlFor={`rate-${tc.code}`}>GBP to {tc.code}</Label>
                <Input
                  id={`rate-${tc.code}`}
                  data-testid={`input-rate-${tc.code}`}
                  type="number"
                  step="0.0001"
                  min="0"
                  value={draftRates[tc.code] ?? ""}
                  onChange={(e) =>
                    setDraftRates(prev => ({ ...prev, [tc.code]: e.target.value }))
                  }
                  placeholder="e.g. 1.16"
                />
              </div>
            ))
          )}
          <div className="md:col-span-2 flex justify-end">
            <Button
              data-testid="button-save-conversion-rates"
              onClick={() => saveRatesMutation.mutate()}
              disabled={saveRatesMutation.isPending || targetCurrencies.length === 0}
            >
              {saveRatesMutation.isPending ? "Saving..." : "Save conversion rates"}
            </Button>
          </div>
          {saveRatesMutation.isSuccess && (
            <p className="text-sm text-muted-foreground md:col-span-2">Conversion rates saved successfully.</p>
          )}
          {saveRatesMutation.isError && (
            <p className="text-sm text-destructive md:col-span-2">Failed to save conversion rates.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function UsersTab() {
  const { refresh } = useAuth();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const { data: users = [], isLoading: usersLoading, refetch } = useQuery<WorkspaceUser[]>({
    queryKey: ["/api/workspace/users"],
  });
  const { data: roles = [] } = useQuery<WorkspaceRole[]>({
    queryKey: ["/api/workspace/roles"],
  });
  const [selectedUser, setSelectedUser] = useState<WorkspaceUser | null>(null);
  const [selectedRoleCode, setSelectedRoleCode] = useState("");
  const [isManageOpen, setIsManageOpen] = useState(false);

  const assignRoleMutation = useMutation({
    mutationFn: async () => {
      if (!selectedUser || !selectedRoleCode) return null;
      const response = await fetch(`/api/workspace/users/${selectedUser.id}/roles`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roleCode: selectedRoleCode }),
      });

      if (!response.ok) {
        const contentType = response.headers.get("content-type") || "";
        if (contentType.includes("application/json")) {
          const error = await response.json();
          throw new Error(error.error || error.message || "Failed to assign role");
        }
        const text = await response.text();
        throw new Error(text || "Failed to assign role");
      }

      return response.json();
    },
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspace/users"] });
      await refresh();
      setIsManageOpen(false);
      setSelectedRoleCode("");
    },
  });

  useEffect(() => {
    if (!isManageOpen) {
      setSelectedRoleCode("");
      setSelectedUser(null);
      assignRoleMutation.reset();
    }
  }, [assignRoleMutation, isManageOpen]);

  useEffect(() => {
    if (isManageOpen && roles.length > 0 && !selectedRoleCode) {
      setSelectedRoleCode(roles[0].id);
    }
  }, [isManageOpen, roles, selectedRoleCode]);

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const matchesStatus = statusFilter === "all" || user.status === statusFilter;
      const matchesSearch =
        !search ||
        user.name.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [search, statusFilter, users]);

  return (
    <Card className="space-y-4">
      <CardHeader>
        <CardTitle>User directory</CardTitle>
        <CardDescription>Manage workspace access, departments, and credentials.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-1 gap-3">
            <Input
              placeholder="Search by name or email"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              className="max-w-sm"
            />
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as typeof statusFilter)}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All users</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" className="gap-2" onClick={() => void refetch()}>
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Department</TableHead>
                <TableHead>Roles</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last login</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium">{user.name}</span>
                      <span className="text-xs text-muted-foreground">{user.email}</span>
                    </div>
                  </TableCell>
                  <TableCell>{user.department}</TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {user.roles.map((role) => (
                        <Badge key={role} variant="secondary">
                          {role}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.status === "active" ? "secondary" : "outline"}>
                      {user.status === "active" ? "Active" : user.status ? "Inactive" : "Unknown"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {user.lastLogin ? new Date(user.lastLogin).toLocaleString() : "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(user);
                        setIsManageOpen(true);
                      }}
                    >
                      Manage
                    </Button>
                  </TableCell>
                </TableRow>
            ))}
          </TableBody>
        </Table>
        {!usersLoading && filteredUsers.length === 0 && (
          <div className="p-6 text-center text-sm text-muted-foreground">No users found.</div>
        )}
        {usersLoading && (
          <div className="p-6 text-center text-sm text-muted-foreground">Loading users...</div>
        )}
      </div>
    </CardContent>
    <Dialog open={isManageOpen} onOpenChange={setIsManageOpen}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Manage user access</DialogTitle>
          <DialogDescription>
            Apply a role to {selectedUser?.name || "this user"}.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={selectedRoleCode} onValueChange={setSelectedRoleCode}>
              <SelectTrigger>
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                {roles.map((role) => (
                  <SelectItem key={role.id} value={role.id}>
                    {role.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {assignRoleMutation.isError && (
            <div className="text-sm text-destructive">
              {(assignRoleMutation.error as Error)?.message || "Failed to assign role."}
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsManageOpen(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => assignRoleMutation.mutate()}
            disabled={!selectedUser || !selectedRoleCode || assignRoleMutation.isPending}
          >
            {assignRoleMutation.isPending ? "Applying..." : "Apply role"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </Card>
  );
}

function AccessControlTab() {
  const { data: roles = [], isLoading: rolesLoading } = useQuery<WorkspaceRole[]>({
    queryKey: ["/api/workspace/roles"],
  });
  const { data: permissions = [] } = useQuery<WorkspacePermission[]>({
    queryKey: ["/api/workspace/permissions"],
  });
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const selectedRole = roles.find((role) => role.id === selectedRoleId) ?? roles[0];
  const permissionGroups = useMemo(() => getPermissionDomainGroups(permissions), [permissions]);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [newRoleCode, setNewRoleCode] = useState("");
  const [newRoleName, setNewRoleName] = useState("");
  const [newRoleDescription, setNewRoleDescription] = useState("");
  const [newRolePermissionIds, setNewRolePermissionIds] = useState<number[]>([]);
  const [draftName, setDraftName] = useState("");
  const [draftDescription, setDraftDescription] = useState("");
  const [draftPermissionIds, setDraftPermissionIds] = useState<number[]>([]);

  useEffect(() => {
    if (!selectedRoleId && roles.length > 0) {
      setSelectedRoleId(roles[0].id);
    }
  }, [roles, selectedRoleId]);

  useEffect(() => {
    if (!selectedRole) {
      setDraftName("");
      setDraftDescription("");
      setDraftPermissionIds([]);
      return;
    }

    setDraftName(selectedRole.name ?? "");
    setDraftDescription(selectedRole.description ?? "");
    setDraftPermissionIds(selectedRole.permissions.map((permission) => permission.id));
  }, [selectedRole?.id]);

  const createRoleMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/workspace/roles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: newRoleCode,
          name: newRoleName,
          description: newRoleDescription || null,
          permissionIds: newRolePermissionIds,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to create role");
      }

      return response.json();
    },
    onSuccess: () => {
      setIsCreateOpen(false);
      setNewRoleCode("");
      setNewRoleName("");
      setNewRoleDescription("");
      setNewRolePermissionIds([]);
      queryClient.invalidateQueries({ queryKey: ["/api/workspace/roles"] });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async () => {
      if (!selectedRole) return null;
      const response = await fetch(`/api/workspace/roles/${selectedRole.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: draftName,
          description: draftDescription,
          permissionIds: draftPermissionIds,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Failed to update role");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspace/roles"] });
    },
  });

  const assignedPermissions = useMemo(() => new Set(draftPermissionIds), [draftPermissionIds]);

  const togglePermission = (
    permissionId: number,
    checked: boolean,
    ids: number[],
    setIds: (ids: number[]) => void,
  ) => {
    if (checked) {
      setIds(Array.from(new Set([...ids, permissionId])));
    } else {
      setIds(ids.filter((id) => id !== permissionId));
    }
  };

  const toggleAllInDomain = (
    domainPermissions: WorkspacePermission[],
    checked: boolean,
    ids: number[],
    setIds: (ids: number[]) => void,
  ) => {
    const domainIds = domainPermissions.map((p) => p.id);
    if (checked) {
      setIds(Array.from(new Set([...ids, ...domainIds])));
    } else {
      const removeSet = new Set(domainIds);
      setIds(ids.filter((id) => !removeSet.has(id)));
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[280px,1fr]">
      <Card className="h-fit">
        <CardHeader className="space-y-3">
          <div>
            <CardTitle>Roles</CardTitle>
            <CardDescription>Browse roles and manage access levels.</CardDescription>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="w-full gap-2"
            onClick={() => setIsCreateOpen(true)}
            data-testid="button-new-role"
          >
            <PlusCircle className="h-4 w-4" />
            New role
          </Button>
        </CardHeader>
        <CardContent className="space-y-1">
          {roles.map((role) => (
            <button
              key={role.id}
              className={`w-full rounded-lg border px-3 py-2 text-left hover-elevate ${
                selectedRoleId === role.id ? "border-primary bg-primary/10" : "border-transparent"
              }`}
              onClick={() => setSelectedRoleId(role.id)}
              data-testid={`button-role-${role.id}`}
            >
              <p className="font-semibold leading-tight">{role.name}</p>
              <span className="text-xs uppercase tracking-wide text-muted-foreground">{role.id}</span>
            </button>
          ))}
          {!rolesLoading && roles.length === 0 && (
            <div className="p-4 text-sm text-muted-foreground">No roles found.</div>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-hidden">
        <CardHeader>
          <div className="flex items-center justify-between gap-4">
            <div>
              <CardTitle>{draftName || selectedRole?.name || "Role details"}</CardTitle>
              <CardDescription className="flex flex-col gap-1">
                <span className="uppercase text-xs tracking-wide">{selectedRole?.id || "—"}</span>
                <span>{draftDescription || selectedRole?.description || "No description available."}</span>
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              disabled={!selectedRole || updateRoleMutation.isPending}
              onClick={() => updateRoleMutation.mutate()}
              data-testid="button-save-role"
            >
              {updateRoleMutation.isPending ? "Saving..." : "Save changes"}
            </Button>
          </div>
        </CardHeader>
        <Separator />
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Display name</Label>
              <Input
                value={draftName}
                onChange={(event) => setDraftName(event.target.value)}
                disabled={!selectedRole}
              />
            </div>
            <div className="space-y-2">
              <Label>Role identifier</Label>
              <Input value={selectedRole?.id?.toUpperCase() || ""} disabled />
            </div>
            <div className="md:col-span-2 space-y-2">
              <Label>Description</Label>
              <Textarea
                value={draftDescription}
                onChange={(event) => setDraftDescription(event.target.value)}
                rows={3}
                disabled={!selectedRole}
              />
            </div>
          </div>
          <ScrollArea className="h-[400px] rounded-lg border">
            <div className="divide-y">
              {permissionGroups.map((group) => {
                const allChecked = group.permissions.every((p) => assignedPermissions.has(p.id));
                const someChecked = group.permissions.some((p) => assignedPermissions.has(p.id));
                return (
                  <div key={group.domain} className="px-4 py-3">
                    <div className="flex items-center gap-3 mb-2">
                      <input
                        type="checkbox"
                        checked={allChecked}
                        ref={(el) => { if (el) el.indeterminate = someChecked && !allChecked; }}
                        disabled={!selectedRole}
                        onChange={(event) =>
                          toggleAllInDomain(group.permissions, event.target.checked, draftPermissionIds, setDraftPermissionIds)
                        }
                        data-testid={`checkbox-domain-${group.domain}`}
                      />
                      <span className="text-sm font-semibold">{group.label}</span>
                    </div>
                    <div className="ml-6 grid gap-1.5">
                      {group.permissions.map((permission) => (
                        <label key={permission.id} className="flex items-center gap-2 text-sm cursor-pointer">
                          <input
                            type="checkbox"
                            checked={assignedPermissions.has(permission.id)}
                            disabled={!selectedRole}
                            onChange={(event) =>
                              togglePermission(permission.id, event.target.checked, draftPermissionIds, setDraftPermissionIds)
                            }
                            data-testid={`checkbox-perm-${permission.code}`}
                          />
                          <span className="font-medium">{getActionLabel(permission.code)}</span>
                          {permission.description && (
                            <span className="text-muted-foreground">— {permission.description}</span>
                          )}
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
          {!rolesLoading && selectedRole && permissionGroups.length === 0 && (
            <div className="text-sm text-muted-foreground">No permissions available.</div>
          )}
          {rolesLoading && (
            <div className="text-sm text-muted-foreground">Loading roles...</div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create role</DialogTitle>
            <DialogDescription>
              Define a role code, name, and assign the permissions it should include.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Role code</Label>
              <Input
                placeholder="ADMIN"
                value={newRoleCode}
                onChange={(event) => setNewRoleCode(event.target.value)}
                data-testid="input-role-code"
              />
            </div>
            <div className="space-y-2">
              <Label>Role name</Label>
              <Input
                placeholder="Administrator"
                value={newRoleName}
                onChange={(event) => setNewRoleName(event.target.value)}
                data-testid="input-role-name"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                rows={3}
                placeholder="Optional description"
                value={newRoleDescription}
                onChange={(event) => setNewRoleDescription(event.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Permissions</Label>
              <div className="max-h-64 overflow-auto rounded-lg border divide-y">
                {permissionGroups.map((group) => {
                  const allChecked = group.permissions.every((p) => newRolePermissionIds.includes(p.id));
                  const someChecked = group.permissions.some((p) => newRolePermissionIds.includes(p.id));
                  return (
                    <div key={group.domain} className="px-3 py-2.5">
                      <div className="flex items-center gap-2 mb-1.5">
                        <input
                          type="checkbox"
                          checked={allChecked}
                          ref={(el) => { if (el) el.indeterminate = someChecked && !allChecked; }}
                          onChange={(event) =>
                            toggleAllInDomain(group.permissions, event.target.checked, newRolePermissionIds, setNewRolePermissionIds)
                          }
                          data-testid={`checkbox-new-domain-${group.domain}`}
                        />
                        <span className="text-sm font-semibold">{group.label}</span>
                      </div>
                      <div className="ml-5 grid gap-1">
                        {group.permissions.map((permission) => (
                          <label key={permission.id} className="flex items-center gap-2 text-sm cursor-pointer">
                            <input
                              type="checkbox"
                              checked={newRolePermissionIds.includes(permission.id)}
                              onChange={(event) =>
                                togglePermission(permission.id, event.target.checked, newRolePermissionIds, setNewRolePermissionIds)
                              }
                              data-testid={`checkbox-new-perm-${permission.code}`}
                            />
                            <span>{getActionLabel(permission.code)}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  );
                })}
                {permissionGroups.length === 0 && (
                  <div className="p-3 text-sm text-muted-foreground">No permissions available.</div>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateOpen(false)} data-testid="button-cancel-create-role">
              Cancel
            </Button>
            <Button
              onClick={() => createRoleMutation.mutate()}
              disabled={!newRoleCode.trim() || !newRoleName.trim() || createRoleMutation.isPending}
              data-testid="button-submit-create-role"
            >
              {createRoleMutation.isPending ? "Creating..." : "Create role"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function SyncSettingsTab() {
  const { toast } = useToast();

  const { data: syncConfig, isLoading } = useQuery<{
    selectedFields: string[];
    availableFields: Array<{ field: string; label: string; group: string }>;
  }>({
    queryKey: ["/api/workspace/sync-required-fields"],
  });

  const [selectedFields, setSelectedFields] = useState<Set<string>>(new Set());
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (syncConfig?.selectedFields) {
      setSelectedFields(new Set(syncConfig.selectedFields));
      setHasChanges(false);
    }
  }, [syncConfig]);

  const toggleField = (field: string) => {
    setSelectedFields((prev) => {
      const next = new Set(prev);
      if (next.has(field)) {
        next.delete(field);
      } else {
        next.add(field);
      }
      return next;
    });
    setHasChanges(true);
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PUT", "/api/workspace/sync-required-fields", {
        fields: Array.from(selectedFields),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspace/sync-required-fields"] });
      setHasChanges(false);
      toast({ title: "Sync settings saved", description: "Required fields for Alumio sync have been updated." });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to save sync settings", variant: "destructive" });
    },
  });

  if (isLoading) {
    return <p className="text-sm text-muted-foreground">Loading sync settings...</p>;
  }

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Required fields for Alumio sync</CardTitle>
          <CardDescription>
            Select which product fields must be populated before a product can be synced to Magento via Alumio.
            Products missing any of these fields will have their sync disabled.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(() => {
            const allFields = syncConfig?.availableFields ?? [];
            const productFields = allFields.filter((f) => f.group === "product");
            const customFields = allFields.filter((f) => f.group === "custom_attribute");
            const renderFieldGrid = (fields: typeof allFields) => (
              <div className="grid gap-3 sm:grid-cols-2">
                {fields.map(({ field, label }) => (
                  <label
                    key={field}
                    className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                    data-testid={`checkbox-sync-field-${field}`}
                  >
                    <Checkbox
                      checked={selectedFields.has(field)}
                      onCheckedChange={() => toggleField(field)}
                    />
                    <span className="text-sm font-medium">{label}</span>
                  </label>
                ))}
              </div>
            );
            return (
              <div className="space-y-6">
                <div>
                  <h4 className="text-sm font-semibold text-muted-foreground mb-3">Product fields</h4>
                  {renderFieldGrid(productFields)}
                </div>
                {customFields.length > 0 && (
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-3">Custom attributes</h4>
                    {renderFieldGrid(customFields)}
                  </div>
                )}
              </div>
            );
          })()}
          <div className="flex items-center justify-between mt-6 pt-4 border-t">
            <p className="text-sm text-muted-foreground">
              {selectedFields.size} field{selectedFields.size !== 1 ? "s" : ""} required for sync
            </p>
            <Button
              onClick={() => saveMutation.mutate()}
              disabled={!hasChanges || saveMutation.isPending}
              data-testid="button-save-sync-settings"
            >
              {saveMutation.isPending ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Save changes
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SettingsPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Workspace settings</h1>
        <p className="text-muted-foreground">Control localization, notifications, users, and role access.</p>
      </div>
      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="sync-settings" data-testid="tab-sync-settings">Sync Settings</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="access-control">Access Control</TabsTrigger>
        </TabsList>
        <TabsContent value="general">
          <GeneralSettingsTab />
        </TabsContent>
        <TabsContent value="sync-settings">
          <SyncSettingsTab />
        </TabsContent>
        <TabsContent value="users">
          <UsersTab />
        </TabsContent>
        <TabsContent value="access-control">
          <AccessControlTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
