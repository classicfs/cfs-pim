import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { PlusCircle, Trash2, Copy, Check, Key, Eye, EyeOff, BookOpen } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ApiKeyRecord = {
  apiKeyId: number;
  name: string;
  keyPrefix: string;
  scopes: string[];
  active: boolean;
  lastUsedAt: string | null;
  createdAt: string;
};

const SCOPE_LABELS: Record<string, { label: string; description: string }> = {
  products: { label: "Products", description: "Read product catalog data" },
  variants: { label: "Variants", description: "Read product variant details" },
  pricing: { label: "Pricing", description: "Read variant pricing and currencies" },
  stock: { label: "Stock", description: "Read inventory and warehouse data" },
  categories: { label: "Categories", description: "Read category tree" },
  brands: { label: "Brands", description: "Read brand data" },
  "reference-data": { label: "Reference Data", description: "Read genders, types, conditions, sizes, clubs, etc." },
  images: { label: "Images", description: "Read product images" },
};

export default function ApiKeysPage() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState<number | null>(null);
  const [newKeyName, setNewKeyName] = useState("");
  const [selectedScopes, setSelectedScopes] = useState<string[]>([]);
  const [revealedKey, setRevealedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showDocs, setShowDocs] = useState(false);

  const { data: apiKeys = [], isLoading, isError } = useQuery<ApiKeyRecord[]>({
    queryKey: ["/api/api-keys"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; scopes: string[] }) => {
      const res = await apiRequest("POST", "/api/api-keys", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
      setRevealedKey(data.key);
      setNewKeyName("");
      setSelectedScopes([]);
      setShowCreateDialog(false);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, active }: { id: number; active: boolean }) => {
      await apiRequest("PATCH", `/api/api-keys/${id}`, { active });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/api-keys/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/api-keys"] });
      setShowDeleteDialog(null);
      toast({ title: "API key deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const toggleScope = (scope: string) => {
    setSelectedScopes((prev) =>
      prev.includes(scope)
        ? prev.filter((s) => s !== scope)
        : [...prev, scope],
    );
  };

  const selectAllScopes = () => {
    if (selectedScopes.length === Object.keys(SCOPE_LABELS).length) {
      setSelectedScopes([]);
    } else {
      setSelectedScopes(Object.keys(SCOPE_LABELS));
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ title: "Failed to copy", description: "Please select and copy the key manually", variant: "destructive" });
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "Never";
    return new Date(dateStr).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-page-title">API Keys</h1>
          <p className="text-muted-foreground mt-1">
            Manage API keys for external access to your product data
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowDocs(!showDocs)}
            data-testid="button-toggle-docs"
          >
            <BookOpen className="h-4 w-4 mr-2" />
            API Docs
          </Button>
          <Button onClick={() => setShowCreateDialog(true)} data-testid="button-create-api-key">
            <PlusCircle className="h-4 w-4 mr-2" />
            Create API Key
          </Button>
        </div>
      </div>

      {showDocs && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Public API Documentation</CardTitle>
            <CardDescription>
              All endpoints require an <code className="bg-muted px-1 rounded">x-api-key</code> header
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 text-sm">
              <div className="font-semibold text-base border-b pb-2">Product Data</div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/products</code>
                  <span className="text-muted-foreground ml-2">List products (paginated, filterable)</span>
                  <div className="text-xs text-muted-foreground mt-1">Query: ?page=1&limit=50&search=...&brandId=...&categoryId=...&enabled=true</div>
                </div>
              </div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/products/:id</code>
                  <span className="text-muted-foreground ml-2">Full product details with variants, categories, images</span>
                </div>
              </div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/products/:id/variants</code>
                  <span className="text-muted-foreground ml-2">Variants for a product</span>
                </div>
              </div>

              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/products/:id/attributes</code>
                  <span className="text-muted-foreground ml-2">Custom attributes for a product</span>
                </div>
              </div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/variants/:id/attributes</code>
                  <span className="text-muted-foreground ml-2">Custom attributes for a variant</span>
                </div>
              </div>

              <div className="font-semibold text-base border-b pb-2 mt-2">Pricing & Stock</div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/variants/:id/prices</code>
                  <span className="text-muted-foreground ml-2">Prices for a variant</span>
                </div>
              </div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div>
                  <code className="text-xs bg-muted px-2 py-1 rounded">/api/public/variants/:id/stock</code>
                  <span className="text-muted-foreground ml-2">Stock levels for a variant</span>
                </div>
              </div>

              <div className="font-semibold text-base border-b pb-2 mt-2">Reference Data</div>
              <div className="grid grid-cols-[200px_1fr] gap-2 items-start">
                <Badge variant="outline" className="font-mono justify-self-start">GET</Badge>
                <div className="space-y-1">
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/categories</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/brands</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/clubs</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/stores</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/attributes</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/images</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/genders</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/product-types</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/conditions</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/sizes</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/colours</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/eras</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/warehouses</code></div>
                  <div><code className="text-xs bg-muted px-2 py-1 rounded">/api/public/reference/currencies</code></div>
                </div>
              </div>

              <div className="font-semibold text-base border-b pb-2 mt-2">Example Request</div>
              <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
{`curl -H "x-api-key: pim_your_key_here" \\
  "https://your-domain.com/api/public/products?page=1&limit=10"`}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Active API Keys</CardTitle>
          <CardDescription>
            Keys grant read-only access to the public API. The full key is only shown once at creation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-muted-foreground text-center py-8">Loading...</div>
          ) : isError ? (
            <div className="text-center py-8 text-destructive">
              Failed to load API keys. Please try refreshing the page.
            </div>
          ) : apiKeys.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Key className="h-12 w-12 mx-auto mb-4 opacity-30" />
              <p className="text-lg font-medium">No API keys yet</p>
              <p className="text-sm mt-1">Create your first key to start using the public API</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Key</TableHead>
                  <TableHead>Scopes</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Used</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-[80px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {apiKeys.map((key) => (
                  <TableRow key={key.apiKeyId} data-testid={`row-api-key-${key.apiKeyId}`}>
                    <TableCell className="font-medium" data-testid={`text-key-name-${key.apiKeyId}`}>
                      {key.name}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-2 py-1 rounded" data-testid={`text-key-prefix-${key.apiKeyId}`}>
                        {key.keyPrefix}...
                      </code>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {key.scopes.map((scope) => (
                          <Badge key={scope} variant="secondary" className="text-xs">
                            {SCOPE_LABELS[scope]?.label || scope}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={key.active}
                        onCheckedChange={(checked) =>
                          toggleMutation.mutate({ id: key.apiKeyId, active: checked })
                        }
                        data-testid={`switch-active-${key.apiKeyId}`}
                      />
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm" data-testid={`text-last-used-${key.apiKeyId}`}>
                      {formatDate(key.lastUsedAt)}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {formatDate(key.createdAt)}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => setShowDeleteDialog(key.apiKeyId)}
                        data-testid={`button-delete-key-${key.apiKeyId}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create API Key</DialogTitle>
            <DialogDescription>
              Generate a new key for external API access. Select which data this key can read.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="key-name">Key Name</Label>
              <Input
                id="key-name"
                placeholder="e.g. Website Integration"
                value={newKeyName}
                onChange={(e) => setNewKeyName(e.target.value)}
                data-testid="input-key-name"
              />
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Scopes</Label>
                <Button variant="ghost" size="sm" onClick={selectAllScopes} data-testid="button-select-all-scopes">
                  {selectedScopes.length === Object.keys(SCOPE_LABELS).length ? "Deselect All" : "Select All"}
                </Button>
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {Object.entries(SCOPE_LABELS).map(([scope, info]) => (
                  <div key={scope} className="flex items-start gap-3 p-2 rounded hover:bg-muted/50">
                    <Checkbox
                      id={`scope-${scope}`}
                      checked={selectedScopes.includes(scope)}
                      onCheckedChange={() => toggleScope(scope)}
                      data-testid={`checkbox-scope-${scope}`}
                    />
                    <div className="grid gap-0.5 leading-none">
                      <label htmlFor={`scope-${scope}`} className="text-sm font-medium cursor-pointer">
                        {info.label}
                      </label>
                      <span className="text-xs text-muted-foreground">{info.description}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => createMutation.mutate({ name: newKeyName, scopes: selectedScopes })}
              disabled={!newKeyName.trim() || selectedScopes.length === 0 || createMutation.isPending}
              data-testid="button-confirm-create-key"
            >
              {createMutation.isPending ? "Creating..." : "Create Key"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!revealedKey} onOpenChange={() => setRevealedKey(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-500" />
              API Key Created
            </DialogTitle>
            <DialogDescription>
              Copy your key now. For security, it won't be shown again.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center gap-2">
              <Input
                readOnly
                value={revealedKey || ""}
                className="font-mono text-sm"
                data-testid="input-revealed-key"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => revealedKey && copyToClipboard(revealedKey)}
                data-testid="button-copy-key"
              >
                {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-xs text-amber-600 dark:text-amber-400">
              Store this key securely. You will not be able to view it again after closing this dialog.
            </p>
          </div>
          <DialogFooter>
            <Button onClick={() => setRevealedKey(null)} data-testid="button-done-key">
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog !== null} onOpenChange={() => setShowDeleteDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete API Key</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently revoke this API key. Any integrations using it will stop working immediately.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => showDeleteDialog && deleteMutation.mutate(showDeleteDialog)}
              data-testid="button-confirm-delete-key"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
