import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download, Filter, Eye, Columns3, Tags, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";

interface ExportFilters {
  search?: string;
  brandId?: number;
  categoryId?: number;
  clubId?: number;
  seasonId?: number;
  enabled?: boolean;
  startDate?: string;
  endDate?: string;
  stockLevel?: string;
  minAttribution?: number;
}

interface PreviewData {
  rows: Record<string, string>[];
  columns: string[];
  columnLabels: string[];
  totalCount: number;
}

const AVAILABLE_COLUMNS = [
  { value: "productId", label: "Product ID" },
  { value: "productSku", label: "SKU" },
  { value: "articleNumber", label: "Article Number" },
  { value: "productDescription", label: "Description" },
  { value: "brandName", label: "Brand" },
  { value: "genderName", label: "Gender" },
  { value: "productTypeName", label: "Product Type" },
  { value: "colourName", label: "Colour" },
  { value: "productStyle", label: "Style" },
  { value: "composition", label: "Composition" },
  { value: "countryOfManufacture", label: "Country of Manufacture" },
  { value: "commodityCode", label: "Commodity Code" },
  { value: "imageCode", label: "Image Code" },
  { value: "enabled", label: "Status" },
  { value: "sync", label: "Sync" },
  { value: "dataAttribution", label: "Data Attribution %" },
  { value: "variantCount", label: "Variant Count" },
  { value: "totalStock", label: "Total Stock" },
  { value: "createdAt", label: "Created Date" },
  { value: "updatedAt", label: "Updated Date" },
];

export default function Export() {
  const { toast } = useToast();
  const [filters, setFilters] = useState<ExportFilters>({});
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    "productSku",
    "productDescription",
    "brandName",
    "dataAttribution",
    "variantCount",
  ]);
  const [selectedAttributeIds, setSelectedAttributeIds] = useState<number[]>([]);
  const [isExporting, setIsExporting] = useState(false);
  const [preview, setPreview] = useState<PreviewData | null>(null);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);

  const { data: brands } = useQuery<Array<{ brandId: number; brandName: string }>>({
    queryKey: ["/api/brands"],
  });

  const { data: categories } = useQuery<Array<{ categoryId: number; name: string }>>({
    queryKey: ["/api/categories"],
  });

  const { data: clubs } = useQuery<Array<{ clubId: number; name: string }>>({
    queryKey: ["/api/clubs"],
  });

  const { data: seasons } = useQuery<Array<{ seasonId: number; code: string }>>({
    queryKey: ["/api/seasons"],
  });

  const { data: attributeDefs = [] } = useQuery<Array<{
    attributeId: number;
    code: string;
    label: string | null;
    dataType: string;
    scope: string;
  }>>({
    queryKey: ["/api/attribute-defs"],
  });

  const productAttributes = attributeDefs.filter(a => {
    const s = (a.scope || "").toLowerCase();
    return s === "product" || s === "parent";
  });

  const handleColumnToggle = (column: string) => {
    setSelectedColumns((prev) =>
      prev.includes(column)
        ? prev.filter((c) => c !== column)
        : [...prev, column]
    );
  };

  const handleAttributeToggle = (attributeId: number) => {
    setSelectedAttributeIds((prev) =>
      prev.includes(attributeId)
        ? prev.filter((id) => id !== attributeId)
        : [...prev, attributeId]
    );
  };

  const abortControllerRef = useRef<AbortController | null>(null);

  const fetchPreview = useCallback(async () => {
    if (selectedColumns.length === 0 && selectedAttributeIds.length === 0) {
      setPreview(null);
      return;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setIsLoadingPreview(true);
    setPreviewError(null);
    try {
      const response = await fetch("/api/export/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filters,
          columns: selectedColumns,
          attributeColumns: selectedAttributeIds,
        }),
        signal: controller.signal,
      });

      if (!response.ok) throw new Error("Preview failed");

      const data = await response.json();
      if (!controller.signal.aborted) {
        setPreview(data);
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      if (!controller.signal.aborted) {
        setPreviewError("Failed to load preview");
        setPreview(null);
      }
    } finally {
      if (!controller.signal.aborted) {
        setIsLoadingPreview(false);
      }
    }
  }, [filters, selectedColumns, selectedAttributeIds]);

  useEffect(() => {
    const timer = setTimeout(() => {
      fetchPreview();
    }, 500);
    return () => clearTimeout(timer);
  }, [fetchPreview]);

  const handleExport = async () => {
    if (selectedColumns.length === 0 && selectedAttributeIds.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one column to export",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);
    try {
      const response = await fetch("/api/export/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filters,
          columns: selectedColumns,
          attributeColumns: selectedAttributeIds,
        }),
      });

      if (!response.ok) throw new Error("Export failed");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `products_export_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Success",
        description: `Exported ${preview?.totalCount || 0} products successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to export products: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const totalSelected = selectedColumns.length + selectedAttributeIds.length;

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-export">
            Export Products
          </h1>
          <p className="text-muted-foreground mt-1">
            Filter and export product data to CSV
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-[65vh] overflow-auto">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="search">Search (SKU or Description)</Label>
                  <Input
                    id="search"
                    placeholder="Search products..."
                    value={filters.search || ""}
                    onChange={(e) =>
                      setFilters({ ...filters, search: e.target.value || undefined })
                    }
                    data-testid="input-search"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="brand">Brand</Label>
                  <Select
                    value={filters.brandId?.toString() || "all"}
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        brandId: value === "all" ? undefined : parseInt(value),
                      })
                    }
                  >
                    <SelectTrigger id="brand" data-testid="select-brand">
                      <SelectValue placeholder="All brands" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All brands</SelectItem>
                      {brands?.map((brand) => (
                        <SelectItem key={brand.brandId} value={brand.brandId.toString()}>
                          {brand.brandName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={filters.categoryId?.toString() || "all"}
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        categoryId: value === "all" ? undefined : parseInt(value),
                      })
                    }
                  >
                    <SelectTrigger id="category" data-testid="select-category">
                      <SelectValue placeholder="All categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {categories?.map((category) => (
                        <SelectItem
                          key={category.categoryId}
                          value={category.categoryId.toString()}
                        >
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="club">Club</Label>
                  <Select
                    value={filters.clubId?.toString() || "all"}
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        clubId: value === "all" ? undefined : parseInt(value),
                      })
                    }
                  >
                    <SelectTrigger id="club" data-testid="select-club">
                      <SelectValue placeholder="All clubs" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All clubs</SelectItem>
                      {clubs?.map((club) => (
                        <SelectItem key={club.clubId} value={club.clubId.toString()}>
                          {club.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="season">Season</Label>
                  <Select
                    value={filters.seasonId?.toString() || "all"}
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        seasonId: value === "all" ? undefined : parseInt(value),
                      })
                    }
                  >
                    <SelectTrigger id="season" data-testid="select-season">
                      <SelectValue placeholder="All seasons" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All seasons</SelectItem>
                      {seasons?.map((season) => (
                        <SelectItem key={season.seasonId} value={season.seasonId.toString()}>
                          {season.code}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={
                      filters.enabled === undefined
                        ? "all"
                        : filters.enabled
                        ? "active"
                        : "inactive"
                    }
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        enabled:
                          value === "all" ? undefined : value === "active" ? true : false,
                      })
                    }
                  >
                    <SelectTrigger id="status" data-testid="select-status">
                      <SelectValue placeholder="All status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Date Range</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <Label htmlFor="startDate" className="text-xs text-muted-foreground">From</Label>
                      <Input
                        id="startDate"
                        type="date"
                        value={filters.startDate || ""}
                        onChange={(e) =>
                          setFilters({ ...filters, startDate: e.target.value || undefined })
                        }
                        data-testid="input-start-date"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="endDate" className="text-xs text-muted-foreground">To</Label>
                      <Input
                        id="endDate"
                        type="date"
                        value={filters.endDate || ""}
                        onChange={(e) =>
                          setFilters({ ...filters, endDate: e.target.value || undefined })
                        }
                        data-testid="input-end-date"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stockLevel">Stock Level</Label>
                  <Select
                    value={filters.stockLevel || "all"}
                    onValueChange={(value) =>
                      setFilters({
                        ...filters,
                        stockLevel: value === "all" ? undefined : value,
                      })
                    }
                  >
                    <SelectTrigger id="stockLevel" data-testid="select-stock-level">
                      <SelectValue placeholder="All stock levels" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All stock levels</SelectItem>
                      <SelectItem value="out_of_stock">Out of Stock</SelectItem>
                      <SelectItem value="low_stock">Low Stock (&lt; 10)</SelectItem>
                      <SelectItem value="in_stock">In Stock (&gt; 10)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minAttribution">Minimum Data Attribution %</Label>
                  <Input
                    id="minAttribution"
                    type="number"
                    min="0"
                    max="100"
                    placeholder="e.g., 50"
                    value={filters.minAttribution || ""}
                    onChange={(e) =>
                      setFilters({
                        ...filters,
                        minAttribution: e.target.value ? parseInt(e.target.value) : undefined,
                      })
                    }
                    data-testid="input-min-attribution"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Columns3 className="h-5 w-5" />
                Product Fields
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Standard product fields to include
              </p>
            </CardHeader>
            <CardContent className="max-h-[65vh] overflow-auto">
              <div className="space-y-3">
                {AVAILABLE_COLUMNS.map((column) => (
                  <div key={column.value} className="flex items-center space-x-2">
                    <Checkbox
                      id={column.value}
                      checked={selectedColumns.includes(column.value)}
                      onCheckedChange={() => handleColumnToggle(column.value)}
                      data-testid={`checkbox-column-${column.value}`}
                    />
                    <Label
                      htmlFor={column.value}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {column.label}
                    </Label>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 mt-6">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    setSelectedColumns(AVAILABLE_COLUMNS.map((c) => c.value))
                  }
                  data-testid="button-select-all"
                >
                  Select All
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedColumns([])}
                  data-testid="button-deselect-all"
                >
                  Deselect All
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Tags className="h-5 w-5" />
                Custom Attributes
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Product-level custom attributes
              </p>
            </CardHeader>
            <CardContent className="max-h-[65vh] overflow-auto">
              {productAttributes.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">
                  No product attributes defined
                </p>
              ) : (
                <>
                  <div className="space-y-3">
                    {productAttributes.map((attr) => (
                      <div key={attr.attributeId} className="flex items-center space-x-2">
                        <Checkbox
                          id={`attr-${attr.attributeId}`}
                          checked={selectedAttributeIds.includes(attr.attributeId)}
                          onCheckedChange={() => handleAttributeToggle(attr.attributeId)}
                          data-testid={`checkbox-attr-${attr.attributeId}`}
                        />
                        <Label
                          htmlFor={`attr-${attr.attributeId}`}
                          className="text-sm font-normal cursor-pointer flex-1"
                        >
                          {attr.label || attr.code}
                        </Label>
                        <Badge variant="outline" className="text-xs">
                          {attr.dataType}
                        </Badge>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2 mt-6">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        setSelectedAttributeIds(productAttributes.map((a) => a.attributeId))
                      }
                      data-testid="button-select-all-attrs"
                    >
                      Select All
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedAttributeIds([])}
                      data-testid="button-deselect-all-attrs"
                    >
                      Deselect All
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              Export Preview
              {preview && (
                <Badge variant="secondary" className="ml-2" data-testid="badge-total-count">
                  {preview.totalCount.toLocaleString()} products matched
                </Badge>
              )}
              {isLoadingPreview && (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              )}
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Showing up to 5 sample rows based on your current filters and selected columns
            </p>
          </CardHeader>
          <CardContent>
            {previewError ? (
              <div className="text-center py-6">
                <p className="text-sm text-destructive">{previewError}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={fetchPreview}
                  data-testid="button-retry-preview"
                >
                  Retry
                </Button>
              </div>
            ) : totalSelected === 0 ? (
              <div className="text-center py-6">
                <p className="text-sm text-muted-foreground">Select at least one column to see a preview</p>
              </div>
            ) : !preview ? (
              <div className="text-center py-6">
                <Loader2 className="h-5 w-5 animate-spin mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Loading preview...</p>
              </div>
            ) : preview.rows.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-sm text-muted-foreground">No products match your current filters</p>
              </div>
            ) : (
              <div className="border rounded-md overflow-auto max-h-[40vh]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {preview.columns.map((col, i) => (
                        <TableHead key={col} className="py-1 whitespace-nowrap text-xs">
                          {preview.columnLabels?.[i] || col}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.rows.map((row, idx) => (
                      <TableRow key={idx} data-testid={`row-preview-${idx}`}>
                        {preview.columns.map((col) => (
                          <TableCell key={col} className="py-1 text-xs truncate max-w-[200px]">
                            {row[col] || <span className="text-muted-foreground">—</span>}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm text-muted-foreground">
                {totalSelected} column{totalSelected !== 1 ? "s" : ""} selected
                {preview && ` · ${preview.totalCount.toLocaleString()} products to export`}
              </div>
            </div>
            <Button
              onClick={handleExport}
              disabled={isExporting || totalSelected === 0}
              className="w-full"
              data-testid="button-export"
            >
              {isExporting ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Download className="h-4 w-4 mr-2" />
              )}
              {isExporting ? "Exporting..." : "Export to CSV"}
            </Button>
            {totalSelected === 0 && (
              <p className="text-sm text-destructive mt-2 text-center">
                Please select at least one column to export
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
