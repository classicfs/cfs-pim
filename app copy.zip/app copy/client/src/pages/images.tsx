import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Search, Trash2, ExternalLink, Image as ImageIcon, ChevronLeft, ChevronRight, Upload, X, Plus } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface ImageRecord {
  imageId: number;
  productId: number | null;
  role: string;
  url: string;
  label: string | null;
  sortOrder: number | null;
  productSku: string | null;
  productDescription: string | null;
}

const IMAGE_ROLES = ["base", "small", "thumbnail", "additional", "swatch"];

export default function Images() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [page, setPage] = useState(0);
  const [deleteImageId, setDeleteImageId] = useState<number | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [skuSearch, setSkuSearch] = useState("");
  const [debouncedSkuSearch, setDebouncedSkuSearch] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<{ productId: number; productSku: string } | null>(null);
  const [newImageUrl, setNewImageUrl] = useState("");
  const [newImageRole, setNewImageRole] = useState("base");
  const [newImageLabel, setNewImageLabel] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const skuSearchTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();
  const limit = 50;

  const handleSearchChange = (value: string) => {
    setSearch(value);
    setPage(0);
    const timeoutId = setTimeout(() => {
      setDebouncedSearch(value);
    }, 300);
    return () => clearTimeout(timeoutId);
  };

  const { data, isLoading } = useQuery<{ images: ImageRecord[]; total: number; roles: string[] }>({
    queryKey: ["/api/images", { limit, offset: page * limit, search: debouncedSearch, role: roleFilter }],
    queryFn: async () => {
      const params = new URLSearchParams({
        limit: String(limit),
        offset: String(page * limit),
      });
      if (debouncedSearch) {
        params.append("search", debouncedSearch);
      }
      if (roleFilter) {
        params.append("role", roleFilter);
      }
      const response = await fetch(`/api/images?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to fetch images");
      return response.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (imageId: number) => {
      await apiRequest("DELETE", `/api/images/${imageId}`);
    },
    onSuccess: () => {
      toast({
        title: "Image deleted",
        description: "The image has been removed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      setDeleteImageId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete image",
        variant: "destructive",
      });
    },
  });

  const importMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      const response = await fetch("/api/images/import", {
        method: "POST",
        body: formData,
      });
      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to import images");
      }
      return response.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Import complete",
        description: `${result.imported} image(s) imported, ${result.skipped} skipped.${result.errors?.length ? ` ${result.errors.length} error(s).` : ""}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message || "Failed to import images",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      importMutation.mutate(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSkuSearchChange = (value: string) => {
    setSkuSearch(value);
    if (skuSearchTimeoutRef.current) clearTimeout(skuSearchTimeoutRef.current);
    skuSearchTimeoutRef.current = setTimeout(() => {
      setDebouncedSkuSearch(value);
    }, 300);
  };

  const { data: skuResults } = useQuery<{ products: Array<{ productId: number; productSku: string; productDescription: string | null }> }>({
    queryKey: ["/api/catalog/products", { search: debouncedSkuSearch, limit: 10 }],
    queryFn: async () => {
      const params = new URLSearchParams({ limit: "10" });
      if (debouncedSkuSearch) params.append("search", debouncedSkuSearch);
      const response = await fetch(`/api/catalog/products?${params.toString()}`);
      if (!response.ok) throw new Error("Failed to search products");
      return response.json();
    },
    enabled: showAddDialog && debouncedSkuSearch.length > 0,
  });

  const createMutation = useMutation({
    mutationFn: async (data: { productId: number; url: string; role: string; label: string }) => {
      const res = await apiRequest("POST", "/api/images", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Image added", description: "The image has been created successfully." });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      resetAddDialog();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to create image", variant: "destructive" });
    },
  });

  const resetAddDialog = () => {
    setShowAddDialog(false);
    setSkuSearch("");
    setDebouncedSkuSearch("");
    setSelectedProduct(null);
    setNewImageUrl("");
    setNewImageRole("base");
    setNewImageLabel("");
  };

  const handleCreateImage = () => {
    if (!selectedProduct || !newImageUrl.trim() || !newImageRole) return;
    createMutation.mutate({
      productId: selectedProduct.productId,
      url: newImageUrl.trim(),
      role: newImageRole,
      label: newImageLabel.trim(),
    });
  };

  const images = data?.images ?? [];
  const total = data?.total ?? 0;
  const roles = data?.roles ?? [];
  const totalPages = Math.ceil(total / limit);

  const hasActiveFilters = debouncedSearch || roleFilter;

  const clearFilters = () => {
    setSearch("");
    setDebouncedSearch("");
    setRoleFilter("");
    setPage(0);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-shrink-0 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex items-center justify-between gap-4 px-6 py-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Images</h1>
            <p className="text-sm text-muted-foreground">
              View and manage product images across all scopes
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
              data-testid="input-image-csv-upload"
            />
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={importMutation.isPending}
              data-testid="button-import-images"
            >
              <Upload className="h-4 w-4 mr-2" />
              {importMutation.isPending ? "Importing..." : "Import CSV"}
            </Button>
            <Button
              onClick={() => setShowAddDialog(true)}
              data-testid="button-add-image"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Image
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-4">
            <CardTitle className="text-lg font-medium">
              Product Images
              {total > 0 && (
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  ({total} total)
                </span>
              )}
            </CardTitle>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by SKU, description, or URL..."
                  value={search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  className="w-72 pl-9"
                  data-testid="input-image-search"
                />
              </div>
              <Select
                value={roleFilter || "all"}
                onValueChange={(val) => {
                  setRoleFilter(val === "all" ? "" : val);
                  setPage(0);
                }}
              >
                <SelectTrigger className="w-44" data-testid="select-image-scope">
                  <SelectValue placeholder="All scopes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All scopes</SelectItem>
                  {roles.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role.charAt(0).toUpperCase() + role.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-filters">
                  <X className="h-4 w-4 mr-1" />
                  Clear
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : images.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <ImageIcon className="h-12 w-12 text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-medium">No images found</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  {hasActiveFilters
                    ? "Try adjusting your search terms or filters"
                    : "Import images using the button above to get started"}
                </p>
              </div>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-24">Preview</TableHead>
                      <TableHead>Product SKU</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Label</TableHead>
                      <TableHead>Scope</TableHead>
                      <TableHead className="w-16 text-center">Order</TableHead>
                      <TableHead>URL</TableHead>
                      <TableHead className="w-24 text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {images.map((image) => (
                      <TableRow key={image.imageId} data-testid={`row-image-${image.imageId}`}>
                        <TableCell>
                          <div className="w-16 h-16 rounded-md border bg-muted flex items-center justify-center overflow-hidden">
                            <img
                              src={image.url}
                              alt={`Product ${image.productSku || "image"}`}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLImageElement).style.display = "none";
                                (e.target as HTMLImageElement).parentElement!.innerHTML =
                                  '<svg class="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>';
                              }}
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          {image.productId ? (
                            <Link href={`/product/${image.productId}`}>
                              <span className="hover:underline cursor-pointer text-primary font-medium" data-testid={`link-product-${image.productId}`}>
                                {image.productSku || "N/A"}
                              </span>
                            </Link>
                          ) : (
                            <span className="text-muted-foreground">No product linked</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground truncate max-w-xs block">
                            {image.productDescription || "-"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm truncate max-w-xs block" data-testid={`text-image-label-${image.imageId}`}>
                            {image.label || "-"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{image.role}</Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          {image.sortOrder ?? "-"}
                        </TableCell>
                        <TableCell>
                          <a
                            href={image.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground truncate max-w-xs"
                            data-testid={`link-image-url-${image.imageId}`}
                          >
                            <span className="truncate">{image.url}</span>
                            <ExternalLink className="h-3 w-3 flex-shrink-0" />
                          </a>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeleteImageId(image.imageId)}
                            data-testid={`button-delete-image-${image.imageId}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <div className="text-sm text-muted-foreground">
                    Showing {page * limit + 1}-{Math.min((page + 1) * limit, total)} of {total} images
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage((p) => Math.max(0, p - 1))}
                      disabled={page === 0}
                      data-testid="button-prev-page"
                    >
                      <ChevronLeft className="h-4 w-4 mr-1" />
                      Previous
                    </Button>
                    <span className="text-sm text-muted-foreground px-2">
                      Page {page + 1} of {totalPages || 1}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPage((p) => p + 1)}
                      disabled={page >= totalPages - 1}
                      data-testid="button-next-page"
                    >
                      Next
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={deleteImageId !== null} onOpenChange={() => setDeleteImageId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Image</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this image? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteImageId && deleteMutation.mutate(deleteImageId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showAddDialog} onOpenChange={(open) => { if (!open) resetAddDialog(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Image</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Product SKU</Label>
              {selectedProduct ? (
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-sm">{selectedProduct.productSku}</Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => { setSelectedProduct(null); setSkuSearch(""); setDebouncedSkuSearch(""); }}
                    data-testid="button-clear-sku"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="Search by SKU..."
                      value={skuSearch}
                      onChange={(e) => handleSkuSearchChange(e.target.value)}
                      className="pl-9"
                      data-testid="input-sku-search"
                    />
                  </div>
                  {skuResults?.products && skuResults.products.length > 0 && (
                    <div className="border rounded-md max-h-40 overflow-auto">
                      {skuResults.products.map((p) => (
                        <button
                          key={p.productId}
                          type="button"
                          className="w-full text-left px-3 py-2 text-sm hover-elevate"
                          onClick={() => {
                            setSelectedProduct({ productId: p.productId, productSku: p.productSku });
                            setSkuSearch("");
                            setDebouncedSkuSearch("");
                          }}
                          data-testid={`button-select-product-${p.productId}`}
                        >
                          <span className="font-medium">{p.productSku}</span>
                          {p.productDescription && (
                            <span className="text-muted-foreground ml-2">{p.productDescription}</span>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                  {debouncedSkuSearch && skuResults?.products?.length === 0 && (
                    <p className="text-sm text-muted-foreground px-1">No products found</p>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Label</Label>
              <Input
                placeholder="Image title / label"
                value={newImageLabel}
                onChange={(e) => setNewImageLabel(e.target.value)}
                data-testid="input-image-label"
              />
            </div>

            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={newImageRole} onValueChange={setNewImageRole}>
                <SelectTrigger data-testid="select-image-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {IMAGE_ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Image URL</Label>
              <Input
                placeholder="https://example.com/image.jpg"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                data-testid="input-image-url"
              />
            </div>

            {newImageUrl.trim() && (
              <div className="border rounded-md p-2 bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Preview</p>
                <img
                  src={newImageUrl.trim()}
                  alt="Preview"
                  className="max-h-32 rounded-md object-contain"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  data-testid="img-add-preview"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetAddDialog} data-testid="button-cancel-add">
              Cancel
            </Button>
            <Button
              onClick={handleCreateImage}
              disabled={!selectedProduct || !newImageUrl.trim() || createMutation.isPending}
              data-testid="button-confirm-add"
            >
              {createMutation.isPending ? "Adding..." : "Add Image"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
