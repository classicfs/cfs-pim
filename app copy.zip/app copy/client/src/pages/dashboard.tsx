import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Package, Layers, Warehouse, Store } from "lucide-react";
import { useLocation } from "wouter";
import { Pie, PieChart, Cell } from "recharts";
import { MetricCard } from "@/components/metric-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";

function timeAgo(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const seconds = Math.floor(diffMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  const weeks = Math.floor(days / 7);
  const months = Math.floor(days / 30);

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days} days ago`;
  if (weeks === 1) return "1 week ago";
  if (weeks < 5) return `${weeks} weeks ago`;
  if (months === 1) return "1 month ago";
  if (months < 12) return `${months} months ago`;
  return date.toLocaleDateString();
}

interface DashboardMetrics {
  totalProducts: number;
  totalVariants: number;
  totalStock: number;
  storeCount: number;
  averageDataAttribution: number;
}

interface Product {
  productId: number;
  productSku: string;
  productDescription: string;
  brandName: string | null;
  enabled: boolean;
  variantCount: number;
  dataAttribution: number;
  createdAt: string;
}

interface DashboardInsights {
  status: {
    enabled: number;
    disabled: number;
  };
  activity: {
    created: number;
    updated: number;
    unchanged: number;
    total: number;
    range: {
      start: string;
      end: string;
    };
  };
  assets: {
    missing: number;
    total: number;
    attribute: string;
  };
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const [departmentFilter, setDepartmentFilter] = useState<number | undefined>(undefined);
  const [activityRange, setActivityRange] = useState("last_30_days");
  const [customStartDate, setCustomStartDate] = useState(() => {
    const start = new Date();
    start.setDate(start.getDate() - 7);
    return start.toISOString().slice(0, 10);
  });
  const [customEndDate, setCustomEndDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [assetField, setAssetField] = useState("images");
  
  const { data: metrics, isLoading: metricsLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard"],
  });

  const { data: departments } = useQuery<Array<{ departmentId: number; name: string }>>({
    queryKey: ["/api/departments"],
  });

  const buildProductsQueryParams = () => {
    const params = new URLSearchParams();
    params.append("limit", "10");
    params.append("offset", "0");
    params.append("sortBy", "product:createdAt");
    params.append("order", "desc");
    if (departmentFilter !== undefined) {
      params.append("departmentId", departmentFilter.toString());
    }
    return params.toString();
  };

  const queryParams = buildProductsQueryParams();
  const { data: productsData, isLoading: productsLoading } = useQuery<{ products: Product[]; count: number }>({
    queryKey: [`/api/catalog/products?${queryParams}`],
  });

  const buildInsightsQueryParams = () => {
    const params = new URLSearchParams();
    params.append("activityRange", activityRange);
    params.append("assetField", assetField);
    if (activityRange === "custom" && customStartDate && customEndDate) {
      params.append("startDate", customStartDate);
      params.append("endDate", customEndDate);
    }
    return params.toString();
  };

  const insightsQueryParams = buildInsightsQueryParams();
  const insightsQueryEnabled =
    activityRange !== "custom" || Boolean(customStartDate && customEndDate);
  const { data: insights, isLoading: insightsLoading } = useQuery<DashboardInsights>({
    queryKey: [`/api/dashboard/insights?${insightsQueryParams}`],
    enabled: insightsQueryEnabled,
  });

  if (metricsLoading || !metrics) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="p-6 space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">PIM Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Product Information Management System
            </p>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Loading...</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  const handleProductClick = (productId: number) => {
    navigate(`/product/${productId}`);
  };

  const navigateToCatalogWithFilter = (filters: Array<{ field: string; operator: string; value?: string; dataType: string; source: string }>) => {
    const serialized = filters.map(f => ({
      field: f.field,
      operator: f.operator,
      value: f.value ?? "",
      dataType: f.dataType,
      source: f.source,
    }));
    const params = new URLSearchParams();
    params.set("filters", JSON.stringify(serialized));
    navigate(`/catalog?${params.toString()}`);
  };

  const handleStatusClick = (key: string) => {
    navigateToCatalogWithFilter([{
      field: "enabled",
      operator: "eq",
      value: key === "enabled" ? "true" : "false",
      dataType: "boolean",
      source: "product",
    }]);
  };

  const handleActivityClick = (key: string) => {
    if (!insights?.activity.range) return;
    const { start, end } = insights.activity.range;
    const startDate = start.slice(0, 10);
    const endISO = new Date(end);
    endISO.setHours(23, 59, 59, 999);
    const endDate = endISO.toISOString().slice(0, 10);

    if (key === "created") {
      navigateToCatalogWithFilter([
        { field: "createdAt", operator: "gte", value: startDate, dataType: "date", source: "product" },
        { field: "createdAt", operator: "lte", value: endDate, dataType: "date", source: "product" },
      ]);
    } else if (key === "updated") {
      navigateToCatalogWithFilter([
        { field: "updatedAt", operator: "gte", value: startDate, dataType: "date", source: "product" },
        { field: "updatedAt", operator: "lte", value: endDate, dataType: "date", source: "product" },
      ]);
    }
  };

  const assetFieldToCatalogFilter: Record<string, { field: string; source: string }> = {
    images: { field: "imageRoleCount", source: "product" },
    brand: { field: "brandName", source: "product" },
    description: { field: "productDescription", source: "product" },
    composition: { field: "composition", source: "product" },
    country: { field: "countryOfManufacture", source: "product" },
    productType: { field: "productTypeName", source: "product" },
  };

  const handleAssetClick = (key: string) => {
    const mapping = assetFieldToCatalogFilter[assetField];
    if (!mapping) return;
    if (assetField === "images") {
      navigateToCatalogWithFilter([{
        field: mapping.field,
        operator: key === "missing" ? "lt" : "gte",
        value: "3",
        dataType: "number",
        source: mapping.source,
      }]);
    } else {
      navigateToCatalogWithFilter([{
        field: mapping.field,
        operator: key === "missing" ? "isEmpty" : "isNotEmpty",
        dataType: "text",
        source: mapping.source,
      }]);
    }
  };

  const getAttributionColor = (attribution: number) => {
    if (attribution >= 80) return "text-green-600 dark:text-green-400";
    if (attribution >= 50) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  const statusChartConfig = {
    enabled: { label: "Enabled", color: "hsl(var(--chart-2))" },
    disabled: { label: "Disabled", color: "hsl(var(--chart-5))" },
  };

  const activityChartConfig = {
    created: { label: "Created", color: "hsl(var(--chart-2))" },
    updated: { label: "Updated", color: "hsl(var(--chart-3))" },
    unchanged: { label: "Unchanged", color: "hsl(var(--chart-4))" },
  };

  const assetsChartConfig = {
    missing: { label: "Missing", color: "hsl(var(--chart-5))" },
    complete: { label: "Complete", color: "hsl(var(--chart-2))" },
  };

  const enabledCount = insights?.status.enabled ?? 0;
  const disabledCount = insights?.status.disabled ?? 0;
  const statusChartData = [
    { key: "enabled", value: enabledCount, fill: "var(--color-enabled)" },
    { key: "disabled", value: disabledCount, fill: "var(--color-disabled)" },
  ];

  const activityCreated = insights?.activity.created ?? 0;
  const activityUpdated = insights?.activity.updated ?? 0;
  const activityUnchanged = insights?.activity.unchanged ?? 0;
  const activityChartData = [
    { key: "created", value: activityCreated, fill: "var(--color-created)" },
    { key: "updated", value: activityUpdated, fill: "var(--color-updated)" },
    { key: "unchanged", value: activityUnchanged, fill: "var(--color-unchanged)" },
  ];

  const assetsMissing = insights?.assets.missing ?? 0;
  const assetsTotal = insights?.assets.total ?? 0;
  const assetsComplete = Math.max(assetsTotal - assetsMissing, 0);
  const assetsChartData = [
    { key: "missing", value: assetsMissing, fill: "var(--color-missing)" },
    { key: "complete", value: assetsComplete, fill: "var(--color-complete)" },
  ];

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-dashboard">
            PIM Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Product Information Management for Classic Football Shirts
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Products"
            value={metrics.totalProducts.toLocaleString()}
            subtitle="Base products"
            icon={Package}
            data-testid="metric-products"
          />
          <MetricCard
            title="Variants"
            value={metrics.totalVariants.toLocaleString()}
            subtitle="Product variants"
            icon={Layers}
            data-testid="metric-variants"
          />
          <MetricCard
            title="Total Stock"
            value={metrics.totalStock.toLocaleString()}
            subtitle="Units across warehouses"
            icon={Warehouse}
            data-testid="metric-stock"
          />
          <MetricCard
            title="Stores"
            value={metrics.storeCount}
            subtitle="Active storefronts"
            icon={Store}
            data-testid="metric-stores"
          />
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Product Status</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Enabled vs disabled
                  </p>
                </div>
                <div className="w-[180px] h-9" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {insightsLoading || !insights ? (
                <p className="text-muted-foreground">Loading status...</p>
              ) : (
                <>
                  <ChartContainer config={statusChartConfig} className="h-[220px] w-full aspect-auto">
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                      <Pie data={statusChartData} dataKey="value" nameKey="key" innerRadius={60} outerRadius={90} strokeWidth={0} className="cursor-pointer">
                        {statusChartData.map((entry) => (
                          <Cell key={entry.key} fill={entry.fill} className="cursor-pointer" onClick={() => handleStatusClick(entry.key)} data-testid={`pie-status-${entry.key}`} />
                        ))}
                      </Pie>
                      <ChartLegend content={<ChartLegendContent nameKey="key" />} />
                    </PieChart>
                  </ChartContainer>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleStatusClick("enabled")} data-testid="link-status-enabled">
                      <p className="text-muted-foreground">Enabled</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{enabledCount.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleStatusClick("disabled")} data-testid="link-status-disabled">
                      <p className="text-muted-foreground">Disabled</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{disabledCount.toLocaleString()}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Product Activity</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Created vs updated vs unchanged
                  </p>
                </div>
                <Select value={activityRange} onValueChange={setActivityRange}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last_day">Last day</SelectItem>
                    <SelectItem value="last_week">Last week</SelectItem>
                    <SelectItem value="last_30_days">Last 30 days</SelectItem>
                    <SelectItem value="custom">Custom range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {activityRange === "custom" ? (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1">
                    <Label htmlFor="activity-start-date" className="text-xs text-muted-foreground">
                      Start date
                    </Label>
                    <Input
                      id="activity-start-date"
                      type="date"
                      value={customStartDate}
                      onChange={(event) => setCustomStartDate(event.target.value)}
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="activity-end-date" className="text-xs text-muted-foreground">
                      End date
                    </Label>
                    <Input
                      id="activity-end-date"
                      type="date"
                      value={customEndDate}
                      onChange={(event) => setCustomEndDate(event.target.value)}
                    />
                  </div>
                </div>
              ) : null}
              {!insightsQueryEnabled ? (
                <p className="text-muted-foreground">Select a start and end date to view activity.</p>
              ) : insightsLoading || !insights ? (
                <p className="text-muted-foreground">Loading activity...</p>
              ) : (
                <>
                  <ChartContainer config={activityChartConfig} className="h-[220px] w-full aspect-auto">
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                      <Pie data={activityChartData} dataKey="value" nameKey="key" innerRadius={60} outerRadius={90} strokeWidth={0}>
                        {activityChartData.map((entry) => (
                          <Cell key={entry.key} fill={entry.fill} className={entry.key !== "unchanged" ? "cursor-pointer" : ""} onClick={entry.key !== "unchanged" ? () => handleActivityClick(entry.key) : undefined} data-testid={`pie-activity-${entry.key}`} />
                        ))}
                      </Pie>
                      <ChartLegend content={<ChartLegendContent nameKey="key" />} />
                    </PieChart>
                  </ChartContainer>
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleActivityClick("created")} data-testid="link-activity-created">
                      <p className="text-muted-foreground">Created</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{activityCreated.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleActivityClick("updated")} data-testid="link-activity-updated">
                      <p className="text-muted-foreground">Updated</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{activityUpdated.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-muted-foreground">Unchanged</p>
                      <p className="text-lg font-semibold">{activityUnchanged.toLocaleString()}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Asset Gaps</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Missing attributes by type
                  </p>
                </div>
                <Select value={assetField} onValueChange={setAssetField}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select attribute" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="images">Images</SelectItem>
                    <SelectItem value="brand">Brand</SelectItem>
                    <SelectItem value="description">Description</SelectItem>
                    <SelectItem value="composition">Composition</SelectItem>
                    <SelectItem value="country">Country of manufacture</SelectItem>
                    <SelectItem value="productType">Product type</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {insightsLoading || !insights ? (
                <p className="text-muted-foreground">Loading asset gaps...</p>
              ) : (
                <>
                  <ChartContainer config={assetsChartConfig} className="h-[220px] w-full aspect-auto">
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                      <Pie data={assetsChartData} dataKey="value" nameKey="key" innerRadius={60} outerRadius={90} strokeWidth={0} className="cursor-pointer">
                        {assetsChartData.map((entry) => (
                          <Cell key={entry.key} fill={entry.fill} className="cursor-pointer" onClick={() => handleAssetClick(entry.key)} data-testid={`pie-asset-${entry.key}`} />
                        ))}
                      </Pie>
                      <ChartLegend content={<ChartLegendContent nameKey="key" />} />
                    </PieChart>
                  </ChartContainer>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleAssetClick("missing")} data-testid="link-asset-missing">
                      <p className="text-muted-foreground">Missing</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{assetsMissing.toLocaleString()}</p>
                    </div>
                    <div className="space-y-1 cursor-pointer hover:opacity-80" onClick={() => handleAssetClick("complete")} data-testid="link-asset-complete">
                      <p className="text-muted-foreground">Complete</p>
                      <p className="text-lg font-semibold underline decoration-dotted">{assetsComplete.toLocaleString()}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <CardTitle>Recent Products</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Click on any product to view and edit details
                </p>
              </div>
              <div className="space-y-2 min-w-[200px]">
                <Label htmlFor="department-filter" className="text-sm">Filter by Department</Label>
                <Select
                  value={departmentFilter?.toString() || "all"}
                  onValueChange={(value) =>
                    setDepartmentFilter(value === "all" ? undefined : parseInt(value))
                  }
                >
                  <SelectTrigger id="department-filter" data-testid="select-department-filter">
                    <SelectValue placeholder="All departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    {departments?.map((department) => (
                      <SelectItem key={department.departmentId} value={department.departmentId.toString()}>
                        {department.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {productsLoading ? (
              <p className="text-muted-foreground">Loading products...</p>
            ) : productsData && productsData.products.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>SKU</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead className="text-center">Variants</TableHead>
                    <TableHead className="text-center">Data Quality</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead>Added</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productsData.products.map((product) => (
                    <TableRow
                      key={product.productId}
                      onClick={() => handleProductClick(product.productId)}
                      className="cursor-pointer hover-elevate"
                      data-testid={`row-product-${product.productId}`}
                    >
                      <TableCell className="font-medium" data-testid={`text-sku-${product.productId}`}>
                        {product.productSku}
                      </TableCell>
                      <TableCell className="max-w-xs truncate" data-testid={`text-description-${product.productId}`}>
                        {product.productDescription || <span className="text-muted-foreground italic">No description</span>}
                      </TableCell>
                      <TableCell data-testid={`text-brand-${product.productId}`}>
                        {product.brandName || <span className="text-muted-foreground">—</span>}
                      </TableCell>
                      <TableCell className="text-center" data-testid={`text-variant-count-${product.productId}`}>
                        {product.variantCount}
                      </TableCell>
                      <TableCell className="text-center">
                        <span 
                          className={`font-medium ${getAttributionColor(product.dataAttribution)}`}
                          data-testid={`text-attribution-${product.productId}`}
                        >
                          {product.dataAttribution}%
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge 
                          variant={product.enabled ? "default" : "secondary"}
                          data-testid={`badge-status-${product.productId}`}
                        >
                          {product.enabled ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground whitespace-nowrap" data-testid={`text-added-${product.productId}`}>
                        {product.createdAt ? timeAgo(product.createdAt) : "—"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-muted-foreground text-center py-8">No products found</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
