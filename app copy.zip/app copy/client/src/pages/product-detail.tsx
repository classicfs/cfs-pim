import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation, Link } from "wouter";
import { ArrowLeft, Edit2, Save, X, Package, Plus, Trash2, Pencil, FolderTree, Search, ImageIcon, RefreshCw, AlertTriangle } from "lucide-react";
import { useState } from "react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ProductDetails {
  productId: number;
  productSku: string;
  articleNumber: string | null;
  productDescription: string | null;
  productColourId: number | null;
  genderId: number | null;
  eraId: number | null;
  brandId: number | null;
  brandName: string | null;
  productTypeId: number | null;
  productStyle: string | null;
  taxClassId: number | null;
  composition: string | null;
  countryOfManufacture: string | null;
  commodityCode: string | null;
  imageCode: string | null;
  enabled: boolean;
  sync: boolean;
  syncRequiredMissing?: string[];
  createdAt: string;
  updatedAt: string;
  dataAttribution: number;
  teamMeta?: Array<{
    clubId: number | null;
    clubName?: string | null;
    isPrimary?: boolean | null;
  }>;
  productAttributes?: AttributeValue[];
  variants: Array<{
    productVariantId: number;
    productVariantSku: string;
    sizeId: number | null;
    sizeName?: string | null;
    sizeShortName?: string | null;
    conditionId: number | null;
    conditionName?: string | null;
    enabled: boolean;
  }>;
}

interface AttributeValue {
  attributeId: number;
  code: string;
  label: string | null;
  dataType: string | null;
  storeId: number | null;
  valueText: string | null;
  valueNum: string | number | null;
  valueBool: boolean | null;
  valueJson: any | null;
}

interface VariantDetails {
  productVariantId: number;
  productVariantSku: string;
  productId: number | null;
  sizeId: number | null;
  taxClassId: number | null;
  conditionId: number | null;
  conditionDetail: string | null;
  barcode: string | null;
  widthCm: number | null;
  lengthCm: number | null;
  weight: string | null;
  depth: string | null;
  costPrice: string | null;
  averageCostPrice: string | null;
  customerPrice: string | null;
  printed: boolean;
  magentoProductId: number | null;
  enabled: boolean;
  attributes?: AttributeValue[];
}

function formatAttributeValue(attribute: AttributeValue): string {
  if (attribute.valueText !== null && String(attribute.valueText).trim() !== "") {
    return String(attribute.valueText);
  }
  if (attribute.valueNum !== null && attribute.valueNum !== undefined) {
    return String(attribute.valueNum);
  }
  if (attribute.valueBool !== null && attribute.valueBool !== undefined) {
    return attribute.valueBool ? "Yes" : "No";
  }
  if (attribute.valueJson !== null && attribute.valueJson !== undefined) {
    return JSON.stringify(attribute.valueJson);
  }
  return "—";
}

function AttachProductsDialog({ open, onOpenChange, productId }: { open: boolean; onOpenChange: (open: boolean) => void; productId: number }) {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  const { data: searchResults = [], isFetching: isSearching } = useQuery<any[]>({
    queryKey: ["/api/catalog/products", { search, limit: 20 }],
    queryFn: async () => {
      if (!search || search.length < 2) return [];
      const params = new URLSearchParams({ search, limit: "20" });
      const res = await fetch(`/api/catalog/products?${params}`);
      const data = await res.json();
      return (data.products ?? data ?? []).filter(
        (p: any) => p.productId !== productId,
      );
    },
    enabled: open && search.length >= 2,
  });

  const mutation = useMutation({
    mutationFn: async (simpleProductIds: number[]) => {
      const res = await apiRequest("POST", `/api/products/${productId}/attach-simple-products`, {
        productIds: simpleProductIds,
      });
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Products attached",
        description: `${data.attached} variant(s) attached, ${data.removed} empty product(s) removed.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({ title: "Failed to attach", description: error.message, variant: "destructive" });
    },
  });

  const handleOpenChange = (nextOpen: boolean) => {
    onOpenChange(nextOpen);
    if (!nextOpen) {
      setSearch("");
      setSelectedIds(new Set());
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Attach Simple Products</DialogTitle>
          <DialogDescription>
            Search for existing products and attach their variants to this product. The original products will be removed if they have no remaining variants.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by SKU or description..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
              data-testid="input-attach-search"
            />
          </div>
          <div className="max-h-72 overflow-y-auto border rounded-md">
            {isSearching ? (
              <div className="p-4 text-center text-sm text-muted-foreground">Searching...</div>
            ) : search.length < 2 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">Type at least 2 characters to search</div>
            ) : searchResults.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">No products found</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10"></TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Variants</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {searchResults.map((p: any) => (
                    <TableRow key={p.productId} className="cursor-pointer" onClick={() => {
                      setSelectedIds((prev) => {
                        const next = new Set(prev);
                        if (next.has(p.productId)) next.delete(p.productId);
                        else next.add(p.productId);
                        return next;
                      });
                    }} data-testid={`row-attach-product-${p.productId}`}>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={selectedIds.has(p.productId)}
                          onCheckedChange={(checked) => {
                            setSelectedIds((prev) => {
                              const next = new Set(prev);
                              if (checked) next.add(p.productId);
                              else next.delete(p.productId);
                              return next;
                            });
                          }}
                          data-testid={`checkbox-attach-${p.productId}`}
                        />
                      </TableCell>
                      <TableCell className="font-mono text-sm">{p.productSku}</TableCell>
                      <TableCell className="text-sm truncate max-w-48">{p.productDescription || "-"}</TableCell>
                      <TableCell><Badge variant="outline">{p.productTypeName || "Simple"}</Badge></TableCell>
                      <TableCell className="text-right">{p.variantCount ?? 0}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
          {selectedIds.size > 0 && (
            <p className="text-sm text-muted-foreground">{selectedIds.size} product(s) selected</p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)} data-testid="button-attach-cancel">Cancel</Button>
          <Button
            onClick={() => mutation.mutate(Array.from(selectedIds))}
            disabled={selectedIds.size === 0 || mutation.isPending}
            data-testid="button-attach-confirm"
          >
            {mutation.isPending ? "Attaching..." : `Attach ${selectedIds.size} Product(s)`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [editedProduct, setEditedProduct] = useState<Partial<ProductDetails>>({});
  const [isCreateVariantOpen, setIsCreateVariantOpen] = useState(false);
  const [variantSizeId, setVariantSizeId] = useState<string>("none");
  const [variantTaxClassId, setVariantTaxClassId] = useState<string>("none");
  const [variantConditionId, setVariantConditionId] = useState<string>("none");
  const [variantEnabled, setVariantEnabled] = useState(true);
  const [variantPrinted, setVariantPrinted] = useState(false);
  const [variantFormKey, setVariantFormKey] = useState(0);
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const [isVariantDialogOpen, setIsVariantDialogOpen] = useState(false);
  const [isVariantEditing, setIsVariantEditing] = useState(false);
  const [editedVariant, setEditedVariant] = useState<Partial<VariantDetails>>({});
  const [isAddProductAttributeOpen, setIsAddProductAttributeOpen] = useState(false);
  const [isAddVariantAttributeOpen, setIsAddVariantAttributeOpen] = useState(false);
  const [isEditProductAttributeOpen, setIsEditProductAttributeOpen] = useState(false);
  const [editingProductAttribute, setEditingProductAttribute] = useState<AttributeValue | null>(null);
  const [selectedAttributeId, setSelectedAttributeId] = useState<string>("");
  const [selectedStoreIdForAttr, setSelectedStoreIdForAttr] = useState<string>("");
  const [attributeValue, setAttributeValue] = useState<string>("");
  const [attributeValueBool, setAttributeValueBool] = useState(false);
  const [editedTeamId, setEditedTeamId] = useState<string>("none");
  const [categorySearch, setCategorySearch] = useState("");
  const [previewImageUrl, setPreviewImageUrl] = useState<string | null>(null);
  const [showAddImageDialog, setShowAddImageDialog] = useState(false);
  const [newImageUrl, setNewImageUrl] = useState("");
  const [newImageRole, setNewImageRole] = useState("base");
  const [newImageLabel, setNewImageLabel] = useState("");
  const [showAssignedCategoriesOnly, setShowAssignedCategoriesOnly] = useState(true);
  const [isBulkEditOpen, setIsBulkEditOpen] = useState(false);
  const [bulkEditValues, setBulkEditValues] = useState<Record<string, any>>({});
  const [bulkEditChanged, setBulkEditChanged] = useState<Set<string>>(new Set());
  const [isAttachDialogOpen, setIsAttachDialogOpen] = useState(false);

  const productId = parseInt(params.id || "0");

  const { data: product, isLoading } = useQuery<ProductDetails>({
    queryKey: ["/api/products", productId, "details"],
    enabled: productId > 0,
  });
  const productAttributes = product?.productAttributes ?? [];
  const primaryTeam = product?.teamMeta?.find((entry) => entry.isPrimary) ?? product?.teamMeta?.[0];

  const { data: brands = [] } = useQuery<any[]>({
    queryKey: ["/api/brands"],
  });

  const { data: productTypes = [] } = useQuery<any[]>({
    queryKey: ["/api/product-types"],
  });

  const { data: clubs = [] } = useQuery<any[]>({
    queryKey: ["/api/clubs"],
  });

  const { data: productColours = [] } = useQuery<any[]>({
    queryKey: ["/api/product-colours"],
  });

  const { data: genders = [] } = useQuery<any[]>({
    queryKey: ["/api/genders"],
  });

  const { data: eras = [] } = useQuery<any[]>({
    queryKey: ["/api/eras"],
  });


  const { data: sizes = [] } = useQuery<any[]>({
    queryKey: ["/api/sizes"],
  });

  const { data: conditions = [] } = useQuery<any[]>({
    queryKey: ["/api/conditions"],
  });

  const { data: taxClasses = [] } = useQuery<any[]>({
    queryKey: ["/api/tax-classes"],
  });

  const { data: attributeDefs = [] } = useQuery<any[]>({
    queryKey: ["/api/attribute-defs"],
  });

  const { data: stores = [] } = useQuery<Array<{ storeId: number; code: string; name: string | null }>>({
    queryKey: ["/api/stores"],
  });

  const { data: currencies = [] } = useQuery<Array<{
    currencyId: number;
    code: string;
    name: string | null;
    symbol: string | null;
    enabled: boolean;
  }>>({
    queryKey: ["/api/currencies"],
  });

  const { data: productStores = [], isLoading: isLoadingProductStores } = useQuery<Array<{ storeId: number; enabled: boolean }>>({
    queryKey: ["/api/products", productId, "stores"],
    enabled: !!productId,
  });

  const { data: allCategories = [] } = useQuery<Array<{ categoryId: number; parentId: number | null; name: string; pathKey: string }>>({
    queryKey: ["/api/categories"],
  });

  const { data: productCategories = [], isLoading: isLoadingProductCategories } = useQuery<Array<{ categoryId: number; name: string; pathKey: string }>>({
    queryKey: ["/api/products", productId, "categories"],
    enabled: !!productId,
  });

  const { data: productImages = [] } = useQuery<Array<{ imageId: number; productId: number; role: string; url: string; label: string | null; sortOrder: number | null }>>({
    queryKey: ["/api/products", productId, "images"],
    enabled: !!productId,
  });

  const { data: productPrices = [] } = useQuery<Array<{
    productPriceId: number;
    productId: number;
    currencyId: number;
    currencyCode: string | null;
    currencyName: string | null;
    currencySymbol: string | null;
    costPrice: string | null;
    averageCostPrice: string | null;
    retailPrice: string | null;
    specialRetailPrice: string | null;
    customerPrice: string | null;
    isManualOverride: boolean;
    stores: Array<{ storeId: number; code: string; name: string | null }>;
  }>>({
    queryKey: ["/api/products", productId, "prices"],
    enabled: !!productId,
  });

  const { data: variantDetails, isLoading: isLoadingVariant } = useQuery<VariantDetails>({
    queryKey: ["/api/variants", selectedVariantId],
    enabled: !!selectedVariantId && isVariantDialogOpen,
  });

  const { data: variantPrices = [], isLoading: isLoadingVariantPrices } = useQuery<Array<{
    variantPriceId: number;
    productVariantId: number;
    currencyId: number;
    currencyCode: string | null;
    currencyName: string | null;
    currencySymbol: string | null;
    costPrice: string | null;
    retailPrice: string | null;
    specialRetailPrice: string | null;
    isManualOverride: boolean;
  }>>({
    queryKey: ["/api/variants", selectedVariantId, "prices-with-currency"],
    enabled: !!selectedVariantId && isVariantDialogOpen,
  });

  const [editingPrices, setEditingPrices] = useState<Record<number, {
    retailPrice: string;
    specialRetailPrice: string;
    costPrice: string;
  }>>({});
  const [isPriceEditing, setIsPriceEditing] = useState(false);

  const variantAttributes = variantDetails?.attributes ?? [];
  const selectedAttributeDef = attributeDefs.find(
    (def: any) => String(def.attributeId) === selectedAttributeId,
  );
  const supportsScope = (
    scope: string | null | undefined,
    target: "product" | "variant",
  ) => {
    if (!scope) return true;
    const normalized = String(scope).toLowerCase();
    if (normalized === "parent") {
      return target === "product";
    }
    if (normalized === "variant") {
      return target === "variant";
    }
    if (normalized === "product") {
      return target === "product";
    }
    return true;
  };

  const updateMutation = useMutation({
    mutationFn: async (updates: Partial<ProductDetails>) => {
      const currentTeamId =
        primaryTeam?.clubId !== null && primaryTeam?.clubId !== undefined
          ? Number(primaryTeam.clubId)
          : null;
      const nextTeamId = editedTeamId === "none" ? null : Number(editedTeamId);

      if (currentTeamId !== nextTeamId) {
        await apiRequest("PATCH", `/api/products/${productId}/team-meta`, {
          clubId: nextTeamId,
        });
      }

      return await apiRequest("PATCH", `/api/products/${productId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Success",
        description: "Product updated successfully",
      });
      setIsEditing(false);
      setEditedProduct({});
      setEditedTeamId(
        primaryTeam?.clubId !== null && primaryTeam?.clubId !== undefined
          ? String(primaryTeam.clubId)
          : "none",
      );
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update product: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const updateVariantMutation = useMutation({
    mutationFn: async (updates: Partial<VariantDetails>) => {
      if (!selectedVariantId) {
        throw new Error("No variant selected");
      }
      return await apiRequest("PATCH", `/api/variants/${selectedVariantId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId] });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      toast({
        title: "Success",
        description: "Variant updated successfully",
      });
      setIsVariantEditing(false);
      setEditedVariant({});
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update variant: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const updateVariantPriceMutation = useMutation({
    mutationFn: async ({ currencyId, retailPrice, specialRetailPrice, costPrice, isManualOverride }: {
      currencyId: number;
      retailPrice: string | null;
      specialRetailPrice: string | null;
      costPrice: string | null;
      isManualOverride?: boolean;
    }) => {
      if (!selectedVariantId) {
        throw new Error("No variant selected");
      }
      return await apiRequest("PUT", `/api/variants/${selectedVariantId}/prices/${currencyId}`, {
        retailPrice,
        specialRetailPrice,
        costPrice,
        isManualOverride: isManualOverride ?? true,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId, "prices-with-currency"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update price: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const detachVariantMutation = useMutation({
    mutationFn: async (variantId: number) => {
      const response = await apiRequest("POST", `/api/products/${productId}/variants/${variantId}/detach`);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      toast({
        title: "Variant Detached",
        description: `Variant has been detached to new product ${data.newProductSku}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to detach variant: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const createVariantMutation = useMutation({
    mutationFn: async (data: {
      productVariantSku: string;
      sizeId: number | null;
      taxClassId: number | null;
      conditionId: number | null;
      conditionDetail: string | null;
      barcode: string | null;
      magentoProductId: number | null;
      widthCm: number | null;
      lengthCm: number | null;
      weight: string | null;
      depth: string | null;
      costPrice: string | null;
      averageCostPrice: string | null;
      customerPrice: string | null;
      printed: boolean;
      enabled: boolean;
    }) => {
      const response = await apiRequest("POST", `/api/products/${productId}/variants`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Variant created",
        description: "The variant is now attached to this product.",
      });
      setIsCreateVariantOpen(false);
      setVariantSizeId("none");
      setVariantTaxClassId("none");
      setVariantConditionId("none");
      setVariantEnabled(true);
      setVariantPrinted(false);
      setVariantFormKey((prev) => prev + 1);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create variant: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const addProductAttributeMutation = useMutation({
    mutationFn: async () => {
      if (!selectedAttributeId) {
        throw new Error("Select an attribute");
      }
      const attributeId = Number(selectedAttributeId);
      const value =
        selectedAttributeDef?.dataType === "boolean" ? attributeValueBool : attributeValue;
      const storeId = selectedStoreIdForAttr ? Number(selectedStoreIdForAttr) : null;
      await apiRequest("POST", `/api/products/${productId}/attributes`, {
        attributeId,
        value,
        storeId,
      });
    },
    onSuccess: () => {
      toast({ title: "Attribute saved", description: "Product attribute updated." });
      setIsAddProductAttributeOpen(false);
      setSelectedAttributeId("");
      setSelectedStoreIdForAttr("");
      setAttributeValue("");
      setAttributeValueBool(false);
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save attribute: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const addVariantAttributeMutation = useMutation({
    mutationFn: async () => {
      if (!selectedVariantId) {
        throw new Error("No variant selected");
      }
      if (!selectedAttributeId) {
        throw new Error("Select an attribute");
      }
      const attributeId = Number(selectedAttributeId);
      const value =
        selectedAttributeDef?.dataType === "boolean" ? attributeValueBool : attributeValue;
      await apiRequest("POST", `/api/variants/${selectedVariantId}/attributes`, {
        attributeId,
        value,
      });
    },
    onSuccess: () => {
      toast({ title: "Attribute saved", description: "Variant attribute updated." });
      setIsAddVariantAttributeOpen(false);
      setSelectedAttributeId("");
      setAttributeValue("");
      setAttributeValueBool(false);
      queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save attribute: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const editProductAttributeMutation = useMutation({
    mutationFn: async () => {
      if (!editingProductAttribute) {
        throw new Error("No attribute selected");
      }
      const attrDef = attributeDefs.find(
        (def: any) => def.attributeId === editingProductAttribute.attributeId,
      );
      const value = attrDef?.dataType === "boolean" ? attributeValueBool : attributeValue;
      await apiRequest("POST", `/api/products/${productId}/attributes`, {
        attributeId: editingProductAttribute.attributeId,
        value,
        storeId: editingProductAttribute.storeId ?? null,
      });
    },
    onSuccess: () => {
      toast({ title: "Attribute updated", description: "Product attribute has been updated." });
      setIsEditProductAttributeOpen(false);
      setEditingProductAttribute(null);
      setAttributeValue("");
      setAttributeValueBool(false);
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update attribute: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const deleteProductAttributeMutation = useMutation({
    mutationFn: async (attributeId: number) => {
      await apiRequest("DELETE", `/api/products/${productId}/attributes/${attributeId}`);
    },
    onSuccess: () => {
      toast({ title: "Attribute removed", description: "Product attribute has been removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to remove attribute: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const updateProductStoresMutation = useMutation({
    mutationFn: async (storeIds: number[]) => {
      await apiRequest("PUT", `/api/products/${productId}/stores`, { storeIds });
    },
    onSuccess: () => {
      toast({ title: "Stores updated", description: "Product store assignments have been updated." });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "stores"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update stores: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const handleStoreToggle = (storeId: number, isCurrentlyAssigned: boolean) => {
    const currentStoreIds = productStores
      .filter(ps => ps.enabled !== false)
      .map(ps => ps.storeId);
    let newStoreIds: number[];
    if (isCurrentlyAssigned) {
      newStoreIds = currentStoreIds.filter(id => id !== storeId);
    } else {
      newStoreIds = [...currentStoreIds, storeId];
    }
    updateProductStoresMutation.mutate(newStoreIds);
  };

  const updateProductCategoriesMutation = useMutation({
    mutationFn: async (categoryIds: number[]) => {
      await apiRequest("PUT", `/api/products/${productId}/categories`, { categoryIds });
    },
    onSuccess: () => {
      toast({ title: "Categories updated", description: "Product category assignments have been updated." });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "categories"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update categories: ${error instanceof Error ? error.message : "Unknown error"}`,
        variant: "destructive",
      });
    },
  });

  const bulkUpdateVariantsMutation = useMutation({
    mutationFn: async (data: { updates: Record<string, any>; gbpPricing?: Record<string, any> }) => {
      return await apiRequest("PATCH", `/api/products/${productId}/variants/bulk-update`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "details"] });
      if (selectedVariantId) {
        queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId, "prices-with-currency"] });
      }
      toast({ title: "Success", description: "All variants updated successfully" });
      setIsBulkEditOpen(false);
      setBulkEditValues({});
      setBulkEditChanged(new Set());
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message || "Failed to bulk update variants", variant: "destructive" });
    },
  });

  const IMAGE_ROLES = ["base", "small", "thumbnail", "additional", "swatch"];

  const addImageMutation = useMutation({
    mutationFn: async (data: { productId: number; url: string; role: string; label: string }) => {
      const res = await apiRequest("POST", "/api/images", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Image added", description: "The image has been added to this product." });
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId, "images"] });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      setShowAddImageDialog(false);
      setNewImageUrl("");
      setNewImageRole("base");
      setNewImageLabel("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to add image", variant: "destructive" });
    },
  });

  const toggleSyncMutation = useMutation({
    mutationFn: async (newSyncValue: boolean) => {
      await apiRequest("PATCH", `/api/products/${productId}`, { sync: newSyncValue });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products", productId] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Sync updated", description: "Product sync setting has been updated." });
    },
    onError: (error: Error) => {
      let desc = "Failed to update sync";
      try {
        const body = JSON.parse(error.message.replace(/^\d+:\s*/, ""));
        if (body?.error) desc = body.error;
      } catch { desc = error.message || desc; }
      toast({ title: "Error", description: desc, variant: "destructive" });
    },
  });

  const resyncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/products/${productId}/resync`);
      return res.json();
    },
    onSuccess: (data: any) => {
      const variantCount = data?.variantEntries?.length ?? 0;
      const desc = variantCount > 0
        ? `Product and ${variantCount} variant${variantCount !== 1 ? "s" : ""} added to the sync queue.`
        : "Product has been added to the sync queue.";
      toast({ title: "Resync queued", description: desc });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to queue resync", variant: "destructive" });
    },
  });

  const handleAddImage = () => {
    if (!productId || !newImageUrl.trim()) return;
    addImageMutation.mutate({
      productId,
      url: newImageUrl.trim(),
      role: newImageRole,
      label: newImageLabel.trim(),
    });
  };

  const handleBulkEditInputChange = (field: string, value: any) => {
    setBulkEditValues(prev => ({ ...prev, [field]: value }));
    setBulkEditChanged(prev => new Set(prev).add(field));
  };

  const handleBulkEditSave = () => {
    const updates: Record<string, any> = {};
    const gbpPricing: Record<string, any> = {};
    const gbpPriceFields: Record<string, string> = {
      gbpRetailPrice: "retailPrice",
      gbpSpecialPrice: "specialRetailPrice",
      gbpCostPrice: "costPrice",
    };
    for (const field of Array.from(bulkEditChanged)) {
      if (bulkEditValues[field] !== undefined) {
        if (field in gbpPriceFields) {
          gbpPricing[gbpPriceFields[field]] = bulkEditValues[field] || null;
        } else {
          updates[field] = bulkEditValues[field];
        }
      }
    }
    if (Object.keys(updates).length === 0 && Object.keys(gbpPricing).length === 0) {
      toast({ title: "No changes made", description: "Please modify at least one field before saving.", variant: "destructive" });
      return;
    }
    bulkUpdateVariantsMutation.mutate({ updates, gbpPricing: Object.keys(gbpPricing).length > 0 ? gbpPricing : undefined });
  };

  const handleCategoryToggle = (categoryId: number, isCurrentlyAssigned: boolean) => {
    const currentCategoryIds = productCategories.map(pc => pc.categoryId);
    let newCategoryIds: number[];
    if (isCurrentlyAssigned) {
      newCategoryIds = currentCategoryIds.filter(id => id !== categoryId);
    } else {
      newCategoryIds = [...currentCategoryIds, categoryId];
    }
    updateProductCategoriesMutation.mutate(newCategoryIds);
  };

  if (isLoading || !product) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          <p className="text-muted-foreground">Loading product...</p>
        </div>
      </div>
    );
  }

  const handleEdit = () => {
    setEditedProduct({
      productDescription: product.productDescription,
      articleNumber: product.articleNumber,
      composition: product.composition,
      countryOfManufacture: product.countryOfManufacture,
      commodityCode: product.commodityCode,
      imageCode: product.imageCode,
      brandId: product.brandId,
      genderId: product.genderId,
      productTypeId: product.productTypeId,
      productStyle: product.productStyle,
      productColourId: product.productColourId,
      eraId: product.eraId,
      enabled: product.enabled,
      sync: product.sync,
    });
    setEditedTeamId(
      primaryTeam?.clubId !== null && primaryTeam?.clubId !== undefined
        ? String(primaryTeam.clubId)
        : "none",
    );
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedProduct({});
    setEditedTeamId(
      primaryTeam?.clubId !== null && primaryTeam?.clubId !== undefined
        ? String(primaryTeam.clubId)
        : "none",
    );
  };

  const handleSave = () => {
    updateMutation.mutate(editedProduct);
  };

  const handleInputChange = (field: keyof ProductDetails, value: any) => {
    setEditedProduct((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleVariantDialogOpen = (variantId: number) => {
    setSelectedVariantId(variantId);
    setIsVariantDialogOpen(true);
    setIsVariantEditing(false);
    setEditedVariant({});
  };

  const handleVariantEdit = (variant: VariantDetails) => {
    setEditedVariant({
      sizeId: variant.sizeId,
      taxClassId: variant.taxClassId,
      conditionId: variant.conditionId,
      conditionDetail: variant.conditionDetail,
      barcode: variant.barcode,
      widthCm: variant.widthCm,
      lengthCm: variant.lengthCm,
      weight: variant.weight,
      depth: variant.depth,
      costPrice: variant.costPrice,
      averageCostPrice: variant.averageCostPrice,
      customerPrice: variant.customerPrice,
      printed: variant.printed,
      magentoProductId: variant.magentoProductId,
      enabled: variant.enabled,
    });
    setIsVariantEditing(true);
  };

  const handleVariantInputChange = (field: keyof VariantDetails, value: any) => {
    setEditedVariant((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleVariantSave = () => {
    updateVariantMutation.mutate(editedVariant);
  };

  const handleCreateVariantSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const productVariantSku = String(formData.get("productVariantSku") ?? "").trim();
    const conditionDetail = String(formData.get("conditionDetail") ?? "").trim() || null;
    const barcode = String(formData.get("barcode") ?? "").trim() || null;
    const magentoRaw = String(formData.get("magentoProductId") ?? "").trim();
    const magentoProductId = magentoRaw ? Number(magentoRaw) : null;
    const widthRaw = String(formData.get("widthCm") ?? "").trim();
    const widthCm = widthRaw ? Number(widthRaw) : null;
    const lengthRaw = String(formData.get("lengthCm") ?? "").trim();
    const lengthCm = lengthRaw ? Number(lengthRaw) : null;
    const weight = String(formData.get("weight") ?? "").trim() || null;
    const depth = String(formData.get("depth") ?? "").trim() || null;
    const costPrice = String(formData.get("costPrice") ?? "").trim() || null;
    const averageCostPrice = String(formData.get("averageCostPrice") ?? "").trim() || null;
    const customerPrice = String(formData.get("customerPrice") ?? "").trim() || null;

    createVariantMutation.mutate({
      productVariantSku,
      sizeId: variantSizeId !== "none" ? Number(variantSizeId) : null,
      taxClassId: variantTaxClassId !== "none" ? Number(variantTaxClassId) : null,
      conditionId: variantConditionId !== "none" ? Number(variantConditionId) : null,
      conditionDetail,
      barcode,
      magentoProductId,
      widthCm,
      lengthCm,
      weight,
      depth,
      costPrice,
      averageCostPrice,
      customerPrice,
      printed: variantPrinted,
      enabled: variantEnabled,
    });
  };

  const getAttributionColor = (attribution: number) => {
    if (attribution >= 80) return "text-green-600 dark:text-green-400";
    if (attribution >= 50) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/catalog")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2" data-testid="heading-product-detail">
                <Package className="h-8 w-8" />
                {product.name || "Untitled product"}
              </h1>
              <p className="text-muted-foreground mt-1">
                {product.productSku}
              </p>
            </div>
            <TooltipProvider>
              <div className="flex items-center gap-3">
                <Switch
                  id="sync-header"
                  checked={product.sync ?? false}
                  onCheckedChange={(value) => toggleSyncMutation.mutate(value)}
                  disabled={toggleSyncMutation.isPending || (!product.sync && (product.syncRequiredMissing?.length ?? 0) > 0)}
                  data-testid="switch-product-sync"
                />
                <Label htmlFor="sync-header" className="text-sm whitespace-nowrap">Sync to Alumio</Label>
                {(product.syncRequiredMissing?.length ?? 0) > 0 && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-xs font-medium">Missing fields</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-xs">
                      <p className="font-medium mb-1">Required for sync:</p>
                      <ul className="text-xs space-y-0.5">
                        {product.syncRequiredMissing!.map((f) => (
                          <li key={f}>• {f}</li>
                        ))}
                      </ul>
                    </TooltipContent>
                  </Tooltip>
                )}
              </div>
            </TooltipProvider>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => resyncMutation.mutate()}
              disabled={resyncMutation.isPending}
              data-testid="button-resync"
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${resyncMutation.isPending ? "animate-spin" : ""}`} />
              {resyncMutation.isPending ? "Queuing..." : "Resync"}
            </Button>
            {!isEditing ? (
              <Button onClick={handleEdit} data-testid="button-edit">
                <Edit2 className="h-4 w-4 mr-2" />
                Edit Product
              </Button>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={handleCancel}
                  disabled={updateMutation.isPending}
                  data-testid="button-cancel"
                >
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  disabled={updateMutation.isPending}
                  data-testid="button-save"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Product Information */}
        <Card>
          <CardHeader>
            <CardTitle>Product Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="productSku">Product SKU</Label>
                <Input
                  id="productSku"
                  value={product.productSku}
                  disabled
                  data-testid="input-product-sku"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="articleNumber">Article Number</Label>
                <Input
                  id="articleNumber"
                  value={isEditing ? (editedProduct.articleNumber ?? "") : (product.articleNumber ?? "")}
                  onChange={(e) => handleInputChange("articleNumber", e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-article-number"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="productDescription">Description</Label>
              <Textarea
                id="productDescription"
                value={isEditing ? (editedProduct.productDescription ?? "") : (product.productDescription ?? "")}
                onChange={(e) => handleInputChange("productDescription", e.target.value)}
                disabled={!isEditing}
                rows={3}
                data-testid="input-product-description"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="brandId">Brand</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.brandId !== null && editedProduct.brandId !== undefined
                        ? String(editedProduct.brandId)
                        : "none"
                      : product.brandId !== null && product.brandId !== undefined
                        ? String(product.brandId)
                        : "none"
                  }
                  onValueChange={(value) => {
                    const newBrandId = value === "none" ? null : Number(value);
                    handleInputChange("brandId", newBrandId);
                    const currentColourId = editedProduct.productColourId;
                    if (currentColourId) {
                      const currentColour = productColours.find((c: any) => c.productColourId === currentColourId);
                      if (currentColour && currentColour.brandId && currentColour.brandId !== newBrandId) {
                        handleInputChange("productColourId", null);
                      }
                    }
                  }}
                  disabled={!isEditing}
                >
                  <SelectTrigger id="brandId" data-testid="input-brand-id">
                    <SelectValue placeholder="Select brand" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No brand</SelectItem>
                    {brands.map((brand) => (
                      <SelectItem key={brand.brandId} value={String(brand.brandId)}>
                        {brand.brandName || `Brand ${brand.brandId}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="productTypeId">Product Type</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.productTypeId !== null && editedProduct.productTypeId !== undefined
                        ? String(editedProduct.productTypeId)
                        : "none"
                      : product.productTypeId !== null && product.productTypeId !== undefined
                        ? String(product.productTypeId)
                        : "none"
                  }
                  onValueChange={(value) =>
                    handleInputChange("productTypeId", value === "none" ? null : Number(value))
                  }
                  disabled={!isEditing}
                >
                  <SelectTrigger id="productTypeId" data-testid="input-product-type-id">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No type</SelectItem>
                    {productTypes.map((type) => (
                      <SelectItem key={type.productTypeId} value={String(type.productTypeId)}>
                        {type.productTypeName || `Type ${type.productTypeId}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="productStyle">Product Style</Label>
                <Input
                  id="productStyle"
                  data-testid="input-product-style"
                  value={
                    isEditing
                      ? editedProduct.productStyle || ""
                      : product.productStyle || ""
                  }
                  onChange={(e) =>
                    handleInputChange("productStyle", e.target.value || null)
                  }
                  disabled={!isEditing}
                  placeholder="e.g. Home, Away, Third"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="productTaxClassId">Tax Class</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.taxClassId !== null && editedProduct.taxClassId !== undefined
                        ? String(editedProduct.taxClassId)
                        : "none"
                      : product.taxClassId !== null && product.taxClassId !== undefined
                        ? String(product.taxClassId)
                        : "none"
                  }
                  onValueChange={(value) =>
                    handleInputChange("taxClassId", value === "none" ? null : Number(value))
                  }
                  disabled={!isEditing}
                >
                  <SelectTrigger id="productTaxClassId" data-testid="select-product-tax-class">
                    <SelectValue placeholder="Select tax class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No tax class</SelectItem>
                    {taxClasses.map((tc: any) => {
                      const id = tc.taxClassId ?? tc.tax_class_id;
                      if (id === null || id === undefined) return null;
                      const name = tc.taxClassName ?? tc.tax_class_name;
                      return (
                        <SelectItem key={id} value={String(id)}>
                          {name || `Tax Class ${id}`}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="productColourId">Product Colour</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.productColourId !== null && editedProduct.productColourId !== undefined
                        ? String(editedProduct.productColourId)
                        : "none"
                      : product.productColourId !== null && product.productColourId !== undefined
                        ? String(product.productColourId)
                        : "none"
                  }
                  onValueChange={(value) =>
                    handleInputChange("productColourId", value === "none" ? null : Number(value))
                  }
                  disabled={!isEditing}
                >
                  <SelectTrigger id="productColourId" data-testid="select-product-colour">
                    <SelectValue placeholder="Select colour" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No colour</SelectItem>
                    {productColours
                      .filter((colour: any) => {
                        const activeBrandId = isEditing ? editedProduct.brandId : product.brandId;
                        if (activeBrandId) {
                          return colour.brandId === activeBrandId || !colour.brandId;
                        }
                        return true;
                      })
                      .map((colour: any) => {
                      const colourName = colour.magentoColourName || colour.brandColourName || `Colour ${colour.productColourId}`;
                      const displayName = colour.brandName ? `${colourName} (${colour.brandName})` : colourName;
                      return (
                        <SelectItem key={colour.productColourId} value={String(colour.productColourId)}>
                          {displayName}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="genderId">Gender</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.genderId !== null && editedProduct.genderId !== undefined
                        ? String(editedProduct.genderId)
                        : "none"
                      : product.genderId !== null && product.genderId !== undefined
                        ? String(product.genderId)
                        : "none"
                  }
                  onValueChange={(value) =>
                    handleInputChange("genderId", value === "none" ? null : Number(value))
                  }
                  disabled={!isEditing}
                >
                  <SelectTrigger id="genderId" data-testid="select-gender">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No gender</SelectItem>
                    {genders.map((gender) => (
                      <SelectItem key={gender.genderId} value={String(gender.genderId)}>
                        {gender.genderName || `Gender ${gender.genderId}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="eraId">Era</Label>
                <Select
                  value={
                    isEditing
                      ? editedProduct.eraId !== null && editedProduct.eraId !== undefined
                        ? String(editedProduct.eraId)
                        : "none"
                      : product.eraId !== null && product.eraId !== undefined
                        ? String(product.eraId)
                        : "none"
                  }
                  onValueChange={(value) =>
                    handleInputChange("eraId", value === "none" ? null : Number(value))
                  }
                  disabled={!isEditing}
                >
                  <SelectTrigger id="eraId" data-testid="select-era">
                    <SelectValue placeholder="Select era" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No era</SelectItem>
                    {eras.map((era) => (
                      <SelectItem key={era.eraId} value={String(era.eraId)}>
                        {era.name || `Era ${era.eraId}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="teamId">Team</Label>
                <Select
                  value={
                    isEditing
                      ? editedTeamId
                      : primaryTeam?.clubId !== null && primaryTeam?.clubId !== undefined
                        ? String(primaryTeam.clubId)
                        : "none"
                  }
                  onValueChange={(value) => setEditedTeamId(value)}
                  disabled={!isEditing}
                >
                  <SelectTrigger id="teamId" data-testid="select-team">
                    <SelectValue placeholder="Select team" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No team</SelectItem>
                    {clubs.map((club) => (
                      <SelectItem key={club.clubId} value={String(club.clubId)}>
                        {club.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="composition">Composition</Label>
                <Input
                  id="composition"
                  value={isEditing ? (editedProduct.composition ?? "") : (product.composition ?? "")}
                  onChange={(e) => handleInputChange("composition", e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-composition"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="countryOfManufacture">Country of Manufacture</Label>
                <Input
                  id="countryOfManufacture"
                  value={isEditing ? (editedProduct.countryOfManufacture ?? "") : (product.countryOfManufacture ?? "")}
                  onChange={(e) => handleInputChange("countryOfManufacture", e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-country-of-manufacture"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="commodityCode">Commodity Code</Label>
                <Input
                  id="commodityCode"
                  value={isEditing ? (editedProduct.commodityCode ?? "") : (product.commodityCode ?? "")}
                  onChange={(e) => handleInputChange("commodityCode", e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-commodity-code"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="imageCode">Image Code</Label>
                <Input
                  id="imageCode"
                  value={isEditing ? (editedProduct.imageCode ?? "") : (product.imageCode ?? "")}
                  onChange={(e) => handleInputChange("imageCode", e.target.value)}
                  disabled={!isEditing}
                  data-testid="input-image-code"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Checkbox
                id="enabled"
                checked={isEditing ? (editedProduct.enabled ?? false) : product.enabled}
                onCheckedChange={(value) => handleInputChange("enabled", value === true)}
                disabled={!isEditing}
                data-testid="checkbox-product-enabled"
              />
              <Label htmlFor="enabled">Enabled</Label>
              {!isEditing && (
                <Badge variant={product.enabled ? "default" : "secondary"} data-testid="badge-enabled">
                  {product.enabled ? "Active" : "Inactive"}
                </Badge>
              )}
            </div>

            <div className="text-xs text-muted-foreground">
              <p>Created: {new Date(product.createdAt).toLocaleString()}</p>
              <p>Updated: {new Date(product.updatedAt).toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>

        {/* Variants */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <CardTitle>
                Product Variants ({product.variants?.length ?? 0})
              </CardTitle>
              <div className="flex items-center gap-2 flex-wrap">
                <Button size="sm" variant="outline" onClick={() => setIsBulkEditOpen(true)} data-testid="button-bulk-edit-variants">
                  <Pencil className="h-4 w-4 mr-2" />
                  Bulk Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => setIsAttachDialogOpen(true)} data-testid="button-attach-products">
                  <Package className="h-4 w-4 mr-2" />
                  Attach Products
                </Button>
                <Dialog open={isCreateVariantOpen} onOpenChange={setIsCreateVariantOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" data-testid="button-create-variant">
                      <Plus className="h-4 w-4 mr-2" />
                      Create Variant
                    </Button>
                  </DialogTrigger>
                <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Create Variant</DialogTitle>
                    <DialogDescription>
                      Add a new variant for this product.
                    </DialogDescription>
                  </DialogHeader>
                  <form key={variantFormKey} onSubmit={handleCreateVariantSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="productVariantSku">Variant SKU</Label>
                        <Input
                          id="productVariantSku"
                          name="productVariantSku"
                          placeholder="SKU-001-RED-S"
                          required
                          data-testid="input-variant-sku"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createMagentoProductId">Magento Product ID</Label>
                        <Input
                          id="createMagentoProductId"
                          name="magentoProductId"
                          type="number"
                          placeholder="e.g. 12345"
                          data-testid="input-create-variant-magento-id"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sizeId">Size</Label>
                        <Select value={variantSizeId} onValueChange={setVariantSizeId}>
                          <SelectTrigger data-testid="select-variant-size">
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No size</SelectItem>
                            {sizes.map((size) => (
                              <SelectItem key={size.sizeId} value={String(size.sizeId)}>
                                {size.magentoSizeLongName || size.magentoSizeShortName || `Size ${size.sizeId}`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="taxClassId">Tax Class</Label>
                        <Select value={variantTaxClassId} onValueChange={setVariantTaxClassId}>
                          <SelectTrigger data-testid="select-variant-tax-class">
                            <SelectValue placeholder="Select tax class" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No tax class</SelectItem>
                            {taxClasses.map((taxClass) => {
                              const taxClassId = taxClass.taxClassId ?? taxClass.tax_class_id;
                              if (taxClassId === null || taxClassId === undefined) {
                                return null;
                              }
                              const taxClassName = taxClass.taxClassName ?? taxClass.tax_class_name;
                              return (
                                <SelectItem key={taxClassId} value={String(taxClassId)}>
                                  {taxClassName || `Tax ${taxClassId}`}
                                </SelectItem>
                              );
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="conditionId">Condition</Label>
                        <Select value={variantConditionId} onValueChange={setVariantConditionId}>
                          <SelectTrigger data-testid="select-variant-condition">
                            <SelectValue placeholder="Select condition" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No condition</SelectItem>
                            {conditions.map((condition) => (
                              <SelectItem key={condition.conditionId} value={String(condition.conditionId)}>
                                {condition.conditionName || `Condition ${condition.conditionId}`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="createConditionDetail">Condition Detail</Label>
                        <Input
                          id="createConditionDetail"
                          name="conditionDetail"
                          placeholder="e.g. Minor pilling on sleeve"
                          data-testid="input-create-variant-condition-detail"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createBarcode">Barcode</Label>
                        <Input
                          id="createBarcode"
                          name="barcode"
                          placeholder="e.g. 5060012345678"
                          data-testid="input-create-variant-barcode"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="createWidthCm">Width (cm)</Label>
                        <Input
                          id="createWidthCm"
                          name="widthCm"
                          type="number"
                          data-testid="input-create-variant-width"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createLengthCm">Length (cm)</Label>
                        <Input
                          id="createLengthCm"
                          name="lengthCm"
                          type="number"
                          data-testid="input-create-variant-length"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createWeight">Weight</Label>
                        <Input
                          id="createWeight"
                          name="weight"
                          type="number"
                          step="0.001"
                          data-testid="input-create-variant-weight"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createDepth">Depth</Label>
                        <Input
                          id="createDepth"
                          name="depth"
                          type="number"
                          step="0.01"
                          data-testid="input-create-variant-depth"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="createCostPrice">Cost Price</Label>
                        <Input
                          id="createCostPrice"
                          name="costPrice"
                          type="number"
                          step="0.01"
                          data-testid="input-create-variant-cost-price"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createAvgCostPrice">Average Cost</Label>
                        <Input
                          id="createAvgCostPrice"
                          name="averageCostPrice"
                          type="number"
                          step="0.01"
                          data-testid="input-create-variant-avg-cost"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="createCustomerPrice">Customer Price</Label>
                        <Input
                          id="createCustomerPrice"
                          name="customerPrice"
                          type="number"
                          step="0.01"
                          data-testid="input-create-variant-customer-price"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={variantPrinted}
                          onCheckedChange={(value) => setVariantPrinted(value === true)}
                          id="createVariantPrinted"
                          data-testid="checkbox-create-variant-printed"
                        />
                        <Label htmlFor="createVariantPrinted">Printed</Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={variantEnabled}
                          onCheckedChange={(value) => setVariantEnabled(value === true)}
                          id="variantEnabled"
                          data-testid="checkbox-variant-enabled"
                        />
                        <Label htmlFor="variantEnabled">Enabled</Label>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsCreateVariantOpen(false)}
                        disabled={createVariantMutation.isPending}
                        data-testid="button-cancel-variant"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createVariantMutation.isPending}
                        data-testid="button-submit-variant"
                      >
                        {createVariantMutation.isPending ? "Creating..." : "Create Variant"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {product.variants && product.variants.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Variant SKU</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead>GBP Retail Price</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {product.variants.map((variant) => (
                    <TableRow
                      key={variant.productVariantId}
                      className="cursor-pointer"
                      onClick={() => handleVariantDialogOpen(variant.productVariantId)}
                      data-testid={`row-variant-${variant.productVariantId}`}
                    >
                      <TableCell className="font-medium" data-testid={`text-variant-sku-${variant.productVariantId}`}>
                        {variant.productVariantSku}
                      </TableCell>
                      <TableCell data-testid={`text-size-${variant.productVariantId}`}>
                        {variant.sizeName || variant.sizeShortName || (variant.sizeId ?? "—")}
                      </TableCell>
                      <TableCell data-testid={`text-condition-${variant.productVariantId}`}>
                        {variant.conditionName || (variant.conditionId ?? "—")}
                      </TableCell>
                      <TableCell data-testid={`text-gbp-price-${variant.productVariantId}`}>
                        {variant.gbpRetailPrice ? `£${Number(variant.gbpRetailPrice).toFixed(2)}` : "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={variant.enabled ? "default" : "secondary"}>
                          {variant.enabled ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(event) => {
                              event.stopPropagation();
                              handleVariantDialogOpen(variant.productVariantId);
                            }}
                            data-testid={`button-view-variant-${variant.productVariantId}`}
                          >
                            View
                          </Button>
                          {product.variants && product.variants.length > 1 &&
                            productTypes.some((t: any) =>
                              t.productTypeId === product.productTypeId &&
                              t.productTypeName?.toLowerCase() === "configurable"
                            ) && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(event) => {
                                event.stopPropagation();
                                if (confirm(`Detach variant ${variant.productVariantSku} into a new simple product?`)) {
                                  detachVariantMutation.mutate(variant.productVariantId);
                                }
                              }}
                              disabled={detachVariantMutation.isPending}
                              data-testid={`button-detach-variant-${variant.productVariantId}`}
                            >
                              Detach
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-sm text-muted-foreground" data-testid="text-no-variants">
                No variants yet. Create the first one to get started.
              </p>
            )}
          </CardContent>
        </Card>

        <Dialog open={isBulkEditOpen} onOpenChange={(open) => {
          setIsBulkEditOpen(open);
          if (!open) {
            setBulkEditValues({});
            setBulkEditChanged(new Set());
          }
        }}>
          <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Bulk Edit All Variants</DialogTitle>
              <DialogDescription>
                Edit fields below. Only fields you change will be updated across all {product.variants?.length ?? 0} variants.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bulkTaxClass">Tax Class</Label>
                  <Select
                    value={bulkEditValues.taxClassId !== undefined ? String(bulkEditValues.taxClassId ?? "none") : ""}
                    onValueChange={(value) => handleBulkEditInputChange("taxClassId", value === "none" ? null : Number(value))}
                  >
                    <SelectTrigger data-testid="select-bulk-tax-class">
                      <SelectValue placeholder="Select tax class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No tax class</SelectItem>
                      {taxClasses.map((taxClass: any) => {
                        const taxClassId = taxClass.taxClassId ?? taxClass.tax_class_id;
                        if (taxClassId === null || taxClassId === undefined) return null;
                        const taxClassName = taxClass.taxClassName ?? taxClass.tax_class_name;
                        return (
                          <SelectItem key={taxClassId} value={String(taxClassId)}>
                            {taxClassName || `Tax ${taxClassId}`}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkCondition">Condition</Label>
                  <Select
                    value={bulkEditValues.conditionId !== undefined ? String(bulkEditValues.conditionId ?? "none") : ""}
                    onValueChange={(value) => handleBulkEditInputChange("conditionId", value === "none" ? null : Number(value))}
                  >
                    <SelectTrigger data-testid="select-bulk-condition">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No condition</SelectItem>
                      {conditions.map((condition: any) => (
                        <SelectItem key={condition.conditionId} value={String(condition.conditionId)}>
                          {condition.conditionName || `Condition ${condition.conditionId}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkConditionDetail">Condition Detail</Label>
                  <Input
                    id="bulkConditionDetail"
                    value={bulkEditValues.conditionDetail ?? ""}
                    onChange={(e) => handleBulkEditInputChange("conditionDetail", e.target.value)}
                    placeholder="e.g. Brand new with tags"
                    data-testid="input-bulk-condition-detail"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bulkBarcode">Barcode</Label>
                  <Input
                    id="bulkBarcode"
                    value={bulkEditValues.barcode ?? ""}
                    onChange={(e) => handleBulkEditInputChange("barcode", e.target.value)}
                    data-testid="input-bulk-barcode"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkMagentoId">Magento Product ID</Label>
                  <Input
                    id="bulkMagentoId"
                    type="number"
                    value={bulkEditValues.magentoProductId ?? ""}
                    onChange={(e) => handleBulkEditInputChange("magentoProductId", e.target.value ? Number(e.target.value) : null)}
                    data-testid="input-bulk-magento-id"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bulkWidth">Width (cm)</Label>
                  <Input
                    id="bulkWidth"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.widthCm ?? ""}
                    onChange={(e) => handleBulkEditInputChange("widthCm", e.target.value)}
                    data-testid="input-bulk-width"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkLength">Length (cm)</Label>
                  <Input
                    id="bulkLength"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.lengthCm ?? ""}
                    onChange={(e) => handleBulkEditInputChange("lengthCm", e.target.value)}
                    data-testid="input-bulk-length"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkWeight">Weight</Label>
                  <Input
                    id="bulkWeight"
                    type="number"
                    step="0.001"
                    value={bulkEditValues.weight ?? ""}
                    onChange={(e) => handleBulkEditInputChange("weight", e.target.value)}
                    data-testid="input-bulk-weight"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkDepth">Depth</Label>
                  <Input
                    id="bulkDepth"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.depth ?? ""}
                    onChange={(e) => handleBulkEditInputChange("depth", e.target.value)}
                    data-testid="input-bulk-depth"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bulkGbpRetailPrice">GBP Retail Price</Label>
                  <Input
                    id="bulkGbpRetailPrice"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.gbpRetailPrice ?? ""}
                    onChange={(e) => handleBulkEditInputChange("gbpRetailPrice", e.target.value)}
                    data-testid="input-bulk-gbp-retail-price"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkGbpSpecialPrice">GBP Special Price</Label>
                  <Input
                    id="bulkGbpSpecialPrice"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.gbpSpecialPrice ?? ""}
                    onChange={(e) => handleBulkEditInputChange("gbpSpecialPrice", e.target.value)}
                    data-testid="input-bulk-gbp-special-price"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bulkGbpCostPrice">GBP Cost Price</Label>
                  <Input
                    id="bulkGbpCostPrice"
                    type="number"
                    step="0.01"
                    value={bulkEditValues.gbpCostPrice ?? ""}
                    onChange={(e) => handleBulkEditInputChange("gbpCostPrice", e.target.value)}
                    data-testid="input-bulk-gbp-cost-price"
                  />
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={bulkEditValues.printed ?? false}
                    onCheckedChange={(value) => handleBulkEditInputChange("printed", value === true)}
                    data-testid="checkbox-bulk-printed"
                  />
                  <Label>Printed</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={bulkEditValues.enabled ?? false}
                    onCheckedChange={(value) => handleBulkEditInputChange("enabled", value === true)}
                    data-testid="checkbox-bulk-enabled"
                  />
                  <Label>Enabled</Label>
                </div>
              </div>

              {bulkEditChanged.size > 0 && (
                <div className="text-sm text-muted-foreground">
                  {bulkEditChanged.size} field{bulkEditChanged.size !== 1 ? "s" : ""} will be updated across all variants.
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsBulkEditOpen(false)} data-testid="button-bulk-edit-cancel">
                Cancel
              </Button>
              <Button onClick={handleBulkEditSave} disabled={bulkUpdateVariantsMutation.isPending || bulkEditChanged.size === 0} data-testid="button-bulk-edit-apply">
                {bulkUpdateVariantsMutation.isPending ? "Applying..." : "Apply to All Variants"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Store Assignments */}
        <Card>
          <CardHeader>
            <CardTitle>Store Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingProductStores ? (
              <p className="text-muted-foreground text-sm">Loading stores...</p>
            ) : stores.length === 0 ? (
              <p className="text-muted-foreground text-sm">No stores configured.</p>
            ) : (
              <div className="space-y-3">
                {stores.map((store) => {
                  const isAssigned = productStores.some(ps => ps.storeId === store.storeId && ps.enabled !== false);
                  return (
                    <div key={store.storeId} className="flex items-center gap-3" data-testid={`store-row-${store.storeId}`}>
                      <Checkbox
                        id={`store-${store.storeId}`}
                        checked={isAssigned}
                        onCheckedChange={() => handleStoreToggle(store.storeId, isAssigned)}
                        disabled={updateProductStoresMutation.isPending}
                        data-testid={`checkbox-store-${store.storeId}`}
                      />
                      <Label htmlFor={`store-${store.storeId}`} className="flex-1 cursor-pointer">
                        <span className="font-medium">{store.name || store.code}</span>
                        {store.name && <span className="text-muted-foreground text-sm ml-2">({store.code})</span>}
                      </Label>
                      {isAssigned && (
                        <Badge variant="secondary" data-testid={`badge-store-assigned-${store.storeId}`}>Assigned</Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Categories */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="flex items-center gap-2">
                <FolderTree className="h-5 w-5" />
                Categories
                {productCategories.length > 0 && (
                  <Badge variant="secondary">{productCategories.length}</Badge>
                )}
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search categories..."
                  value={categorySearch}
                  onChange={(e) => {
                    setCategorySearch(e.target.value);
                    if (e.target.value && showAssignedCategoriesOnly) {
                      setShowAssignedCategoriesOnly(false);
                    }
                  }}
                  className="pl-8"
                  data-testid="input-category-search"
                />
              </div>
              <Button
                variant={showAssignedCategoriesOnly ? "default" : "outline"}
                size="sm"
                onClick={() => setShowAssignedCategoriesOnly(!showAssignedCategoriesOnly)}
                data-testid="button-toggle-assigned-categories"
              >
                {showAssignedCategoriesOnly ? "Assigned" : "All"}
              </Button>
            </div>
            {isLoadingProductCategories ? (
              <p className="text-muted-foreground text-sm">Loading categories...</p>
            ) : allCategories.length === 0 ? (
              <p className="text-muted-foreground text-sm">No categories available. Create categories first.</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {allCategories
                  .filter((cat) => {
                    const isAssigned = productCategories.some(pc => pc.categoryId === cat.categoryId);
                    if (showAssignedCategoriesOnly && !isAssigned) return false;
                    if (categorySearch) {
                      const searchLower = categorySearch.toLowerCase();
                      return cat.name.toLowerCase().includes(searchLower) || cat.pathKey.toLowerCase().includes(searchLower);
                    }
                    return true;
                  })
                  .map((cat) => {
                    const isAssigned = productCategories.some(pc => pc.categoryId === cat.categoryId);
                    const depth = cat.pathKey.split("/").length - 1;
                    return (
                      <div
                        key={cat.categoryId}
                        className="flex items-center gap-2 py-1"
                        style={{ paddingLeft: `${depth * 16}px` }}
                      >
                        <Checkbox
                          checked={isAssigned}
                          onCheckedChange={() => handleCategoryToggle(cat.categoryId, isAssigned)}
                          disabled={updateProductCategoriesMutation.isPending}
                          data-testid={`checkbox-category-${cat.categoryId}`}
                        />
                        <Link
                          href="/categories"
                          className="flex-1 cursor-pointer hover:underline"
                          data-testid={`link-category-${cat.categoryId}`}
                        >
                          <span className="font-medium">{cat.name}</span>
                          {depth > 0 && <span className="text-muted-foreground text-sm ml-2">({cat.pathKey})</span>}
                        </Link>
                        {isAssigned && (
                          <Badge variant="secondary" data-testid={`badge-category-assigned-${cat.categoryId}`}>Assigned</Badge>
                        )}
                      </div>
                    );
                  })}
                {showAssignedCategoriesOnly && productCategories.length === 0 && (
                  <p className="text-muted-foreground text-sm text-center py-2">No categories assigned. Click "All" to browse and assign categories.</p>
                )}
                {!showAssignedCategoriesOnly && categorySearch && allCategories.filter((cat) => {
                  const searchLower = categorySearch.toLowerCase();
                  return cat.name.toLowerCase().includes(searchLower) || cat.pathKey.toLowerCase().includes(searchLower);
                }).length === 0 && (
                  <p className="text-muted-foreground text-sm text-center py-2">No categories match your search.</p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Product Images */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="flex items-center gap-2">
                <ImageIcon className="h-5 w-5" />
                Images
                {productImages.length > 0 && (
                  <Badge variant="secondary">{productImages.length}</Badge>
                )}
              </CardTitle>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowAddImageDialog(true)}
                data-testid="button-add-image"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Image
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {productImages.length === 0 ? (
              <p className="text-muted-foreground text-sm" data-testid="text-no-images">No images available for this product.</p>
            ) : (
              <div className="flex flex-wrap gap-3">
                {productImages.map((img) => (
                  <div key={img.imageId} className="flex flex-col items-center gap-1">
                    <button
                      type="button"
                      className="w-16 h-16 rounded-md border cursor-pointer hover-elevate flex-shrink-0"
                      onClick={() => setPreviewImageUrl(img.url)}
                      title={img.label || img.role}
                      data-testid={`img-product-${img.imageId}`}
                    >
                      <img
                        src={img.url}
                        alt={img.label || img.role}
                        className="w-full h-full object-cover rounded-md"
                        loading="lazy"
                      />
                    </button>
                    <span className="text-[10px] text-muted-foreground leading-tight">{img.role}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={!!previewImageUrl} onOpenChange={(open) => { if (!open) setPreviewImageUrl(null); }}>
          <DialogContent className="max-w-2xl p-4 pt-10">
            <DialogHeader className="sr-only">
              <DialogTitle>Image Preview</DialogTitle>
            </DialogHeader>
            {previewImageUrl && (
              <img
                src={previewImageUrl}
                alt="Product image preview"
                className="w-full h-auto rounded-md"
                data-testid="img-preview-large"
              />
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={showAddImageDialog} onOpenChange={(open) => { if (!open) { setShowAddImageDialog(false); setNewImageUrl(""); setNewImageRole("base"); setNewImageLabel(""); } }}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Image</DialogTitle>
              <DialogDescription>Add a new image to this product.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Label</Label>
                <Input
                  placeholder="Image title / label"
                  value={newImageLabel}
                  onChange={(e) => setNewImageLabel(e.target.value)}
                  data-testid="input-add-image-label"
                />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select value={newImageRole} onValueChange={setNewImageRole}>
                  <SelectTrigger data-testid="select-add-image-role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {IMAGE_ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Image URL</Label>
                <Input
                  placeholder="https://example.com/image.jpg"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  data-testid="input-add-image-url"
                />
              </div>
              {newImageUrl.trim() && (
                <div className="border rounded-md p-2 bg-muted/50">
                  <p className="text-xs text-muted-foreground mb-1">Preview</p>
                  <img
                    src={newImageUrl.trim()}
                    alt="Preview"
                    className="max-h-32 rounded-md object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                    data-testid="img-add-image-preview"
                  />
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowAddImageDialog(false); setNewImageUrl(""); setNewImageRole("base"); setNewImageLabel(""); }} data-testid="button-cancel-add-image">
                Cancel
              </Button>
              <Button
                onClick={handleAddImage}
                disabled={!newImageUrl.trim() || addImageMutation.isPending}
                data-testid="button-confirm-add-image"
              >
                {addImageMutation.isPending ? "Adding..." : "Add Image"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Additional Attributes */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Additional Attributes</CardTitle>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setSelectedAttributeId("");
                  setAttributeValue("");
                  setAttributeValueBool(false);
                  setIsAddProductAttributeOpen(true);
                }}
                disabled={attributeDefs.length === 0}
                data-testid="button-add-product-attribute"
              >
                Add Attribute
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {productAttributes.length > 0 ? (() => {
              const globalAttrs = productAttributes.filter((a) => !a.storeId);
              const storeGrouped = new Map<number, typeof productAttributes>();
              for (const attr of productAttributes) {
                if (attr.storeId) {
                  const group = storeGrouped.get(attr.storeId) ?? [];
                  group.push(attr);
                  storeGrouped.set(attr.storeId, group);
                }
              }
              const storeTabs = Array.from(storeGrouped.entries()).map(([sid, attrs]) => {
                const storeInfo = stores.find((s: any) => s.storeId === sid);
                return { storeId: sid, label: storeInfo?.name ?? storeInfo?.code ?? `Store ${sid}`, attrs };
              });

              const renderAttributeTable = (attrs: typeof productAttributes) => (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Attribute</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="w-24">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attrs.map((attribute) => (
                      <TableRow key={`${attribute.attributeId}-${attribute.storeId ?? 'global'}`} data-testid={`row-product-attribute-${attribute.attributeId}`}>
                        <TableCell className="font-medium">
                          {attribute.label ?? attribute.code}
                        </TableCell>
                        <TableCell>{formatAttributeValue(attribute)}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {attribute.dataType ?? "—"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => {
                                setEditingProductAttribute(attribute);
                                if (attribute.valueBool !== null && attribute.valueBool !== undefined) {
                                  setAttributeValueBool(attribute.valueBool);
                                  setAttributeValue("");
                                } else {
                                  setAttributeValue(formatAttributeValue(attribute));
                                  setAttributeValueBool(false);
                                }
                                setIsEditProductAttributeOpen(true);
                              }}
                              data-testid={`button-edit-attribute-${attribute.attributeId}`}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => deleteProductAttributeMutation.mutate(attribute.attributeId)}
                              disabled={deleteProductAttributeMutation.isPending}
                              data-testid={`button-delete-attribute-${attribute.attributeId}`}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              );

              if (storeTabs.length === 0) {
                return renderAttributeTable(globalAttrs);
              }

              return (
                <Tabs defaultValue="global" className="w-full">
                  <TabsList>
                    <TabsTrigger value="global">Global</TabsTrigger>
                    {storeTabs.map((tab) => (
                      <TabsTrigger key={tab.storeId} value={String(tab.storeId)}>
                        {tab.label}
                        <Badge variant="secondary" className="ml-1.5 text-xs px-1.5 py-0">{tab.attrs.length}</Badge>
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  <TabsContent value="global" className="mt-4">
                    {globalAttrs.length > 0 ? renderAttributeTable(globalAttrs) : (
                      <p className="text-sm text-muted-foreground">No global attributes.</p>
                    )}
                  </TabsContent>
                  {storeTabs.map((tab) => (
                    <TabsContent key={tab.storeId} value={String(tab.storeId)} className="mt-4">
                      {renderAttributeTable(tab.attrs)}
                    </TabsContent>
                  ))}
                </Tabs>
              );
            })() : (
              <p className="text-sm text-muted-foreground" data-testid="text-no-additional-attributes">
                No additional attributes recorded for this product.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Prices */}
        <Card>
          <CardHeader>
            <CardTitle>Prices</CardTitle>
          </CardHeader>
          <CardContent>
            {productPrices.length > 0 ? (() => {
              // Group prices by store association
              // Prices with no store match go into "Default"
              // Prices matching a store's default currency go into that store's tab
              const priceGroups = new Map<string, { label: string; prices: typeof productPrices }>();
              priceGroups.set("default", { label: "Default", prices: [] });

              for (const price of productPrices) {
                if (price.stores.length === 0) {
                  const group = priceGroups.get("default")!;
                  group.prices.push(price);
                } else {
                  for (const s of price.stores) {
                    const key = `store-${s.storeId}`;
                    if (!priceGroups.has(key)) {
                      priceGroups.set(key, { label: s.name ?? s.code, prices: [] });
                    }
                    priceGroups.get(key)!.prices.push(price);
                  }
                  // Also add to default if it's a base currency used everywhere
                  if (price.stores.length > 0) {
                    const defaultGroup = priceGroups.get("default")!;
                    if (!defaultGroup.prices.some((p) => p.currencyCode === price.currencyCode)) {
                      defaultGroup.prices.push(price);
                    }
                  }
                }
              }

              const formatPrice = (value: string | null, symbol: string | null) => {
                if (!value) return "—";
                return `${symbol ?? ""}${Number(value).toFixed(2)}`;
              };

              const renderPriceTable = (prices: typeof productPrices) => (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Currency</TableHead>
                      <TableHead className="text-right">Retail</TableHead>
                      <TableHead className="text-right">Special</TableHead>
                      <TableHead className="text-right">Cost</TableHead>
                      <TableHead className="text-right">Avg Cost</TableHead>
                      <TableHead>Override</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {prices.map((price) => (
                      <TableRow key={price.productPriceId}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {price.currencyCode ?? "Unknown"}
                            {price.stores.length > 0 && (
                              <div className="flex gap-1">
                                {price.stores.map((s) => (
                                  <Badge key={s.storeId} variant="outline" className="text-xs">
                                    {s.name ?? s.code}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{formatPrice(price.retailPrice, price.currencySymbol)}</TableCell>
                        <TableCell className="text-right">{formatPrice(price.specialRetailPrice, price.currencySymbol)}</TableCell>
                        <TableCell className="text-right">{formatPrice(price.costPrice, price.currencySymbol)}</TableCell>
                        <TableCell className="text-right">{formatPrice(price.averageCostPrice, price.currencySymbol)}</TableCell>
                        <TableCell>
                          {price.isManualOverride ? (
                            <Badge variant="secondary" className="text-xs">Manual</Badge>
                          ) : (
                            <span className="text-muted-foreground text-xs">Auto</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              );

              return renderPriceTable(productPrices);
            })() : (
              <p className="text-sm text-muted-foreground">
                No prices recorded for this product.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog
        open={isVariantDialogOpen}
        onOpenChange={(open) => {
          setIsVariantDialogOpen(open);
          if (!open) {
            setSelectedVariantId(null);
            setIsVariantEditing(false);
            setEditedVariant({});
          }
        }}
      >
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Variant Details</DialogTitle>
            <DialogDescription>
              View and edit variant-level attributes.
            </DialogDescription>
          </DialogHeader>
          {isLoadingVariant || !variantDetails ? (
            <div className="p-6 text-sm text-muted-foreground">Loading variant...</div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="variantSku">Variant SKU</Label>
                  <Input
                    id="variantSku"
                    value={variantDetails.productVariantSku}
                    disabled
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantMagentoId">Magento Product ID</Label>
                  <Input
                    id="variantMagentoId"
                    type="number"
                    value={
                      isVariantEditing
                        ? (editedVariant.magentoProductId ?? "")
                        : (variantDetails.magentoProductId ?? "")
                    }
                    onChange={(event) =>
                      handleVariantInputChange("magentoProductId", event.target.value ? Number(event.target.value) : null)
                    }
                    disabled={!isVariantEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="variantSize">Size</Label>
                  <Select
                    value={
                      isVariantEditing
                        ? editedVariant.sizeId !== null && editedVariant.sizeId !== undefined
                          ? String(editedVariant.sizeId)
                          : "none"
                        : variantDetails.sizeId !== null && variantDetails.sizeId !== undefined
                          ? String(variantDetails.sizeId)
                          : "none"
                    }
                    onValueChange={(value) =>
                      handleVariantInputChange("sizeId", value === "none" ? null : Number(value))
                    }
                    disabled={!isVariantEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No size</SelectItem>
                      {sizes.map((size) => (
                        <SelectItem key={size.sizeId} value={String(size.sizeId)}>
                          {size.magentoSizeLongName || size.magentoSizeShortName || `Size ${size.sizeId}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantTaxClass">Tax Class</Label>
                  <Select
                    value={
                      isVariantEditing
                        ? editedVariant.taxClassId !== null && editedVariant.taxClassId !== undefined
                          ? String(editedVariant.taxClassId)
                          : "none"
                        : variantDetails.taxClassId !== null && variantDetails.taxClassId !== undefined
                          ? String(variantDetails.taxClassId)
                          : "none"
                    }
                    onValueChange={(value) =>
                      handleVariantInputChange("taxClassId", value === "none" ? null : Number(value))
                    }
                    disabled={!isVariantEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select tax class" />
                    </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No tax class</SelectItem>
                      {taxClasses.map((taxClass) => {
                        const taxClassId = taxClass.taxClassId ?? taxClass.tax_class_id;
                        if (taxClassId === null || taxClassId === undefined) {
                          return null;
                        }
                        const taxClassName = taxClass.taxClassName ?? taxClass.tax_class_name;
                        return (
                          <SelectItem key={taxClassId} value={String(taxClassId)}>
                            {taxClassName || `Tax ${taxClassId}`}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantCondition">Condition</Label>
                  <Select
                    value={
                      isVariantEditing
                        ? editedVariant.conditionId !== null && editedVariant.conditionId !== undefined
                          ? String(editedVariant.conditionId)
                          : "none"
                        : variantDetails.conditionId !== null && variantDetails.conditionId !== undefined
                          ? String(variantDetails.conditionId)
                          : "none"
                    }
                    onValueChange={(value) =>
                      handleVariantInputChange("conditionId", value === "none" ? null : Number(value))
                    }
                    disabled={!isVariantEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No condition</SelectItem>
                      {conditions.map((condition) => (
                        <SelectItem key={condition.conditionId} value={String(condition.conditionId)}>
                          {condition.conditionName || `Condition ${condition.conditionId}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="variantConditionDetail">Condition Detail</Label>
                  <Input
                    id="variantConditionDetail"
                    value={
                      isVariantEditing
                        ? (editedVariant.conditionDetail ?? "")
                        : (variantDetails.conditionDetail ?? "")
                    }
                    onChange={(event) => handleVariantInputChange("conditionDetail", event.target.value)}
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantBarcode">Barcode</Label>
                  <Input
                    id="variantBarcode"
                    value={
                      isVariantEditing ? (editedVariant.barcode ?? "") : (variantDetails.barcode ?? "")
                    }
                    onChange={(event) => handleVariantInputChange("barcode", event.target.value)}
                    disabled={!isVariantEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="variantWidth">Width (cm)</Label>
                  <Input
                    id="variantWidth"
                    type="number"
                    value={
                      isVariantEditing ? (editedVariant.widthCm ?? "") : (variantDetails.widthCm ?? "")
                    }
                    onChange={(event) =>
                      handleVariantInputChange("widthCm", event.target.value ? Number(event.target.value) : null)
                    }
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantLength">Length (cm)</Label>
                  <Input
                    id="variantLength"
                    type="number"
                    value={
                      isVariantEditing ? (editedVariant.lengthCm ?? "") : (variantDetails.lengthCm ?? "")
                    }
                    onChange={(event) =>
                      handleVariantInputChange("lengthCm", event.target.value ? Number(event.target.value) : null)
                    }
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantWeight">Weight</Label>
                  <Input
                    id="variantWeight"
                    type="number"
                    step="0.001"
                    value={
                      isVariantEditing ? (editedVariant.weight ?? "") : (variantDetails.weight ?? "")
                    }
                    onChange={(event) =>
                      handleVariantInputChange("weight", event.target.value)
                    }
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantDepth">Depth</Label>
                  <Input
                    id="variantDepth"
                    type="number"
                    step="0.01"
                    value={
                      isVariantEditing ? (editedVariant.depth ?? "") : (variantDetails.depth ?? "")
                    }
                    onChange={(event) =>
                      handleVariantInputChange("depth", event.target.value)
                    }
                    disabled={!isVariantEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="variantCostPrice">Cost Price</Label>
                  <Input
                    id="variantCostPrice"
                    type="number"
                    step="0.01"
                    value={
                      isVariantEditing ? (editedVariant.costPrice ?? "") : (variantDetails.costPrice ?? "")
                    }
                    onChange={(event) => handleVariantInputChange("costPrice", event.target.value)}
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantAvgCost">Average Cost</Label>
                  <Input
                    id="variantAvgCost"
                    type="number"
                    step="0.01"
                    value={
                      isVariantEditing
                        ? (editedVariant.averageCostPrice ?? "")
                        : (variantDetails.averageCostPrice ?? "")
                    }
                    onChange={(event) => handleVariantInputChange("averageCostPrice", event.target.value)}
                    disabled={!isVariantEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variantCustomerPrice">Customer Price</Label>
                  <Input
                    id="variantCustomerPrice"
                    type="number"
                    step="0.01"
                    value={
                      isVariantEditing
                        ? (editedVariant.customerPrice ?? "")
                        : (variantDetails.customerPrice ?? "")
                    }
                    onChange={(event) => handleVariantInputChange("customerPrice", event.target.value)}
                    disabled={!isVariantEditing}
                  />
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={
                      isVariantEditing
                        ? editedVariant.printed === true
                        : variantDetails.printed
                    }
                    onCheckedChange={(value) => handleVariantInputChange("printed", value === true)}
                    disabled={!isVariantEditing}
                  />
                  <Label>Printed</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={
                      isVariantEditing
                        ? editedVariant.enabled === true
                        : variantDetails.enabled
                    }
                    onCheckedChange={(value) => handleVariantInputChange("enabled", value === true)}
                    disabled={!isVariantEditing}
                  />
                  <Label>Enabled</Label>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">Pricing by Currency</div>
                  {!isPriceEditing ? (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        const priceMap: Record<number, { retailPrice: string; specialRetailPrice: string; costPrice: string }> = {};
                        currencies.filter(c => c.enabled).forEach((curr) => {
                          const existing = variantPrices.find(p => p.currencyId === curr.currencyId);
                          priceMap[curr.currencyId] = {
                            retailPrice: existing?.retailPrice ?? "",
                            specialRetailPrice: existing?.specialRetailPrice ?? "",
                            costPrice: existing?.costPrice ?? "",
                          };
                        });
                        setEditingPrices(priceMap);
                        setIsPriceEditing(true);
                      }}
                      data-testid="button-edit-prices"
                    >
                      <Pencil className="h-4 w-4 mr-2" />
                      Edit Prices
                    </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setIsPriceEditing(false);
                          setEditingPrices({});
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        onClick={async () => {
                          let gbpChanged = false;
                          for (const [currencyIdStr, prices] of Object.entries(editingPrices)) {
                            const currencyId = Number(currencyIdStr);
                            const currencyInfo = currencies.find(c => c.currencyId === currencyId);
                            const isGbp = currencyInfo?.code === "GBP";
                            const existing = variantPrices.find(p => p.currencyId === currencyId);
                            const normalize = (v: string | null | undefined) => v?.trim() || null;
                            const priceChanged =
                              normalize(prices.retailPrice) !== normalize(existing?.retailPrice) ||
                              normalize(prices.specialRetailPrice) !== normalize(existing?.specialRetailPrice) ||
                              normalize(prices.costPrice) !== normalize(existing?.costPrice);
                            if (isGbp && priceChanged) gbpChanged = true;
                            const shouldBeManual = !isGbp && priceChanged
                              ? true
                              : existing?.isManualOverride ?? false;
                            await updateVariantPriceMutation.mutateAsync({
                              currencyId,
                              retailPrice: prices.retailPrice || null,
                              specialRetailPrice: prices.specialRetailPrice || null,
                              costPrice: prices.costPrice || null,
                              isManualOverride: shouldBeManual,
                            });
                          }
                          if (gbpChanged && selectedVariantId) {
                            await apiRequest("POST", `/api/variants/${selectedVariantId}/prices/auto-convert`, { baseCurrencyCode: "GBP" });
                            queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId, "prices-with-currency"] });
                          }
                          toast({
                            title: "Success",
                            description: gbpChanged ? "Prices updated and auto-converted" : "Prices updated successfully",
                          });
                          setIsPriceEditing(false);
                          setEditingPrices({});
                        }}
                        disabled={updateVariantPriceMutation.isPending}
                        data-testid="button-save-prices"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Save Prices
                      </Button>
                    </div>
                  )}
                </div>
                {isLoadingVariantPrices ? (
                  <p className="text-sm text-muted-foreground">Loading prices...</p>
                ) : currencies.filter(c => c.enabled).length === 0 ? (
                  <p className="text-sm text-muted-foreground">No currencies configured.</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Currency</TableHead>
                        <TableHead>Retail Price</TableHead>
                        <TableHead>Special Price</TableHead>
                        <TableHead>Cost Price</TableHead>
                        <TableHead>Source</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currencies.filter(c => c.enabled).sort((a, b) => {
                        if (a.code === "GBP") return -1;
                        if (b.code === "GBP") return 1;
                        return (a.code ?? "").localeCompare(b.code ?? "");
                      }).map((curr) => {
                        const existingPrice = variantPrices.find(p => p.currencyId === curr.currencyId);
                        const editing = editingPrices[curr.currencyId];
                        const isBase = curr.code === "GBP";
                        const isOverride = existingPrice?.isManualOverride === true;
                        return (
                          <TableRow key={curr.currencyId}>
                            <TableCell className="font-medium">
                              {curr.symbol ?? ""} {curr.code}
                              <span className="text-muted-foreground ml-1 text-xs">
                                {curr.name ? `(${curr.name})` : ""}
                              </span>
                            </TableCell>
                            <TableCell>
                              {isPriceEditing ? (
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={editing?.retailPrice ?? ""}
                                  onChange={(e) => setEditingPrices(prev => ({
                                    ...prev,
                                    [curr.currencyId]: { ...prev[curr.currencyId], retailPrice: e.target.value }
                                  }))}
                                  className="w-28"
                                  data-testid={`input-retail-price-${curr.code}`}
                                />
                              ) : (
                                existingPrice?.retailPrice ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {isPriceEditing ? (
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={editing?.specialRetailPrice ?? ""}
                                  onChange={(e) => setEditingPrices(prev => ({
                                    ...prev,
                                    [curr.currencyId]: { ...prev[curr.currencyId], specialRetailPrice: e.target.value }
                                  }))}
                                  className="w-28"
                                  data-testid={`input-special-price-${curr.code}`}
                                />
                              ) : (
                                existingPrice?.specialRetailPrice ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {isPriceEditing ? (
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={editing?.costPrice ?? ""}
                                  onChange={(e) => setEditingPrices(prev => ({
                                    ...prev,
                                    [curr.currencyId]: { ...prev[curr.currencyId], costPrice: e.target.value }
                                  }))}
                                  className="w-28"
                                  data-testid={`input-cost-price-${curr.code}`}
                                />
                              ) : (
                                existingPrice?.costPrice ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {isBase ? (
                                <Badge variant="secondary" data-testid={`badge-source-${curr.code}`}>Base</Badge>
                              ) : isOverride ? (
                                <div className="flex items-center gap-2">
                                  <Badge variant="outline" data-testid={`badge-source-${curr.code}`}>Manual</Badge>
                                  {!isPriceEditing && (
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="text-xs"
                                      data-testid={`button-reset-override-${curr.code}`}
                                      onClick={async () => {
                                        try {
                                          await apiRequest("PATCH", `/api/variants/${selectedVariantId}/prices/${curr.currencyId}/reset-override`, {});
                                          queryClient.invalidateQueries({ queryKey: ["/api/variants", selectedVariantId, "prices-with-currency"] });
                                          toast({ title: "Override reset", description: `${curr.code} price will now auto-convert from GBP.` });
                                        } catch {
                                          toast({ title: "Error", description: "Failed to reset override", variant: "destructive" });
                                        }
                                      }}
                                    >
                                      Reset
                                    </Button>
                                  )}
                                </div>
                              ) : existingPrice ? (
                                <Badge variant="secondary" data-testid={`badge-source-${curr.code}`}>Auto</Badge>
                              ) : null}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-medium">Variant Attributes</div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedAttributeId("");
                      setAttributeValue("");
                      setAttributeValueBool(false);
                      setIsAddVariantAttributeOpen(true);
                    }}
                    disabled={attributeDefs.length === 0}
                    data-testid="button-add-variant-attribute"
                  >
                    Add Attribute
                  </Button>
                </div>
                {variantAttributes.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Attribute</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead>Type</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {variantAttributes.map((attribute) => (
                        <TableRow key={attribute.attributeId}>
                          <TableCell className="font-medium">
                            {attribute.label ?? attribute.code}
                          </TableCell>
                          <TableCell>{formatAttributeValue(attribute)}</TableCell>
                          <TableCell className="text-muted-foreground">
                            {attribute.dataType ?? "—"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <p className="text-sm text-muted-foreground" data-testid="text-no-variant-attributes">
                    No variant attributes recorded.
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                {!isVariantEditing ? (
                  <Button onClick={() => handleVariantEdit(variantDetails)}>
                    <Edit2 className="h-4 w-4 mr-2" />
                    Edit Variant
                  </Button>
                ) : (
                  <>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setIsVariantEditing(false);
                        setEditedVariant({});
                      }}
                      disabled={updateVariantMutation.isPending}
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleVariantSave}
                      disabled={updateVariantMutation.isPending}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {updateVariantMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog
        open={isAddProductAttributeOpen}
        onOpenChange={(open) => {
          setIsAddProductAttributeOpen(open);
          if (!open) {
            setSelectedAttributeId("");
            setSelectedStoreIdForAttr("");
            setAttributeValue("");
            setAttributeValueBool(false);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Product Attribute</DialogTitle>
            <DialogDescription>
              Assign an additional attribute to this product.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Select
              value={selectedAttributeId || "none"}
              onValueChange={(value) => setSelectedAttributeId(value === "none" ? "" : value)}
              disabled={attributeDefs.length === 0}
            >
              <SelectTrigger data-testid="select-product-attribute-def">
                <SelectValue placeholder="Select attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No attribute</SelectItem>
                {attributeDefs.map((attribute: any) => (
                    <SelectItem key={attribute.attributeId} value={String(attribute.attributeId)}>
                      {attribute.label ?? attribute.code}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Select
              value={selectedStoreIdForAttr || "global"}
              onValueChange={(value) => setSelectedStoreIdForAttr(value === "global" ? "" : value)}
            >
              <SelectTrigger data-testid="select-product-attribute-store">
                <SelectValue placeholder="Store scope" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="global">Global (all stores)</SelectItem>
                {stores.map((s: any) => (
                  <SelectItem key={s.storeId} value={String(s.storeId)}>
                    {s.name ?? s.code}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedAttributeDef?.dataType === "boolean" ? (
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={attributeValueBool}
                  onCheckedChange={(checked) => setAttributeValueBool(checked === true)}
                  data-testid="checkbox-product-attribute-value"
                />
                <span className="text-sm">Value</span>
              </div>
            ) : selectedAttributeDef?.dataType === "json" ? (
              <Textarea
                placeholder="JSON value"
                value={attributeValue}
                onChange={(event) => setAttributeValue(event.target.value)}
                rows={4}
                data-testid="textarea-product-attribute-value"
              />
            ) : (
              <Input
                type={selectedAttributeDef?.dataType === "number" ? "number" : "text"}
                placeholder="Attribute value"
                value={attributeValue}
                onChange={(event) => setAttributeValue(event.target.value)}
                data-testid="input-product-attribute-value"
              />
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddProductAttributeOpen(false)}
              data-testid="button-cancel-product-attribute"
            >
              Cancel
            </Button>
            <Button
              onClick={() => addProductAttributeMutation.mutate()}
              disabled={!selectedAttributeId || addProductAttributeMutation.isPending}
              data-testid="button-save-product-attribute"
            >
              {addProductAttributeMutation.isPending ? "Saving..." : "Save Attribute"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isEditProductAttributeOpen}
        onOpenChange={(open) => {
          setIsEditProductAttributeOpen(open);
          if (!open) {
            setEditingProductAttribute(null);
            setAttributeValue("");
            setAttributeValueBool(false);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Product Attribute</DialogTitle>
            <DialogDescription>
              Update the value for {editingProductAttribute?.label ?? editingProductAttribute?.code ?? "this attribute"}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {(() => {
              const attrDef = attributeDefs.find(
                (def: any) => def.attributeId === editingProductAttribute?.attributeId,
              );
              if (attrDef?.dataType === "boolean") {
                return (
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={attributeValueBool}
                      onCheckedChange={(checked) => setAttributeValueBool(checked === true)}
                      data-testid="checkbox-edit-product-attribute-value"
                    />
                    <span className="text-sm">Value</span>
                  </div>
                );
              } else if (attrDef?.dataType === "json") {
                return (
                  <Textarea
                    placeholder="JSON value"
                    value={attributeValue}
                    onChange={(event) => setAttributeValue(event.target.value)}
                    rows={4}
                    data-testid="textarea-edit-product-attribute-value"
                  />
                );
              } else {
                return (
                  <Input
                    type={attrDef?.dataType === "number" ? "number" : "text"}
                    placeholder="Attribute value"
                    value={attributeValue}
                    onChange={(event) => setAttributeValue(event.target.value)}
                    data-testid="input-edit-product-attribute-value"
                  />
                );
              }
            })()}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditProductAttributeOpen(false)}
              data-testid="button-cancel-edit-product-attribute"
            >
              Cancel
            </Button>
            <Button
              onClick={() => editProductAttributeMutation.mutate()}
              disabled={editProductAttributeMutation.isPending}
              data-testid="button-save-edit-product-attribute"
            >
              {editProductAttributeMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isAddVariantAttributeOpen}
        onOpenChange={(open) => {
          setIsAddVariantAttributeOpen(open);
          if (!open) {
            setSelectedAttributeId("");
            setAttributeValue("");
            setAttributeValueBool(false);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Variant Attribute</DialogTitle>
            <DialogDescription>
              Assign an additional attribute to this variant.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Select
              value={selectedAttributeId || "none"}
              onValueChange={(value) => setSelectedAttributeId(value === "none" ? "" : value)}
              disabled={attributeDefs.length === 0}
            >
              <SelectTrigger data-testid="select-variant-attribute-def">
                <SelectValue placeholder="Select attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No attribute</SelectItem>
                {attributeDefs.map((attribute: any) => (
                    <SelectItem key={attribute.attributeId} value={String(attribute.attributeId)}>
                      {attribute.label ?? attribute.code}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            {selectedAttributeDef?.dataType === "boolean" ? (
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={attributeValueBool}
                  onCheckedChange={(checked) => setAttributeValueBool(checked === true)}
                  data-testid="checkbox-variant-attribute-value"
                />
                <span className="text-sm">Value</span>
              </div>
            ) : selectedAttributeDef?.dataType === "json" ? (
              <Textarea
                placeholder="JSON value"
                value={attributeValue}
                onChange={(event) => setAttributeValue(event.target.value)}
                rows={4}
                data-testid="textarea-variant-attribute-value"
              />
            ) : (
              <Input
                type={selectedAttributeDef?.dataType === "number" ? "number" : "text"}
                placeholder="Attribute value"
                value={attributeValue}
                onChange={(event) => setAttributeValue(event.target.value)}
                data-testid="input-variant-attribute-value"
              />
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddVariantAttributeOpen(false)}
              data-testid="button-cancel-variant-attribute"
            >
              Cancel
            </Button>
            <Button
              onClick={() => addVariantAttributeMutation.mutate()}
              disabled={!selectedAttributeId || addVariantAttributeMutation.isPending}
              data-testid="button-save-variant-attribute"
            >
              {addVariantAttributeMutation.isPending ? "Saving..." : "Save Attribute"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AttachProductsDialog
        open={isAttachDialogOpen}
        onOpenChange={setIsAttachDialogOpen}
        productId={productId}
      />
    </div>
  );
}
