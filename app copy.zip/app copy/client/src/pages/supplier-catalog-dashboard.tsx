import { Package, Users, Tag, TrendingUp } from "lucide-react";
import { MetricCard } from "@/components/metric-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SupplierCatalogDashboard() {
  // Placeholder metrics - will be populated when database is connected
  const metrics = {
    totalSupplierProducts: 0,
    totalSuppliers: 0,
    totalCategories: 0,
    averagePrice: 0,
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-supplier-dashboard">
            Supplier Catalog Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            View and manage products available from suppliers
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Supplier Products"
            value={metrics.totalSupplierProducts.toLocaleString()}
            subtitle="Products from suppliers"
            icon={Package}
            data-testid="metric-supplier-products"
          />
          <MetricCard
            title="Suppliers"
            value={metrics.totalSuppliers.toLocaleString()}
            subtitle="Active suppliers"
            icon={Users}
            data-testid="metric-suppliers"
          />
          <MetricCard
            title="Categories"
            value={metrics.totalCategories.toLocaleString()}
            subtitle="Product categories"
            icon={Tag}
            data-testid="metric-categories"
          />
          <MetricCard
            title="Avg Price"
            value={metrics.averagePrice > 0 ? `$${metrics.averagePrice.toFixed(2)}` : "—"}
            subtitle="Average supplier price"
            icon={TrendingUp}
            data-testid="metric-avg-price"
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Getting Started</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Package className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Supplier Products Yet</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Once you connect your supplier database schema, product information from suppliers will appear here.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
