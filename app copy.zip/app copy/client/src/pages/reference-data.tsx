import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Database, Upload, FileSpreadsheet, Check, AlertCircle, Info } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface ReferenceTableType {
  code: string;
  name: string;
  columns: Array<{ key: string; label: string; required: boolean }>;
}

interface ImportResult {
  inserted: number;
  updated: number;
  errors: string[];
}

export default function ReferenceData() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedTable, setSelectedTable] = useState<string>("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [lastResult, setLastResult] = useState<ImportResult | null>(null);

  const { data: tableTypes = [], isLoading: isLoadingTables } = useQuery<ReferenceTableType[]>({
    queryKey: ["/api/reference-data/tables"],
  });

  const importMutation = useMutation({
    mutationFn: async ({ tableType, file }: { tableType: string; file: File }) => {
      const formData = new FormData();
      formData.append("tableType", tableType);
      formData.append("file", file);

      const response = await fetch("/api/reference-data/import", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Import failed");
      }

      return response.json() as Promise<ImportResult>;
    },
    onSuccess: (result) => {
      setLastResult(result);
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }

      if (result.errors.length === 0) {
        toast({
          title: "Import completed",
          description: `${result.inserted} inserted, ${result.updated} updated`,
        });
      } else {
        toast({
          title: "Import completed with errors",
          description: `${result.inserted} inserted, ${result.updated} updated, ${result.errors.length} errors`,
          variant: "destructive",
        });
      }

      // Invalidate reference data-related queries
      queryClient.invalidateQueries({ queryKey: ["/api/reference-data/tables"] });
      queryClient.invalidateQueries({ queryKey: ["/api/brands"] });
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
      queryClient.invalidateQueries({ queryKey: ["/api/genders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tax-classes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/currencies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
    },
    onError: (error: any) => {
      toast({
        title: "Import failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const selectedTableInfo = tableTypes.find((t) => t.code === selectedTable);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setLastResult(null);
    }
  };

  const handleImport = () => {
    if (!selectedTable || !selectedFile) return;
    importMutation.mutate({ tableType: selectedTable, file: selectedFile });
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reference Data Import</h1>
          <p className="text-muted-foreground mt-1 max-w-2xl">
            Import data into reference tables like teams, brands, seasons, and more using CSV files.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Select Table
              </CardTitle>
              <CardDescription>
                Choose which reference table you want to import data into
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedTable} onValueChange={(value) => {
                setSelectedTable(value);
                setLastResult(null);
              }}>
                <SelectTrigger data-testid="select-table-type">
                  <SelectValue placeholder="Select a table..." />
                </SelectTrigger>
                <SelectContent>
                  {tableTypes.map((table) => (
                    <SelectItem key={table.code} value={table.code} data-testid={`select-table-${table.code}`}>
                      {table.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedTableInfo && (
                <div className="space-y-3">
                  <div className="text-sm font-medium">Expected columns:</div>
                  <div className="flex flex-wrap gap-2">
                    {selectedTableInfo.columns.map((col) => (
                      <Badge
                        key={col.key}
                        variant={col.required ? "default" : "secondary"}
                      >
                        {col.label}
                        {col.required && <span className="ml-1 text-destructive">*</span>}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-destructive">*</span> Required columns
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="h-5 w-5" />
                Upload CSV
              </CardTitle>
              <CardDescription>
                Upload a CSV file with data to import
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileSelect}
                className="hidden"
                data-testid="input-file-csv"
              />
              <div
                className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover-elevate"
                onClick={() => fileInputRef.current?.click()}
                data-testid="dropzone-csv"
              >
                <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                {selectedFile ? (
                  <div>
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(selectedFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="font-medium">Click to select a CSV file</p>
                    <p className="text-sm text-muted-foreground">
                      or drag and drop
                    </p>
                  </div>
                )}
              </div>

              <Button
                onClick={handleImport}
                disabled={!selectedTable || !selectedFile || importMutation.isPending}
                className="w-full"
                data-testid="button-import"
              >
                {importMutation.isPending ? "Importing..." : "Import Data"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {lastResult && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {lastResult.errors.length === 0 ? (
                  <Check className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-destructive" />
                )}
                Import Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-300">
                    {lastResult.inserted} inserted
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-300">
                    {lastResult.updated} updated
                  </Badge>
                </div>
                {lastResult.errors.length > 0 && (
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive">
                      {lastResult.errors.length} errors
                    </Badge>
                  </div>
                )}
              </div>

              {lastResult.errors.length > 0 && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Import Errors</AlertTitle>
                  <AlertDescription>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      {lastResult.errors.slice(0, 10).map((error, i) => (
                        <li key={i} className="text-sm">{error}</li>
                      ))}
                      {lastResult.errors.length > 10 && (
                        <li className="text-sm">...and {lastResult.errors.length - 10} more errors</li>
                      )}
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              Available Reference Tables
            </CardTitle>
            <CardDescription>
              Overview of all reference tables that can be imported
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingTables ? (
              <p className="text-muted-foreground">Loading tables...</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Table</TableHead>
                    <TableHead>Required Columns</TableHead>
                    <TableHead>Optional Columns</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tableTypes.map((table) => (
                    <TableRow key={table.code} data-testid={`row-table-${table.code}`}>
                      <TableCell className="font-medium">{table.name}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {table.columns
                            .filter((c) => c.required)
                            .map((c) => (
                              <Badge key={c.key} variant="default" className="text-xs">
                                {c.label}
                              </Badge>
                            ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {table.columns
                            .filter((c) => !c.required)
                            .map((c) => (
                              <Badge key={c.key} variant="secondary" className="text-xs">
                                {c.label}
                              </Badge>
                            ))}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
