import { useState } from "react";
import { Search, Package, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SupplierCatalog() {
  const [search, setSearch] = useState("");
  const [supplierId, setSupplierId] = useState<string>("");
  const [categoryId, setCategoryId] = useState<string>("");
  const [page, setPage] = useState(0);
  const limit = 50;

  const suppliers: any[] = [];
  const categories: any[] = [];
  const products: any[] = [];
  const totalCount = products.length;
  const totalPages = Math.ceil(totalCount / limit);

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-supplier-catalog">
            Supplier Product Catalog
          </h1>
          <p className="text-muted-foreground mt-1">
            Browse products available from suppliers
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by SKU or description..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              className="pl-9"
              data-testid="input-search"
            />
          </div>
          <Select
            value={supplierId || "all"}
            onValueChange={(value) => { setSupplierId(value === "all" ? "" : value); setPage(0); }}
          >
            <SelectTrigger className="w-[180px]" data-testid="select-supplier">
              <SelectValue placeholder="All Suppliers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Suppliers</SelectItem>
              {suppliers.map((supplier) => (
                <SelectItem key={supplier.id} value={supplier.id.toString()}>
                  {supplier.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={categoryId || "all"}
            onValueChange={(value) => { setCategoryId(value === "all" ? "" : value); setPage(0); }}
          >
            <SelectTrigger className="w-[180px]" data-testid="select-category">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {(search || supplierId || categoryId) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setSearch("");
                setSupplierId("");
                setCategoryId("");
                setPage(0);
              }}
              data-testid="button-clear-filters"
            >
              Clear
            </Button>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Supplier Products ({totalCount})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Package className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Supplier Products</h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Once you connect your supplier database schema, products from suppliers will be displayed here.
              </p>
            </div>
            {totalPages > 0 && (
              <div className="flex items-center justify-between pt-4 px-1">
                <span className="text-sm text-muted-foreground" data-testid="text-pagination-info">
                  Showing {Math.min(page * limit + 1, totalCount)}–{Math.min((page + 1) * limit, totalCount)} of {totalCount.toLocaleString()}
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(0)}
                    disabled={page === 0}
                    data-testid="button-first-page"
                  >
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(p => Math.max(0, p - 1))}
                    disabled={page === 0}
                    data-testid="button-prev-page"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground mx-2" data-testid="text-page-indicator">
                    Page {page + 1} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                    disabled={page >= totalPages - 1}
                    data-testid="button-next-page"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(totalPages - 1)}
                    disabled={page >= totalPages - 1}
                    data-testid="button-last-page"
                  >
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
