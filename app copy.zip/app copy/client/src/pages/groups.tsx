import { useCallback, useEffect, useRef, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { FolderKanban, Plus, Search, Trash2, CalendarIcon, X, UserMinus, UserPlus } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithDetails } from "@shared/schema_v2";

interface ProductGroup {
  groupId: number;
  name: string;
  description: string | null;
  createdAt: Date;
  productCount: number;
}

interface ProductGroupDetail extends ProductGroup {
  status: string | null;
  isSystem: boolean | null;
  updatedAt: Date | null;
}

interface GroupProductRow {
  productGroupMemberId: number;
  productId: number;
  productSku: string | null;
  productDescription: string | null;
  brandName: string | null;
  enabled: boolean | null;
  startDate: string | null;
  endDate: string | null;
  live: boolean;
}

function EndDatePicker({
  memberId,
  currentEndDate,
  onSave,
  isPending,
}: {
  memberId: number;
  currentEndDate: string | null;
  onSave: (endDate: string | null) => void;
  isPending: boolean;
}) {
  const [localValue, setLocalValue] = useState(
    currentEndDate ? new Date(currentEndDate).toISOString().slice(0, 16) : ""
  );
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    setLocalValue(currentEndDate ? new Date(currentEndDate).toISOString().slice(0, 16) : "");
  }, [currentEndDate]);

  const hasChanged = currentEndDate
    ? localValue !== new Date(currentEndDate).toISOString().slice(0, 16)
    : localValue !== "";

  const isFutureEndDate = currentEndDate && new Date(currentEndDate) > new Date();

  const formatDisplay = (date: string | null) => {
    if (!date) return "Set end date";
    return new Date(date).toLocaleString();
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="h-7 text-xs font-normal justify-start whitespace-nowrap"
          data-testid={`button-end-date-${memberId}`}
        >
          <CalendarIcon className="h-3 w-3 mr-1 shrink-0" />
          <span className="truncate">{formatDisplay(currentEndDate)}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64 p-3 space-y-2" align="start">
        <Input
          type="datetime-local"
          value={localValue}
          onChange={(e) => setLocalValue(e.target.value)}
          min={new Date().toISOString().slice(0, 16)}
          data-testid={`input-end-date-${memberId}`}
        />
        <div className="flex gap-2">
          <Button
            size="sm"
            className="flex-1"
            disabled={!localValue || !hasChanged || isPending}
            onClick={() => {
              onSave(new Date(localValue).toISOString());
              setIsOpen(false);
            }}
            data-testid={`button-save-end-date-${memberId}`}
          >
            {isPending ? "Saving..." : "Save"}
          </Button>
          {isFutureEndDate && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                onSave(null);
                setIsOpen(false);
              }}
              disabled={isPending}
              data-testid={`button-clear-end-date-${memberId}`}
            >
              <X className="h-3 w-3 mr-1" />
              Remove
            </Button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

const createGroupSchema = z.object({
  name: z.string().min(1, "Group name is required"),
  description: z.string().optional(),
});

type CreateGroupFormData = z.infer<typeof createGroupSchema>;

export default function Groups() {
  const [, navigate] = useLocation();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);
  const [editingGroupName, setEditingGroupName] = useState("");
  const [editingGroupDescription, setEditingGroupDescription] = useState("");
  const [selectedProductIds, setSelectedProductIds] = useState<Set<number>>(new Set());
  const [productSearch, setProductSearch] = useState("");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAddProductsDialogOpen, setIsAddProductsDialogOpen] = useState(false);
  const [addProductIds, setAddProductIds] = useState<Set<number>>(new Set());
  const [addProductSearch, setAddProductSearch] = useState("");
  const [addEndDate, setAddEndDate] = useState("");
  const [selectedMemberIds, setSelectedMemberIds] = useState<Set<number>>(new Set());
  const [isBulkEndDateOpen, setIsBulkEndDateOpen] = useState(false);
  const [bulkEndDate, setBulkEndDate] = useState("");
  const [hideInactive, setHideInactive] = useState(false);
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({});
  const [tableFixed, setTableFixed] = useState(false);
  const resizeRef = useRef<{ col: string; startX: number; startW: number } | null>(null);
  const groupTableRef = useRef<HTMLTableElement>(null);
  const { toast } = useToast();

  const getColStyle = (colId: string) => {
    const w = columnWidths[colId];
    return w ? { width: w, minWidth: w, maxWidth: w } : undefined;
  };

  const captureAllColumnWidths = useCallback(() => {
    if (!groupTableRef.current) return;
    const headerCells = groupTableRef.current.querySelectorAll("thead th[data-col-id]");
    const widths: Record<string, number> = {};
    headerCells.forEach((th) => {
      const colId = (th as HTMLElement).dataset.colId;
      if (colId) {
        widths[colId] = (th as HTMLElement).getBoundingClientRect().width;
      }
    });
    setColumnWidths((prev) => ({ ...widths, ...prev }));
    setTableFixed(true);
  }, []);

  const handleResizeStart = useCallback((e: React.MouseEvent, colId: string) => {
    e.preventDefault();
    e.stopPropagation();
    const th = (e.target as HTMLElement).closest("th");
    if (!th) return;
    if (!tableFixed) captureAllColumnWidths();
    const startW = th.getBoundingClientRect().width;
    resizeRef.current = { col: colId, startX: e.clientX, startW };
    const onMouseMove = (ev: MouseEvent) => {
      if (!resizeRef.current) return;
      const diff = ev.clientX - resizeRef.current.startX;
      const newWidth = Math.max(40, resizeRef.current.startW + diff);
      setColumnWidths((prev) => ({ ...prev, [resizeRef.current!.col]: newWidth }));
    };
    const onMouseUp = () => {
      resizeRef.current = null;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  }, [tableFixed, captureAllColumnWidths]);

  const { data: groups = [], isLoading } = useQuery<ProductGroup[]>({
    queryKey: ["/api/groups"],
  });

  const { data: selectedGroup, isLoading: isLoadingGroup } = useQuery<ProductGroupDetail | null>({
    queryKey: ["/api/groups", selectedGroupId],
    enabled: selectedGroupId !== null,
  });

  const { data: groupProducts = [], isLoading: isLoadingGroupProducts } = useQuery<GroupProductRow[]>({
    queryKey: ["/api/groups", selectedGroupId, "products"],
    enabled: selectedGroupId !== null,
  });

  const { data: productsData, isLoading: isLoadingProducts, error: productsError } = useQuery<{ products: ProductWithDetails[]; count: number }>({
    queryKey: ["/api/catalog/products"],
    enabled: isCreateDialogOpen || isAddProductsDialogOpen,
  });

  // Extract products array from the response
  const products = Array.isArray(productsData?.products) ? productsData.products : [];

  const form = useForm<CreateGroupFormData>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  useEffect(() => {
    if (!selectedGroup) return;
    setEditingGroupName(selectedGroup.name ?? "");
    setEditingGroupDescription(selectedGroup.description ?? "");
    setSelectedMemberIds(new Set());
  }, [selectedGroup]);

  const createGroupMutation = useMutation({
    mutationFn: async (data: CreateGroupFormData & { productIds: number[] }) => {
      const response = await apiRequest("POST", "/api/groups", data);
      return response.json();
    },
    onSuccess: (group: ProductGroup) => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({
        title: "Success",
        description: "Product group created successfully",
      });
      setIsCreateDialogOpen(false);
      setSelectedProductIds(new Set());
      form.reset();
      setSelectedGroupId(group.groupId);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create product group",
      });
    },
  });

  const updateGroupMutation = useMutation({
    mutationFn: async () => {
      if (!selectedGroupId) {
        throw new Error("Select a group to update.");
      }
      const response = await apiRequest("PUT", `/api/groups/${selectedGroupId}`, {
        name: editingGroupName.trim(),
        description: editingGroupDescription.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Group updated",
        description: "The group details were saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to update group",
        description: error.message || "Please try again.",
      });
    },
  });

  const toggleMemberLiveMutation = useMutation({
    mutationFn: async ({ memberId, live }: { memberId: number; live: boolean }) => {
      const response = await apiRequest("PATCH", `/api/groups/${selectedGroupId}/members/${memberId}`, { live });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId, "products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update member status",
      });
    },
  });

  const updateMemberEndDateMutation = useMutation({
    mutationFn: async ({ memberId, endDate }: { memberId: number; endDate: string | null }) => {
      const response = await apiRequest("PATCH", `/api/groups/${selectedGroupId}/members/${memberId}`, { endDate });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId, "products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({
        title: "End date updated",
        description: "The membership end date has been saved.",
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update end date",
      });
    },
  });

  const addProductsToGroupMutation = useMutation({
    mutationFn: async ({ productIds, endDate }: { productIds: number[]; endDate?: string }) => {
      const response = await apiRequest("POST", `/api/groups/${selectedGroupId}/members`, {
        productIds,
        endDate: endDate || null,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId, "products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({ title: "Products added", description: "Products have been added to the group." });
      setIsAddProductsDialogOpen(false);
      setAddProductIds(new Set());
      setAddProductSearch("");
      setAddEndDate("");
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message || "Failed to add products" });
    },
  });

  const bulkEndDateMutation = useMutation({
    mutationFn: async ({ memberIds, endDate }: { memberIds: number[]; endDate: string | null }) => {
      const response = await apiRequest("PATCH", `/api/groups/${selectedGroupId}/members/bulk-end-date`, {
        memberIds,
        endDate,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId, "products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({ title: "End dates updated", description: "End dates have been set for the selected products." });
      setSelectedMemberIds(new Set());
      setIsBulkEndDateOpen(false);
      setBulkEndDate(undefined);
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message || "Failed to update end dates" });
    },
  });

  const deleteMembersMutation = useMutation({
    mutationFn: async (memberIds: number[]) => {
      const response = await apiRequest("DELETE", `/api/groups/${selectedGroupId}/members`, { memberIds });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId, "products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups", selectedGroupId] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({ title: "Members removed", description: "Selected records have been deleted from the group." });
      setSelectedMemberIds(new Set());
    },
    onError: (error: Error) => {
      toast({ variant: "destructive", title: "Error", description: error.message || "Failed to delete members" });
    },
  });

  const deleteGroupMutation = useMutation({
    mutationFn: async () => {
      if (!selectedGroupId) throw new Error("No group selected");
      await apiRequest("DELETE", `/api/groups/${selectedGroupId}`);
    },
    onSuccess: () => {
      toast({
        title: "Group deleted",
        description: "The product group has been deleted.",
      });
      const deletedId = selectedGroupId;
      setSelectedGroupId(null);
      setIsDeleteDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      queryClient.removeQueries({ queryKey: ["/api/groups", deletedId] });
      queryClient.removeQueries({ queryKey: ["/api/groups", deletedId, "products"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete product group",
      });
    },
  });

  const handleCreateGroup = (data: CreateGroupFormData) => {
    if (selectedProductIds.size === 0) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please select at least one product",
      });
      return;
    }

    createGroupMutation.mutate({
      ...data,
      productIds: Array.from(selectedProductIds),
    });
  };

  const handleSelectProduct = (productId: number, checked: boolean) => {
    const newSelection = new Set(selectedProductIds);
    if (checked) {
      newSelection.add(productId);
    } else {
      newSelection.delete(productId);
    }
    setSelectedProductIds(newSelection);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allProductIds = filteredProducts.map(p => p.productId);
      setSelectedProductIds(new Set(allProductIds));
    } else {
      setSelectedProductIds(new Set());
    }
  };

  const filterProducts = (search: string) => {
    return products.filter(product => {
      if (!search) return true;
      const s = search.toLowerCase();
      return (
        product.productSku?.toLowerCase().includes(s) ||
        product.productDescription?.toLowerCase().includes(s) ||
        product.brandName?.toLowerCase().includes(s)
      );
    });
  };

  const filteredProducts = filterProducts(productSearch);
  const addFilteredProducts = filterProducts(addProductSearch);

  const areAllSelected = filteredProducts.length > 0 && filteredProducts.every(p => selectedProductIds.has(p.productId));
  const areSomeSelected = filteredProducts.some(p => selectedProductIds.has(p.productId)) && !areAllSelected;

  const addAreAllSelected = addFilteredProducts.length > 0 && addFilteredProducts.every(p => addProductIds.has(p.productId));

  const handleAddProductSelect = (productId: number, checked: boolean) => {
    const newSelection = new Set(addProductIds);
    if (checked) newSelection.add(productId); else newSelection.delete(productId);
    setAddProductIds(newSelection);
  };

  const handleAddSelectAll = (checked: boolean) => {
    if (checked) {
      setAddProductIds(new Set(addFilteredProducts.map(p => p.productId)));
    } else {
      setAddProductIds(new Set());
    }
  };

  const handleToggleMember = (memberId: number, checked: boolean) => {
    const newSelection = new Set(selectedMemberIds);
    if (checked) newSelection.add(memberId); else newSelection.delete(memberId);
    setSelectedMemberIds(newSelection);
  };

  const liveProductIds = new Set(groupProducts.filter(r => r.live).map(r => r.productId));
  const displayedGroupProducts = hideInactive ? groupProducts.filter(r => r.live) : groupProducts;
  const displayedMemberIds = displayedGroupProducts.map(r => r.productGroupMemberId);
  const areAllMembersSelected = displayedMemberIds.length > 0 && displayedMemberIds.every(id => selectedMemberIds.has(id));

  const handleToggleAllMembers = (checked: boolean) => {
    if (checked) {
      setSelectedMemberIds(new Set(displayedMemberIds));
    } else {
      setSelectedMemberIds(new Set());
    }
  };

  const formatDate = (date: Date | null | undefined) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleString();
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-groups">
              Product Groups
            </h1>
            <p className="text-muted-foreground mt-1">
              Organize and manage collections of products
            </p>
          </div>
          <Button
            onClick={() => setIsCreateDialogOpen(true)}
            data-testid="button-create-group"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create Group
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FolderKanban className="h-5 w-5" />
              Groups ({groups.length})
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Create and manage product groups to organize your catalog
            </p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Loading groups...</p>
              </div>
            ) : groups.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <FolderKanban className="h-16 w-16 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No groups yet</h3>
                <p className="text-sm text-muted-foreground max-w-sm mb-4">
                  Groups help organize your product catalog into manageable collections.
                </p>
                <Button
                  onClick={() => setIsCreateDialogOpen(true)}
                  variant="outline"
                  data-testid="button-create-first-group"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your First Group
                </Button>
              </div>
            ) : (
              <div className="max-h-[65vh] overflow-auto border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-center">Products</TableHead>
                      <TableHead>Created</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {groups.map((group) => (
                      <TableRow
                        key={group.groupId}
                        className="cursor-pointer hover-elevate"
                        data-state={selectedGroupId === group.groupId ? "selected" : undefined}
                        onClick={() => setSelectedGroupId(group.groupId)}
                        data-testid={`row-group-${group.groupId}`}
                      >
                        <TableCell className="font-medium" data-testid={`text-group-name-${group.groupId}`}>
                          {group.name}
                        </TableCell>
                        <TableCell className="max-w-md truncate" data-testid={`text-group-description-${group.groupId}`}>
                          {group.description || <span className="text-muted-foreground italic">No description</span>}
                        </TableCell>
                        <TableCell className="text-center" data-testid={`text-group-product-count-${group.groupId}`}>
                          <Badge variant="secondary">{group.productCount}</Badge>
                        </TableCell>
                        <TableCell data-testid={`text-group-created-${group.groupId}`}>
                          {formatDate(group.createdAt)}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-start justify-between gap-4">
            <div>
              <CardTitle>Group details</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Select a group to review products and update the group details.
              </p>
            </div>
            {selectedGroup && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setIsDeleteDialogOpen(true)}
                className="shrink-0"
                data-testid="button-delete-group"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {!selectedGroupId ? (
              <div className="text-sm text-muted-foreground">
                Click a group row to see its products.
              </div>
            ) : isLoadingGroup ? (
              <div className="text-sm text-muted-foreground">Loading group details...</div>
            ) : !selectedGroup ? (
              <div className="text-sm text-muted-foreground">Group not found.</div>
            ) : (
              <>
                <div className="flex items-end gap-3">
                  <div className="space-y-2 flex-1">
                    <label className="text-sm font-medium">Group name</label>
                    <Input
                      value={editingGroupName}
                      onChange={(event) => setEditingGroupName(event.target.value)}
                      className="h-9"
                      data-testid="input-group-edit-name"
                    />
                  </div>
                  <div className="space-y-2 flex-1">
                    <label className="text-sm font-medium">Description</label>
                    <Input
                      value={editingGroupDescription}
                      onChange={(event) => setEditingGroupDescription(event.target.value)}
                      className="h-9"
                      data-testid="input-group-edit-description"
                    />
                  </div>
                  <Button
                    size="sm"
                    onClick={() => updateGroupMutation.mutate()}
                    disabled={!editingGroupName.trim() || updateGroupMutation.isPending}
                    className="h-9"
                    data-testid="button-save-group"
                  >
                    {updateGroupMutation.isPending ? "Saving..." : "Save"}
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {selectedMemberIds.size > 0 && (
                      <>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => deleteMembersMutation.mutate(Array.from(selectedMemberIds))}
                          disabled={deleteMembersMutation.isPending}
                          data-testid="button-delete-members"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          {deleteMembersMutation.isPending ? "Deleting..." : `Delete (${selectedMemberIds.size})`}
                        </Button>
                      </>
                    )}
                    {selectedMemberIds.size > 0 && (
                      <Popover open={isBulkEndDateOpen} onOpenChange={setIsBulkEndDateOpen}>
                        <PopoverTrigger asChild>
                          <Button variant="outline" size="sm" data-testid="button-bulk-end-date">
                            <CalendarIcon className="h-4 w-4 mr-1" />
                            Set end date ({selectedMemberIds.size})
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-64 p-3 space-y-2" align="start">
                          <Input
                            type="datetime-local"
                            value={bulkEndDate}
                            onChange={(e) => setBulkEndDate(e.target.value)}
                            min={new Date().toISOString().slice(0, 16)}
                            data-testid="input-bulk-end-date"
                          />
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              className="flex-1"
                              disabled={!bulkEndDate || bulkEndDateMutation.isPending}
                              onClick={() => {
                                if (bulkEndDate) {
                                  bulkEndDateMutation.mutate({
                                    memberIds: Array.from(selectedMemberIds),
                                    endDate: new Date(bulkEndDate).toISOString(),
                                  });
                                }
                              }}
                              data-testid="button-apply-bulk-end-date"
                            >
                              {bulkEndDateMutation.isPending ? "Applying..." : "Apply"}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                bulkEndDateMutation.mutate({
                                  memberIds: Array.from(selectedMemberIds),
                                  endDate: null,
                                });
                              }}
                              disabled={bulkEndDateMutation.isPending}
                              data-testid="button-clear-bulk-end-date"
                            >
                              <X className="h-3 w-3 mr-1" />
                              Clear
                            </Button>
                          </div>
                        </PopoverContent>
                      </Popover>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5">
                      <Switch
                        checked={hideInactive}
                        onCheckedChange={(checked) => {
                          setHideInactive(checked);
                          setSelectedMemberIds(new Set());
                        }}
                        id="hide-inactive"
                        data-testid="switch-hide-inactive"
                      />
                      <label htmlFor="hide-inactive" className="text-xs text-muted-foreground cursor-pointer">
                        Hide inactive
                      </label>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => setIsAddProductsDialogOpen(true)}
                      data-testid="button-add-products-to-group"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Products
                    </Button>
                  </div>
                </div>

                <div className="border rounded-md max-h-[45vh] overflow-auto">
                  <Table ref={groupTableRef} style={tableFixed ? { tableLayout: "fixed" } : undefined}>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="py-1" data-col-id="_checkbox" style={getColStyle("_checkbox") || { width: 40 }}>
                          <Checkbox
                            checked={areAllMembersSelected}
                            onCheckedChange={handleToggleAllMembers}
                            data-testid="checkbox-select-all-members"
                          />
                        </TableHead>
                        <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="sku" style={getColStyle("sku")}>
                          SKU
                          <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "sku")} />
                        </TableHead>
                        <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="description" style={getColStyle("description")}>
                          Description
                          <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "description")} />
                        </TableHead>
                        <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="brand" style={getColStyle("brand")}>
                          Brand
                          <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "brand")} />
                        </TableHead>
                        <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="startDate" style={getColStyle("startDate")}>
                          Start Date
                          <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "startDate")} />
                        </TableHead>
                        <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="endDate" style={getColStyle("endDate")}>
                          End Date
                          <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "endDate")} />
                        </TableHead>
                        <TableHead className="py-1 text-center whitespace-nowrap" data-col-id="_actions" style={getColStyle("_actions")}>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoadingGroupProducts ? (
                        <TableRow>
                          <TableCell colSpan={7} className="py-1 text-muted-foreground">
                            Loading products...
                          </TableCell>
                        </TableRow>
                      ) : groupProducts.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="py-1 text-muted-foreground">
                            No products in this group yet.
                          </TableCell>
                        </TableRow>
                      ) : (
                        displayedGroupProducts.map((row) => (
                          <TableRow
                            key={row.productGroupMemberId}
                            className={row.live ? "" : "opacity-50"}
                            data-testid={`row-group-member-${row.productGroupMemberId}`}
                          >
                            <TableCell className="py-1">
                              <Checkbox
                                checked={selectedMemberIds.has(row.productGroupMemberId)}
                                onCheckedChange={(checked) => handleToggleMember(row.productGroupMemberId, checked as boolean)}
                                data-testid={`checkbox-member-${row.productGroupMemberId}`}
                              />
                            </TableCell>
                            <TableCell className="py-1 font-medium truncate whitespace-nowrap overflow-hidden">
                              {row.productSku || "N/A"}
                            </TableCell>
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">
                              {row.productDescription || "N/A"}
                            </TableCell>
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{row.brandName || "N/A"}</TableCell>
                            <TableCell className="py-1 text-xs whitespace-nowrap" data-testid={`text-start-date-${row.productGroupMemberId}`}>
                              {formatDate(row.startDate)}
                            </TableCell>
                            <TableCell className="py-1 whitespace-nowrap" data-testid={`text-end-date-${row.productGroupMemberId}`}>
                              {row.live ? (
                                <EndDatePicker
                                  memberId={row.productGroupMemberId}
                                  currentEndDate={row.endDate}
                                  onSave={(endDate) => updateMemberEndDateMutation.mutate({ memberId: row.productGroupMemberId, endDate })}
                                  isPending={updateMemberEndDateMutation.isPending}
                                />
                              ) : (
                                <span className="text-xs">{formatDate(row.endDate)}</span>
                              )}
                            </TableCell>
                            <TableCell className="py-1 text-center overflow-visible">
                              {row.live ? (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-7 w-7 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
                                        onClick={() =>
                                          toggleMemberLiveMutation.mutate({
                                            memberId: row.productGroupMemberId,
                                            live: false,
                                          })
                                        }
                                        disabled={toggleMemberLiveMutation.isPending}
                                        data-testid={`button-remove-member-${row.productGroupMemberId}`}
                                      >
                                        <UserMinus className="h-4 w-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Remove from group</TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              ) : (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span tabIndex={0}>
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="h-7 w-7 p-0"
                                          onClick={() =>
                                            toggleMemberLiveMutation.mutate({
                                              memberId: row.productGroupMemberId,
                                              live: true,
                                            })
                                          }
                                          disabled={liveProductIds.has(row.productId) || toggleMemberLiveMutation.isPending}
                                          data-testid={`button-readd-member-${row.productGroupMemberId}`}
                                        >
                                          <UserPlus className="h-4 w-4" />
                                        </Button>
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                      {liveProductIds.has(row.productId)
                                        ? "This product is already active in the group"
                                        : "Re-add to group"}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col" data-testid="dialog-create-group">
          <DialogHeader>
            <DialogTitle>Create Product Group</DialogTitle>
            <DialogDescription>
              Enter group details and select products to include in this group
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateGroup)} className="space-y-4 flex-1 overflow-hidden flex flex-col">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Group Name *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter group name"
                          data-testid="input-group-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          {...field}
                          placeholder="Enter group description (optional)"
                          rows={2}
                          data-testid="input-group-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Select Products *</FormLabel>
                  <div className="mt-2 space-y-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search products by SKU, description, or brand..."
                        value={productSearch}
                        onChange={(e) => setProductSearch(e.target.value)}
                        className="pl-9"
                        data-testid="input-search-products"
                      />
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {selectedProductIds.size} product{selectedProductIds.size !== 1 ? 's' : ''} selected
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-auto border rounded-md">
                {isLoadingProducts ? (
                  <div className="flex items-center justify-center py-8">
                    <p className="text-muted-foreground">Loading products...</p>
                  </div>
                ) : filteredProducts.length === 0 ? (
                  <div className="flex items-center justify-center py-8">
                    <p className="text-muted-foreground">
                      {productSearch ? "No products match your search" : "No products available"}
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader className="sticky top-0 bg-background z-10">
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={areAllSelected}
                            onCheckedChange={handleSelectAll}
                            data-testid="checkbox-select-all-products"
                          />
                        </TableHead>
                        <TableHead>SKU</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Brand</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="text-center">Variants</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => (
                        <TableRow
                          key={product.productId}
                          className="cursor-pointer hover-elevate"
                          onClick={() => handleSelectProduct(product.productId, !selectedProductIds.has(product.productId))}
                          data-testid={`row-product-${product.productId}`}
                        >
                          <TableCell onClick={(e) => e.stopPropagation()}>
                            <Checkbox
                              checked={selectedProductIds.has(product.productId)}
                              onCheckedChange={(checked) => handleSelectProduct(product.productId, checked as boolean)}
                              data-testid={`checkbox-product-${product.productId}`}
                            />
                          </TableCell>
                          <TableCell className="font-medium">
                            {product.productSku || "N/A"}
                          </TableCell>
                          <TableCell className="max-w-xs truncate">
                            {product.productDescription || "N/A"}
                          </TableCell>
                          <TableCell>{product.brandName || "N/A"}</TableCell>
                          <TableCell>{product.productTypeName || "N/A"}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline" className="text-xs">
                              {product.variantCount}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsCreateDialogOpen(false);
                    setSelectedProductIds(new Set());
                    form.reset();
                  }}
                  data-testid="button-cancel-create-group"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createGroupMutation.isPending || selectedProductIds.size === 0}
                  data-testid="button-submit-create-group"
                >
                  {createGroupMutation.isPending ? "Creating..." : "Create Group"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={isAddProductsDialogOpen} onOpenChange={setIsAddProductsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col" data-testid="dialog-add-products">
          <DialogHeader>
            <DialogTitle>Add Products to Group</DialogTitle>
            <DialogDescription>
              Select products to add to "{selectedGroup?.name}"
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products by SKU, description, or brand..."
                  value={addProductSearch}
                  onChange={(e) => setAddProductSearch(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-add-products"
                />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground">
                {addProductIds.size} product{addProductIds.size !== 1 ? "s" : ""} selected
              </div>
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium">End date (optional):</label>
                <div className="flex items-center gap-2">
                  <Input
                    type="datetime-local"
                    value={addEndDate}
                    onChange={(e) => setAddEndDate(e.target.value)}
                    min={new Date().toISOString().slice(0, 16)}
                    className="h-8 text-xs w-[200px]"
                    data-testid="input-add-end-date"
                  />
                  {addEndDate && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => setAddEndDate("")}
                      data-testid="button-clear-add-end-date"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-auto border rounded-md">
            {isLoadingProducts ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-muted-foreground">Loading products...</p>
              </div>
            ) : addFilteredProducts.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <p className="text-muted-foreground">
                  {addProductSearch ? "No products match your search" : "No products available"}
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader className="sticky top-0 bg-background z-10">
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={addAreAllSelected}
                        onCheckedChange={handleAddSelectAll}
                        data-testid="checkbox-select-all-add-products"
                      />
                    </TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-center">Variants</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {addFilteredProducts.map((product) => (
                    <TableRow
                      key={product.productId}
                      className="cursor-pointer hover-elevate"
                      onClick={() => handleAddProductSelect(product.productId, !addProductIds.has(product.productId))}
                      data-testid={`row-add-product-${product.productId}`}
                    >
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <Checkbox
                          checked={addProductIds.has(product.productId)}
                          onCheckedChange={(checked) => handleAddProductSelect(product.productId, checked as boolean)}
                          data-testid={`checkbox-add-product-${product.productId}`}
                        />
                      </TableCell>
                      <TableCell className="font-medium">{product.productSku || "N/A"}</TableCell>
                      <TableCell className="max-w-xs truncate">{product.productDescription || "N/A"}</TableCell>
                      <TableCell>{product.brandName || "N/A"}</TableCell>
                      <TableCell>{product.productTypeName || "N/A"}</TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-xs">{product.variantCount}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsAddProductsDialogOpen(false);
                setAddProductIds(new Set());
                setAddProductSearch("");
                setAddEndDate("");
              }}
              data-testid="button-cancel-add-products"
            >
              Cancel
            </Button>
            <Button
              onClick={() => {
                addProductsToGroupMutation.mutate({
                  productIds: Array.from(addProductIds),
                  endDate: addEndDate ? new Date(addEndDate).toISOString() : undefined,
                });
              }}
              disabled={addProductsToGroupMutation.isPending || addProductIds.size === 0}
              data-testid="button-submit-add-products"
            >
              {addProductsToGroupMutation.isPending ? "Adding..." : `Add ${addProductIds.size} Product${addProductIds.size !== 1 ? "s" : ""}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent data-testid="dialog-delete-group">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete group</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{selectedGroup?.name}"? This will remove all membership history for this group. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-group">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteGroupMutation.mutate()}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteGroupMutation.isPending}
              data-testid="button-confirm-delete-group"
            >
              {deleteGroupMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
