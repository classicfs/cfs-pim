import { ShieldCheck, RefreshCcw, ServerCog, UserCog, Activity, Bug } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const quickActions = [
  {
    title: "User Access Review",
    description: "Audit roles and revoke stale admin rights.",
    icon: UserCog,
    action: "Review Users",
  },
  {
    title: "Run Data Validation",
    description: "Check the catalog for missing attributes and errors.",
    icon: ShieldCheck,
    action: "Start Scan",
  },
  {
    title: "Sync External Channels",
    description: "Push the latest updates to storefronts and feeds.",
    icon: RefreshCcw,
    action: "Sync Now",
  },
];

const systemHealth = [
  {
    title: "Catalog Services",
    status: "Operational",
    detail: "Last heartbeat 2 minutes ago",
  },
  {
    title: "Search Index",
    status: "Degraded",
    detail: "Re-index running · ~6 minutes remaining",
  },
  {
    title: "Supplier API",
    status: "Operational",
    detail: "Latency avg. 230ms",
  },
];

const maintenanceTasks = [
  {
    title: "Bulk Price Update",
    detail: "Scheduled tonight at 01:00 UTC",
    badge: "Scheduled",
  },
  {
    title: "Warehouse Sync",
    detail: "Needs confirmation",
    badge: "Action required",
  },
  {
    title: "Image CDN Purge",
    detail: "Completed 3 hours ago",
    badge: "Complete",
  },
];

const activityLog = [
  {
    title: "Variant normalization job finished",
    detail: "1,204 records touched · by ops-bot",
    icon: ServerCog,
  },
  {
    title: "Manual override applied to supplier feed",
    detail: "Updated 82 products · by r.lewis",
    icon: Activity,
  },
  {
    title: "Data quality alert acknowledged",
    detail: "Low imagery coverage · by s.cho",
    icon: Bug,
  },
];

export default function AdminTools() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Tools</h1>
          <p className="text-muted-foreground mt-1 max-w-2xl">
            Monitor system health, run maintenance jobs, and keep your workspace in a good state of repair.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {quickActions.map((action) => (
            <Card key={action.title}>
              <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
                <div>
                  <CardTitle className="text-xl">{action.title}</CardTitle>
                  <CardDescription>{action.description}</CardDescription>
                </div>
                <action.icon className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardFooter className="pt-0">
                <Button variant="secondary" className="w-full md:w-auto">
                  {action.action}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>System Health</CardTitle>
              <CardDescription>Key platform services and their latest heartbeat.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {systemHealth.map((service) => (
                <div key={service.title} className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium">{service.title}</p>
                    <p className="text-sm text-muted-foreground">{service.detail}</p>
                  </div>
                  <Badge variant={service.status === "Operational" ? "secondary" : "destructive"}>
                    {service.status}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Maintenance Queue</CardTitle>
              <CardDescription>Upcoming jobs and tasks that need monitoring.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {maintenanceTasks.map((task) => (
                <div key={task.title} className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium">{task.title}</p>
                    <p className="text-sm text-muted-foreground">{task.detail}</p>
                  </div>
                  <Badge
                    variant={
                      task.badge === "Scheduled"
                        ? "secondary"
                        : task.badge === "Complete"
                        ? "outline"
                        : "destructive"
                    }
                  >
                    {task.badge}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Admin Activity</CardTitle>
            <CardDescription>High-signal events from the last 24 hours.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {activityLog.map((entry) => (
              <div key={entry.title} className="flex items-start gap-4 rounded-lg border border-border p-4">
                <div className="rounded-md bg-muted text-muted-foreground p-2">
                  <entry.icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="font-medium">{entry.title}</p>
                  <p className="text-sm text-muted-foreground">{entry.detail}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
