import { useEffect, useMemo } from "react";
import { useLocation } from "wouter";
import { ShieldCheck, ArrowRight } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

export default function Login() {
  const { user, loading, login } = useAuth();
  const [, navigate] = useLocation();

  const nextPath = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    const next = params.get("next");
    return next && next.startsWith("/") ? next : "/";
  }, []);

  useEffect(() => {
    if (!loading && user) {
      navigate(nextPath);
    }
  }, [loading, user, navigate, nextPath]);

  const startLogin = () => login(nextPath);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-foreground">
      <div className="mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center px-4 py-12">
        <div className="mb-10 flex flex-col items-center gap-3 text-center">
          <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-white/70">
            <ShieldCheck className="h-4 w-4" />
            Workspace Sign-In
          </div>
          <h1 className="text-3xl font-semibold text-white sm:text-4xl">CFS: Product Information Management</h1>
          <p className="max-w-2xl text-sm text-white/70">
            Sign in with your Google Workspace account to manage product catalogs, imports, and exports in one place.
          </p>
        </div>

        <Card className="w-full max-w-xl border-white/10 bg-white/5 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-xl text-white">Sign in with Google</CardTitle>
            <CardDescription className="text-white/70">
              We only allow accounts from your organization&apos;s Workspace domain.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <Button
              onClick={startLogin}
              size="lg"
              className="w-full justify-center gap-3 bg-white text-slate-900 transition-all hover:-translate-y-[1px] hover:bg-white/90"
            >
              <FcGoogle className="h-5 w-5" />
              Continue with Google
            </Button>
            <div className="rounded-md border border-white/10 bg-black/10 p-4 text-sm text-white/80">
              <p className="font-medium text-white">What happens next?</p>
              <ul className="mt-2 space-y-1 text-white/70">
                <li className="flex items-start gap-2">
                  <ArrowRight className="mt-0.5 h-4 w-4 opacity-70" />
                  You will be redirected to Google Workspace SSO.
                </li>
                <li className="flex items-start gap-2">
                  <ArrowRight className="mt-0.5 h-4 w-4 opacity-70" />
                  Google verifies you belong to the allowed domain.
                </li>
                <li className="flex items-start gap-2">
                  <ArrowRight className="mt-0.5 h-4 w-4 opacity-70" />
                  You return here and unlock the dashboard and catalog tools.
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <p className="mt-6 text-xs text-white/50">
          Need help? Ask an admin to confirm your Workspace email or update the allowed domain.
        </p>
      </div>
    </div>
  );
}
