import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Coins, Eye, Package, Store as StoreIcon, Plus, Pencil } from "lucide-react";

type StoreRecord = {
  storeId: number;
  code: string;
  name: string | null;
  websiteCode: string;
};

type CurrencyRecord = {
  currencyId: number;
  code: string;
  name: string | null;
  symbol: string | null;
};

type StoreCurrencyRecord = {
  storeId: number;
  currencyId: number;
  isDefault: boolean | null;
  code?: string | null;
  name?: string | null;
  symbol?: string | null;
};

type CatalogSummary = {
  products: any[];
  count: number;
};

type CurrencyUpdatePayload = {
  storeId: number;
  currencyId: number;
};

type CreateStorePayload = {
  code: string;
  name?: string | null;
  websiteCode: string;
};

function getTabFromLocation(location: string) {
  if (location.startsWith("/stores/products")) return "products";
  if (location.startsWith("/stores/currency")) return "currency";
  return "views";
}

function formatCurrencyLabel(currency: CurrencyRecord) {
  if (currency.name) {
    return `${currency.code} - ${currency.name}`;
  }
  return currency.code;
}

type UpdateStorePayload = {
  storeId: number;
  code?: string;
  name?: string | null;
  websiteCode?: string;
};

export default function StoresPage() {
  const [location, navigate] = useLocation();
  const activeTab = getTabFromLocation(location);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingStore, setEditingStore] = useState<StoreRecord | null>(null);
  const [editStoreCode, setEditStoreCode] = useState("");
  const [editStoreName, setEditStoreName] = useState("");
  const [editStoreWebsiteCode, setEditStoreWebsiteCode] = useState("");
  const [newStoreCode, setNewStoreCode] = useState("");
  const [newStoreName, setNewStoreName] = useState("");
  const [newStoreWebsiteCode, setNewStoreWebsiteCode] = useState("");
  const { toast } = useToast();

  const { data: stores = [] } = useQuery<StoreRecord[]>({
    queryKey: ["/api/stores"],
  });

  const { data: currencies = [] } = useQuery<CurrencyRecord[]>({
    queryKey: ["/api/currencies"],
  });

  const { data: storeCurrencies = [] } = useQuery<StoreCurrencyRecord[]>({
    queryKey: ["/api/store-currencies"],
  });

  const { data: catalogSummary } = useQuery<CatalogSummary>({
    queryKey: ["/api/catalog/products?limit=0"],
  });

  const { data: storeProductCounts = [] } = useQuery<Array<{ storeId: number; productCount: number }>>({
    queryKey: ["/api/stores/product-counts"],
  });

  const updateCurrencyMutation = useMutation({
    mutationFn: async ({ storeId, currencyId }: CurrencyUpdatePayload) => {
      await apiRequest("PATCH", `/api/stores/${storeId}/currency`, { currencyId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/store-currencies"] });
    },
  });

  const createStoreMutation = useMutation({
    mutationFn: async (payload: CreateStorePayload) => {
      const response = await apiRequest("POST", "/api/stores", payload);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/store-currencies"] });
      toast({
        title: "Store created",
        description: "The new store is now available in the list.",
      });
      setIsCreateDialogOpen(false);
      setNewStoreCode("");
      setNewStoreName("");
      setNewStoreWebsiteCode("");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create store",
      });
    },
  });

  const updateStoreMutation = useMutation({
    mutationFn: async ({ storeId, code, name, websiteCode }: UpdateStorePayload) => {
      const response = await apiRequest("PATCH", `/api/stores/${storeId}`, { code, name, websiteCode });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/store-currencies"] });
      toast({
        title: "Store updated",
        description: "The store has been updated successfully.",
      });
      setIsEditDialogOpen(false);
      setEditingStore(null);
      setEditStoreCode("");
      setEditStoreName("");
      setEditStoreWebsiteCode("");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update store",
      });
    },
  });

  const currencyById = useMemo(() => {
    return new Map(currencies.map((currency) => [currency.currencyId, currency]));
  }, [currencies]);

  const defaultCurrencyByStore = useMemo(() => {
    const map = new Map<number, number>();
    storeCurrencies.forEach((entry) => {
      if (entry.isDefault) {
        map.set(entry.storeId, entry.currencyId);
      }
    });
    return map;
  }, [storeCurrencies]);

  const fallbackCurrencyByStore = useMemo(() => {
    const map = new Map<number, number>();
    storeCurrencies.forEach((entry) => {
      if (!map.has(entry.storeId)) {
        map.set(entry.storeId, entry.currencyId);
      }
    });
    return map;
  }, [storeCurrencies]);

  const totalProducts = catalogSummary?.count ?? 0;
  const storesWithCurrency = new Set(defaultCurrencyByStore.keys()).size;

  const productCountByStore = useMemo(() => {
    const map = new Map<number, number>();
    storeProductCounts.forEach((entry) => {
      map.set(entry.storeId, entry.productCount);
    });
    return map;
  }, [storeProductCounts]);

  const summaryCards = [
    {
      title: "Stores",
      value: stores.length,
      subtitle: "Active storefronts",
      icon: StoreIcon,
    },
    {
      title: "Catalog products",
      value: totalProducts,
      subtitle: "Available across stores",
      icon: Package,
    },
    {
      title: "Currencies available",
      value: currencies.length,
      subtitle: "For multi-currency pricing",
      icon: Coins,
    },
  ];

  const handleTabChange = (value: string) => {
    if (value === "views") {
      navigate("/stores/views");
      return;
    }
    navigate(`/stores/${value}`);
  };

  const handleCreateStore = () => {
    const trimmedCode = newStoreCode.trim().toUpperCase();
    const trimmedName = newStoreName.trim();
    const trimmedWebsiteCode = newStoreWebsiteCode.trim();
    if (!trimmedCode) {
      toast({
        variant: "destructive",
        title: "Missing store code",
        description: "Please provide a unique code to create a store.",
      });
      return;
    }

    if (!trimmedWebsiteCode) {
      toast({
        variant: "destructive",
        title: "Missing website code",
        description: "Please provide a website code for the store.",
      });
      return;
    }

    createStoreMutation.mutate({
      code: trimmedCode,
      name: trimmedName || null,
      websiteCode: trimmedWebsiteCode,
    });
  };

  const handleOpenEditDialog = (store: StoreRecord) => {
    setEditingStore(store);
    setEditStoreCode(store.code);
    setEditStoreName(store.name || "");
    setEditStoreWebsiteCode(store.websiteCode || "");
    setIsEditDialogOpen(true);
  };

  const handleUpdateStore = () => {
    if (!editingStore) return;

    const trimmedCode = editStoreCode.trim().toUpperCase();
    const trimmedName = editStoreName.trim();
    const trimmedWebsiteCode = editStoreWebsiteCode.trim();

    if (!trimmedCode) {
      toast({
        variant: "destructive",
        title: "Missing store code",
        description: "Please provide a unique code for this store.",
      });
      return;
    }

    if (!trimmedWebsiteCode) {
      toast({
        variant: "destructive",
        title: "Missing website code",
        description: "Please provide a website code for this store.",
      });
      return;
    }

    updateStoreMutation.mutate({
      storeId: editingStore.storeId,
      code: trimmedCode,
      name: trimmedName || null,
      websiteCode: trimmedWebsiteCode,
    });
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-2xl font-semibold text-foreground">Stores</h1>
          <p className="text-sm text-muted-foreground">
            Manage store views, catalog coverage, and currency defaults across storefronts.
          </p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Create New Store
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-6">
        <TabsList>
          <TabsTrigger value="views" className="gap-2">
            <Eye className="h-4 w-4" />
            Store views
          </TabsTrigger>
          <TabsTrigger value="products" className="gap-2">
            <Package className="h-4 w-4" />
            Store products
          </TabsTrigger>
          <TabsTrigger value="currency" className="gap-2">
            <Coins className="h-4 w-4" />
            Store currency
          </TabsTrigger>
        </TabsList>

        <TabsContent value="views" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {summaryCards.map((card) => (
              <Card key={card.title}>
                <CardHeader className="space-y-1">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      {card.title}
                    </CardTitle>
                    <card.icon className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-semibold text-foreground">{card.value}</div>
                  <CardDescription>{card.subtitle}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Store overview</CardTitle>
              <CardDescription>Current storefronts and their default currencies.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Store</TableHead>
                    <TableHead>Code</TableHead>
                    <TableHead>Website Code</TableHead>
                    <TableHead>Default currency</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stores.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-sm text-muted-foreground">
                        No stores available.
                      </TableCell>
                    </TableRow>
                  ) : (
                    stores.map((store) => {
                      const currencyId =
                        defaultCurrencyByStore.get(store.storeId) ??
                        fallbackCurrencyByStore.get(store.storeId);
                      const currency = currencyId ? currencyById.get(currencyId) : null;
                      return (
                        <TableRow key={store.storeId} data-testid={`row-store-${store.storeId}`}>
                          <TableCell className="font-medium">{store.name || "Unnamed store"}</TableCell>
                          <TableCell className="text-muted-foreground">{store.code}</TableCell>
                          <TableCell className="text-muted-foreground">{store.websiteCode}</TableCell>
                          <TableCell>
                            {currency ? (
                              <Badge variant="outline">{currency.code}</Badge>
                            ) : (
                              <Badge variant="secondary">Unassigned</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => handleOpenEditDialog(store)}
                              data-testid={`button-edit-store-${store.storeId}`}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Store product coverage</CardTitle>
              <CardDescription>
                Track how the global catalog maps into each store view.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Store</TableHead>
                    <TableHead>Products available</TableHead>
                    <TableHead>Catalog scope</TableHead>
                    <TableHead className="text-right">Catalog</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stores.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-sm text-muted-foreground">
                        No stores available.
                      </TableCell>
                    </TableRow>
                  ) : (
                    stores.map((store) => {
                      const assignedCount = productCountByStore.get(store.storeId) ?? 0;
                      return (
                        <TableRow key={store.storeId}>
                          <TableCell className="font-medium">{store.name || "Unnamed store"}</TableCell>
                          <TableCell>{assignedCount}</TableCell>
                          <TableCell>
                            {assignedCount > 0 ? (
                              <Badge variant="default">{assignedCount} products assigned</Badge>
                            ) : (
                              <Badge variant="secondary">No products assigned</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button asChild variant="ghost" size="sm">
                              <Link href="/catalog">View catalog</Link>
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="currency" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Store currency defaults</CardTitle>
              <CardDescription>
                Choose the default currency for each store. Defaults apply to pricing and exports.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Store</TableHead>
                    <TableHead>Current default</TableHead>
                    <TableHead>Update currency</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stores.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">
                        No stores available.
                      </TableCell>
                    </TableRow>
                  ) : (
                    stores.map((store) => {
                      const currentCurrencyId =
                        defaultCurrencyByStore.get(store.storeId) ??
                        fallbackCurrencyByStore.get(store.storeId);
                      const currentCurrency = currentCurrencyId
                        ? currencyById.get(currentCurrencyId)
                        : null;
                      const isUpdating =
                        updateCurrencyMutation.isPending &&
                        updateCurrencyMutation.variables?.storeId === store.storeId;

                      return (
                        <TableRow key={store.storeId}>
                          <TableCell className="font-medium">{store.name || "Unnamed store"}</TableCell>
                          <TableCell>
                            {currentCurrency ? (
                              <Badge variant="outline">
                                {currentCurrency.code}
                                {currentCurrency.symbol ? ` ${currentCurrency.symbol}` : ""}
                              </Badge>
                            ) : (
                              <Badge variant="secondary">Unassigned</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <Select
                              value={currentCurrencyId ? String(currentCurrencyId) : ""}
                              onValueChange={(value) => {
                                const parsed = Number(value);
                                if (!Number.isNaN(parsed)) {
                                  updateCurrencyMutation.mutate({
                                    storeId: store.storeId,
                                    currencyId: parsed,
                                  });
                                }
                              }}
                              disabled={currencies.length === 0 || isUpdating}
                            >
                              <SelectTrigger className="w-56">
                                <SelectValue placeholder="Select currency" />
                              </SelectTrigger>
                              <SelectContent>
                                {currencies.map((currency) => (
                                  <SelectItem key={currency.currencyId} value={String(currency.currencyId)}>
                                    {formatCurrencyLabel(currency)}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Store</DialogTitle>
            <DialogDescription>
              Add a new store view. Provide a unique code and optional display name.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="store-code">Store code</Label>
              <Input
                id="store-code"
                value={newStoreCode}
                onChange={(event) => setNewStoreCode(event.target.value)}
                placeholder="e.g. UK"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="store-name">Store name</Label>
              <Input
                id="store-name"
                value={newStoreName}
                onChange={(event) => setNewStoreName(event.target.value)}
                placeholder="e.g. United Kingdom"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="store-website-code">Website code</Label>
              <Input
                id="store-website-code"
                value={newStoreWebsiteCode}
                onChange={(event) => setNewStoreWebsiteCode(event.target.value)}
                placeholder="e.g. BASE"
                data-testid="input-new-store-website-code"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setIsCreateDialogOpen(false)}
              disabled={createStoreMutation.isPending}
            >
              Cancel
            </Button>
            <Button onClick={handleCreateStore} disabled={createStoreMutation.isPending}>
              {createStoreMutation.isPending ? "Creating..." : "Create Store"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Store</DialogTitle>
            <DialogDescription>
              Update the store code and display name.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-store-code">Store code</Label>
              <Input
                id="edit-store-code"
                value={editStoreCode}
                onChange={(event) => setEditStoreCode(event.target.value)}
                placeholder="e.g. UK"
                data-testid="input-edit-store-code"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-store-name">Store name</Label>
              <Input
                id="edit-store-name"
                value={editStoreName}
                onChange={(event) => setEditStoreName(event.target.value)}
                placeholder="e.g. United Kingdom"
                data-testid="input-edit-store-name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-store-website-code">Website code</Label>
              <Input
                id="edit-store-website-code"
                value={editStoreWebsiteCode}
                onChange={(event) => setEditStoreWebsiteCode(event.target.value)}
                placeholder="e.g. BASE"
                data-testid="input-edit-store-website-code"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setIsEditDialogOpen(false)}
              disabled={updateStoreMutation.isPending}
            >
              Cancel
            </Button>
            <Button onClick={handleUpdateStore} disabled={updateStoreMutation.isPending} data-testid="button-save-store">
              {updateStoreMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
