import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Search, Package, AlertCircle, Plus, Trash2, RefreshCw, Copy, ClipboardPaste, ImageIcon, X, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Users } from "lucide-react";

const getProductStyleName = (style: string | null): string => {
  if (style === null || style === undefined || style === "") return "N/A";
  return style;
};
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { ColumnVisibilitySelector, type ColumnConfig, getInitialVisibility } from "@/components/column-visibility-selector";
import { ProductCreationDialog } from "@/components/product-creation-dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { ProductWithDetails } from "@shared/schema_v2";

const COLUMN_CONFIGS: ColumnConfig[] = [
  { id: "thumbnail", label: "Image", defaultVisible: true },
  { id: "sku", label: "SKU", defaultVisible: true },
  { id: "articleNumber", label: "Article Number", defaultVisible: false },
  { id: "description", label: "Description", defaultVisible: true },
  { id: "brand", label: "Brand", defaultVisible: true },
  { id: "gender", label: "Gender", defaultVisible: true },
  { id: "productType", label: "Product Type", defaultVisible: true },
  { id: "team", label: "Team", defaultVisible: false },
  { id: "colour", label: "Colour", defaultVisible: false },
  { id: "style", label: "Style", defaultVisible: false },
  { id: "composition", label: "Composition", defaultVisible: false },
  { id: "countryOfManufacture", label: "Country of Manufacture", defaultVisible: false },
  { id: "commodityCode", label: "Commodity Code", defaultVisible: false },
  { id: "imageCode", label: "Image Code", defaultVisible: false },
  { id: "variants", label: "Variants", defaultVisible: true },
  { id: "stock", label: "Stock", defaultVisible: true },
  { id: "attribution", label: "Attribution", defaultVisible: true },
  { id: "missingFields", label: "Missing Fields", defaultVisible: true },
  { id: "status", label: "Status", defaultVisible: true },
  { id: "groups", label: "Groups", defaultVisible: true },
  { id: "sync", label: "Sync", defaultVisible: true },
  { id: "createdAt", label: "Created At", defaultVisible: false },
  { id: "updatedAt", label: "Updated At", defaultVisible: false },
];

const createGroupSchema = z.object({
  name: z.string().min(1, "Group name is required"),
  description: z.string().optional(),
});

type CatalogFilterOperator = "eq" | "neq" | "contains" | "gt" | "gte" | "lt" | "lte" | "isEmpty" | "isNotEmpty";
type CatalogFilterSource = "product" | "variant" | "attribute";
type CatalogFilterDataType = "text" | "number" | "boolean" | "date";

type CatalogFilter = {
  id: string;
  field: string;
  operator: CatalogFilterOperator;
  value: string;
  dataType: CatalogFilterDataType;
  source: CatalogFilterSource;
  attributeId?: number;
  scope?: string | null;
};

type FilterOption = {
  key: string;
  label: string;
  dataType: CatalogFilterDataType;
  source: CatalogFilterSource;
  field: string;
  attributeId?: number;
  scope?: string | null;
};

const DEFAULT_SORT_VALUE = "__default__";

type CreateGroupFormData = z.infer<typeof createGroupSchema>;
type CreateProductPayload = {
  productSku: string;
  articleNumber: string;
  productDescription: string;
  productColourId: number | null;
  genderId: number | null;
  brandId: number | null;
  productTypeId: number | null;
  productStyle: string | null;
  clubId: number | null;
  composition: string;
  countryOfManufacture: string;
  commodityCode: string;
  imageCode: string;
  enabled: boolean;
  categoryId: number | null;
};

export default function Catalog() {
  const [location, navigate] = useLocation();
  const [searchInput, setSearchInput] = useState("");
  const [appliedSearch, setAppliedSearch] = useState("");
  const [draftFilters, setDraftFilters] = useState<CatalogFilter[]>([]);
  const [appliedFilters, setAppliedFilters] = useState<CatalogFilter[]>([]);
  const [sortBy, setSortBy] = useState<string>("");
  const [order, setOrder] = useState<string>("asc");
  const [draftSortBy, setDraftSortBy] = useState<string>(DEFAULT_SORT_VALUE);
  const [draftOrder, setDraftOrder] = useState<string>("asc");
  const [page, setPage] = useState(0);
  const [columnVisibility, setColumnVisibility] = useState<Record<string, boolean>>(() => getInitialVisibility(COLUMN_CONFIGS, "catalog-column-visibility"));
  const [selectedProductIds, setSelectedProductIds] = useState<Set<number>>(new Set());
  const [isCreateGroupDialogOpen, setIsCreateGroupDialogOpen] = useState(false);
  const [isAssignAttributeOpen, setIsAssignAttributeOpen] = useState(false);
  const [assignProductId, setAssignProductId] = useState<number | null>(null);
  const [assignTarget, setAssignTarget] = useState<"product" | "variant">("product");
  const [assignAttributeId, setAssignAttributeId] = useState<string>("");
  const [assignVariantId, setAssignVariantId] = useState<string>("");
  const [assignValue, setAssignValue] = useState<string>("");
  const [assignValueBool, setAssignValueBool] = useState(false);
  const [addImageProductId, setAddImageProductId] = useState<number | null>(null);
  const [addImageUrl, setAddImageUrl] = useState("");
  const [addImageRole, setAddImageRole] = useState("base");
  const [addImageLabel, setAddImageLabel] = useState("");
  const [selectedGroupIds, setSelectedGroupIds] = useState<Set<number>>(new Set());
  const [addToGroupsOpen, setAddToGroupsOpen] = useState(false);
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({});
  const [tableFixed, setTableFixed] = useState(false);
  const resizeRef = useRef<{ col: string; startX: number; startW: number } | null>(null);
  const tableRef = useRef<HTMLTableElement>(null);

  const getColStyle = (colId: string) => {
    const w = columnWidths[colId];
    return w ? { width: w, minWidth: w, maxWidth: w } : undefined;
  };

  const captureAllColumnWidths = useCallback(() => {
    if (!tableRef.current) return;
    const headerCells = tableRef.current.querySelectorAll("thead th[data-col-id]");
    const widths: Record<string, number> = {};
    headerCells.forEach((th) => {
      const colId = (th as HTMLElement).dataset.colId;
      if (colId) {
        widths[colId] = (th as HTMLElement).getBoundingClientRect().width;
      }
    });
    setColumnWidths((prev) => ({ ...widths, ...prev }));
    setTableFixed(true);
  }, []);

  const handleResizeStart = useCallback((e: React.MouseEvent, colId: string) => {
    e.preventDefault();
    e.stopPropagation();
    const th = (e.target as HTMLElement).closest("th");
    if (!th) return;

    if (!tableFixed) {
      captureAllColumnWidths();
    }

    const startW = th.getBoundingClientRect().width;
    resizeRef.current = { col: colId, startX: e.clientX, startW };

    const onMouseMove = (ev: MouseEvent) => {
      if (!resizeRef.current) return;
      const diff = ev.clientX - resizeRef.current.startX;
      const newWidth = Math.max(40, resizeRef.current.startW + diff);
      setColumnWidths((prev) => ({ ...prev, [resizeRef.current!.col]: newWidth }));
    };
    const onMouseUp = () => {
      resizeRef.current = null;
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  }, [tableFixed, captureAllColumnWidths]);

  const { toast } = useToast();
  const limit = 50;

  const form = useForm<CreateGroupFormData>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const buildQueryParams = () => {
    const params = new URLSearchParams();
    if (appliedSearch) params.append("search", appliedSearch);
    if (appliedFilters.length > 0) {
      const serializedFilters = appliedFilters.map(({ id, ...rest }) => rest);
      params.append("filters", JSON.stringify(serializedFilters));
    }
    if (sortBy) params.append("sortBy", sortBy);
    if (order) params.append("order", order);
    params.append("limit", limit.toString());
    params.append("offset", (page * limit).toString());
    return params.toString();
  };

  // Read URL parameters on mount (including from sessionStorage for back-navigation)
  useEffect(() => {
    let params = new URLSearchParams(window.location.search);

    // If no meaningful params in URL, try restoring from sessionStorage (back-navigation case)
    const hasUrlState = params.has("search") || params.has("filters") || params.has("sortBy") || params.has("offset");
    if (!hasUrlState) {
      const saved = sessionStorage.getItem("catalog-state");
      if (saved) {
        try {
          params = new URLSearchParams(saved);
        } catch (e) {
          // ignore
        }
      }
    }

    const urlSearch = params.get("search");
    const urlFilters = params.get("filters");
    const urlSortBy = params.get("sortBy");
    const urlOrder = params.get("order");
    const urlOffset = params.get("offset");

    if (urlSearch) {
      setSearchInput(urlSearch);
      setAppliedSearch(urlSearch);
    }
    if (urlFilters) {
      try {
        const parsed = JSON.parse(urlFilters);
        if (Array.isArray(parsed)) {
          const hydrated = parsed.map((item) => ({
            id: `${Date.now()}-${Math.random()}`,
            field: String(item.field ?? ""),
            operator: (item.operator ?? "eq") as CatalogFilterOperator,
            value: item.value !== undefined && item.value !== null ? String(item.value) : "",
            dataType: (item.dataType ?? "text") as CatalogFilterDataType,
            source: (item.source ?? "product") as CatalogFilterSource,
            attributeId: item.attributeId ? Number(item.attributeId) : undefined,
            scope: item.scope ?? null,
          }));
          setDraftFilters(hydrated);
          setAppliedFilters(hydrated);
        }
      } catch (error) {
        console.warn("Failed to parse catalog filters from URL", error);
      }
    }
    if (urlSortBy) {
      setSortBy(urlSortBy);
      setDraftSortBy(urlSortBy);
    } else {
      setDraftSortBy(DEFAULT_SORT_VALUE);
    }
    if (urlOrder) {
      setOrder(urlOrder);
      setDraftOrder(urlOrder);
    }
    if (urlOffset) {
      const offsetNum = parseInt(urlOffset, 10);
      if (!isNaN(offsetNum) && offsetNum > 0) {
        setPage(Math.floor(offsetNum / limit));
      }
    }
  }, []);

  // Sync URL with filter state and persist to sessionStorage
  useEffect(() => {
    const params = buildQueryParams();
    if (params) {
      navigate(`/catalog?${params}`, { replace: true });
      sessionStorage.setItem("catalog-state", params);
    } else {
      navigate('/catalog', { replace: true });
      sessionStorage.removeItem("catalog-state");
    }
  }, [appliedSearch, appliedFilters, sortBy, order, page]);

  const queryParams = buildQueryParams();
  const { data, isLoading } = useQuery<{ products: ProductWithDetails[]; count: number }>({
    queryKey: ["/api/catalog/products", queryParams],
    queryFn: async () => {
      const response = await fetch(`/api/catalog/products?${queryParams}`);
      return response.json();
    },
  });

  const { data: brands = [] } = useQuery<any[]>({
    queryKey: ["/api/brands"],
  });

  const { data: categories = [] } = useQuery<any[]>({
    queryKey: ["/api/categories"],
  });

  const { data: clubs = [] } = useQuery<any[]>({
    queryKey: ["/api/clubs"],
  });

  const { data: productTypes = [] } = useQuery<any[]>({
    queryKey: ["/api/product-types"],
  });

  const { data: productColours = [] } = useQuery<any[]>({
    queryKey: ["/api/product-colours"],
  });

  const { data: genders = [] } = useQuery<any[]>({
    queryKey: ["/api/genders"],
  });

  const { data: taxClasses = [] } = useQuery<any[]>({
    queryKey: ["/api/tax-classes"],
  });

  const { data: sizes = [] } = useQuery<any[]>({
    queryKey: ["/api/sizes"],
  });

  const { data: conditions = [] } = useQuery<any[]>({
    queryKey: ["/api/conditions"],
  });

  const { data: eras = [] } = useQuery<any[]>({
    queryKey: ["/api/eras"],
  });

  const { data: attributeDefs = [] } = useQuery<any[]>({
    queryKey: ["/api/attribute-defs"],
  });

  // Build dropdown options map for filter fields that should use a Select instead of free text
  const filterDropdownOptions = useMemo<Record<string, string[]>>(() => {
    return {
      genderName: genders.map((g: any) => g.genderName).filter(Boolean).sort(),
      brandName: brands.map((b: any) => b.brandName).filter(Boolean).sort(),
      colourName: productColours.map((c: any) => c.magentoColourName || c.brandColourName).filter(Boolean).sort(),
      eraName: eras.map((e: any) => e.name).filter(Boolean).sort(),
      teamName: clubs.map((c: any) => c.name).filter(Boolean).sort(),
      productTypeName: productTypes.map((t: any) => t.productTypeName).filter(Boolean).sort(),
      conditionName: conditions.map((c: any) => c.conditionName).filter(Boolean).sort(),
    };
  }, [genders, brands, productColours, eras, clubs, productTypes, conditions]);

  const { data: productVariants = [] } = useQuery<any[]>({
    queryKey: ["/api/products", assignProductId, "variants"],
    enabled: isAssignAttributeOpen && !!assignProductId && assignTarget === "variant",
    queryFn: async () => {
      const response = await fetch(`/api/products/${assignProductId}/variants`);
      return response.json();
    },
  });

  const { data: allGroups = [] } = useQuery<any[]>({
    queryKey: ["/api/groups"],
  });

  const addToGroupMutation = useMutation({
    mutationFn: async ({ groupIds, productIds }: { groupIds: number[]; productIds: number[] }) => {
      const results = await Promise.all(
        groupIds.map(async (groupId) => {
          const response = await apiRequest("POST", `/api/groups/${groupId}/members`, { productIds });
          return await response.json();
        })
      );
      return results;
    },
    onSuccess: (_data, variables) => {
      const groupNames = variables.groupIds
        .map((id) => allGroups.find((g: any) => g.groupId === id)?.name)
        .filter(Boolean)
        .join(", ");
      toast({
        title: "Products added to groups",
        description: `Added ${variables.productIds.length} product(s) to ${groupNames}`,
      });
      setSelectedGroupIds(new Set());
      setAddToGroupsOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to add products to groups",
      });
    },
  });

  const createGroupMutation = useMutation({
    mutationFn: async (data: CreateGroupFormData) => {
      const response = await apiRequest("POST", "/api/groups", {
        name: data.name,
        description: data.description || null,
        productIds: Array.from(selectedProductIds),
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Group created",
        description: `Successfully created group with ${selectedProductIds.size} products`,
      });
      setSelectedProductIds(new Set());
      setIsCreateGroupDialogOpen(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      navigate("/groups");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create group",
      });
    },
  });

  const deleteProductsMutation = useMutation({
    mutationFn: async (productIds: number[]) => {
      if (productIds.length === 1) {
        await apiRequest("DELETE", `/api/products/${productIds[0]}`);
        return;
      }
      await apiRequest("POST", "/api/products/bulk-delete", { productIds });
    },
    onSuccess: () => {
      toast({
        title: "Products deleted",
        description: "Selected products have been removed.",
      });
      setSelectedProductIds(new Set());
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete products",
      });
    },
  });

  const recalculatePricesMutation = useMutation({
    mutationFn: async (productIds: number[]) => {
      const response = await apiRequest("POST", "/api/products/bulk-recalculate-prices", { productIds });
      return await response.json();
    },
    onSuccess: (data: any) => {
      toast({
        title: "Prices recalculated",
        description: `Recalculated prices for ${data.variantsRecalculated} variant${data.variantsRecalculated !== 1 ? 's' : ''} across ${data.productsProcessed} product${data.productsProcessed !== 1 ? 's' : ''}.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to recalculate prices",
      });
    },
  });

  const bulkSyncMutation = useMutation({
    mutationFn: async ({ productIds, sync }: { productIds: number[]; sync: boolean }) => {
      const response = await apiRequest("POST", "/api/products/bulk-sync", { productIds, sync });
      return await response.json();
    },
    onSuccess: (data: any) => {
      const skipped: Array<{ sku: string | null; missingFields: string[] }> = data.skipped ?? [];
      if (skipped.length > 0) {
        const skuList = skipped.slice(0, 5).map((s) => s.sku || "Unknown").join(", ");
        const extra = skipped.length > 5 ? ` and ${skipped.length - 5} more` : "";
        if (data.updated === 0) {
          toast({
            variant: "destructive",
            title: "Sync not enabled",
            description: `All ${skipped.length} product(s) are missing required fields: ${skuList}${extra}`,
          });
        } else {
          toast({
            title: "Sync partially updated",
            description: `Enabled sync for ${data.updated} product(s). Skipped ${skipped.length}: ${skuList}${extra} (missing required fields).`,
          });
        }
      } else {
        toast({
          title: "Sync updated",
          description: `Updated sync to ${data.sync ? "On" : "Off"} for ${data.updated} product${data.updated !== 1 ? 's' : ''}.`,
        });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update sync",
      });
    },
  });

  const createProductMutation = useMutation({
    mutationFn: async (data: CreateProductPayload) => {
      const response = await apiRequest("POST", "/api/products", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Product created",
        description: "The product is now available in the catalog.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create product",
      });
    },
  });

  const assignAttributeMutation = useMutation({
    mutationFn: async () => {
      if (!assignProductId) {
        throw new Error("Select a product to update");
      }
      if (!assignAttributeId) {
        throw new Error("Select an attribute");
      }

      const attributeId = Number(assignAttributeId);
      const selectedAttributeDef = attributeDefs.find(
        (def: any) => Number(def.attributeId) === attributeId,
      );
      const dataType = selectedAttributeDef?.dataType ?? null;
      const value =
        dataType === "boolean" ? assignValueBool : assignValue;

      if (assignTarget === "product") {
        await apiRequest("POST", `/api/products/${assignProductId}/attributes`, {
          attributeId,
          value,
        });
        return;
      }

      if (!assignVariantId) {
        throw new Error("Select a variant");
      }

      await apiRequest("POST", `/api/variants/${assignVariantId}/attributes`, {
        attributeId,
        value,
      });
    },
    onSuccess: () => {
      toast({
        title: "Attribute saved",
        description: "The attribute value is now attached.",
      });
      setIsAssignAttributeOpen(false);
      setAssignAttributeId("");
      setAssignVariantId("");
      setAssignValue("");
      setAssignValueBool(false);
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      if (assignProductId) {
        queryClient.invalidateQueries({ queryKey: ["/api/products", assignProductId, "details"] });
      }
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to assign attribute",
      });
    },
  });

  const [copiedProductId, setCopiedProductId] = useState<number | null>(null);
  const [copiedProductSku, setCopiedProductSku] = useState<string | null>(null);

  const duplicateProductMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await apiRequest("POST", `/api/products/${productId}/duplicate`);
      return await response.json();
    },
    onSuccess: (result: { productId: number; productSku: string }) => {
      toast({
        title: "Product pasted",
        description: `Created "${result.productSku}" as a copy.`,
      });
      setCopiedProductId(null);
      setCopiedProductSku(null);
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to paste product",
      });
    },
  });

  const IMAGE_ROLES = ["base", "small", "thumbnail", "additional", "swatch"];

  const addImageMutation = useMutation({
    mutationFn: async (data: { productId: number; url: string; role: string; label: string }) => {
      const res = await apiRequest("POST", "/api/images", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Image added", description: "The image has been added to the product." });
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products", addImageProductId, "images"] });
      queryClient.invalidateQueries({ queryKey: ["/api/catalog/products"] });
      resetAddImageDialog();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to add image", variant: "destructive" });
    },
  });

  const resyncMutation = useMutation({
    mutationFn: async (productId: number) => {
      const res = await apiRequest("POST", `/api/products/${productId}/resync`);
      return res.json();
    },
    onSuccess: (data: any) => {
      const variantCount = data?.variantEntries?.length ?? 0;
      const desc = variantCount > 0
        ? `Product and ${variantCount} variant${variantCount !== 1 ? "s" : ""} added to the sync queue.`
        : "Product has been added to the sync queue.";
      toast({ title: "Resync queued", description: desc });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message || "Failed to queue resync", variant: "destructive" });
    },
  });

  const resetAddImageDialog = () => {
    setAddImageProductId(null);
    setAddImageUrl("");
    setAddImageRole("base");
    setAddImageLabel("");
  };

  const products = data?.products || [];
  const totalCount = data?.count || 0;
  const totalPages = Math.ceil(totalCount / limit);

  const formatDate = (date: Date | null | undefined) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString();
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const currentPageIds = new Set(products.map(p => p.productId));
      setSelectedProductIds(currentPageIds);
    } else {
      setSelectedProductIds(new Set());
    }
  };

  const handleSelectProduct = (productId: number, checked: boolean) => {
    const newSelection = new Set(selectedProductIds);
    if (checked) {
      newSelection.add(productId);
    } else {
      newSelection.delete(productId);
    }
    setSelectedProductIds(newSelection);
  };

  const areAllSelected = products.length > 0 && products.every(p => selectedProductIds.has(p.productId));
  const areSomeSelected = products.some(p => selectedProductIds.has(p.productId)) && !areAllSelected;

  const toggleSort = (field: string) => {
    if (sortBy !== field) {
      setSortBy(field);
      setOrder("asc");
      setDraftSortBy(field);
      setDraftOrder("asc");
      setPage(0);
      return;
    }
    if (order === "asc") {
      setOrder("desc");
      setDraftOrder("desc");
      setPage(0);
      return;
    }
    setSortBy("");
    setOrder("asc");
    setDraftSortBy(DEFAULT_SORT_VALUE);
    setDraftOrder("asc");
    setPage(0);
  };

  const renderSortableHeader = (label: string, field: string) => {
    const isActive = sortBy === field;
    const indicator = isActive ? (order === "asc" ? " ▲" : " ▼") : "";

    return (
      <button
        type="button"
        className="flex items-center gap-1 text-left font-semibold text-sm"
        onClick={() => toggleSort(field)}
        data-testid={`button-sort-${field}`}
      >
        <span>{label}</span>
        <span className="text-muted-foreground">{indicator}</span>
      </button>
    );
  };

  const handleAddFilter = () => {
    const option = filterOptions[0];
    if (!option) return;
    setDraftFilters((prev) => [...prev, createFilter(option)]);
  };

  const handleFilterFieldChange = (id: string, field: string) => {
    const option = filterOptions.find((item) => item.field === field);
    if (!option) return;
    setDraftFilters((prev) =>
      prev.map((filter) =>
        filter.id === id
          ? {
              ...filter,
              field,
              dataType: option.dataType,
              source: option.source,
              attributeId: option.attributeId,
              scope: option.scope ?? null,
              operator: option.dataType === "text" ? "contains" : "eq",
              value: "",
            }
          : filter,
      ),
    );
  };

  const handleFilterOperatorChange = (id: string, operator: CatalogFilterOperator) => {
    setDraftFilters((prev) =>
      prev.map((filter) =>
        filter.id === id
          ? {
              ...filter,
              operator,
              value: requiresValue(operator) ? filter.value : "",
            }
          : filter,
      ),
    );
  };

  const handleFilterValueChange = (id: string, value: string) => {
    setDraftFilters((prev) =>
      prev.map((filter) => (filter.id === id ? { ...filter, value } : filter)),
    );
  };

  const handleRemoveFilter = (id: string) => {
    setDraftFilters((prev) => prev.filter((filter) => filter.id !== id));
  };

  const handleApplyFilters = () => {
    setAppliedSearch(searchInput.trim());
    setAppliedFilters(draftFilters.filter((filter) => filter.field));
    setSortBy(draftSortBy === DEFAULT_SORT_VALUE ? "" : draftSortBy);
    setOrder(draftOrder);
    setPage(0);
  };

  const handleResetFilters = () => {
    setSearchInput("");
    setAppliedSearch("");
    setDraftFilters([]);
    setAppliedFilters([]);
    setDraftSortBy(DEFAULT_SORT_VALUE);
    setDraftOrder("asc");
    setSortBy("");
    setOrder("asc");
    setPage(0);
  };

  const selectedAttributeDef = attributeDefs.find(
    (def: any) => String(def.attributeId) === assignAttributeId,
  );
  const normalizeScope = (scope: string | null | undefined) => {
    if (!scope) return null;
    const normalized = String(scope).trim().toLowerCase();
    if (normalized === "parent" || normalized === "product") return "product";
    if (normalized === "variant" || normalized === "child") return "variant";
    return null;
  };
  const availableAttributeDefs = attributeDefs.filter((def: any) => {
    const normalized = normalizeScope(def.scope);
    if (!normalized) return true;
    return normalized === assignTarget;
  });

  const filterOptions = useMemo<FilterOption[]>(() => {
    const coreOptions: FilterOption[] = [
      { key: "productSku", label: "SKU", dataType: "text", source: "product", field: "productSku" },
      { key: "productDescription", label: "Description", dataType: "text", source: "product", field: "productDescription" },
      { key: "brandName", label: "Brand", dataType: "text", source: "product", field: "brandName" },
      { key: "genderName", label: "Gender", dataType: "text", source: "product", field: "genderName" },
      { key: "colourName", label: "Colour", dataType: "text", source: "product", field: "colourName" },
      { key: "eraName", label: "Era", dataType: "text", source: "product", field: "eraName" },
      { key: "teamName", label: "Team / Club", dataType: "text", source: "product", field: "teamName" },
      { key: "productTypeName", label: "Product Type", dataType: "text", source: "product", field: "productTypeName" },
      { key: "productStyle", label: "Style", dataType: "text", source: "product", field: "productStyle" },
      { key: "conditionName", label: "Condition", dataType: "text", source: "product", field: "conditionName" },
      { key: "seasonName", label: "Season", dataType: "text", source: "product", field: "seasonName" },
      { key: "composition", label: "Composition", dataType: "text", source: "product", field: "composition" },
      { key: "countryOfManufacture", label: "Country of Manufacture", dataType: "text", source: "product", field: "countryOfManufacture" },
      { key: "commodityCode", label: "Commodity Code", dataType: "text", source: "product", field: "commodityCode" },
      { key: "articleNumber", label: "Article Number", dataType: "text", source: "product", field: "articleNumber" },
      { key: "imageCode", label: "Image Code", dataType: "text", source: "product", field: "imageCode" },
      { key: "enabled", label: "Enabled", dataType: "boolean", source: "product", field: "enabled" },
      { key: "sync", label: "Sync", dataType: "boolean", source: "product", field: "sync" },
      { key: "createdAt", label: "Created At", dataType: "date", source: "product", field: "createdAt" },
      { key: "updatedAt", label: "Updated At", dataType: "date", source: "product", field: "updatedAt" },
      { key: "dataAttribution", label: "Attribution %", dataType: "number", source: "product", field: "dataAttribution" },
      { key: "totalStock", label: "Total Stock", dataType: "number", source: "product", field: "totalStock" },
      { key: "variantCount", label: "Variant Count", dataType: "number", source: "product", field: "variantCount" },
      { key: "imageRoleCount", label: "Image Roles (base/thumb/small)", dataType: "number", source: "product", field: "imageRoleCount" },
    ];

    const variantOptions: FilterOption[] = [
      { key: "variantCostPrice", label: "Variant Cost Price", dataType: "number", source: "variant", field: "variantCostPrice" },
      { key: "variantRetailPrice", label: "Variant Retail Price", dataType: "number", source: "variant", field: "variantRetailPrice" },
      { key: "variantPrinted", label: "Variant Printed", dataType: "boolean", source: "variant", field: "variantPrinted" },
      { key: "variantEnabled", label: "Variant Enabled", dataType: "boolean", source: "variant", field: "variantEnabled" },
    ];

    const attributeOptions = attributeDefs.map((def: any) => {
      const scope = normalizeScope(def.scope);
      const labelPrefix = scope === "variant" ? "Variant Attribute" : "Attribute";
      const rawDataType = String(def.dataType ?? "text").toLowerCase();
      const dataType: CatalogFilterDataType =
        rawDataType === "number"
          ? "number"
          : rawDataType === "boolean"
            ? "boolean"
            : "text";
      return {
        key: `attr-${def.attributeId}`,
        label: `${labelPrefix}: ${def.label ?? def.code}`,
        dataType,
        source: "attribute" as const,
        field: `attr:${def.attributeId}`,
        attributeId: Number(def.attributeId),
        scope,
      };
    });

    return [...coreOptions, ...variantOptions, ...attributeOptions].sort((a, b) =>
      a.label.localeCompare(b.label, "en"),
    );
  }, [attributeDefs, normalizeScope]);

  const operatorOptionsByType: Record<CatalogFilterDataType, Array<{ value: CatalogFilterOperator; label: string }>> = {
    text: [
      { value: "contains", label: "contains" },
      { value: "eq", label: "equals" },
      { value: "neq", label: "not equals" },
      { value: "isEmpty", label: "is empty" },
      { value: "isNotEmpty", label: "is not empty" },
    ],
    number: [
      { value: "eq", label: "=" },
      { value: "neq", label: "!=" },
      { value: "gt", label: ">" },
      { value: "gte", label: ">=" },
      { value: "lt", label: "<" },
      { value: "lte", label: "<=" },
      { value: "isEmpty", label: "is empty" },
      { value: "isNotEmpty", label: "is not empty" },
    ],
    boolean: [
      { value: "eq", label: "is" },
      { value: "isEmpty", label: "is empty" },
      { value: "isNotEmpty", label: "is not empty" },
    ],
    date: [
      { value: "eq", label: "on" },
      { value: "gt", label: "after" },
      { value: "gte", label: "on/after" },
      { value: "lt", label: "before" },
      { value: "lte", label: "on/before" },
      { value: "isEmpty", label: "is empty" },
      { value: "isNotEmpty", label: "is not empty" },
    ],
  };

  const requiresValue = (operator: CatalogFilterOperator) => !["isEmpty", "isNotEmpty"].includes(operator);

  const createFilter = (option: FilterOption): CatalogFilter => ({
    id: `${Date.now()}-${Math.random()}`,
    field: option.field,
    operator: option.dataType === "text" ? "contains" : "eq",
    value: "",
    dataType: option.dataType,
    source: option.source,
    attributeId: option.attributeId,
    scope: option.scope ?? null,
  });

  const sortOptions = useMemo(() => {
    const options = new Map<string, string>();
    options.set(DEFAULT_SORT_VALUE, "Default (Newest)");
    for (const option of filterOptions) {
      if (option.source === "attribute" && option.attributeId) {
        options.set(`attr:${option.attributeId}`, option.label);
      } else if (option.source === "variant") {
        options.set(`variant:${option.field}`, option.label);
      } else {
        options.set(`product:${option.field}`, option.label);
      }
    }
    return Array.from(options.entries()).map(([value, label]) => ({ value, label }));
  }, [filterOptions]);

  const handleCreateGroup = (data: CreateGroupFormData) => {
    createGroupMutation.mutate(data);
  };

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-catalog">
              Product Catalog
            </h1>
            <p className="text-muted-foreground mt-1">
              Browse and filter products in the catalog
            </p>
          </div>
          <ProductCreationDialog
            onCreateProduct={(data) => createProductMutation.mutate(data)}
            isCreating={createProductMutation.isPending}
            categories={categories}
            brands={brands}
            productTypes={productTypes}
            productColours={productColours}
            genders={genders}
            clubs={clubs}
            taxClasses={taxClasses}
            sizes={sizes}
            conditions={conditions}
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by SKU or description..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={handleAddFilter}
              disabled={filterOptions.length === 0}
              data-testid="button-add-filter"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Filter
            </Button>
            <Select value={draftSortBy} onValueChange={setDraftSortBy}>
              <SelectTrigger className="w-[180px]" data-testid="select-sort-field">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={draftOrder} onValueChange={setDraftOrder}>
              <SelectTrigger className="w-[130px]" data-testid="select-sort-order">
                <SelectValue placeholder="Order" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asc">Ascending</SelectItem>
                <SelectItem value="desc">Descending</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleApplyFilters} size="sm" data-testid="button-apply-filters">
              Apply
            </Button>
            {(appliedFilters.length > 0 || appliedSearch) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleResetFilters}
                data-testid="button-clear-filters"
              >
                Clear
              </Button>
            )}
          </div>

          {draftFilters.length > 0 && (
            <div className="space-y-2">
              {draftFilters.map((filter) => {
                const operatorOptions = operatorOptionsByType[filter.dataType];
                return (
                  <div
                    key={filter.id}
                    className="grid gap-2 md:grid-cols-[2fr_1fr_2fr_auto] items-start"
                  >
                    <Select
                      value={filter.field}
                      onValueChange={(value) => handleFilterFieldChange(filter.id, value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select field" />
                      </SelectTrigger>
                      <SelectContent>
                        {filterOptions.map((option) => (
                          <SelectItem key={option.key} value={option.field}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select
                      value={filter.operator}
                      onValueChange={(value) =>
                        handleFilterOperatorChange(filter.id, value as CatalogFilterOperator)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Operator" />
                      </SelectTrigger>
                      <SelectContent>
                        {operatorOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {requiresValue(filter.operator) ? (
                      filter.dataType === "boolean" ? (
                        <Select
                          value={filter.value || "true"}
                          onValueChange={(value) => handleFilterValueChange(filter.id, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Value" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="true">True</SelectItem>
                            <SelectItem value="false">False</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : filterDropdownOptions[filter.field] && filterDropdownOptions[filter.field].length > 0 ? (
                        <Select
                          value={filter.value || ""}
                          onValueChange={(value) => handleFilterValueChange(filter.id, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select..." />
                          </SelectTrigger>
                          <SelectContent>
                            {filterDropdownOptions[filter.field].map((opt) => (
                              <SelectItem key={opt} value={opt}>
                                {opt}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type={filter.dataType === "number" ? "number" : filter.dataType === "date" ? "date" : "text"}
                          value={filter.value}
                          onChange={(e) => handleFilterValueChange(filter.id, e.target.value)}
                          placeholder="Value"
                        />
                      )
                    ) : (
                      <div className="h-9 rounded-md border bg-muted/20" />
                    )}

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveFilter(filter.id)}
                      data-testid={`button-remove-filter-${filter.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3 flex-wrap">
                <span>Products ({totalCount.toLocaleString()})</span>
                {selectedProductIds.size > 0 && (
                  <>
                    <span className="text-sm font-normal text-muted-foreground" data-testid="text-selection-count">
                      {selectedProductIds.size} selected
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedProductIds(new Set())}
                      data-testid="button-clear-selection"
                    >
                      Clear
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => setIsCreateGroupDialogOpen(true)}
                      data-testid="button-create-group"
                    >
                      Create Group
                    </Button>
                    {allGroups.length > 0 && (
                      <Popover open={addToGroupsOpen} onOpenChange={(open) => {
                        setAddToGroupsOpen(open);
                        if (!open) setSelectedGroupIds(new Set());
                      }}>
                        <PopoverTrigger asChild>
                          <Button variant="outline" size="sm" data-testid="button-add-to-group">
                            <Users className="h-4 w-4 mr-1" />
                            Add to Group{selectedGroupIds.size > 0 ? ` (${selectedGroupIds.size})` : ""}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-56 p-2" align="start">
                          <div className="space-y-1 max-h-48 overflow-y-auto">
                            {allGroups.map((group: any) => {
                              const gId = Number(group.groupId);
                              const checked = selectedGroupIds.has(gId);
                              return (
                                <label
                                  key={gId}
                                  className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent cursor-pointer text-sm"
                                  data-testid={`checkbox-group-${gId}`}
                                >
                                  <Checkbox
                                    checked={checked}
                                    onCheckedChange={(c) => {
                                      setSelectedGroupIds((prev) => {
                                        const next = new Set(prev);
                                        c ? next.add(gId) : next.delete(gId);
                                        return next;
                                      });
                                    }}
                                  />
                                  {group.name}
                                </label>
                              );
                            })}
                          </div>
                          <div className="border-t mt-2 pt-2">
                            <Button
                              size="sm"
                              className="w-full"
                              disabled={selectedGroupIds.size === 0 || addToGroupMutation.isPending}
                              onClick={() => {
                                addToGroupMutation.mutate({
                                  groupIds: Array.from(selectedGroupIds),
                                  productIds: Array.from(selectedProductIds),
                                });
                              }}
                              data-testid="button-confirm-add-to-groups"
                            >
                              {addToGroupMutation.isPending ? "Adding..." : `Add to ${selectedGroupIds.size} group${selectedGroupIds.size !== 1 ? "s" : ""}`}
                            </Button>
                          </div>
                        </PopoverContent>
                      </Popover>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        recalculatePricesMutation.mutate(Array.from(selectedProductIds));
                      }}
                      disabled={recalculatePricesMutation.isPending}
                      data-testid="button-recalculate-prices"
                    >
                      <RefreshCw className={`h-4 w-4 mr-2 ${recalculatePricesMutation.isPending ? 'animate-spin' : ''}`} />
                      {recalculatePricesMutation.isPending ? "Recalculating..." : "Recalculate Prices"}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        bulkSyncMutation.mutate({ productIds: Array.from(selectedProductIds), sync: true });
                      }}
                      disabled={bulkSyncMutation.isPending}
                      data-testid="button-enable-sync"
                    >
                      Enable Sync
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        bulkSyncMutation.mutate({ productIds: Array.from(selectedProductIds), sync: false });
                      }}
                      disabled={bulkSyncMutation.isPending}
                      data-testid="button-disable-sync"
                    >
                      Disable Sync
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (window.confirm(`Delete ${selectedProductIds.size} selected product(s)?`)) {
                          deleteProductsMutation.mutate(Array.from(selectedProductIds));
                        }
                      }}
                      data-testid="button-delete-products"
                    >
                      Delete
                    </Button>
                  </>
                )}
                {copiedProductId && (
                  <>
                    <Badge variant="secondary" className="text-xs" data-testid="badge-copied-product">
                      Copied: {copiedProductSku}
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => duplicateProductMutation.mutate(copiedProductId)}
                      disabled={duplicateProductMutation.isPending}
                      data-testid="button-paste-product"
                    >
                      <ClipboardPaste className="h-4 w-4 mr-2" />
                      {duplicateProductMutation.isPending ? "Pasting..." : "Paste"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setCopiedProductId(null);
                        setCopiedProductSku(null);
                      }}
                      data-testid="button-clear-clipboard"
                    >
                      Clear
                    </Button>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <ColumnVisibilitySelector
                  columns={COLUMN_CONFIGS}
                  storageKey="catalog-column-visibility"
                  visibility={columnVisibility}
                  onVisibilityChange={setColumnVisibility}
                />
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="px-6 pt-0 pb-4">
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Loading products...</p>
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-8">
                <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No products found</p>
              </div>
            ) : (
              <TooltipProvider>
                <div className="w-full max-h-[65vh] overflow-auto border rounded-md">
                  <Table ref={tableRef} style={tableFixed ? { tableLayout: "fixed" } : undefined}>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="py-1" data-col-id="_checkbox" style={getColStyle("_checkbox") || { width: 40 }}>
                          <Checkbox
                            checked={areAllSelected}
                            onCheckedChange={handleSelectAll}
                            data-testid="checkbox-select-all"
                          />
                        </TableHead>
                        {columnVisibility.thumbnail && (
                          <TableHead className="py-1 whitespace-nowrap w-[50px]" data-col-id="thumbnail">
                            Image
                          </TableHead>
                        )}
                        {columnVisibility.sku && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="sku" style={getColStyle("sku")}>
                            {renderSortableHeader("SKU", "product:productSku")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "sku")} />
                          </TableHead>
                        )}
                        {columnVisibility.articleNumber && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="articleNumber" style={getColStyle("articleNumber")}>
                            {renderSortableHeader("Article Number", "product:articleNumber")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "articleNumber")} />
                          </TableHead>
                        )}
                        {columnVisibility.description && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="description" style={getColStyle("description")}>
                            {renderSortableHeader("Name", "product:name")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "description")} />
                          </TableHead>
                        )}
                        {columnVisibility.brand && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="brand" style={getColStyle("brand")}>
                            {renderSortableHeader("Brand", "product:brandName")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "brand")} />
                          </TableHead>
                        )}
                        {columnVisibility.gender && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="gender" style={getColStyle("gender")}>
                            {renderSortableHeader("Gender", "product:genderName")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "gender")} />
                          </TableHead>
                        )}
                        {columnVisibility.productType && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="productType" style={getColStyle("productType")}>
                            {renderSortableHeader("Product Type", "product:productTypeName")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "productType")} />
                          </TableHead>
                        )}
                        {columnVisibility.team && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="team" style={getColStyle("team")}>
                            {renderSortableHeader("Team", "product:teamName")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "team")} />
                          </TableHead>
                        )}
                        {columnVisibility.colour && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="colour" style={getColStyle("colour")}>
                            {renderSortableHeader("Colour", "product:colourName")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "colour")} />
                          </TableHead>
                        )}
                        {columnVisibility.style && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="style" style={getColStyle("style")}>
                            {renderSortableHeader("Style", "product:productStyle")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "style")} />
                          </TableHead>
                        )}
                        {columnVisibility.composition && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="composition" style={getColStyle("composition")}>
                            {renderSortableHeader("Composition", "product:composition")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "composition")} />
                          </TableHead>
                        )}
                        {columnVisibility.countryOfManufacture && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="countryOfManufacture" style={getColStyle("countryOfManufacture")}>
                            {renderSortableHeader("Country", "product:countryOfManufacture")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "countryOfManufacture")} />
                          </TableHead>
                        )}
                        {columnVisibility.commodityCode && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="commodityCode" style={getColStyle("commodityCode")}>
                            {renderSortableHeader("Commodity Code", "product:commodityCode")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "commodityCode")} />
                          </TableHead>
                        )}
                        {columnVisibility.imageCode && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="imageCode" style={getColStyle("imageCode")}>
                            {renderSortableHeader("Image Code", "product:imageCode")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "imageCode")} />
                          </TableHead>
                        )}
                        {columnVisibility.variants && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="variants" style={getColStyle("variants")}>
                            {renderSortableHeader("Variants", "product:variantCount")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "variants")} />
                          </TableHead>
                        )}
                        {columnVisibility.stock && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="stock" style={getColStyle("stock")}>
                            {renderSortableHeader("Stock", "product:totalStock")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "stock")} />
                          </TableHead>
                        )}
                        {columnVisibility.attribution && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="attribution" style={getColStyle("attribution")}>
                            {renderSortableHeader("Attribution", "product:dataAttribution")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "attribution")} />
                          </TableHead>
                        )}
                        {columnVisibility.missingFields && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="missingFields" style={getColStyle("missingFields")}>
                            {renderSortableHeader("Missing Fields", "product:missingFields")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "missingFields")} />
                          </TableHead>
                        )}
                        {columnVisibility.status && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="status" style={getColStyle("status")}>
                            {renderSortableHeader("Status", "product:enabled")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "status")} />
                          </TableHead>
                        )}
                        {columnVisibility.groups && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="groups" style={getColStyle("groups")}>
                            Groups
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "groups")} />
                          </TableHead>
                        )}
                        {columnVisibility.sync && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="sync" style={getColStyle("sync")}>
                            {renderSortableHeader("Sync", "product:sync")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "sync")} />
                          </TableHead>
                        )}
                        {columnVisibility.createdAt && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="createdAt" style={getColStyle("createdAt")}>
                            {renderSortableHeader("Created", "product:createdAt")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "createdAt")} />
                          </TableHead>
                        )}
                        {columnVisibility.updatedAt && (
                          <TableHead className="py-1 whitespace-nowrap relative overflow-hidden" data-col-id="updatedAt" style={getColStyle("updatedAt")}>
                            {renderSortableHeader("Updated", "product:updatedAt")}
                            <div className="absolute right-0 top-0 bottom-0 w-[5px] cursor-col-resize hover:bg-primary/40 active:bg-primary/60" onMouseDown={(e) => handleResizeStart(e, "updatedAt")} />
                          </TableHead>
                        )}
                        <TableHead className="py-1 text-right whitespace-nowrap" data-col-id="_actions" style={getColStyle("_actions")}>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map((product) => {
                        return (
                          <React.Fragment key={product.productId}>
                            <TableRow
                              className="cursor-pointer hover-elevate"
                              onClick={() => navigate(`/product/${product.productId}`)}
                              data-testid={`row-product-${product.productId}`}
                            >
                              <TableCell className="py-1" onClick={(e) => e.stopPropagation()}>
                                <Checkbox
                                  checked={selectedProductIds.has(product.productId)}
                                  onCheckedChange={(checked) => handleSelectProduct(product.productId, checked as boolean)}
                                  data-testid={`checkbox-product-${product.productId}`}
                                />
                              </TableCell>
                          {columnVisibility.thumbnail && (
                            <TableCell className="py-1 w-[50px]">
                              {(product as any).thumbnailUrl ? (
                                <img
                                  src={(product as any).thumbnailUrl}
                                  alt={product.name || product.productSku || "Product"}
                                  className="h-8 w-8 object-cover rounded"
                                  loading="lazy"
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).style.display = "none";
                                    (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden");
                                  }}
                                />
                              ) : (
                                <div className="h-8 w-8 rounded bg-muted flex items-center justify-center">
                                  <ImageIcon className="h-4 w-4 text-muted-foreground" />
                                </div>
                              )}
                            </TableCell>
                          )}
                          {columnVisibility.sku && (
                            <TableCell className="font-medium py-1 truncate whitespace-nowrap overflow-hidden">{product.productSku || "N/A"}</TableCell>
                          )}
                          {columnVisibility.articleNumber && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.articleNumber || "N/A"}</TableCell>
                          )}
                          {columnVisibility.description && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.name || "N/A"}</TableCell>
                          )}
                          {columnVisibility.brand && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.brandName || "N/A"}</TableCell>
                          )}
                          {columnVisibility.gender && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.genderName || "N/A"}</TableCell>
                          )}
                          {columnVisibility.productType && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.productTypeName || "N/A"}</TableCell>
                          )}
                          {columnVisibility.team && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.teamName || "N/A"}</TableCell>
                          )}
                          {columnVisibility.colour && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.colourName || "N/A"}</TableCell>
                          )}
                          {columnVisibility.style && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{getProductStyleName(product.productStyle)}</TableCell>
                          )}
                          {columnVisibility.composition && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.composition || "N/A"}</TableCell>
                          )}
                          {columnVisibility.countryOfManufacture && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.countryOfManufacture || "N/A"}</TableCell>
                          )}
                          {columnVisibility.commodityCode && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.commodityCode || "N/A"}</TableCell>
                          )}
                          {columnVisibility.imageCode && (
                            <TableCell className="py-1 truncate whitespace-nowrap overflow-hidden">{product.imageCode || "N/A"}</TableCell>
                          )}
                          {columnVisibility.variants && (
                            <TableCell className="py-1">
                              {product.productTypeName?.toLowerCase() === "simple" ? (
                                <Badge variant="outline" className="text-xs">Simple</Badge>
                              ) : (
                                <Badge variant="secondary" className="text-xs">{product.variantCount}</Badge>
                              )}
                            </TableCell>
                          )}
                          {columnVisibility.stock && (
                            <TableCell className="py-1">
                              <Badge 
                                className="text-xs"
                                variant={
                                  product.totalStock === 0 ? "destructive" : 
                                  product.totalStock < 10 ? "secondary" : 
                                  "default"
                                }
                              >
                                {product.totalStock}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility.attribution && (
                            <TableCell className="py-1">
                              {product.dataAttribution !== undefined ? (
                                <Badge 
                                  className="text-xs"
                                  variant={product.dataAttribution < 50 ? "destructive" : product.dataAttribution < 80 ? "secondary" : "default"}
                                >
                                  {product.dataAttribution.toFixed(0)}%
                                </Badge>
                              ) : (
                                <span className="text-muted-foreground text-xs">N/A</span>
                              )}
                            </TableCell>
                          )}
                          {columnVisibility.missingFields && (
                            <TableCell className="py-1" onClick={(e) => e.stopPropagation()}>
                              {product.missingFields && product.missingFields.trim() !== '' ? (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <div className="flex items-center gap-1 text-destructive whitespace-nowrap">
                                      <AlertCircle className="h-3 w-3" />
                                      <span className="text-xs">{product.missingFields.split(', ').length} missing</span>
                                    </div>
                                  </TooltipTrigger>
                                  <TooltipContent className="max-w-xs">
                                    <p className="font-semibold mb-1">Missing Fields:</p>
                                    <p className="text-sm">{product.missingFields}</p>
                                  </TooltipContent>
                                </Tooltip>
                              ) : (
                                <span className="text-muted-foreground text-xs">Complete</span>
                              )}
                            </TableCell>
                          )}
                          {columnVisibility.status && (
                            <TableCell className="py-1">
                              <Badge variant={product.enabled ? "default" : "secondary"} className="text-xs">
                                {product.enabled ? "Enabled" : "Disabled"}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility.groups && (
                            <TableCell className="py-1 overflow-hidden" onClick={(e) => e.stopPropagation()}>
                              {product.groups ? (
                                <div className="flex flex-nowrap gap-1 overflow-hidden">
                                  {product.groups.split(", ").map((groupName: string) => (
                                    <Badge key={groupName} variant="outline" className="text-xs whitespace-nowrap shrink-0" data-testid={`badge-group-${product.productId}`}>
                                      {groupName}
                                    </Badge>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-xs">—</span>
                              )}
                            </TableCell>
                          )}
                          {columnVisibility.sync && (
                            <TableCell className="py-1">
                              <Badge variant={product.sync ? "default" : "secondary"} className="text-xs" data-testid={`badge-sync-${product.productId}`}>
                                {product.sync ? "On" : "Off"}
                              </Badge>
                            </TableCell>
                          )}
                          {columnVisibility.createdAt && (
                            <TableCell className="text-xs text-muted-foreground py-1 whitespace-nowrap">{formatDate(product.createdAt)}</TableCell>
                          )}
                          {columnVisibility.updatedAt && (
                              <TableCell className="text-xs text-muted-foreground py-1 whitespace-nowrap">{formatDate(product.updatedAt)}</TableCell>
                          )}
                          <TableCell className="py-1 text-right overflow-visible" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1 whitespace-nowrap">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-7 w-7"
                                    onClick={() => resyncMutation.mutate(product.productId)}
                                    disabled={resyncMutation.isPending}
                                    data-testid={`button-resync-${product.productId}`}
                                  >
                                    <RefreshCw className={`h-3.5 w-3.5 ${resyncMutation.isPending ? "animate-spin" : ""}`} />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Resync to Alumio</TooltipContent>
                              </Tooltip>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-7 w-7"
                                    onClick={() => setAddImageProductId(product.productId)}
                                    data-testid={`button-add-image-${product.productId}`}
                                  >
                                    <ImageIcon className="h-3.5 w-3.5" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Add image</TooltipContent>
                              </Tooltip>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="icon"
                                    variant={copiedProductId === product.productId ? "default" : "ghost"}
                                    className="h-7 w-7"
                                    onClick={() => {
                                      setCopiedProductId(product.productId);
                                      setCopiedProductSku(product.productSku || "Unknown");
                                      toast({
                                        title: "Product copied",
                                        description: `"${product.productSku}" copied to clipboard. Use Paste to duplicate.`,
                                      });
                                    }}
                                    data-testid={`button-copy-product-${product.productId}`}
                                  >
                                    <Copy className="h-3.5 w-3.5" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Copy product</TooltipContent>
                              </Tooltip>
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs"
                                disabled={attributeDefs.length === 0}
                                onClick={() => {
                                  setAssignProductId(product.productId);
                                  setAssignTarget("product");
                                  setAssignAttributeId("");
                                  setAssignVariantId("");
                                  setAssignValue("");
                                  setAssignValueBool(false);
                                  setIsAssignAttributeOpen(true);
                                }}
                                data-testid={`button-assign-attribute-${product.productId}`}
                              >
                                Add Attribute
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                className="h-7 text-xs"
                                onClick={() => {
                                  if (window.confirm("Delete this product?")) {
                                    deleteProductsMutation.mutate([product.productId]);
                                  }
                                }}
                                data-testid={`button-delete-product-${product.productId}`}
                              >
                                Delete
                              </Button>
                            </div>
                          </TableCell>
                            </TableRow>
                          </React.Fragment>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </TooltipProvider>
            )}
            {totalPages > 0 && (
              <div className="flex items-center justify-between pt-4 px-1">
                <span className="text-sm text-muted-foreground" data-testid="text-pagination-info">
                  Showing {Math.min(page * limit + 1, totalCount)}–{Math.min((page + 1) * limit, totalCount)} of {totalCount.toLocaleString()}
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(0)}
                    disabled={page === 0}
                    data-testid="button-first-page"
                  >
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(p => Math.max(0, p - 1))}
                    disabled={page === 0}
                    data-testid="button-prev-page"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground mx-2 flex items-center gap-1" data-testid="text-page-indicator">
                    Page{" "}
                    <Input
                      type="number"
                      min={1}
                      max={totalPages}
                      value={page + 1}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (!isNaN(val) && val >= 1 && val <= totalPages) {
                          setPage(val - 1);
                        }
                      }}
                      onBlur={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (isNaN(val) || val < 1) {
                          setPage(0);
                        } else if (val > totalPages) {
                          setPage(totalPages - 1);
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          (e.target as HTMLInputElement).blur();
                        }
                      }}
                      className="h-8 w-16 text-center text-sm px-1"
                      data-testid="input-page-number"
                    />
                    {" "}of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                    disabled={page >= totalPages - 1}
                    data-testid="button-next-page"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setPage(totalPages - 1)}
                    disabled={page >= totalPages - 1}
                    data-testid="button-last-page"
                  >
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isCreateGroupDialogOpen} onOpenChange={setIsCreateGroupDialogOpen}>
        <DialogContent data-testid="dialog-create-group">
          <DialogHeader>
            <DialogTitle>Create Product Group</DialogTitle>
            <DialogDescription>
              Create a new group with {selectedProductIds.size} selected product{selectedProductIds.size !== 1 ? 's' : ''}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateGroup)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Group Name *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Enter group name"
                        data-testid="input-group-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        placeholder="Enter group description"
                        rows={3}
                        data-testid="input-group-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateGroupDialogOpen(false)}
                  data-testid="button-cancel-group"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createGroupMutation.isPending}
                  data-testid="button-submit-group"
                >
                  {createGroupMutation.isPending ? "Creating..." : "Create Group"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog
        open={isAssignAttributeOpen}
        onOpenChange={(open) => {
          setIsAssignAttributeOpen(open);
          if (!open) {
            setAssignProductId(null);
            setAssignTarget("product");
            setAssignAttributeId("");
            setAssignVariantId("");
            setAssignValue("");
            setAssignValueBool(false);
          }
        }}
      >
        <DialogContent data-testid="dialog-assign-attribute">
          <DialogHeader>
            <DialogTitle>Add Attribute</DialogTitle>
            <DialogDescription>
              Assign an additional attribute to this product or a specific variant.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <Select
                value={assignTarget}
                onValueChange={(value) => {
                  setAssignTarget(value as "product" | "variant");
                  setAssignAttributeId("");
                  setAssignVariantId("");
                  setAssignValue("");
                  setAssignValueBool(false);
                }}
              >
                <SelectTrigger data-testid="select-attribute-target">
                  <SelectValue placeholder="Target" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="product">Product</SelectItem>
                  <SelectItem value="variant">Variant</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={assignAttributeId || "none"}
                onValueChange={(value) => setAssignAttributeId(value === "none" ? "" : value)}
                disabled={availableAttributeDefs.length === 0}
              >
                <SelectTrigger data-testid="select-attribute-def">
                  <SelectValue placeholder="Select attribute" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No attribute</SelectItem>
                  {availableAttributeDefs.map((attribute: any) => (
                    <SelectItem key={attribute.attributeId} value={String(attribute.attributeId)}>
                      {attribute.label ?? attribute.code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {assignTarget === "variant" && (
                <Select
                  value={assignVariantId || "none"}
                  onValueChange={(value) => setAssignVariantId(value === "none" ? "" : value)}
                  disabled={productVariants.length === 0}
                >
                  <SelectTrigger data-testid="select-variant">
                    <SelectValue placeholder="Select variant" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No variant</SelectItem>
                    {productVariants.map((variant: any) => (
                      <SelectItem key={variant.productVariantId} value={String(variant.productVariantId)}>
                        {variant.productVariantSku}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            {selectedAttributeDef?.dataType === "boolean" ? (
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={assignValueBool}
                  onCheckedChange={(checked) => setAssignValueBool(checked === true)}
                  data-testid="checkbox-attribute-value"
                />
                <span className="text-sm">Value</span>
              </div>
            ) : selectedAttributeDef?.dataType === "json" ? (
              <Textarea
                placeholder="JSON value"
                value={assignValue}
                onChange={(event) => setAssignValue(event.target.value)}
                rows={4}
                data-testid="textarea-attribute-value"
              />
            ) : (
              <Input
                type={selectedAttributeDef?.dataType === "number" ? "number" : "text"}
                placeholder="Attribute value"
                value={assignValue}
                onChange={(event) => setAssignValue(event.target.value)}
                data-testid="input-attribute-value"
              />
            )}
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAssignAttributeOpen(false)}
              data-testid="button-cancel-assign-attribute"
            >
              Cancel
            </Button>
            <Button
              onClick={() => assignAttributeMutation.mutate()}
              disabled={
                !assignAttributeId ||
                (assignTarget === "variant" && !assignVariantId) ||
                assignAttributeMutation.isPending
              }
              data-testid="button-save-assign-attribute"
            >
              {assignAttributeMutation.isPending ? "Saving..." : "Save Attribute"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={addImageProductId !== null} onOpenChange={(open) => { if (!open) resetAddImageDialog(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Image</DialogTitle>
            <DialogDescription>Add an image to this product.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Label</Label>
              <Input
                placeholder="Image title / label"
                value={addImageLabel}
                onChange={(e) => setAddImageLabel(e.target.value)}
                data-testid="input-catalog-image-label"
              />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={addImageRole} onValueChange={setAddImageRole}>
                <SelectTrigger data-testid="select-catalog-image-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {IMAGE_ROLES.map((r) => (
                    <SelectItem key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Image URL</Label>
              <Input
                placeholder="https://example.com/image.jpg"
                value={addImageUrl}
                onChange={(e) => setAddImageUrl(e.target.value)}
                data-testid="input-catalog-image-url"
              />
            </div>
            {addImageUrl.trim() && (
              <div className="border rounded-md p-2 bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Preview</p>
                <img
                  src={addImageUrl.trim()}
                  alt="Preview"
                  className="max-h-32 rounded-md object-contain"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  data-testid="img-catalog-add-preview"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetAddImageDialog} data-testid="button-cancel-catalog-add-image">
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (addImageProductId && addImageUrl.trim()) {
                  addImageMutation.mutate({
                    productId: addImageProductId,
                    url: addImageUrl.trim(),
                    role: addImageRole,
                    label: addImageLabel.trim(),
                  });
                }
              }}
              disabled={!addImageUrl.trim() || addImageMutation.isPending}
              data-testid="button-confirm-catalog-add-image"
            >
              {addImageMutation.isPending ? "Adding..." : "Add Image"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
