import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Sword, Swords } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithDetails } from "@shared/schema_v2";

type ClubSummary = {
  clubId: number;
  name: string;
  country?: string | null;
  foundedYear?: number | null;
  productCount?: number | null;
  variantCount?: number | null;
};

type RivalryItem = {
  clubRivalryId: number | null;
  rivalClubId: number | null;
  rivalClubName: string | null;
  rivalryTypeId: number | null;
  rivalryTypeName: string | null;
  knownAs: string | null;
  intensity: number | null;
  periodStart: string | null;
  periodEnd: string | null;
  isPrimary: boolean | null;
  notes: string | null;
  rivalProductCount: number | null;
};

type RivalryResponse = {
  club: ClubSummary;
  rivals: RivalryItem[];
};

const formatPeriod = (start?: string | null, end?: string | null) => {
  if (!start && !end) return "All seasons";
  const startLabel = start ? new Date(start).getFullYear() : "—";
  const endLabel = end ? new Date(end).getFullYear() : "present";
  return `${startLabel} - ${endLabel}`;
};

const getIntensityBadge = (intensity?: number | null) => {
  if (!intensity && intensity !== 0) {
    return { label: "Unrated", variant: "secondary" as const };
  }
  if (intensity >= 8) {
    return { label: `High ${intensity}`, variant: "destructive" as const };
  }
  if (intensity >= 5) {
    return { label: `Medium ${intensity}`, variant: "default" as const };
  }
  return { label: `Low ${intensity}`, variant: "secondary" as const };
};

const formatProductLabel = (product: ProductWithDetails) => {
  const sku = product.productSku ? `#${product.productSku}` : "SKU pending";
  return `${sku} · ${product.productDescription ?? "Unnamed product"}`;
};

export default function Rivalries() {
  const { toast } = useToast();
  const [selectedClubId, setSelectedClubId] = useState<string>("");
  const [selectedRivalId, setSelectedRivalId] = useState<string>("");
  const [baseSearch, setBaseSearch] = useState("");
  const [rivalSearch, setRivalSearch] = useState("");
  const [selectedBaseProductIds, setSelectedBaseProductIds] = useState<Set<number>>(new Set());
  const [selectedRivalProductIds, setSelectedRivalProductIds] = useState<Set<number>>(new Set());
  const [newTypeCode, setNewTypeCode] = useState("");
  const [newTypeName, setNewTypeName] = useState("");
  const [newTypeDescription, setNewTypeDescription] = useState("");
  const [editingTypeId, setEditingTypeId] = useState<number | null>(null);
  const [editingTypeCode, setEditingTypeCode] = useState("");
  const [editingTypeName, setEditingTypeName] = useState("");
  const [editingTypeDescription, setEditingTypeDescription] = useState("");
  const [newRivalClubId, setNewRivalClubId] = useState("");
  const [newRivalryTypeId, setNewRivalryTypeId] = useState("");
  const [newKnownAs, setNewKnownAs] = useState("");
  const [newIntensity, setNewIntensity] = useState("");
  const [newPeriodStart, setNewPeriodStart] = useState("");
  const [newPeriodEnd, setNewPeriodEnd] = useState("");
  const [newIsPrimary, setNewIsPrimary] = useState(false);
  const [newNotes, setNewNotes] = useState("");

  const { data: clubs = [], isLoading: isLoadingClubs } = useQuery<ClubSummary[]>({
    queryKey: ["/api/clubs"],
  });

  const { data: rivalryTypes = [] } = useQuery<any[]>({
    queryKey: ["/api/rivalry-types"],
  });

  const { data: rivalryData, isLoading: isLoadingRivalries } = useQuery<RivalryResponse>({
    queryKey: ["/api/rivalries", selectedClubId],
    enabled: Boolean(selectedClubId),
  });

  useEffect(() => {
    setSelectedRivalId("");
    setSelectedBaseProductIds(new Set());
    setSelectedRivalProductIds(new Set());
    setBaseSearch("");
    setRivalSearch("");
    setNewRivalClubId("");
    setNewRivalryTypeId("");
    setNewKnownAs("");
    setNewIntensity("");
    setNewPeriodStart("");
    setNewPeriodEnd("");
    setNewIsPrimary(false);
    setNewNotes("");
  }, [selectedClubId]);

  useEffect(() => {
    if (!rivalryData?.rivals?.length) {
      setSelectedRivalId("");
      return;
    }
    const hasSelected = rivalryData.rivals.some(
      (rival) => String(rival.rivalClubId) === selectedRivalId,
    );
    if (!selectedRivalId || !hasSelected) {
      setSelectedRivalId(String(rivalryData.rivals[0].rivalClubId ?? ""));
    }
  }, [rivalryData?.rivals, selectedRivalId]);

  useEffect(() => {
    setSelectedRivalProductIds(new Set());
    setRivalSearch("");
  }, [selectedRivalId]);

  const baseClub = useMemo(
    () => clubs.find((club) => String(club.clubId) === selectedClubId),
    [clubs, selectedClubId],
  );

  const selectedRival = useMemo(
    () => rivalryData?.rivals.find((rival) => String(rival.rivalClubId) === selectedRivalId),
    [rivalryData?.rivals, selectedRivalId],
  );

  const { data: baseProductsData, isLoading: isLoadingBaseProducts } = useQuery<{
    products: ProductWithDetails[];
    count: number;
  }>({
    queryKey: ["/api/catalog/products", "rivalries", selectedClubId, baseSearch],
    enabled: Boolean(selectedClubId),
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("clubId", selectedClubId);
      params.set("limit", "100");
      if (baseSearch.trim()) params.set("search", baseSearch.trim());
      const response = await fetch(`/api/catalog/products?${params.toString()}`);
      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Failed to fetch club products");
      }
      return response.json();
    },
  });

  const { data: rivalProductsData, isLoading: isLoadingRivalProducts } = useQuery<{
    products: ProductWithDetails[];
    count: number;
  }>({
    queryKey: ["/api/catalog/products", "rivalries", selectedRivalId, rivalSearch],
    enabled: Boolean(selectedRivalId),
    queryFn: async () => {
      const params = new URLSearchParams();
      params.set("clubId", selectedRivalId);
      params.set("limit", "100");
      if (rivalSearch.trim()) params.set("search", rivalSearch.trim());
      const response = await fetch(`/api/catalog/products?${params.toString()}`);
      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Failed to fetch rival products");
      }
      return response.json();
    },
  });

  const baseProducts = baseProductsData?.products ?? [];
  const rivalProducts = rivalProductsData?.products ?? [];

  const createBundleMutation = useMutation({
    mutationFn: async () => {
      const baseName = baseClub?.name?.trim();
      const rivalName = selectedRival?.rivalClubName?.trim();
      if (!baseName || !rivalName) {
        throw new Error("Select both clubs to create a bundle.");
      }
      if (selectedBaseProductIds.size === 0 || selectedRivalProductIds.size === 0) {
        throw new Error("Select at least one product from each club.");
      }
      const productIds = [
        ...Array.from(selectedBaseProductIds),
        ...Array.from(selectedRivalProductIds),
      ];
      const description = `Rivalry bundle linking ${baseName} and ${rivalName}.`;
      await apiRequest("POST", "/api/groups", {
        name: `${baseName} vs ${rivalName}`,
        description,
        productIds,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      toast({
        title: "Rivalry bundle created",
        description: "The linked products are now grouped together.",
      });
      setSelectedBaseProductIds(new Set());
      setSelectedRivalProductIds(new Set());
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Unable to create bundle",
        description: error.message || "Please try again.",
      });
    },
  });

  const createRivalryTypeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/rivalry-types", {
        code: newTypeCode.trim(),
        name: newTypeName.trim(),
        description: newTypeDescription.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Rivalry type created", description: "The new type is ready to use." });
      setNewTypeCode("");
      setNewTypeName("");
      setNewTypeDescription("");
      queryClient.invalidateQueries({ queryKey: ["/api/rivalry-types"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Unable to create rivalry type",
        description: error.message || "Please try again.",
      });
    },
  });

  const updateRivalryTypeMutation = useMutation({
    mutationFn: async () => {
      if (!editingTypeId) {
        throw new Error("Select a rivalry type to update.");
      }
      const response = await apiRequest("PUT", `/api/rivalry-types/${editingTypeId}`, {
        code: editingTypeCode.trim(),
        name: editingTypeName.trim(),
        description: editingTypeDescription.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Rivalry type updated", description: "The rivalry type was saved." });
      setEditingTypeId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/rivalry-types"] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Unable to update rivalry type",
        description: error.message || "Please try again.",
      });
    },
  });

  const createRivalryMutation = useMutation({
    mutationFn: async () => {
      if (!selectedClubId) {
        throw new Error("Select a club first.");
      }
      if (!newRivalClubId) {
        throw new Error("Select a rival club.");
      }
      if (!newRivalryTypeId) {
        throw new Error("Select a rivalry type.");
      }
      const response = await apiRequest("POST", "/api/club-rivalries", {
        clubIdA: Number(selectedClubId),
        clubIdB: Number(newRivalClubId),
        rivalryTypeId: Number(newRivalryTypeId),
        knownAs: newKnownAs.trim() || null,
        intensity: newIntensity.trim() === "" ? null : Number(newIntensity),
        periodStart: newPeriodStart || null,
        periodEnd: newPeriodEnd || null,
        isPrimary: newIsPrimary,
        notes: newNotes.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Rivalry added",
        description: "The new rivalry is now available.",
      });
      setNewRivalClubId("");
      setNewRivalryTypeId("");
      setNewKnownAs("");
      setNewIntensity("");
      setNewPeriodStart("");
      setNewPeriodEnd("");
      setNewIsPrimary(false);
      setNewNotes("");
      queryClient.invalidateQueries({ queryKey: ["/api/rivalries", selectedClubId] });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Unable to add rivalry",
        description: error.message || "Please try again.",
      });
    },
  });

  const startEditingType = (type: any) => {
    setEditingTypeId(type.rivalryTypeId);
    setEditingTypeCode(type.code ?? "");
    setEditingTypeName(type.name ?? "");
    setEditingTypeDescription(type.description ?? "");
  };

  const toggleSelection = (setFn: React.Dispatch<React.SetStateAction<Set<number>>>, productId: number) => {
    setFn((prev) => {
      const next = new Set(prev);
      if (next.has(productId)) {
        next.delete(productId);
      } else {
        next.add(productId);
      }
      return next;
    });
  };

  const clearSelections = () => {
    setSelectedBaseProductIds(new Set());
    setSelectedRivalProductIds(new Set());
  };

  const totalSelected = selectedBaseProductIds.size + selectedRivalProductIds.size;
  const rivals = rivalryData?.rivals ?? [];
  const availableRivalClubs = clubs.filter((club) => String(club.clubId) !== selectedClubId);

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-rivalries">
            Rivalries
          </h1>
          <p className="text-muted-foreground mt-1">
            Connect products across club rivalries to power head-to-head merchandising.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Swords className="h-5 w-5" />
                Select a club
              </CardTitle>
              <CardDescription>Choose a club to explore its rivalry network.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Select value={selectedClubId} onValueChange={setSelectedClubId} disabled={isLoadingClubs}>
                  <SelectTrigger data-testid="select-rivalry-club">
                    <SelectValue placeholder={isLoadingClubs ? "Loading clubs..." : "Select club"} />
                  </SelectTrigger>
                  <SelectContent>
                    {clubs.map((club) => (
                      <SelectItem key={club.clubId} value={String(club.clubId)}>
                        {club.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {baseClub ? (
                <div className="rounded-lg border border-border/60 bg-muted/40 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Selected club</p>
                      <p className="text-lg font-semibold">{baseClub.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {baseClub.country ?? "Country unknown"} · Founded {baseClub.foundedYear ?? "—"}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary">{rivals.length} rivalries</Badge>
                      <p className="text-xs text-muted-foreground mt-2">
                        {baseClub.productCount ?? 0} products · {baseClub.variantCount ?? 0} variants
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-muted p-4 text-sm text-muted-foreground">
                  Select a club to unlock rivalry insights and product pairing tools.
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Sword className="h-5 w-5" />
                Rivalry overview
              </CardTitle>
              <CardDescription>At-a-glance details for the selected club.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {selectedClubId ? (
                <>
                  <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card px-4 py-3">
                    <div>
                      <p className="text-sm font-medium">Active rivalries</p>
                      <p className="text-xs text-muted-foreground">Includes historic and current ties</p>
                    </div>
                    <Badge variant="default">{rivals.length}</Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card px-4 py-3">
                    <div>
                      <p className="text-sm font-medium">Primary rivalries</p>
                      <p className="text-xs text-muted-foreground">Flagged as top rivalries</p>
                    </div>
                    <Badge variant="secondary">
                      {rivals.filter((rival) => rival.isPrimary).length}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border border-border/60 bg-card px-4 py-3">
                    <div>
                      <p className="text-sm font-medium">Rival products</p>
                      <p className="text-xs text-muted-foreground">Total products across rivals</p>
                    </div>
                    <Badge variant="secondary">
                      {rivals.reduce((sum, rival) => sum + (rival.rivalProductCount ?? 0), 0)}
                    </Badge>
                  </div>
                </>
              ) : (
                <div className="rounded-lg border border-dashed border-muted p-4 text-sm text-muted-foreground">
                  Select a club to see rivalry coverage metrics.
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Rivalry map</CardTitle>
            <CardDescription>Review each rivalry and jump into bundle building.</CardDescription>
          </CardHeader>
          <CardContent>
            {!selectedClubId ? (
              <div className="text-sm text-muted-foreground">
                Pick a club to see its rivalry map.
              </div>
            ) : isLoadingRivalries ? (
              <div className="text-sm text-muted-foreground">Loading rivalries...</div>
            ) : rivals.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                No rivalries found for this club yet.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rival club</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Known as</TableHead>
                    <TableHead>Intensity</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Products</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rivals.map((rival) => {
                    const badge = getIntensityBadge(rival.intensity);
                    return (
                      <TableRow key={`${rival.clubRivalryId}-${rival.rivalClubId}`}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {rival.rivalClubName ?? "Unknown club"}
                            {rival.isPrimary ? <Badge variant="default">Primary</Badge> : null}
                          </div>
                        </TableCell>
                        <TableCell>{rival.rivalryTypeName ?? "—"}</TableCell>
                        <TableCell>{rival.knownAs ?? "—"}</TableCell>
                        <TableCell>
                          <Badge variant={badge.variant}>{badge.label}</Badge>
                        </TableCell>
                        <TableCell>{formatPeriod(rival.periodStart, rival.periodEnd)}</TableCell>
                        <TableCell>{rival.rivalProductCount ?? 0}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedRivalId(String(rival.rivalClubId ?? ""))}
                          >
                            Build bundle
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Add a rivalry</CardTitle>
            <CardDescription>Link a rival club to the selected team.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!selectedClubId ? (
              <div className="text-sm text-muted-foreground">
                Select a club above to add a rivalry.
              </div>
            ) : (
              <>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Rival club</label>
                    <Select value={newRivalClubId} onValueChange={setNewRivalClubId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select rival club" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableRivalClubs.map((club) => (
                          <SelectItem key={club.clubId} value={String(club.clubId)}>
                            {club.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Rivalry type</label>
                    <Select value={newRivalryTypeId} onValueChange={setNewRivalryTypeId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        {rivalryTypes.map((type) => (
                          <SelectItem key={type.rivalryTypeId} value={String(type.rivalryTypeId)}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Known as</label>
                    <Input
                      value={newKnownAs}
                      onChange={(event) => setNewKnownAs(event.target.value)}
                      placeholder="North London derby"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Intensity</label>
                    <Input
                      type="number"
                      value={newIntensity}
                      onChange={(event) => setNewIntensity(event.target.value)}
                      placeholder="0-10"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Period start</label>
                    <Input
                      type="date"
                      value={newPeriodStart}
                      onChange={(event) => setNewPeriodStart(event.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Period end</label>
                    <Input
                      type="date"
                      value={newPeriodEnd}
                      onChange={(event) => setNewPeriodEnd(event.target.value)}
                    />
                  </div>
                  <div className="flex items-end gap-3">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={newIsPrimary}
                        onCheckedChange={(checked) => setNewIsPrimary(Boolean(checked))}
                      />
                      <span className="text-sm">Primary rivalry</span>
                    </div>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <label className="text-sm font-medium">Notes</label>
                    <Input
                      value={newNotes}
                      onChange={(event) => setNewNotes(event.target.value)}
                      placeholder="Optional notes about the rivalry"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2">
                  <Button
                    onClick={() => createRivalryMutation.mutate()}
                    disabled={createRivalryMutation.isPending}
                  >
                    {createRivalryMutation.isPending ? "Adding..." : "Add rivalry"}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Rivalry bundle builder</CardTitle>
            <CardDescription>
              Select products from both clubs to create a linked rivalry group.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Primary club</label>
                <div className="rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-sm">
                  {baseClub?.name ?? "Select a club above"}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Rival club</label>
                <Select
                  value={selectedRivalId}
                  onValueChange={setSelectedRivalId}
                  disabled={!selectedClubId || rivals.length === 0}
                >
                  <SelectTrigger data-testid="select-rival-club">
                    <SelectValue placeholder={rivals.length ? "Select rival" : "No rivals yet"} />
                  </SelectTrigger>
                  <SelectContent>
                    {rivals.map((rival) => (
                      <SelectItem key={rival.rivalClubId} value={String(rival.rivalClubId)}>
                        {rival.rivalClubName ?? "Unknown club"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {!selectedClubId || !selectedRivalId ? (
              <div className="rounded-lg border border-dashed border-muted p-4 text-sm text-muted-foreground">
                Select both clubs to start pairing products.
              </div>
            ) : (
              <>
                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold">{baseClub?.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {selectedBaseProductIds.size} selected · {baseProducts.length} loaded
                        </p>
                      </div>
                      <Input
                        value={baseSearch}
                        onChange={(event) => setBaseSearch(event.target.value)}
                        placeholder="Search products"
                        className="w-48"
                      />
                    </div>
                    <div className="rounded-lg border border-border/60">
                      <ScrollArea className="h-72">
                        <Table>
                          <TableBody>
                            {isLoadingBaseProducts ? (
                              <TableRow>
                                <TableCell className="text-sm text-muted-foreground">
                                  Loading products...
                                </TableCell>
                              </TableRow>
                            ) : baseProducts.length === 0 ? (
                              <TableRow>
                                <TableCell className="text-sm text-muted-foreground">
                                  No products found for this club.
                                </TableCell>
                              </TableRow>
                            ) : (
                              baseProducts.map((product) => (
                                <TableRow key={product.productId}>
                                  <TableCell>
                                    <div className="flex items-center gap-3">
                                      <Checkbox
                                        checked={selectedBaseProductIds.has(product.productId)}
                                        onCheckedChange={() =>
                                          toggleSelection(setSelectedBaseProductIds, product.productId)
                                        }
                                      />
                                      <span className="text-sm">{formatProductLabel(product)}</span>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold">{selectedRival?.rivalClubName ?? "Rival club"}</p>
                        <p className="text-xs text-muted-foreground">
                          {selectedRivalProductIds.size} selected · {rivalProducts.length} loaded
                        </p>
                      </div>
                      <Input
                        value={rivalSearch}
                        onChange={(event) => setRivalSearch(event.target.value)}
                        placeholder="Search products"
                        className="w-48"
                      />
                    </div>
                    <div className="rounded-lg border border-border/60">
                      <ScrollArea className="h-72">
                        <Table>
                          <TableBody>
                            {isLoadingRivalProducts ? (
                              <TableRow>
                                <TableCell className="text-sm text-muted-foreground">
                                  Loading products...
                                </TableCell>
                              </TableRow>
                            ) : rivalProducts.length === 0 ? (
                              <TableRow>
                                <TableCell className="text-sm text-muted-foreground">
                                  No products found for this rival club.
                                </TableCell>
                              </TableRow>
                            ) : (
                              rivalProducts.map((product) => (
                                <TableRow key={product.productId}>
                                  <TableCell>
                                    <div className="flex items-center gap-3">
                                      <Checkbox
                                        checked={selectedRivalProductIds.has(product.productId)}
                                        onCheckedChange={() =>
                                          toggleSelection(setSelectedRivalProductIds, product.productId)
                                        }
                                      />
                                      <span className="text-sm">{formatProductLabel(product)}</span>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border/60 bg-muted/30 px-4 py-3">
                  <p className="text-sm text-muted-foreground">
                    {totalSelected} products selected across both clubs.
                  </p>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" onClick={clearSelections} disabled={totalSelected === 0}>
                      Clear selection
                    </Button>
                    <Button
                      onClick={() => createBundleMutation.mutate()}
                      disabled={
                        selectedBaseProductIds.size === 0 ||
                        selectedRivalProductIds.size === 0 ||
                        createBundleMutation.isPending
                      }
                    >
                      {createBundleMutation.isPending ? "Creating..." : "Create rivalry bundle"}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Rivalry types</CardTitle>
            <CardDescription>Define the labels used to categorize rivalries.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-[160px_1fr_1fr_auto]">
              <Input
                value={newTypeCode}
                onChange={(event) => setNewTypeCode(event.target.value)}
                placeholder="Code"
              />
              <Input
                value={newTypeName}
                onChange={(event) => setNewTypeName(event.target.value)}
                placeholder="Type name"
              />
              <Input
                value={newTypeDescription}
                onChange={(event) => setNewTypeDescription(event.target.value)}
                placeholder="Description"
              />
              <Button
                onClick={() => createRivalryTypeMutation.mutate()}
                disabled={createRivalryTypeMutation.isPending}
              >
                {createRivalryTypeMutation.isPending ? "Adding..." : "Add type"}
              </Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rivalryTypes.length === 0 ? (
                  <TableRow>
                    <TableCell className="text-sm text-muted-foreground" colSpan={4}>
                      No rivalry types yet.
                    </TableCell>
                  </TableRow>
                ) : (
                  rivalryTypes.map((type) => (
                    <TableRow key={type.rivalryTypeId}>
                      <TableCell>
                        {editingTypeId === type.rivalryTypeId ? (
                          <Input
                            value={editingTypeCode}
                            onChange={(event) => setEditingTypeCode(event.target.value)}
                          />
                        ) : (
                          type.code
                        )}
                      </TableCell>
                      <TableCell>
                        {editingTypeId === type.rivalryTypeId ? (
                          <Input
                            value={editingTypeName}
                            onChange={(event) => setEditingTypeName(event.target.value)}
                          />
                        ) : (
                          type.name
                        )}
                      </TableCell>
                      <TableCell>
                        {editingTypeId === type.rivalryTypeId ? (
                          <Input
                            value={editingTypeDescription}
                            onChange={(event) => setEditingTypeDescription(event.target.value)}
                          />
                        ) : (
                          type.description ?? "—"
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        {editingTypeId === type.rivalryTypeId ? (
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              onClick={() => updateRivalryTypeMutation.mutate()}
                              disabled={updateRivalryTypeMutation.isPending}
                            >
                              Save
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditingTypeId(null)}
                            >
                              Cancel
                            </Button>
                          </div>
                        ) : (
                          <Button size="sm" variant="outline" onClick={() => startEditingType(type)}>
                            Edit
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
