import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CalendarClock,
  Plus,
  Trash2,
  ArrowLeft,
  Search,
  Ban,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithDetails } from "@shared/schema_v2";
import { Skeleton } from "@/components/ui/skeleton";

interface ScheduledChangeRow {
  id: number;
  name: string;
  description: string | null;
  scheduledAt: string;
  endsAt: string | null;
  status: string;
  scopeType: string;
  scopeGroupId: number | null;
  createdBy: number | null;
  createdAt: string;
  appliedAt: string | null;
  revertedAt: string | null;
  errorMessage: string | null;
  creatorName: string | null;
  groupName: string | null;
  itemCount: number;
}

interface ScheduledChangeItemRow {
  id: number;
  scheduledChangeId: number;
  productId: number | null;
  variantId: number | null;
  entityType: string;
  fieldName: string;
  newValue: string | null;
  oldValue: string | null;
  changeMode: string | null;
  status: string;
  errorMessage: string | null;
  productSku: string | null;
  productDescription: string | null;
}

interface ScheduledChangeDetail extends ScheduledChangeRow {
  items: ScheduledChangeItemRow[];
  updatedAt: string | null;
}

interface CurrencyOption {
  currencyId: number;
  code: string;
  name: string;
  symbol: string;
}

interface PerProductValue {
  productId: number;
  value: string;
}

interface FieldChangeEntry {
  entityType: string;
  fieldName: string;
  mode: "all" | "per-product";
  changeMode: "absolute" | "percentage";
  globalValue: string;
  perProductValues: PerProductValue[];
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  applied: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  reverted: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  cancelled: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300",
  failed: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  error: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const PRODUCT_FIELDS = [
  { value: "productDescription", label: "Description", entityType: "product", inputType: "text" },
  { value: "enabled", label: "Enabled", entityType: "product", inputType: "boolean" },
  { value: "sync", label: "Sync to Magento", entityType: "product", inputType: "boolean" },
  { value: "productStyle", label: "Style", entityType: "product", inputType: "text" },
  { value: "composition", label: "Composition", entityType: "product", inputType: "text" },
  { value: "countryOfManufacture", label: "Country of Manufacture", entityType: "product", inputType: "text" },
  { value: "commodityCode", label: "Commodity Code", entityType: "product", inputType: "text" },
  { value: "imageCode", label: "Image Code", entityType: "product", inputType: "text" },
  { value: "articleNumber", label: "Article Number", entityType: "product", inputType: "text" },
];

function getFieldLabel(fieldName: string, currencies: CurrencyOption[]): string {
  const pf = PRODUCT_FIELDS.find((f) => f.value === fieldName);
  if (pf) return pf.label;
  if (fieldName === "add_to_group") return "Add to Group";
  if (fieldName.startsWith("retailPrice_")) {
    const code = fieldName.replace("retailPrice_", "");
    const cur = currencies.find((c) => c.code === code);
    return `Retail Price (${cur?.symbol || code})`;
  }
  if (fieldName.startsWith("specialRetailPrice_")) {
    const code = fieldName.replace("specialRetailPrice_", "");
    const cur = currencies.find((c) => c.code === code);
    return `Special Price (${cur?.symbol || code})`;
  }
  return fieldName;
}

function formatPriceValue(value: string | null): string {
  if (!value) return "-";
  try {
    const parsed = JSON.parse(value);
    if (typeof parsed === "object" && parsed !== null) {
      const prices = Object.values(parsed).filter((v) => v !== null) as string[];
      if (prices.length === 0) return "-";
      const unique = [...new Set(prices)];
      if (unique.length === 1) return unique[0];
      return unique.join(", ");
    }
  } catch {
    // not JSON
  }
  return value;
}

function StatusBadge({ status }: { status: string }) {
  return (
    <Badge
      className={`${STATUS_COLORS[status] || "bg-gray-100 text-gray-800"} border-0 font-medium capitalize`}
      data-testid={`badge-status-${status}`}
    >
      {status}
    </Badge>
  );
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return "-";
  return new Date(dateStr).toLocaleString();
}

export default function ScheduledChanges() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("");
  const { toast } = useToast();

  const { data: changes = [], isLoading } = useQuery<ScheduledChangeRow[]>({
    queryKey: ["/api/scheduled-changes"],
  });

  const filteredChanges = statusFilter
    ? changes.filter((c) => c.status === statusFilter)
    : changes;

  if (selectedId) {
    return (
      <ScheduledChangeDetailView
        id={selectedId}
        onBack={() => setSelectedId(null)}
      />
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <CalendarClock className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold" data-testid="text-page-title">
            Scheduled Changes
          </h1>
        </div>
        <Button
          onClick={() => setIsCreateOpen(true)}
          data-testid="button-create-scheduled-change"
        >
          <Plus className="h-4 w-4 mr-2" />
          Schedule Change
        </Button>
      </div>

      <div className="flex items-center gap-3">
        <Select value={statusFilter || "all"} onValueChange={(v) => setStatusFilter(v === "all" ? "" : v)}>
          <SelectTrigger className="w-48" data-testid="select-status-filter">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="applied">Applied</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : filteredChanges.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <CalendarClock className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="text-lg font-medium">No scheduled changes</p>
              <p className="text-sm mt-1">Create one to schedule future product updates</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Scheduled For</TableHead>
                  <TableHead>Scope</TableHead>
                  <TableHead>Changes</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredChanges.map((change) => (
                  <ScheduledChangeTableRow
                    key={change.id}
                    change={change}
                    onSelect={() => setSelectedId(change.id)}
                  />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <CreateScheduledChangeDialog
        open={isCreateOpen}
        onOpenChange={setIsCreateOpen}
      />
    </div>
  );
}

function ScheduledChangeTableRow({
  change,
  onSelect,
}: {
  change: ScheduledChangeRow;
  onSelect: () => void;
}) {
  const { toast } = useToast();

  const cancelMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/scheduled-changes/${change.id}/cancel`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-changes"] });
      toast({ title: "Scheduled change cancelled" });
    },
    onError: (error: any) => {
      toast({ title: "Failed to cancel", description: error.message, variant: "destructive" });
    },
  });

  return (
    <TableRow
      className="cursor-pointer hover:bg-muted/50"
      data-testid={`row-scheduled-change-${change.id}`}
    >
      <TableCell onClick={onSelect}>
        <div>
          <span className="font-medium" data-testid={`text-name-${change.id}`}>
            {change.name}
          </span>
          {change.description && (
            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
              {change.description}
            </p>
          )}
        </div>
      </TableCell>
      <TableCell onClick={onSelect}>
        <StatusBadge status={change.status} />
      </TableCell>
      <TableCell onClick={onSelect} data-testid={`text-scheduled-at-${change.id}`}>
        {formatDate(change.scheduledAt)}
        {change.endsAt && (
          <span className="text-xs text-muted-foreground block">
            until {formatDate(change.endsAt)}
          </span>
        )}
        {change.revertedAt && (
          <span className="text-xs text-blue-600 dark:text-blue-400 block">
            reverted {formatDate(change.revertedAt)}
          </span>
        )}
      </TableCell>
      <TableCell onClick={onSelect}>
        <span className="capitalize" data-testid={`text-scope-${change.id}`}>
          {change.scopeType === "add_to_group" && change.groupName
            ? `Add to: ${change.groupName}`
            : change.scopeType === "group" && change.groupName
              ? `Group: ${change.groupName}`
              : "Products"}
        </span>
      </TableCell>
      <TableCell onClick={onSelect} data-testid={`text-item-count-${change.id}`}>
        {change.itemCount}
      </TableCell>
      <TableCell onClick={onSelect} data-testid={`text-creator-${change.id}`}>
        {change.creatorName || "-"}
      </TableCell>
      <TableCell>
        {change.status === "pending" && (
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              cancelMutation.mutate();
            }}
            disabled={cancelMutation.isPending}
            data-testid={`button-cancel-${change.id}`}
          >
            <Ban className="h-4 w-4" />
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
}

function ScheduledChangeDetailView({
  id,
  onBack,
}: {
  id: number;
  onBack: () => void;
}) {
  const { toast } = useToast();
  const { data: currencies = [] } = useQuery<CurrencyOption[]>({
    queryKey: ["/api/currencies"],
  });

  const { data: change, isLoading } = useQuery<ScheduledChangeDetail>({
    queryKey: ["/api/scheduled-changes", id],
  });

  const cancelMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/scheduled-changes/${id}/cancel`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-changes"] });
      toast({ title: "Scheduled change cancelled" });
      onBack();
    },
    onError: (error: any) => {
      toast({ title: "Failed to cancel", description: error.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (!change) {
    return (
      <div className="p-6">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <p className="mt-4 text-muted-foreground">Scheduled change not found</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack} data-testid="button-back">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold" data-testid="text-detail-name">
              {change.name}
            </h1>
            <StatusBadge status={change.status} />
          </div>
          {change.description && (
            <p className="text-sm text-muted-foreground mt-1">{change.description}</p>
          )}
        </div>
        {change.status === "pending" && (
          <Button
            variant="outline"
            onClick={() => cancelMutation.mutate()}
            disabled={cancelMutation.isPending}
            data-testid="button-cancel-change"
          >
            <Ban className="h-4 w-4 mr-2" />
            Cancel
          </Button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Scheduled For</p>
            <p className="font-medium mt-1" data-testid="text-detail-scheduled-at">
              {formatDate(change.scheduledAt)}
            </p>
          </CardContent>
        </Card>
        {change.endsAt && (
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Auto-Reverts At</p>
              <p className="font-medium mt-1" data-testid="text-detail-ends-at">
                {formatDate(change.endsAt)}
              </p>
              {change.revertedAt && (
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1" data-testid="text-detail-reverted-at">
                  Reverted {formatDate(change.revertedAt)}
                </p>
              )}
            </CardContent>
          </Card>
        )}
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Scope</p>
            <p className="font-medium mt-1 capitalize" data-testid="text-detail-scope">
              {change.scopeType === "add_to_group" && change.groupName
                ? `Add to Group: ${change.groupName}`
                : change.scopeType === "group" && change.groupName
                  ? `Group: ${change.groupName}`
                  : "Individual Products"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Created By</p>
            <p className="font-medium mt-1" data-testid="text-detail-creator">
              {change.creatorName || "-"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">
              {change.status === "reverted" ? "Reverted At" : change.status === "applied" ? "Applied At" : "Created At"}
            </p>
            <p className="font-medium mt-1" data-testid="text-detail-date">
              {formatDate(change.status === "reverted" ? change.revertedAt : change.status === "applied" ? change.appliedAt : change.createdAt)}
            </p>
          </CardContent>
        </Card>
      </div>

      {change.errorMessage && (
        <Card className="border-destructive">
          <CardContent className="p-4">
            <p className="text-sm font-medium text-destructive">Error</p>
            <p className="text-sm text-muted-foreground mt-1">{change.errorMessage}</p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Change Items ({change.items.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Field</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Change</TableHead>
                <TableHead>New Value</TableHead>
                <TableHead>Old Value</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Error</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {change.items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    No change items
                  </TableCell>
                </TableRow>
              ) : (
                change.items.map((item) => {
                  const fieldLabel = item.entityType === "group_membership"
                    ? "Group Membership"
                    : getFieldLabel(item.fieldName, currencies);

                  const isPending = item.status === "pending";
                  const isPercentage = item.changeMode === "percentage";

                  let changeDescription: string;
                  if (item.entityType === "group_membership") {
                    changeDescription = item.newValue ? `End: ${new Date(item.newValue).toLocaleString()}` : "Add (no end date)";
                  } else if (isPercentage) {
                    if (isPending) {
                      changeDescription = `${item.newValue}% off retail`;
                    } else {
                      changeDescription = "% off retail";
                    }
                  } else {
                    changeDescription = "Set value";
                  }

                  let displayNewValue: string;
                  if (item.entityType === "group_membership") {
                    displayNewValue = "-";
                  } else if (isPercentage && isPending) {
                    displayNewValue = "Calculated on apply";
                  } else {
                    displayNewValue = formatPriceValue(item.newValue);
                  }

                  return (
                    <TableRow key={item.id} data-testid={`row-item-${item.id}`}>
                      <TableCell className="font-medium" data-testid={`text-item-field-${item.id}`}>
                        {fieldLabel}
                      </TableCell>
                      <TableCell>
                        {item.productSku ? (
                          <div>
                            <span className="font-medium" data-testid={`text-item-sku-${item.id}`}>{item.productSku}</span>
                            {item.productDescription && (
                              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.productDescription}</p>
                            )}
                          </div>
                        ) : (
                          <span className="text-muted-foreground">All in scope</span>
                        )}
                      </TableCell>
                      <TableCell className="text-sm" data-testid={`text-item-change-${item.id}`}>
                        {changeDescription}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate" data-testid={`text-item-new-value-${item.id}`}>
                        {displayNewValue}
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate">{formatPriceValue(item.oldValue)}</TableCell>
                      <TableCell>
                        <StatusBadge status={item.status} />
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate text-xs text-destructive">
                        {item.errorMessage || ""}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function CreateScheduledChangeDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [changeType, setChangeType] = useState<"field_changes" | "add_to_group">("field_changes");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [scopeType, setScopeType] = useState<string>("products");
  const [scopeGroupId, setScopeGroupId] = useState<number | null>(null);
  const [selectedProductIds, setSelectedProductIds] = useState<Set<number>>(new Set());
  const [productSearch, setProductSearch] = useState("");
  const [fieldChanges, setFieldChanges] = useState<FieldChangeEntry[]>([]);
  const [expandedFields, setExpandedFields] = useState<Set<number>>(new Set());
  const [targetGroupId, setTargetGroupId] = useState<number | null>(null);
  const [membershipEndDate, setMembershipEndDate] = useState("");

  const { data: productsData } = useQuery<{ products: ProductWithDetails[]; count: number }>({
    queryKey: ["/api/catalog/products"],
    enabled: open,
  });
  const products = Array.isArray(productsData?.products) ? productsData.products : [];

  const { data: groups = [] } = useQuery<any[]>({
    queryKey: ["/api/groups"],
    enabled: open && (scopeType === "group" || changeType === "add_to_group"),
  });

  const { data: currencies = [] } = useQuery<CurrencyOption[]>({
    queryKey: ["/api/currencies"],
    enabled: open,
  });

  const selectedProducts = products.filter((p) => selectedProductIds.has(p.productId));

  const filteredProducts = productSearch
    ? products.filter(
        (p) =>
          p.productSku?.toLowerCase().includes(productSearch.toLowerCase()) ||
          p.productDescription?.toLowerCase().includes(productSearch.toLowerCase()) ||
          p.brandName?.toLowerCase().includes(productSearch.toLowerCase()),
      )
    : products;

  const allFields = [
    ...PRODUCT_FIELDS,
    ...currencies.map((c) => ({
      value: `retailPrice_${c.code}`,
      label: `Retail Price (${c.symbol || c.code})`,
      entityType: "variant_price",
      inputType: "number" as const,
    })),
    ...currencies.map((c) => ({
      value: `specialRetailPrice_${c.code}`,
      label: `Special Price (${c.symbol || c.code})`,
      entityType: "variant_price",
      inputType: "number" as const,
    })),
  ];

  useEffect(() => {
    if (fieldChanges.length === 0) return;
    const pids = Array.from(selectedProductIds);
    setFieldChanges((prev) =>
      prev.map((fc) => {
        const existing = new Map(fc.perProductValues.map((pv) => [pv.productId, pv.value]));
        const synced = pids.map((pid) => ({
          productId: pid,
          value: existing.get(pid) ?? "",
        }));
        return { ...fc, perProductValues: synced };
      }),
    );
  }, [selectedProductIds]);

  const createMutation = useMutation({
    mutationFn: async () => {
      if (changeType === "add_to_group") {
        const productIds = Array.from(selectedProductIds);
        const items = productIds.map((pid) => ({
          entityType: "group_membership",
          fieldName: "add_to_group",
          newValue: membershipEndDate ? new Date(membershipEndDate).toISOString() : null,
          productId: pid,
        }));

        await apiRequest("POST", "/api/scheduled-changes", {
          name,
          description: description || null,
          scheduledAt,
          endsAt: endsAt || null,
          scopeType: "add_to_group",
          scopeGroupId: targetGroupId,
          productIds,
          items,
        });
        return;
      }

      const items: Array<{
        entityType: string;
        fieldName: string;
        newValue: string | null;
        changeMode?: string;
        productId?: number;
      }> = [];

      const targetProductIds =
        scopeType === "products" ? Array.from(selectedProductIds) : [];

      for (const fc of fieldChanges) {
        if (!fc.fieldName) continue;

        const isPriceField = fc.entityType === "variant_price";

        if (fc.mode === "all") {
          items.push({
            entityType: fc.entityType,
            fieldName: fc.fieldName,
            newValue: fc.globalValue || null,
            ...(isPriceField && fc.changeMode !== "absolute" ? { changeMode: fc.changeMode } : {}),
          });
        } else {
          for (const ppv of fc.perProductValues) {
            if (ppv.value !== "" && selectedProductIds.has(ppv.productId)) {
              items.push({
                entityType: fc.entityType,
                fieldName: fc.fieldName,
                newValue: ppv.value || null,
                productId: ppv.productId,
                ...(isPriceField && fc.changeMode !== "absolute" ? { changeMode: fc.changeMode } : {}),
              });
            }
          }
        }
      }

      await apiRequest("POST", "/api/scheduled-changes", {
        name,
        description: description || null,
        scheduledAt,
        endsAt: endsAt || null,
        scopeType,
        scopeGroupId: scopeType === "group" ? scopeGroupId : null,
        productIds: targetProductIds,
        items,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scheduled-changes"] });
      toast({ title: "Scheduled change created" });
      resetAndClose();
    },
    onError: (error: any) => {
      toast({ title: "Failed to create", description: error.message, variant: "destructive" });
    },
  });

  function resetAndClose() {
    setStep(1);
    setChangeType("field_changes");
    setName("");
    setDescription("");
    setScheduledAt("");
    setEndsAt("");
    setScopeType("products");
    setScopeGroupId(null);
    setSelectedProductIds(new Set());
    setProductSearch("");
    setFieldChanges([]);
    setExpandedFields(new Set());
    setTargetGroupId(null);
    setMembershipEndDate("");
    onOpenChange(false);
  }

  function addFieldChange() {
    const pids = Array.from(selectedProductIds);
    setFieldChanges([
      ...fieldChanges,
      {
        entityType: "product",
        fieldName: "",
        mode: "all",
        changeMode: "absolute",
        globalValue: "",
        perProductValues: pids.map((pid) => ({ productId: pid, value: "" })),
      },
    ]);
  }

  function removeFieldChange(index: number) {
    setFieldChanges(fieldChanges.filter((_, i) => i !== index));
    setExpandedFields((prev) => {
      const next = new Set<number>();
      prev.forEach((v) => {
        if (v < index) next.add(v);
        else if (v > index) next.add(v - 1);
      });
      return next;
    });
  }

  function updateFieldEntry(index: number, updates: Partial<FieldChangeEntry>) {
    setFieldChanges((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], ...updates };
      return next;
    });
  }

  function updatePerProductValue(fieldIndex: number, productId: number, value: string) {
    setFieldChanges((prev) => {
      const next = [...prev];
      const ppvs = [...next[fieldIndex].perProductValues];
      const pvIdx = ppvs.findIndex((p) => p.productId === productId);
      if (pvIdx >= 0) {
        ppvs[pvIdx] = { ...ppvs[pvIdx], value };
      }
      next[fieldIndex] = { ...next[fieldIndex], perProductValues: ppvs };
      return next;
    });
  }

  function toggleExpanded(index: number) {
    setExpandedFields((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  }

  const canProceedStep1 = name.trim() && scheduledAt;
  const canProceedStep2 =
    changeType === "add_to_group"
      ? selectedProductIds.size > 0
      : scopeType === "group"
        ? scopeGroupId !== null
        : selectedProductIds.size > 0;
  const canSubmit =
    changeType === "add_to_group"
      ? targetGroupId !== null && selectedProductIds.size > 0
      : fieldChanges.some((fc) => fc.fieldName);

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? onOpenChange(v) : resetAndClose())}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle data-testid="text-dialog-title">
            Schedule a Change — Step {step} of 3
          </DialogTitle>
          <DialogDescription>
            {step === 1 && "Set the name, type, and when this change should be applied."}
            {step === 2 && (changeType === "add_to_group"
              ? "Select which products to add to the group."
              : "Choose which products or group to apply changes to.")}
            {step === 3 && (changeType === "add_to_group"
              ? "Select the target group and optionally set a membership end date."
              : "Define what field changes to make. You can set one value for all products or different values per product.")}
          </DialogDescription>
        </DialogHeader>

        {step === 1 && (
          <div className="space-y-4 py-2">
            <div>
              <Label>Change Type</Label>
              <Select value={changeType} onValueChange={(v: "field_changes" | "add_to_group") => setChangeType(v)}>
                <SelectTrigger data-testid="select-change-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="field_changes">Field Changes</SelectItem>
                  <SelectItem value="add_to_group">Add Products to Group</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="sc-name">Name</Label>
              <Input
                id="sc-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={changeType === "add_to_group" ? "e.g. Add new season kits to Premier League" : "e.g. Summer Sale Price Drop"}
                data-testid="input-name"
              />
            </div>
            <div>
              <Label htmlFor="sc-description">Description (optional)</Label>
              <Textarea
                id="sc-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What this scheduled change is for..."
                data-testid="input-description"
              />
            </div>
            <div>
              <Label htmlFor="sc-date">Scheduled Date & Time</Label>
              <Input
                id="sc-date"
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                data-testid="input-scheduled-at"
              />
            </div>
            <div>
              <Label htmlFor="sc-end-date">End Date & Time (optional — auto-reverts changes)</Label>
              <Input
                id="sc-end-date"
                type="datetime-local"
                value={endsAt}
                onChange={(e) => setEndsAt(e.target.value)}
                min={scheduledAt || undefined}
                data-testid="input-ends-at"
              />
              {endsAt && (
                <p className="text-xs text-muted-foreground mt-1">
                  Changes will be automatically reverted at this time.
                </p>
              )}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4 py-2">
            {changeType === "field_changes" && (
              <div>
                <Label>Scope</Label>
                <Select value={scopeType} onValueChange={setScopeType}>
                  <SelectTrigger data-testid="select-scope-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="products">Individual Products</SelectItem>
                    <SelectItem value="group">Product Group</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {changeType === "field_changes" && scopeType === "group" && (
              <div>
                <Label>Product Group</Label>
                <Select
                  value={scopeGroupId?.toString() || ""}
                  onValueChange={(v) => setScopeGroupId(Number(v))}
                >
                  <SelectTrigger data-testid="select-group">
                    <SelectValue placeholder="Select a group" />
                  </SelectTrigger>
                  <SelectContent>
                    {groups.map((g: any) => (
                      <SelectItem
                        key={g.productGroupId || g.groupId}
                        value={String(g.productGroupId || g.groupId)}
                      >
                        {g.name} ({g.productCount ?? 0} products)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {(changeType === "add_to_group" || (changeType === "field_changes" && scopeType === "products")) && (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-9"
                    placeholder="Search products..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    data-testid="input-product-search"
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedProductIds.size} product(s) selected
                </p>
                <div className="border rounded-md max-h-64 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-10"></TableHead>
                        <TableHead>SKU</TableHead>
                        <TableHead>Description</TableHead>
                        <TableHead>Brand</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.slice(0, 100).map((p) => (
                        <TableRow key={p.productId}>
                          <TableCell>
                            <Checkbox
                              checked={selectedProductIds.has(p.productId)}
                              onCheckedChange={(checked) => {
                                const next = new Set(selectedProductIds);
                                if (checked) next.add(p.productId);
                                else next.delete(p.productId);
                                setSelectedProductIds(next);
                              }}
                              data-testid={`checkbox-product-${p.productId}`}
                            />
                          </TableCell>
                          <TableCell className="font-mono text-sm">{p.productSku}</TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {p.productDescription}
                          </TableCell>
                          <TableCell>{p.brandName}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        )}

        {step === 3 && changeType === "add_to_group" && (
          <div className="space-y-4 py-2">
            <div>
              <Label>Target Group</Label>
              <Select
                value={targetGroupId?.toString() || ""}
                onValueChange={(v) => setTargetGroupId(Number(v))}
              >
                <SelectTrigger data-testid="select-target-group">
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g: any) => (
                    <SelectItem
                      key={g.productGroupId || g.groupId}
                      value={String(g.productGroupId || g.groupId)}
                    >
                      {g.name} ({g.productCount ?? 0} products)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="sc-end-date">Membership End Date (optional)</Label>
              <Input
                id="sc-end-date"
                type="datetime-local"
                value={membershipEndDate}
                onChange={(e) => setMembershipEndDate(e.target.value)}
                data-testid="input-membership-end-date"
              />
              <p className="text-xs text-muted-foreground mt-1">
                If set, the products will be automatically removed from the group after this date.
              </p>
            </div>
            <Card className="p-4">
              <p className="text-sm font-medium mb-2">Summary</p>
              <p className="text-sm text-muted-foreground">
                {selectedProductIds.size} product(s) will be added to{" "}
                {targetGroupId
                  ? groups.find((g: any) => (g.productGroupId || g.groupId) === targetGroupId)?.name || "the selected group"
                  : "..."}{" "}
                {membershipEndDate
                  ? `with an end date of ${new Date(membershipEndDate).toLocaleString()}`
                  : "with no end date"}
              </p>
            </Card>
          </div>
        )}

        {step === 3 && changeType === "field_changes" && (
          <div className="space-y-4 py-2">
            {fieldChanges.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No field changes added yet. Click the button below to add one.
              </p>
            )}

            {fieldChanges.map((fc, index) => {
              const isExpanded = expandedFields.has(index);
              const fieldDef = allFields.find((f) => f.value === fc.fieldName);
              const inputType = fieldDef?.inputType || "text";

              return (
                <Card key={index} className="p-4 space-y-3">
                  <div className="flex items-end gap-2">
                    <div className="flex-1 min-w-0">
                      <Label className="text-xs">Field</Label>
                      <Select
                        value={fc.fieldName || undefined}
                        onValueChange={(v) => {
                          const field = allFields.find((f) => f.value === v);
                          updateFieldEntry(index, {
                            fieldName: v,
                            entityType: field?.entityType || "product",
                          });
                        }}
                      >
                        <SelectTrigger data-testid={`select-field-${index}`}>
                          <SelectValue placeholder="Select field" />
                        </SelectTrigger>
                        <SelectContent>
                          {allFields.map((f) => (
                            <SelectItem key={f.value} value={f.value}>
                              {f.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {scopeType === "products" && selectedProductIds.size > 1 && (
                      <div className="flex-shrink-0">
                        <Label className="text-xs">Apply</Label>
                        <Select
                          value={fc.mode}
                          onValueChange={(v: "all" | "per-product") =>
                            updateFieldEntry(index, { mode: v })
                          }
                        >
                          <SelectTrigger className="w-40" data-testid={`select-mode-${index}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Same for all</SelectItem>
                            <SelectItem value="per-product">Per product</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {fc.entityType === "variant_price" && fc.fieldName.startsWith("specialRetailPrice_") && (
                      <div className="flex-shrink-0">
                        <Label className="text-xs">Mode</Label>
                        <Select
                          value={fc.changeMode}
                          onValueChange={(v: "absolute" | "percentage") =>
                            updateFieldEntry(index, { changeMode: v })
                          }
                        >
                          <SelectTrigger className="w-36" data-testid={`select-change-mode-${index}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="absolute">Set exact price</SelectItem>
                            <SelectItem value="percentage">% off retail</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <Button
                      variant="ghost"
                      size="icon"
                      className="flex-shrink-0"
                      onClick={() => removeFieldChange(index)}
                      data-testid={`button-remove-field-${index}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>

                  {fc.mode === "all" && (
                    <div>
                      <Label className="text-xs">
                        {fc.entityType === "variant_price" && fc.changeMode === "percentage"
                          ? "Discount % off Retail Price"
                          : "New Value"}
                      </Label>
                      {inputType === "boolean" ? (
                        <Select
                          value={fc.globalValue || undefined}
                          onValueChange={(v) => updateFieldEntry(index, { globalValue: v })}
                        >
                          <SelectTrigger data-testid={`select-value-${index}`}>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="true">Yes</SelectItem>
                            <SelectItem value="false">No</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          type={inputType === "number" ? "number" : "text"}
                          step={inputType === "number" ? "0.01" : undefined}
                          value={fc.globalValue}
                          onChange={(e) => updateFieldEntry(index, { globalValue: e.target.value })}
                          placeholder={
                            fc.entityType === "variant_price" && fc.changeMode === "percentage"
                              ? "e.g. 15 to set special price 15% below retail"
                              : inputType === "number" ? "0.00" : "New value"
                          }
                          data-testid={`input-value-${index}`}
                        />
                      )}
                    </div>
                  )}

                  {fc.mode === "per-product" && (
                    <div>
                      <button
                        type="button"
                        className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors mb-2"
                        onClick={() => toggleExpanded(index)}
                        data-testid={`button-toggle-products-${index}`}
                      >
                        {isExpanded ? (
                          <ChevronDown className="h-3 w-3" />
                        ) : (
                          <ChevronRight className="h-3 w-3" />
                        )}
                        {selectedProducts.length} product(s) — set individual values
                      </button>
                      {isExpanded && (
                        <div className="border rounded-md max-h-48 overflow-y-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>SKU</TableHead>
                                <TableHead>Description</TableHead>
                                <TableHead className="w-48">New Value</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {selectedProducts.map((p) => {
                                const ppv = fc.perProductValues.find(
                                  (v) => v.productId === p.productId,
                                );
                                return (
                                  <TableRow key={p.productId}>
                                    <TableCell className="font-mono text-xs">
                                      {p.productSku}
                                    </TableCell>
                                    <TableCell className="text-xs max-w-[150px] truncate">
                                      {p.productDescription}
                                    </TableCell>
                                    <TableCell>
                                      {inputType === "boolean" ? (
                                        <Select
                                          value={ppv?.value || undefined}
                                          onValueChange={(v) =>
                                            updatePerProductValue(index, p.productId, v)
                                          }
                                        >
                                          <SelectTrigger
                                            className="h-8"
                                            data-testid={`select-ppv-${index}-${p.productId}`}
                                          >
                                            <SelectValue placeholder="Select" />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="true">Yes</SelectItem>
                                            <SelectItem value="false">No</SelectItem>
                                          </SelectContent>
                                        </Select>
                                      ) : (
                                        <Input
                                          type={inputType === "number" ? "number" : "text"}
                                          step={inputType === "number" ? "0.01" : undefined}
                                          className="h-8"
                                          value={ppv?.value || ""}
                                          onChange={(e) =>
                                            updatePerProductValue(
                                              index,
                                              p.productId,
                                              e.target.value,
                                            )
                                          }
                                          placeholder={inputType === "number" ? "0.00" : "Value"}
                                          data-testid={`input-ppv-${index}-${p.productId}`}
                                        />
                                      )}
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      )}
                    </div>
                  )}
                </Card>
              );
            })}

            <Button
              variant="outline"
              size="sm"
              onClick={addFieldChange}
              data-testid="button-add-field"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add field change
            </Button>
          </div>
        )}

        <DialogFooter className="flex justify-between">
          <div>
            {step > 1 && (
              <Button
                variant="ghost"
                onClick={() => setStep(step - 1)}
                data-testid="button-prev-step"
              >
                Back
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={resetAndClose} data-testid="button-cancel-dialog">
              Cancel
            </Button>
            {step < 3 ? (
              <Button
                onClick={() => setStep(step + 1)}
                disabled={step === 1 ? !canProceedStep1 : !canProceedStep2}
                data-testid="button-next-step"
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={() => createMutation.mutate()}
                disabled={!canSubmit || createMutation.isPending}
                data-testid="button-submit"
              >
                {createMutation.isPending ? "Creating..." : "Create Scheduled Change"}
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
