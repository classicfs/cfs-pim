import { useMutation, useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Attributes() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [selectedAttribute, setSelectedAttribute] = useState<"teams" | "genders" | "eras" | "brands" | "types" | "styles" | "colours" | "sizes" | "taxClasses" | "conditions" | "customAttributes">("teams");
  const [teamName, setTeamName] = useState("");
  const [teamCountry, setTeamCountry] = useState("");
  const [teamFoundedYear, setTeamFoundedYear] = useState("");
  const [genderName, setGenderName] = useState("");
  const [eraName, setEraName] = useState("");
  const [eraStartYear, setEraStartYear] = useState("");
  const [eraEndYear, setEraEndYear] = useState("");
  const [editingTeamId, setEditingTeamId] = useState<number | null>(null);
  const [editingTeamName, setEditingTeamName] = useState("");
  const [editingTeamCountry, setEditingTeamCountry] = useState("");
  const [editingTeamFoundedYear, setEditingTeamFoundedYear] = useState("");
  const [editingGenderId, setEditingGenderId] = useState<number | null>(null);
  const [editingGenderName, setEditingGenderName] = useState("");
  const [editingEraId, setEditingEraId] = useState<number | null>(null);
  const [editingEraName, setEditingEraName] = useState("");
  const [editingEraStartYear, setEditingEraStartYear] = useState("");
  const [editingEraEndYear, setEditingEraEndYear] = useState("");
  const [editingBrandId, setEditingBrandId] = useState<number | null>(null);
  const [editingBrandName, setEditingBrandName] = useState("");
  const [editingBrandGrouping, setEditingBrandGrouping] = useState("");
  const [editingProductTypeId, setEditingProductTypeId] = useState<number | null>(null);
  const [editingProductTypeName, setEditingProductTypeName] = useState("");
  const [editingConditionId, setEditingConditionId] = useState<number | null>(null);
  const [editingConditionName, setEditingConditionName] = useState("");
  const [editingTaxClassId, setEditingTaxClassId] = useState<number | null>(null);
  const [editingTaxClassName, setEditingTaxClassName] = useState("");
  const [editingColourId, setEditingColourId] = useState<number | null>(null);
  const [editingColourName, setEditingColourName] = useState("");
  const [editingColourMagentoId, setEditingColourMagentoId] = useState("");
  const [editingColourBrandId, setEditingColourBrandId] = useState("");
  const [editingColourBrandColourId, setEditingColourBrandColourId] = useState("");
  const [editingColourBrandName, setEditingColourBrandName] = useState("");
  const [editingSizeId, setEditingSizeId] = useState<number | null>(null);
  const [editingSizeMagentoId, setEditingSizeMagentoId] = useState("");
  const [editingSizeShortName, setEditingSizeShortName] = useState("");
  const [editingSizeLongName, setEditingSizeLongName] = useState("");
  const [editingSizeConfigOptions, setEditingSizeConfigOptions] = useState("");
  const [editingSizeSizingCategory, setEditingSizeSizingCategory] = useState("");
  const [brandName, setBrandName] = useState("");
  const [brandGrouping, setBrandGrouping] = useState("");
  const [brandIdInput, setBrandIdInput] = useState("");
  const [productTypeName, setProductTypeName] = useState("");
  const [productTypeIdInput, setProductTypeIdInput] = useState("");
  const [conditionName, setConditionName] = useState("");
  const [conditionIdInput, setConditionIdInput] = useState("");
  const [taxClassName, setTaxClassName] = useState("");
  const [colourName, setColourName] = useState("");
  const [colourMagentoId, setColourMagentoId] = useState("");
  const [colourBrandId, setColourBrandId] = useState("");
  const [colourBrandColourId, setColourBrandColourId] = useState("");
  const [colourBrandName, setColourBrandName] = useState("");
  const [sizeMagentoId, setSizeMagentoId] = useState("");
  const [sizeShortName, setSizeShortName] = useState("");
  const [sizeLongName, setSizeLongName] = useState("");
  const [sizeConfigOptions, setSizeConfigOptions] = useState("");
  const [sizeSizingCategory, setSizeSizingCategory] = useState("");
  const [attributeCode, setAttributeCode] = useState("");
  const [attributeLabel, setAttributeLabel] = useState("");
  // scope removed — no longer needed after flattening product/variant tables
  const [attributeDataType, setAttributeDataType] = useState<"text" | "number" | "boolean" | "json">("text");
  const [attributeMagentoScope, setAttributeMagentoScope] = useState<"global" | "website" | "store_view">("global");

  const { data: clubs = [] } = useQuery<any[]>({ queryKey: ["/api/clubs"] });
  const { data: genders = [] } = useQuery<any[]>({ queryKey: ["/api/genders"] });
  const { data: eras = [] } = useQuery<any[]>({ queryKey: ["/api/eras"] });
  const { data: brands = [] } = useQuery<any[]>({ queryKey: ["/api/brands"] });
  const { data: productTypes = [] } = useQuery<any[]>({ queryKey: ["/api/product-types"] });
  const { data: productColours = [] } = useQuery<any[]>({ queryKey: ["/api/product-colours"] });
  const { data: sizes = [] } = useQuery<any[]>({ queryKey: ["/api/sizes"] });
  const { data: taxClasses = [] } = useQuery<any[]>({ queryKey: ["/api/tax-classes"] });
  const { data: conditions = [] } = useQuery<any[]>({ queryKey: ["/api/conditions"] });
  const { data: productStyles = [] } = useQuery<any[]>({ queryKey: ["/api/product-styles/counts"] });
  const { data: attributeDefs = [] } = useQuery<any[]>({ queryKey: ["/api/attribute-defs"] });

  const attributeRows = useMemo(
    () => [
      { key: "teams", label: "Teams", count: clubs.length },
      { key: "genders", label: "Genders", count: genders.length },
      { key: "eras", label: "Eras", count: eras.length },
      { key: "brands", label: "Brands", count: brands.length },
      { key: "types", label: "Product Types", count: productTypes.length },
      { key: "styles", label: "Product Styles", count: productStyles.length },
      { key: "colours", label: "Product Colours", count: productColours.length },
      { key: "sizes", label: "Sizes", count: sizes.length },
      { key: "taxClasses", label: "Tax Classes", count: taxClasses.length },
      { key: "conditions", label: "Conditions", count: conditions.length },
      { key: "customAttributes", label: "Custom Attributes", count: attributeDefs.length },
    ],
    [clubs.length, genders.length, eras.length, brands.length, productTypes.length, productStyles.length, productColours.length, sizes.length, taxClasses.length, conditions.length, attributeDefs.length],
  );

  const createTeamMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/clubs", {
        name: teamName.trim(),
        country: teamCountry.trim() || null,
        foundedYear: teamFoundedYear ? Number(teamFoundedYear) : null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Team created", description: "The team is now available for products." });
      setTeamName("");
      setTeamCountry("");
      setTeamFoundedYear("");
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create team",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createGenderMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/genders", {
        genderName: genderName.trim(),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Gender created", description: "The gender is now available for products." });
      setGenderName("");
      queryClient.invalidateQueries({ queryKey: ["/api/genders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create gender",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createEraMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/eras", {
        name: eraName.trim(),
        startYear: eraStartYear ? Number(eraStartYear) : null,
        endYear: eraEndYear ? Number(eraEndYear) : null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Era created", description: "The era is now available for products." });
      setEraName("");
      setEraStartYear("");
      setEraEndYear("");
      queryClient.invalidateQueries({ queryKey: ["/api/eras"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create era",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateTeamMutation = useMutation({
    mutationFn: async (payload: { clubId: number; name: string; country?: string | null; foundedYear?: number | null }) => {
      const response = await apiRequest("PUT", `/api/clubs/${payload.clubId}`, {
        name: payload.name,
        country: payload.country ?? null,
        foundedYear: payload.foundedYear ?? null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Team updated", description: "The team details were saved." });
      setEditingTeamId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update team",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTeamMutation = useMutation({
    mutationFn: async (clubId: number) => {
      await apiRequest("DELETE", `/api/clubs/${clubId}`);
    },
    onSuccess: () => {
      toast({ title: "Team deleted", description: "The team was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/clubs"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete team",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateGenderMutation = useMutation({
    mutationFn: async (payload: { genderId: number; genderName: string }) => {
      const response = await apiRequest("PUT", `/api/genders/${payload.genderId}`, {
        genderName: payload.genderName,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Gender updated", description: "The gender was saved." });
      setEditingGenderId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/genders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update gender",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateEraMutation = useMutation({
    mutationFn: async (payload: { eraId: number; name: string; startYear: number; endYear: number }) => {
      const response = await apiRequest("PUT", `/api/eras/${payload.eraId}`, {
        name: payload.name,
        startYear: payload.startYear,
        endYear: payload.endYear,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Era updated", description: "The era was saved." });
      setEditingEraId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/eras"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update era",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteGenderMutation = useMutation({
    mutationFn: async (genderId: number) => {
      await apiRequest("DELETE", `/api/genders/${genderId}`);
    },
    onSuccess: () => {
      toast({ title: "Gender deleted", description: "The gender was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/genders"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete gender",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteEraMutation = useMutation({
    mutationFn: async (eraId: number) => {
      await apiRequest("DELETE", `/api/eras/${eraId}`);
    },
    onSuccess: () => {
      toast({ title: "Era deleted", description: "The era was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/eras"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete era",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const createBrandMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/brands", {
        brandName: brandName.trim(),
        brandGrouping: brandGrouping.trim() || null,
        brandId: brandIdInput ? Number(brandIdInput) : null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Brand created", description: "The brand is now available." });
      setBrandName("");
      setBrandGrouping("");
      setBrandIdInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/brands"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create brand", description: error.message, variant: "destructive" });
    },
  });

  const createProductTypeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/product-types", {
        productTypeName: productTypeName.trim(),
        productTypeId: productTypeIdInput ? Number(productTypeIdInput) : null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Product type created", description: "The product type is now available." });
      setProductTypeName("");
      setProductTypeIdInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create product type", description: error.message, variant: "destructive" });
    },
  });

  const createConditionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/conditions", {
        conditionName: conditionName.trim(),
        conditionId: conditionIdInput ? Number(conditionIdInput) : null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Condition created", description: "The condition is now available." });
      setConditionName("");
      setConditionIdInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/conditions"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create condition", description: error.message, variant: "destructive" });
    },
  });

  const createTaxClassMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/tax-classes", {
        taxClassName: taxClassName.trim(),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Tax class created", description: "The tax class is now available." });
      setTaxClassName("");
      queryClient.invalidateQueries({ queryKey: ["/api/tax-classes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create tax class", description: error.message, variant: "destructive" });
    },
  });

  const createAttributeDefMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/attribute-defs", {
        code: attributeCode.trim(),
        label: attributeLabel.trim() || null,
        dataType: attributeDataType,
        magentoScope: attributeMagentoScope,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Attribute created", description: "The attribute definition is now available." });
      setAttributeCode("");
      setAttributeLabel("");
      setAttributeDataType("text");
      setAttributeMagentoScope("global");
      queryClient.invalidateQueries({ queryKey: ["/api/attribute-defs"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create attribute", description: error.message, variant: "destructive" });
    },
  });

  const updateAttributeDefMutation = useMutation({
    mutationFn: async ({ attributeId, updates }: { attributeId: number; updates: { magentoSync?: boolean; magentoScope?: string } }) => {
      await apiRequest("PATCH", `/api/attribute-defs/${attributeId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attribute-defs"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update attribute", description: error.message, variant: "destructive" });
    },
  });

  const deleteAttributeDefMutation = useMutation({
    mutationFn: async (attributeId: number) => {
      await apiRequest("DELETE", `/api/attribute-defs/${attributeId}`);
    },
    onSuccess: () => {
      toast({ title: "Attribute deleted", description: "The attribute and its values were removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/attribute-defs"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete attribute", description: error.message, variant: "destructive" });
    },
  });

  const createColourMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/product-colours", {
        magentoColourName: colourName.trim(),
        magentoColourId: colourMagentoId.trim() || null,
        brandId: colourBrandId ? Number(colourBrandId) : null,
        brandColourId: colourBrandColourId ? Number(colourBrandColourId) : null,
        brandColourName: colourBrandName.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Colour created", description: "The colour is now available." });
      setColourName("");
      setColourMagentoId("");
      setColourBrandId("");
      setColourBrandColourId("");
      setColourBrandName("");
      queryClient.invalidateQueries({ queryKey: ["/api/product-colours"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create colour", description: error.message, variant: "destructive" });
    },
  });

  const createSizeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/sizes", {
        magentoSizeId: sizeMagentoId ? Number(sizeMagentoId) : null,
        magentoSizeShortName: sizeShortName.trim() || null,
        magentoSizeLongName: sizeLongName.trim() || null,
        configOptions: sizeConfigOptions.trim() || null,
        sizingCategory: sizeSizingCategory.trim() || null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Size created", description: "The size is now available." });
      setSizeMagentoId("");
      setSizeShortName("");
      setSizeLongName("");
      setSizeConfigOptions("");
      setSizeSizingCategory("");
      queryClient.invalidateQueries({ queryKey: ["/api/sizes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to create size", description: error.message, variant: "destructive" });
    },
  });

  const updateBrandMutation = useMutation({
    mutationFn: async (payload: { brandId: number; brandName: string; brandGrouping?: string | null }) => {
      const response = await apiRequest("PUT", `/api/brands/${payload.brandId}`, {
        brandName: payload.brandName,
        brandGrouping: payload.brandGrouping ?? null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Brand updated", description: "The brand was saved." });
      setEditingBrandId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/brands"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update brand", description: error.message, variant: "destructive" });
    },
  });

  const deleteBrandMutation = useMutation({
    mutationFn: async (brandId: number) => {
      await apiRequest("DELETE", `/api/brands/${brandId}`);
    },
    onSuccess: () => {
      toast({ title: "Brand deleted", description: "The brand was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/brands"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete brand", description: error.message, variant: "destructive" });
    },
  });

  const updateProductTypeMutation = useMutation({
    mutationFn: async (payload: { productTypeId: number; productTypeName: string }) => {
      const response = await apiRequest("PUT", `/api/product-types/${payload.productTypeId}`, {
        productTypeName: payload.productTypeName,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Product type updated", description: "The product type was saved." });
      setEditingProductTypeId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update product type", description: error.message, variant: "destructive" });
    },
  });

  const deleteProductTypeMutation = useMutation({
    mutationFn: async (productTypeId: number) => {
      await apiRequest("DELETE", `/api/product-types/${productTypeId}`);
    },
    onSuccess: () => {
      toast({ title: "Product type deleted", description: "The product type was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/product-types"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete product type", description: error.message, variant: "destructive" });
    },
  });

  const updateConditionMutation = useMutation({
    mutationFn: async (payload: { conditionId: number; conditionName: string }) => {
      const response = await apiRequest("PUT", `/api/conditions/${payload.conditionId}`, {
        conditionName: payload.conditionName,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Condition updated", description: "The condition was saved." });
      setEditingConditionId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/conditions"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update condition", description: error.message, variant: "destructive" });
    },
  });

  const deleteConditionMutation = useMutation({
    mutationFn: async (conditionId: number) => {
      await apiRequest("DELETE", `/api/conditions/${conditionId}`);
    },
    onSuccess: () => {
      toast({ title: "Condition deleted", description: "The condition was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/conditions"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete condition", description: error.message, variant: "destructive" });
    },
  });

  const updateTaxClassMutation = useMutation({
    mutationFn: async (payload: { taxClassId: number; taxClassName: string }) => {
      const response = await apiRequest("PUT", `/api/tax-classes/${payload.taxClassId}`, {
        taxClassName: payload.taxClassName,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Tax class updated", description: "The tax class was saved." });
      setEditingTaxClassId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/tax-classes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update tax class", description: error.message, variant: "destructive" });
    },
  });

  const deleteTaxClassMutation = useMutation({
    mutationFn: async (taxClassId: number) => {
      await apiRequest("DELETE", `/api/tax-classes/${taxClassId}`);
    },
    onSuccess: () => {
      toast({ title: "Tax class deleted", description: "The tax class was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/tax-classes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete tax class", description: error.message, variant: "destructive" });
    },
  });

  const updateColourMutation = useMutation({
    mutationFn: async (payload: {
      productColourId: number;
      magentoColourName?: string | null;
      magentoColourId?: string | null;
      brandId?: number | null;
      brandColourId?: number | null;
      brandColourName?: string | null;
    }) => {
      const response = await apiRequest("PUT", `/api/product-colours/${payload.productColourId}`, {
        magentoColourName: payload.magentoColourName ?? null,
        magentoColourId: payload.magentoColourId ?? null,
        brandId: payload.brandId ?? null,
        brandColourId: payload.brandColourId ?? null,
        brandColourName: payload.brandColourName ?? null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Colour updated", description: "The colour was saved." });
      setEditingColourId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/product-colours"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update colour", description: error.message, variant: "destructive" });
    },
  });

  const deleteColourMutation = useMutation({
    mutationFn: async (productColourId: number) => {
      await apiRequest("DELETE", `/api/product-colours/${productColourId}`);
    },
    onSuccess: () => {
      toast({ title: "Colour deleted", description: "The colour was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/product-colours"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete colour", description: error.message, variant: "destructive" });
    },
  });

  const updateSizeMutation = useMutation({
    mutationFn: async (payload: {
      sizeId: number;
      magentoSizeId?: number | null;
      magentoSizeShortName?: string | null;
      magentoSizeLongName?: string | null;
      configOptions?: string | null;
      sizingCategory?: string | null;
    }) => {
      const response = await apiRequest("PUT", `/api/sizes/${payload.sizeId}`, {
        magentoSizeId: payload.magentoSizeId ?? null,
        magentoSizeShortName: payload.magentoSizeShortName ?? null,
        magentoSizeLongName: payload.magentoSizeLongName ?? null,
        configOptions: payload.configOptions ?? null,
        sizingCategory: payload.sizingCategory ?? null,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Size updated", description: "The size was saved." });
      setEditingSizeId(null);
      queryClient.invalidateQueries({ queryKey: ["/api/sizes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update size", description: error.message, variant: "destructive" });
    },
  });

  const deleteSizeMutation = useMutation({
    mutationFn: async (sizeId: number) => {
      await apiRequest("DELETE", `/api/sizes/${sizeId}`);
    },
    onSuccess: () => {
      toast({ title: "Size deleted", description: "The size was removed." });
      queryClient.invalidateQueries({ queryKey: ["/api/sizes"] });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete size", description: error.message, variant: "destructive" });
    },
  });

  const selectedTitle = attributeRows.find((row) => row.key === selectedAttribute)?.label ?? "Attributes";

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="p-6 pb-0 space-y-6 flex flex-col min-h-0 h-full">
        <div className="shrink-0">
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-attributes">Attributes</h1>
          <p className="text-muted-foreground mt-1">
            Manage product attributes like teams, genders, and reference data.
          </p>
        </div>
        <div className="grid gap-6 lg:grid-cols-[1fr_2fr] min-h-0 flex-1 pb-6">
          <div className="border rounded-md overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background z-10">
                <TableRow>
                  <TableHead>Attribute</TableHead>
                  <TableHead className="text-right">Options</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {attributeRows.map((row) => (
                  <TableRow
                    key={row.key}
                    className="cursor-pointer"
                    data-testid={`row-attribute-${row.key}`}
                    onClick={() => setSelectedAttribute(row.key as typeof selectedAttribute)}
                  >
                    <TableCell className={row.key === selectedAttribute ? "font-semibold" : undefined}>
                      {row.label}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">{row.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex flex-col gap-4 min-h-0">
            <div className="border rounded-md p-4 shrink-0">
              <h2 className="text-lg font-semibold">{selectedTitle}</h2>
              <p className="text-sm text-muted-foreground">
                Manage the available options for this attribute.
              </p>
            </div>

            {selectedAttribute === "teams" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Team name"
                    value={teamName}
                    onChange={(event) => setTeamName(event.target.value)}
                    data-testid="input-team-name"
                  />
                  <Input
                    placeholder="Country (optional)"
                    value={teamCountry}
                    onChange={(event) => setTeamCountry(event.target.value)}
                    data-testid="input-team-country"
                  />
                  <Input
                    placeholder="Founded year (optional)"
                    type="number"
                    value={teamFoundedYear}
                    onChange={(event) => setTeamFoundedYear(event.target.value)}
                    data-testid="input-team-founded-year"
                  />
                  <Button
                    onClick={() => createTeamMutation.mutate()}
                    disabled={!teamName.trim() || createTeamMutation.isPending}
                    data-testid="button-create-team"
                  >
                    {createTeamMutation.isPending ? "Saving..." : "Add Team"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Team</TableHead>
                        <TableHead>Country</TableHead>
                        <TableHead>Founded</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {clubs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-muted-foreground">
                            No teams found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        clubs.map((club: any) => (
                          <TableRow key={club.clubId}>
                            <TableCell>
                              {editingTeamId === club.clubId ? (
                                <Input
                                  value={editingTeamName}
                                  onChange={(event) => setEditingTeamName(event.target.value)}
                                  data-testid={`input-team-name-${club.clubId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const filters = [{"field":"teamName","operator":"eq","value":club.name,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {club.name}
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editingTeamId === club.clubId ? (
                                <Input
                                  value={editingTeamCountry}
                                  onChange={(event) => setEditingTeamCountry(event.target.value)}
                                  data-testid={`input-team-country-${club.clubId}`}
                                />
                              ) : (
                                club.country || "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingTeamId === club.clubId ? (
                                <Input
                                  type="number"
                                  value={editingTeamFoundedYear}
                                  onChange={(event) => setEditingTeamFoundedYear(event.target.value)}
                                  data-testid={`input-team-founded-${club.clubId}`}
                                />
                              ) : (
                                club.foundedYear || "—"
                              )}
                            </TableCell>
                            <TableCell className="text-right">{club.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{club.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingTeamId === club.clubId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateTeamMutation.mutate({
                                        clubId: club.clubId,
                                        name: editingTeamName.trim(),
                                        country: editingTeamCountry.trim() || null,
                                        foundedYear: editingTeamFoundedYear
                                          ? Number(editingTeamFoundedYear)
                                          : null,
                                      })
                                    }
                                    disabled={!editingTeamName.trim() || updateTeamMutation.isPending}
                                    data-testid={`button-save-team-${club.clubId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingTeamId(null)}
                                    data-testid={`button-cancel-team-${club.clubId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingTeamId(club.clubId);
                                      setEditingTeamName(club.name ?? "");
                                      setEditingTeamCountry(club.country ?? "");
                                      setEditingTeamFoundedYear(club.foundedYear ? String(club.foundedYear) : "");
                                    }}
                                    data-testid={`button-edit-team-${club.clubId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this team?")) {
                                        deleteTeamMutation.mutate(club.clubId);
                                      }
                                    }}
                                    data-testid={`button-delete-team-${club.clubId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "genders" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="flex gap-3 shrink-0">
                  <Input
                    placeholder="Gender name"
                    value={genderName}
                    onChange={(event) => setGenderName(event.target.value)}
                    data-testid="input-gender-name"
                  />
                  <Button
                    onClick={() => createGenderMutation.mutate()}
                    disabled={!genderName.trim() || createGenderMutation.isPending}
                    data-testid="button-create-gender"
                  >
                    {createGenderMutation.isPending ? "Saving..." : "Add Gender"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Gender</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {genders.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-muted-foreground">
                            No genders found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        genders.map((gender: any) => (
                          <TableRow key={gender.genderId}>
                            <TableCell>
                              {editingGenderId === gender.genderId ? (
                                <Input
                                  value={editingGenderName}
                                  onChange={(event) => setEditingGenderName(event.target.value)}
                                  data-testid={`input-gender-name-${gender.genderId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const filters = [{"field":"genderName","operator":"eq","value":gender.genderName,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {gender.genderName}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-right">{gender.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{gender.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingGenderId === gender.genderId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateGenderMutation.mutate({
                                        genderId: gender.genderId,
                                        genderName: editingGenderName.trim(),
                                      })
                                    }
                                    disabled={!editingGenderName.trim() || updateGenderMutation.isPending}
                                    data-testid={`button-save-gender-${gender.genderId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingGenderId(null)}
                                    data-testid={`button-cancel-gender-${gender.genderId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingGenderId(gender.genderId);
                                      setEditingGenderName(gender.genderName ?? "");
                                    }}
                                    data-testid={`button-edit-gender-${gender.genderId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this gender?")) {
                                        deleteGenderMutation.mutate(gender.genderId);
                                      }
                                    }}
                                    data-testid={`button-delete-gender-${gender.genderId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "eras" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="flex gap-3 shrink-0">
                  <Input
                    placeholder="Era name"
                    value={eraName}
                    onChange={(event) => setEraName(event.target.value)}
                    data-testid="input-era-name"
                  />
                  <Input
                    placeholder="Start year"
                    type="number"
                    value={eraStartYear}
                    onChange={(event) => setEraStartYear(event.target.value)}
                    data-testid="input-era-start-year"
                  />
                  <Input
                    placeholder="End year"
                    type="number"
                    value={eraEndYear}
                    onChange={(event) => setEraEndYear(event.target.value)}
                    data-testid="input-era-end-year"
                  />
                  <Button
                    onClick={() => createEraMutation.mutate()}
                    disabled={
                      !eraName.trim() ||
                      !eraStartYear.trim() ||
                      !eraEndYear.trim() ||
                      createEraMutation.isPending
                    }
                    data-testid="button-create-era"
                  >
                    {createEraMutation.isPending ? "Saving..." : "Add Era"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Era</TableHead>
                        <TableHead>Start Year</TableHead>
                        <TableHead>End Year</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {eras.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-muted-foreground">
                            No eras found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        eras.map((era: any) => {
                          const isEditing = editingEraId === era.eraId;
                          const startYearValue = Number(editingEraStartYear);
                          const endYearValue = Number(editingEraEndYear);

                          return (
                            <TableRow key={era.eraId}>
                              <TableCell>
                                {isEditing ? (
                                  <Input
                                    value={editingEraName}
                                    onChange={(event) => setEditingEraName(event.target.value)}
                                    data-testid={`input-era-name-${era.eraId}`}
                                  />
                                ) : (
                                  <span
                                    className="text-blue-600 hover:underline cursor-pointer"
                                    onClick={() => {
                                      const filters = [{"field":"eraName","operator":"eq","value":era.name,"dataType":"text","source":"product"}];
                                      navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                    }}
                                  >
                                    {era.name}
                                  </span>
                                )}
                              </TableCell>
                              <TableCell>
                                {isEditing ? (
                                  <Input
                                    type="number"
                                    value={editingEraStartYear}
                                    onChange={(event) => setEditingEraStartYear(event.target.value)}
                                    data-testid={`input-era-start-${era.eraId}`}
                                  />
                                ) : (
                                  era.startYear
                                )}
                              </TableCell>
                              <TableCell>
                                {isEditing ? (
                                  <Input
                                    type="number"
                                    value={editingEraEndYear}
                                    onChange={(event) => setEditingEraEndYear(event.target.value)}
                                    data-testid={`input-era-end-${era.eraId}`}
                                  />
                                ) : (
                                  era.endYear
                                )}
                              </TableCell>
                              <TableCell className="text-right">{era.productCount ?? 0}</TableCell>
                              <TableCell className="text-right">{era.variantCount ?? 0}</TableCell>
                              <TableCell className="text-right">
                                {isEditing ? (
                                  <div className="flex items-center justify-end gap-2">
                                    <Button
                                      size="sm"
                                      onClick={() =>
                                        updateEraMutation.mutate({
                                          eraId: era.eraId,
                                          name: editingEraName.trim(),
                                          startYear: startYearValue,
                                          endYear: endYearValue,
                                        })
                                      }
                                      disabled={
                                        !editingEraName.trim() ||
                                        Number.isNaN(startYearValue) ||
                                        Number.isNaN(endYearValue) ||
                                        updateEraMutation.isPending
                                      }
                                      data-testid={`button-save-era-${era.eraId}`}
                                    >
                                      Save
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setEditingEraId(null)}
                                      data-testid={`button-cancel-era-${era.eraId}`}
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                ) : (
                                  <div className="flex items-center justify-end gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setEditingEraId(era.eraId);
                                        setEditingEraName(era.name ?? "");
                                        setEditingEraStartYear(String(era.startYear ?? ""));
                                        setEditingEraEndYear(String(era.endYear ?? ""));
                                      }}
                                      data-testid={`button-edit-era-${era.eraId}`}
                                    >
                                      Edit
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="text-destructive border-destructive/40"
                                      onClick={() => {
                                        if (window.confirm("Delete this era?")) {
                                          deleteEraMutation.mutate(era.eraId);
                                        }
                                      }}
                                      data-testid={`button-delete-era-${era.eraId}`}
                                    >
                                      Delete
                                    </Button>
                                  </div>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "brands" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Brand name"
                    value={brandName}
                    onChange={(event) => setBrandName(event.target.value)}
                    data-testid="input-brand-name"
                  />
                  <Input
                    placeholder="Brand grouping (optional)"
                    value={brandGrouping}
                    onChange={(event) => setBrandGrouping(event.target.value)}
                    data-testid="input-brand-grouping"
                  />
                  <Input
                    placeholder="Brand ID (optional)"
                    type="number"
                    value={brandIdInput}
                    onChange={(event) => setBrandIdInput(event.target.value)}
                    data-testid="input-brand-id"
                  />
                  <Button
                    onClick={() => createBrandMutation.mutate()}
                    disabled={!brandName.trim() || createBrandMutation.isPending}
                    data-testid="button-create-brand"
                  >
                    {createBrandMutation.isPending ? "Saving..." : "Add Brand"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Brand</TableHead>
                        <TableHead>Grouping</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {brands.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-muted-foreground">
                            No brands found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        brands.map((brand: any) => (
                          <TableRow key={brand.brandId}>
                            <TableCell>
                              {editingBrandId === brand.brandId ? (
                                <Input
                                  value={editingBrandName}
                                  onChange={(event) => setEditingBrandName(event.target.value)}
                                  data-testid={`input-brand-name-${brand.brandId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const filters = [{"field":"brandName","operator":"eq","value":brand.brandName,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {brand.brandName}
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editingBrandId === brand.brandId ? (
                                <Input
                                  value={editingBrandGrouping}
                                  onChange={(event) => setEditingBrandGrouping(event.target.value)}
                                  data-testid={`input-brand-grouping-${brand.brandId}`}
                                />
                              ) : (
                                brand.brandGrouping || "—"
                              )}
                            </TableCell>
                            <TableCell className="text-right">{brand.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{brand.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingBrandId === brand.brandId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateBrandMutation.mutate({
                                        brandId: brand.brandId,
                                        brandName: editingBrandName.trim(),
                                        brandGrouping: editingBrandGrouping.trim() || null,
                                      })
                                    }
                                    disabled={!editingBrandName.trim() || updateBrandMutation.isPending}
                                    data-testid={`button-save-brand-${brand.brandId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingBrandId(null)}
                                    data-testid={`button-cancel-brand-${brand.brandId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingBrandId(brand.brandId);
                                      setEditingBrandName(brand.brandName ?? "");
                                      setEditingBrandGrouping(brand.brandGrouping ?? "");
                                    }}
                                    data-testid={`button-edit-brand-${brand.brandId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this brand?")) {
                                        deleteBrandMutation.mutate(brand.brandId);
                                      }
                                    }}
                                    data-testid={`button-delete-brand-${brand.brandId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "types" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Product type name"
                    value={productTypeName}
                    onChange={(event) => setProductTypeName(event.target.value)}
                    data-testid="input-product-type-name"
                  />
                  <Input
                    placeholder="Product type ID (optional)"
                    type="number"
                    value={productTypeIdInput}
                    onChange={(event) => setProductTypeIdInput(event.target.value)}
                    data-testid="input-product-type-id"
                  />
                  <Button
                    onClick={() => createProductTypeMutation.mutate()}
                    disabled={!productTypeName.trim() || createProductTypeMutation.isPending}
                    data-testid="button-create-product-type"
                  >
                    {createProductTypeMutation.isPending ? "Saving..." : "Add Product Type"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product Type</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productTypes.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-muted-foreground">
                            No product types found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        productTypes.map((type: any) => (
                          <TableRow key={type.productTypeId}>
                            <TableCell>
                              {editingProductTypeId === type.productTypeId ? (
                                <Input
                                  value={editingProductTypeName}
                                  onChange={(event) => setEditingProductTypeName(event.target.value)}
                                  data-testid={`input-product-type-name-${type.productTypeId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const filters = [{"field":"productTypeName","operator":"eq","value":type.productTypeName,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {type.productTypeName}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-right">{type.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{type.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingProductTypeId === type.productTypeId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateProductTypeMutation.mutate({
                                        productTypeId: type.productTypeId,
                                        productTypeName: editingProductTypeName.trim(),
                                      })
                                    }
                                    disabled={!editingProductTypeName.trim() || updateProductTypeMutation.isPending}
                                    data-testid={`button-save-product-type-${type.productTypeId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingProductTypeId(null)}
                                    data-testid={`button-cancel-product-type-${type.productTypeId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingProductTypeId(type.productTypeId);
                                      setEditingProductTypeName(type.productTypeName ?? "");
                                    }}
                                    data-testid={`button-edit-product-type-${type.productTypeId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this product type?")) {
                                        deleteProductTypeMutation.mutate(type.productTypeId);
                                      }
                                    }}
                                    data-testid={`button-delete-product-type-${type.productTypeId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "colours" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Magento colour name"
                    value={colourName}
                    onChange={(event) => setColourName(event.target.value)}
                    data-testid="input-colour-name"
                  />
                  <Input
                    placeholder="Magento colour ID (optional)"
                    value={colourMagentoId}
                    onChange={(event) => setColourMagentoId(event.target.value)}
                    data-testid="input-colour-magento-id"
                  />
                  <Input
                    placeholder="Brand ID (optional)"
                    type="number"
                    value={colourBrandId}
                    onChange={(event) => setColourBrandId(event.target.value)}
                    data-testid="input-colour-brand-id"
                  />
                  <Input
                    placeholder="Brand colour ID (optional)"
                    type="number"
                    value={colourBrandColourId}
                    onChange={(event) => setColourBrandColourId(event.target.value)}
                    data-testid="input-colour-brand-colour-id"
                  />
                  <Input
                    placeholder="Brand colour name (optional)"
                    value={colourBrandName}
                    onChange={(event) => setColourBrandName(event.target.value)}
                    data-testid="input-colour-brand-name"
                  />
                  <Button
                    onClick={() => createColourMutation.mutate()}
                    disabled={!colourName.trim() && !colourBrandName.trim() || createColourMutation.isPending}
                    data-testid="button-create-colour"
                  >
                    {createColourMutation.isPending ? "Saving..." : "Add Colour"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Colour</TableHead>
                        <TableHead>Magento ID</TableHead>
                        <TableHead>Brand ID</TableHead>
                        <TableHead>Brand Colour ID</TableHead>
                        <TableHead>Brand Colour</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productColours.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-muted-foreground">
                            No colours found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        productColours.map((colour: any) => (
                          <TableRow key={colour.productColourId}>
                            <TableCell>
                              {editingColourId === colour.productColourId ? (
                                <Input
                                  value={editingColourName}
                                  onChange={(event) => setEditingColourName(event.target.value)}
                                  data-testid={`input-colour-name-${colour.productColourId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const colourName = colour.magentoColourName || colour.brandColourName || `Colour ${colour.productColourId}`;
                                    const filters = [{"field":"colourName","operator":"eq","value":colourName,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {(() => {
                                    const colourName = colour.magentoColourName || colour.brandColourName || `Colour ${colour.productColourId}`;
                                    return (colour as any).brandName ? `${colourName} (${(colour as any).brandName})` : colourName;
                                  })()}
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editingColourId === colour.productColourId ? (
                                <Input
                                  value={editingColourMagentoId}
                                  onChange={(event) => setEditingColourMagentoId(event.target.value)}
                                  data-testid={`input-colour-magento-${colour.productColourId}`}
                                />
                              ) : (
                                colour.magentoColourId || "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingColourId === colour.productColourId ? (
                                <Input
                                  type="number"
                                  value={editingColourBrandId}
                                  onChange={(event) => setEditingColourBrandId(event.target.value)}
                                  data-testid={`input-colour-brand-${colour.productColourId}`}
                                />
                              ) : (
                                colour.brandId ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingColourId === colour.productColourId ? (
                                <Input
                                  type="number"
                                  value={editingColourBrandColourId}
                                  onChange={(event) => setEditingColourBrandColourId(event.target.value)}
                                  data-testid={`input-colour-brand-colour-${colour.productColourId}`}
                                />
                              ) : (
                                colour.brandColourId ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingColourId === colour.productColourId ? (
                                <Input
                                  value={editingColourBrandName}
                                  onChange={(event) => setEditingColourBrandName(event.target.value)}
                                  data-testid={`input-colour-brand-name-${colour.productColourId}`}
                                />
                              ) : (
                                colour.brandColourName || "—"
                              )}
                            </TableCell>
                            <TableCell className="text-right">{colour.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{colour.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingColourId === colour.productColourId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateColourMutation.mutate({
                                        productColourId: colour.productColourId,
                                        magentoColourName: editingColourName.trim() || null,
                                        magentoColourId: editingColourMagentoId.trim() || null,
                                        brandId: editingColourBrandId ? Number(editingColourBrandId) : null,
                                        brandColourId: editingColourBrandColourId
                                          ? Number(editingColourBrandColourId)
                                          : null,
                                        brandColourName: editingColourBrandName.trim() || null,
                                      })
                                    }
                                    disabled={
                                      (!editingColourName.trim() && !editingColourBrandName.trim()) ||
                                      updateColourMutation.isPending
                                    }
                                    data-testid={`button-save-colour-${colour.productColourId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingColourId(null)}
                                    data-testid={`button-cancel-colour-${colour.productColourId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingColourId(colour.productColourId);
                                      setEditingColourName(colour.magentoColourName ?? "");
                                      setEditingColourMagentoId(colour.magentoColourId ?? "");
                                      setEditingColourBrandId(colour.brandId ? String(colour.brandId) : "");
                                      setEditingColourBrandColourId(
                                        colour.brandColourId ? String(colour.brandColourId) : "",
                                      );
                                      setEditingColourBrandName(colour.brandColourName ?? "");
                                    }}
                                    data-testid={`button-edit-colour-${colour.productColourId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this colour?")) {
                                        deleteColourMutation.mutate(colour.productColourId);
                                      }
                                    }}
                                    data-testid={`button-delete-colour-${colour.productColourId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "sizes" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Magento size long name"
                    value={sizeLongName}
                    onChange={(event) => setSizeLongName(event.target.value)}
                    data-testid="input-size-long-name"
                  />
                  <Input
                    placeholder="Magento size short name"
                    value={sizeShortName}
                    onChange={(event) => setSizeShortName(event.target.value)}
                    data-testid="input-size-short-name"
                  />
                  <Input
                    placeholder="Magento size ID (optional)"
                    type="number"
                    value={sizeMagentoId}
                    onChange={(event) => setSizeMagentoId(event.target.value)}
                    data-testid="input-size-magento-id"
                  />
                  <Input
                    placeholder="Config options (optional)"
                    value={sizeConfigOptions}
                    onChange={(event) => setSizeConfigOptions(event.target.value)}
                    data-testid="input-size-config-options"
                  />
                  <Input
                    placeholder="Sizing category (optional)"
                    value={sizeSizingCategory}
                    onChange={(event) => setSizeSizingCategory(event.target.value)}
                    data-testid="input-size-category"
                  />
                  <Button
                    onClick={() => createSizeMutation.mutate()}
                    disabled={!sizeLongName.trim() && !sizeShortName.trim() || createSizeMutation.isPending}
                    data-testid="button-create-size"
                  >
                    {createSizeMutation.isPending ? "Saving..." : "Add Size"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Long Name</TableHead>
                        <TableHead>Short Name</TableHead>
                        <TableHead>Magento ID</TableHead>
                        <TableHead>Config</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sizes.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-muted-foreground">
                            No sizes found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        sizes.map((size: any) => (
                          <TableRow key={size.sizeId}>
                            <TableCell>
                              {editingSizeId === size.sizeId ? (
                                <Input
                                  value={editingSizeLongName}
                                  onChange={(event) => setEditingSizeLongName(event.target.value)}
                                  data-testid={`input-size-long-${size.sizeId}`}
                                />
                              ) : (
                                size.magentoSizeLongName || "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingSizeId === size.sizeId ? (
                                <Input
                                  value={editingSizeShortName}
                                  onChange={(event) => setEditingSizeShortName(event.target.value)}
                                  data-testid={`input-size-short-${size.sizeId}`}
                                />
                              ) : (
                                size.magentoSizeShortName || "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingSizeId === size.sizeId ? (
                                <Input
                                  type="number"
                                  value={editingSizeMagentoId}
                                  onChange={(event) => setEditingSizeMagentoId(event.target.value)}
                                  data-testid={`input-size-magento-${size.sizeId}`}
                                />
                              ) : (
                                size.magentoSizeId ?? "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingSizeId === size.sizeId ? (
                                <Input
                                  value={editingSizeConfigOptions}
                                  onChange={(event) => setEditingSizeConfigOptions(event.target.value)}
                                  data-testid={`input-size-config-${size.sizeId}`}
                                />
                              ) : (
                                size.configOptions || "—"
                              )}
                            </TableCell>
                            <TableCell>
                              {editingSizeId === size.sizeId ? (
                                <Input
                                  value={editingSizeSizingCategory}
                                  onChange={(event) => setEditingSizeSizingCategory(event.target.value)}
                                  data-testid={`input-size-category-${size.sizeId}`}
                                />
                              ) : (
                                size.sizingCategory || "—"
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {editingSizeId === size.sizeId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateSizeMutation.mutate({
                                        sizeId: size.sizeId,
                                        magentoSizeId: editingSizeMagentoId ? Number(editingSizeMagentoId) : null,
                                        magentoSizeShortName: editingSizeShortName.trim() || null,
                                        magentoSizeLongName: editingSizeLongName.trim() || null,
                                        configOptions: editingSizeConfigOptions.trim() || null,
                                        sizingCategory: editingSizeSizingCategory.trim() || null,
                                      })
                                    }
                                    disabled={
                                      (!editingSizeLongName.trim() && !editingSizeShortName.trim()) ||
                                      updateSizeMutation.isPending
                                    }
                                    data-testid={`button-save-size-${size.sizeId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingSizeId(null)}
                                    data-testid={`button-cancel-size-${size.sizeId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingSizeId(size.sizeId);
                                      setEditingSizeMagentoId(size.magentoSizeId ? String(size.magentoSizeId) : "");
                                      setEditingSizeShortName(size.magentoSizeShortName ?? "");
                                      setEditingSizeLongName(size.magentoSizeLongName ?? "");
                                      setEditingSizeConfigOptions(size.configOptions ?? "");
                                      setEditingSizeSizingCategory(size.sizingCategory ?? "");
                                    }}
                                    data-testid={`button-edit-size-${size.sizeId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this size?")) {
                                        deleteSizeMutation.mutate(size.sizeId);
                                      }
                                    }}
                                    data-testid={`button-delete-size-${size.sizeId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "taxClasses" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="flex gap-3 shrink-0">
                  <Input
                    placeholder="Tax class name"
                    value={taxClassName}
                    onChange={(event) => setTaxClassName(event.target.value)}
                    data-testid="input-tax-class-name"
                  />
                  <Button
                    onClick={() => createTaxClassMutation.mutate()}
                    disabled={!taxClassName.trim() || createTaxClassMutation.isPending}
                    data-testid="button-create-tax-class"
                  >
                    {createTaxClassMutation.isPending ? "Saving..." : "Add Tax Class"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tax Class</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {taxClasses.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={2} className="text-muted-foreground">
                            No tax classes found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        taxClasses.map((taxClass: any) => (
                          <TableRow key={taxClass.taxClassId}>
                            <TableCell>
                              {editingTaxClassId === taxClass.taxClassId ? (
                                <Input
                                  value={editingTaxClassName}
                                  onChange={(event) => setEditingTaxClassName(event.target.value)}
                                  data-testid={`input-tax-class-${taxClass.taxClassId}`}
                                />
                              ) : (
                                taxClass.taxClassName
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              {editingTaxClassId === taxClass.taxClassId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateTaxClassMutation.mutate({
                                        taxClassId: taxClass.taxClassId,
                                        taxClassName: editingTaxClassName.trim(),
                                      })
                                    }
                                    disabled={!editingTaxClassName.trim() || updateTaxClassMutation.isPending}
                                    data-testid={`button-save-tax-class-${taxClass.taxClassId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingTaxClassId(null)}
                                    data-testid={`button-cancel-tax-class-${taxClass.taxClassId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingTaxClassId(taxClass.taxClassId);
                                      setEditingTaxClassName(taxClass.taxClassName ?? "");
                                    }}
                                    data-testid={`button-edit-tax-class-${taxClass.taxClassId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this tax class?")) {
                                        deleteTaxClassMutation.mutate(taxClass.taxClassId);
                                      }
                                    }}
                                    data-testid={`button-delete-tax-class-${taxClass.taxClassId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "conditions" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Condition name"
                    value={conditionName}
                    onChange={(event) => setConditionName(event.target.value)}
                    data-testid="input-condition-name"
                  />
                  <Input
                    placeholder="Condition ID (optional)"
                    type="number"
                    value={conditionIdInput}
                    onChange={(event) => setConditionIdInput(event.target.value)}
                    data-testid="input-condition-id"
                  />
                  <Button
                    onClick={() => createConditionMutation.mutate()}
                    disabled={!conditionName.trim() || createConditionMutation.isPending}
                    data-testid="button-create-condition"
                  >
                    {createConditionMutation.isPending ? "Saving..." : "Add Condition"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Condition</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {conditions.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-muted-foreground">
                            No conditions found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        conditions.map((condition: any) => (
                          <TableRow key={condition.conditionId}>
                            <TableCell>
                              {editingConditionId === condition.conditionId ? (
                                <Input
                                  value={editingConditionName}
                                  onChange={(event) => setEditingConditionName(event.target.value)}
                                  data-testid={`input-condition-name-${condition.conditionId}`}
                                />
                              ) : (
                                <span
                                  className="text-blue-600 hover:underline cursor-pointer"
                                  onClick={() => {
                                    const filters = [{"field":"conditionName","operator":"eq","value":condition.conditionName,"dataType":"text","source":"product"}];
                                    navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                  }}
                                >
                                  {condition.conditionName}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-right">{condition.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{condition.variantCount ?? 0}</TableCell>
                            <TableCell className="text-right">
                              {editingConditionId === condition.conditionId ? (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() =>
                                      updateConditionMutation.mutate({
                                        conditionId: condition.conditionId,
                                        conditionName: editingConditionName.trim(),
                                      })
                                    }
                                    disabled={!editingConditionName.trim() || updateConditionMutation.isPending}
                                    data-testid={`button-save-condition-${condition.conditionId}`}
                                  >
                                    Save
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingConditionId(null)}
                                    data-testid={`button-cancel-condition-${condition.conditionId}`}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingConditionId(condition.conditionId);
                                      setEditingConditionName(condition.conditionName ?? "");
                                    }}
                                    data-testid={`button-edit-condition-${condition.conditionId}`}
                                  >
                                    Edit
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => {
                                      if (window.confirm("Delete this condition?")) {
                                        deleteConditionMutation.mutate(condition.conditionId);
                                      }
                                    }}
                                    data-testid={`button-delete-condition-${condition.conditionId}`}
                                  >
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "styles" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Style</TableHead>
                        <TableHead className="text-right">Products</TableHead>
                        <TableHead className="text-right">Variants</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productStyles.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={3} className="text-muted-foreground">
                            No product styles found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        productStyles.map((style: any) => (
                          <TableRow key={style.productStyle}>
                            <TableCell>
                              <span
                                className="text-blue-600 hover:underline cursor-pointer"
                                onClick={() => {
                                  const filters = [{"field":"productStyle","operator":"eq","value":style.productStyle,"dataType":"text","source":"product"}];
                                  navigate(`/catalog?filters=${encodeURIComponent(JSON.stringify(filters))}`);
                                }}
                              >
                                {style.productStyle}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">{style.productCount ?? 0}</TableCell>
                            <TableCell className="text-right">{style.variantCount ?? 0}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {selectedAttribute === "customAttributes" && (
              <div className="flex flex-col gap-4 min-h-0 flex-1">
                <div className="grid gap-3 sm:grid-cols-2 shrink-0">
                  <Input
                    placeholder="Attribute code"
                    value={attributeCode}
                    onChange={(event) => setAttributeCode(event.target.value)}
                    data-testid="input-attribute-code"
                  />
                  <Input
                    placeholder="Label (optional)"
                    value={attributeLabel}
                    onChange={(event) => setAttributeLabel(event.target.value)}
                    data-testid="input-attribute-label"
                  />
                  <Select
                    value={attributeDataType}
                    onValueChange={(value) =>
                      setAttributeDataType(value as "text" | "number" | "boolean" | "json")
                    }
                  >
                    <SelectTrigger data-testid="select-attribute-type">
                      <SelectValue placeholder="Data type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="text">Text</SelectItem>
                      <SelectItem value="number">Number</SelectItem>
                      <SelectItem value="boolean">Boolean</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={attributeMagentoScope}
                    onValueChange={(value) =>
                      setAttributeMagentoScope(value as "global" | "website" | "store_view")
                    }
                  >
                    <SelectTrigger data-testid="select-attribute-magento-scope">
                      <SelectValue placeholder="Magento Scope" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="global">Global</SelectItem>
                      <SelectItem value="website">Website</SelectItem>
                      <SelectItem value="store_view">Store View</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={() => createAttributeDefMutation.mutate()}
                    disabled={!attributeCode.trim() || createAttributeDefMutation.isPending}
                    data-testid="button-create-attribute-def"
                  >
                    {createAttributeDefMutation.isPending ? "Saving..." : "Add Attribute"}
                  </Button>
                </div>
                <div className="border rounded-md flex-1 min-h-0 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Code</TableHead>
                        <TableHead>Label</TableHead>
                        <TableHead>Data Type</TableHead>
                        <TableHead>Magento Scope</TableHead>
                        <TableHead>Magento Sync</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {attributeDefs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-muted-foreground">
                            No custom attributes found.
                          </TableCell>
                        </TableRow>
                      ) : (
                        attributeDefs.map((attributeDef: any) => (
                          <TableRow key={attributeDef.attributeId}>
                            <TableCell className="font-medium">{attributeDef.code}</TableCell>
                            <TableCell>{attributeDef.label ?? "—"}</TableCell>
                            <TableCell>{attributeDef.dataType ?? "—"}</TableCell>
                            <TableCell>
                              <Select
                                value={attributeDef.magentoScope ?? "global"}
                                onValueChange={(value) => {
                                  updateAttributeDefMutation.mutate({
                                    attributeId: attributeDef.attributeId,
                                    updates: { magentoScope: value },
                                  });
                                }}
                              >
                                <SelectTrigger className="w-32" data-testid={`select-magento-scope-${attributeDef.attributeId}`}>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="global">Global</SelectItem>
                                  <SelectItem value="website">Website</SelectItem>
                                  <SelectItem value="store_view">Store View</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Switch
                                checked={attributeDef.magentoSync ?? false}
                                onCheckedChange={(checked) => {
                                  updateAttributeDefMutation.mutate({
                                    attributeId: attributeDef.attributeId,
                                    updates: { magentoSync: checked },
                                  });
                                }}
                                data-testid={`switch-magento-sync-${attributeDef.attributeId}`}
                              />
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => {
                                  if (window.confirm("Delete this attribute and all its values?")) {
                                    deleteAttributeDefMutation.mutate(attributeDef.attributeId);
                                  }
                                }}
                                data-testid={`button-delete-attribute-${attributeDef.attributeId}`}
                              >
                                Delete
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
