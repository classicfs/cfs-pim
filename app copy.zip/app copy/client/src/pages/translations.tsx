import { Languages } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Translations() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="space-y-6 p-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight" data-testid="heading-translations">
            Translations
          </h1>
          <p className="mt-1 text-muted-foreground">
            Manage product translations across channels.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Coming soon</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="py-10 text-center">
              <Languages className="mx-auto mb-4 h-14 w-14 text-muted-foreground" />
              <p className="mx-auto max-w-md text-muted-foreground">
                This area will house translation workflows and review tools once the feature is ready.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
