import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FolderTree, Plus, Search, ChevronRight, ChevronDown, Trash2, Package } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Category {
  categoryId: number;
  parentId: number | null;
  name: string;
  pathKey: string;
}

interface CategoryProduct {
  productId: number;
  productSku: string | null;
  productDescription: string | null;
  enabled: boolean | null;
  brandName: string | null;
}

interface CategoryTreeNode extends Category {
  children: CategoryTreeNode[];
  depth: number;
}

const createCategorySchema = z.object({
  name: z.string().min(1, "Category name is required"),
  parentId: z.string().optional(),
});

type CreateCategoryFormData = z.infer<typeof createCategorySchema>;

function buildCategoryTree(categories: Category[]): CategoryTreeNode[] {
  const categoryMap = new Map<number, CategoryTreeNode>();
  const roots: CategoryTreeNode[] = [];

  for (const cat of categories) {
    categoryMap.set(cat.categoryId, { ...cat, children: [], depth: 0 });
  }

  for (const cat of categories) {
    const node = categoryMap.get(cat.categoryId)!;
    if (cat.parentId && categoryMap.has(cat.parentId)) {
      const parent = categoryMap.get(cat.parentId)!;
      node.depth = parent.depth + 1;
      parent.children.push(node);
    } else {
      roots.push(node);
    }
  }

  const setDepths = (nodes: CategoryTreeNode[], depth: number) => {
    for (const node of nodes) {
      node.depth = depth;
      setDepths(node.children, depth + 1);
    }
  };
  setDepths(roots, 0);

  return roots;
}

function flattenTree(nodes: CategoryTreeNode[]): CategoryTreeNode[] {
  const result: CategoryTreeNode[] = [];
  const traverse = (nodeList: CategoryTreeNode[]) => {
    for (const node of nodeList) {
      result.push(node);
      traverse(node.children);
    }
  };
  traverse(nodes);
  return result;
}

export default function Categories() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<number>>(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: categoryProducts = [], isLoading: isLoadingProducts } = useQuery<CategoryProduct[]>({
    queryKey: ["/api/categories", selectedCategoryId, "products"],
    enabled: selectedCategoryId !== null,
  });

  const selectedCategory = categories.find(c => c.categoryId === selectedCategoryId);

  const form = useForm<CreateCategoryFormData>({
    resolver: zodResolver(createCategorySchema),
    defaultValues: {
      name: "",
      parentId: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CreateCategoryFormData) => {
      return apiRequest("POST", "/api/categories", {
        name: data.name,
        parentId: data.parentId && data.parentId !== "none" ? parseInt(data.parentId) : null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({ title: "Category created successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create category",
        description: error?.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (categoryId: number) => {
      return apiRequest("DELETE", `/api/categories/${categoryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      if (selectedCategoryId) {
        setSelectedCategoryId(null);
      }
      toast({ title: "Category deleted successfully" });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete category",
        description: error?.message || "An error occurred",
        variant: "destructive",
      });
    },
  });

  const tree = useMemo(() => buildCategoryTree(categories), [categories]);
  const flatList = useMemo(() => flattenTree(tree), [tree]);

  const filteredList = useMemo(() => {
    if (!searchTerm) return flatList;
    const term = searchTerm.toLowerCase();
    return flatList.filter(c => c.name.toLowerCase().includes(term) || c.pathKey.toLowerCase().includes(term));
  }, [flatList, searchTerm]);

  const toggleExpand = (id: number) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const isVisible = (node: CategoryTreeNode): boolean => {
    if (searchTerm) return true;
    if (node.parentId === null) return true;
    let currentId: number | null = node.parentId;
    while (currentId !== null) {
      if (!expandedIds.has(currentId)) return false;
      const parent = categories.find(c => c.categoryId === currentId);
      currentId = parent?.parentId ?? null;
    }
    return true;
  };

  const visibleCategories = filteredList.filter(isVisible);

  const onSubmit = (data: CreateCategoryFormData) => {
    createMutation.mutate(data);
  };

  return (
    <div className="flex h-full" data-testid="categories-page">
      <div className="w-1/3 border-r p-4 overflow-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <FolderTree className="h-5 w-5" />
            Categories
          </h2>
          <Button
            size="sm"
            onClick={() => {
              form.reset({
                name: "",
                parentId: selectedCategoryId ? String(selectedCategoryId) : "none",
              });
              setIsCreateDialogOpen(true);
            }}
            data-testid="button-create-category"
          >
            <Plus className="h-4 w-4 mr-1" />
            New
          </Button>
        </div>

        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
            data-testid="input-search-categories"
          />
        </div>

        {isLoading ? (
          <div className="text-muted-foreground text-sm">Loading...</div>
        ) : visibleCategories.length === 0 ? (
          <div className="text-muted-foreground text-sm">No categories found</div>
        ) : (
          <div className="space-y-1">
            {visibleCategories.map((cat) => {
              const hasChildren = cat.children.length > 0;
              const isExpanded = expandedIds.has(cat.categoryId);
              const isSelected = selectedCategoryId === cat.categoryId;

              return (
                <div
                  key={cat.categoryId}
                  className={`flex items-center gap-1 px-2 py-1.5 rounded cursor-pointer hover-elevate ${
                    isSelected ? "bg-accent" : ""
                  }`}
                  style={{ paddingLeft: `${cat.depth * 16 + 8}px` }}
                  onClick={() => setSelectedCategoryId(cat.categoryId)}
                  data-testid={`category-item-${cat.categoryId}`}
                >
                  {hasChildren ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleExpand(cat.categoryId);
                      }}
                      className="p-0.5"
                      data-testid={`button-expand-${cat.categoryId}`}
                    >
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </button>
                  ) : (
                    <span className="w-5" />
                  )}
                  <span className="truncate flex-1">{cat.name}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex-1 p-4 overflow-auto">
        {selectedCategory ? (
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2">
              <div>
                <CardTitle className="text-lg">{selectedCategory.name}</CardTitle>
                <p className="text-sm text-muted-foreground mt-1">{selectedCategory.pathKey}</p>
              </div>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => deleteMutation.mutate(selectedCategory.categoryId)}
                disabled={deleteMutation.isPending}
                data-testid="button-delete-category"
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </CardHeader>
            <CardContent>
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <Package className="h-4 w-4" />
                Products in this category
              </h3>
              {isLoadingProducts ? (
                <div className="text-muted-foreground text-sm">Loading products...</div>
              ) : categoryProducts.length === 0 ? (
                <div className="text-muted-foreground text-sm">No products assigned to this category</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>SKU</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Brand</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryProducts.map((p) => (
                      <TableRow key={p.productId} data-testid={`product-row-${p.productId}`}>
                        <TableCell className="font-mono">{p.productSku || "-"}</TableCell>
                        <TableCell>{p.productDescription || "-"}</TableCell>
                        <TableCell>{p.brandName || "-"}</TableCell>
                        <TableCell>
                          <Badge variant={p.enabled ? "default" : "secondary"}>
                            {p.enabled ? "Enabled" : "Disabled"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <FolderTree className="h-12 w-12 mb-4" />
            <p>Select a category to view its products</p>
          </div>
        )}
      </div>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Category</DialogTitle>
            <DialogDescription>
              Add a new category to organize your products
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. Training Wear"
                        {...field}
                        data-testid="input-category-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="parentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Parent Category (optional)</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-parent-category">
                          <SelectValue placeholder="Select a parent category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">None (root category)</SelectItem>
                        {categories.map((cat) => (
                          <SelectItem key={cat.categoryId} value={String(cat.categoryId)}>
                            {cat.pathKey}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                  data-testid="button-cancel-create"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  data-testid="button-submit-category"
                >
                  {createMutation.isPending ? "Creating..." : "Create Category"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
