import {
  pgSchema,
  pgTable,
  text,
  bigint,
  bigserial,
  integer,
  boolean,
  numeric,
  timestamp,
  jsonb,
  smallint,
  date,
  real,
  primaryKey,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

const pim = pgSchema("pim");

// App users, Google auth, roles & permissions
export const appUser = pim.table("app_user", {
  appUserId: bigserial("app_user_id", { mode: "number" }).primaryKey(),
  email: text("email").notNull().unique(),
  googleSub: text("google_sub").notNull().unique(),
  displayName: text("display_name"),
  givenName: text("given_name"),
  familyName: text("family_name"),
  avatarUrl: text("avatar_url"),
  status: text("status").notNull(),
  lastLoginAt: timestamp("last_login_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
});

export const authIdentity = pim.table(
  "auth_identity",
  {
    authIdentityId: bigserial("auth_identity_id", { mode: "number" }).primaryKey(),
    appUserId: bigint("app_user_id", { mode: "number" })
      .notNull()
      .references(() => appUser.appUserId),
    provider: text("provider").notNull(),
    providerSubject: text("provider_subject").notNull(),
    providerEmail: text("provider_email"),
    providerPayload: jsonb("provider_payload"),
    createdAt: timestamp("created_at", { mode: "date" }),
    updatedAt: timestamp("updated_at", { mode: "date" }),
  },
  (table) => ({
    providerSubjectIdx: uniqueIndex("uq_provider_subject").on(
      table.provider,
      table.providerSubject,
    ),
    appUserIdIdx: index("auth_identity_app_user_id").on(table.appUserId),
  }),
);

export const appSession = pim.table("app_session", {
  appSessionId: bigserial("app_session_id", { mode: "number" }).primaryKey(),
  appUserId: bigint("app_user_id", { mode: "number" })
    .notNull()
    .references(() => appUser.appUserId),
  sessionTokenHash: text("session_token_hash").notNull().unique(),
  createdAt: timestamp("created_at", { mode: "date" }),
  expiresAt: timestamp("expires_at", { mode: "date" }),
  revokedAt: timestamp("revoked_at", { mode: "date" }),
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
});

export const appRole = pim.table("app_role", {
  appRoleId: bigserial("app_role_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  isSystem: boolean("is_system"),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
});

export const appUserRole = pim.table(
  "app_user_role",
  {
    appUserId: bigint("app_user_id", { mode: "number" })
      .notNull()
      .references(() => appUser.appUserId),
    appRoleId: bigint("app_role_id", { mode: "number" })
      .notNull()
      .references(() => appRole.appRoleId),
    assignedAt: timestamp("assigned_at", { mode: "date" }),
    assignedBy: bigint("assigned_by", { mode: "number" }).references(() => appUser.appUserId),
    assignedReason: text("assigned_reason"),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.appUserId, table.appRoleId] }),
  }),
);

export const appPermission = pim.table("app_permission", {
  appPermissionId: bigserial("app_permission_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name"),
  description: text("description"),
});

export const appRolePermission = pim.table(
  "app_role_permission",
  {
    appRoleId: bigint("app_role_id", { mode: "number" })
      .notNull()
      .references(() => appRole.appRoleId),
    appPermissionId: bigint("app_permission_id", { mode: "number" })
      .notNull()
      .references(() => appPermission.appPermissionId),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.appRoleId, table.appPermissionId] }),
  }),
);

export const auditEvent = pim.table("audit_event", {
  auditEventId: bigserial("audit_event_id", { mode: "number" }).primaryKey(),
  actorUserId: bigint("actor_user_id", { mode: "number" }).references(() => appUser.appUserId),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: text("entity_id"),
  diffJson: jsonb("diff_json"),
  createdAt: timestamp("created_at", { mode: "date" }),
});

// CSV import staging (generic)
export const importJob = pim.table("import_job", {
  importJobId: bigserial("import_job_id", { mode: "number" }).primaryKey(),
  createdBy: bigint("created_by", { mode: "number" }).references(() => appUser.appUserId),
  sourceType: text("source_type"),
  importType: text("import_type").notNull(),
  status: text("status").notNull(),
  originalFilename: text("original_filename"),
  fileSha256: text("file_sha256"),
  totalRows: integer("total_rows"),
  validRows: integer("valid_rows"),
  invalidRows: integer("invalid_rows"),
  appliedRows: integer("applied_rows"),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
  appliedAt: timestamp("applied_at", { mode: "date" }),
});

export const importRow = pim.table(
  "import_row",
  {
    importRowId: bigserial("import_row_id", { mode: "number" }).primaryKey(),
    importJobId: bigint("import_job_id", { mode: "number" })
      .notNull()
      .references(() => importJob.importJobId),
    rowNumber: integer("row_number").notNull(),
    rowRaw: jsonb("row_raw").notNull(),
    rowNormalized: jsonb("row_normalized"),
    rowStatus: text("row_status").notNull(),
    rowKey: text("row_key"),
    createdAt: timestamp("created_at", { mode: "date" }),
    updatedAt: timestamp("updated_at", { mode: "date" }),
  },
  (table) => ({
    jobRowUnique: uniqueIndex("import_row_job_row_unique").on(
      table.importJobId,
      table.rowNumber,
    ),
    jobStatusIdx: index("import_row_job_status_idx").on(
      table.importJobId,
      table.rowStatus,
    ),
  }),
);

export const importError = pim.table("import_error", {
  importErrorId: bigserial("import_error_id", { mode: "number" }).primaryKey(),
  importRowId: bigint("import_row_id", { mode: "number" })
    .notNull()
    .references(() => importRow.importRowId),
  fieldKey: text("field_key"),
  errorCode: text("error_code"),
  errorMessage: text("error_message"),
  metaJson: jsonb("meta_json"),
  createdAt: timestamp("created_at", { mode: "date" }),
});

// Core reference data
export const brands = pim.table("brands", {
  brandId: integer("brand_id").primaryKey(),
  brandGrouping: text("brand_grouping"),
  brandName: text("brand_name"),
});

export const productType = pim.table("product_type", {
  productTypeId: integer("product_type_id").primaryKey(),
  productTypeName: text("product_type_name"),
});

export const condition = pim.table("condition", {
  conditionId: integer("condition_id").primaryKey(),
  conditionName: text("condition_name"),
});

export const gender = pim.table("gender", {
  genderId: bigserial("gender_id", { mode: "number" }).primaryKey(),
  genderName: text("gender_name"),
});

export const taxClass = pim.table("tax_class", {
  taxClassId: bigserial("tax_class_id", { mode: "number" }).primaryKey(),
  taxClassName: text("tax_class_name").notNull().unique(),
});

export const productColour = pim.table("product_colour", {
  productColourId: bigserial("product_colour_id", { mode: "number" }).primaryKey(),
  magentoColourId: text("magento_colour_id"),
  magentoColourName: text("magento_colour_name"),
  brandId: integer("brand_id"),
  brandColourId: integer("brand_colour_id"),
  brandColourName: text("brand_colour_name"),
});

export const productSizes = pim.table("product_sizes", {
  sizeId: bigserial("size_id", { mode: "number" }).primaryKey(),
  magentoSizeId: integer("magento_size_id"),
  magentoSizeShortName: text("magento_size_short_name"),
  magentoSizeLongName: text("magento_size_long_name"),
  configOptions: text("config_options"),
  sizingCategory: text("sizing_category"),
});

// Era (reference) — product-level FK
export const era = pim.table("era", {
  eraId: bigserial("era_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
  startYear: integer("start_year").notNull(),
  endYear: integer("end_year").notNull(),
});

// Currency
export const currency = pim.table("currency", {
  currencyId: bigserial("currency_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name"),
  symbol: text("symbol"),
  minorUnit: smallint("minor_unit"),
  enabled: boolean("enabled"),
});

// Category hierarchy
export const category = pim.table("category", {
  categoryId: bigserial("category_id", { mode: "number" }).primaryKey(),
  parentId: bigint("parent_id", { mode: "number" }).references(() => category.categoryId),
  name: text("name").notNull(),
  pathKey: text("path_key").notNull().unique(),
});

export const productCategory = pim.table(
  "product_category",
  {
    productId: bigint("product_id", { mode: "number" })
      .notNull()
      .references(() => product.productId),
    categoryId: bigint("category_id", { mode: "number" })
      .notNull()
      .references(() => category.categoryId),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productId, table.categoryId] }),
  }),
);

// Stores & currencies
export const store = pim.table("store", {
  storeId: bigserial("store_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name"),
  websiteCode: text("website_code").notNull(),
});

export const storeCurrency = pim.table(
  "store_currency",
  {
    storeId: bigint("store_id", { mode: "number" })
      .notNull()
      .references(() => store.storeId),
    currencyId: bigint("currency_id", { mode: "number" })
      .notNull()
      .references(() => currency.currencyId),
    isDefault: boolean("is_default"),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.storeId, table.currencyId] }),
  }),
);

// Product-Store assignment (which stores a product is available in)
export const productStore = pim.table(
  "product_store",
  {
    productId: bigint("product_id", { mode: "number" })
      .notNull()
      .references(() => product.productId),
    storeId: bigint("store_id", { mode: "number" })
      .notNull()
      .references(() => store.storeId),
    enabled: boolean("enabled").default(true),
    createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productId, table.storeId] }),
  }),
);

// Per-currency pricing
export const variantPrice = pim.table(
  "variant_price",
  {
    variantPriceId: bigserial("variant_price_id", { mode: "number" }).primaryKey(),
    productVariantId: bigint("product_variant_id", { mode: "number" }).references(
      () => productVariant.productVariantId,
    ),
    currencyId: bigint("currency_id", { mode: "number" }).references(() => currency.currencyId),
    costPrice: numeric("cost_price", { precision: 12, scale: 2 }),
    averageCostPrice: numeric("average_cost_price", { precision: 12, scale: 2 }),
    retailPrice: numeric("retail_price", { precision: 12, scale: 2 }),
    specialRetailPrice: numeric("special_retail_price", { precision: 12, scale: 2 }),
    customerPrice: numeric("customer_price", { precision: 12, scale: 2 }),
    isManualOverride: boolean("is_manual_override").default(false),
    validFrom: timestamp("valid_from", { mode: "date" }),
    validTo: timestamp("valid_to", { mode: "date" }),
  },
  (table) => ({
    variantCurrencyIdx: index("variant_price_variant_currency_idx").on(
      table.productVariantId,
      table.currencyId,
    ),
    variantCurrencyPeriod: uniqueIndex("uq_variant_currency_period").on(
      table.productVariantId,
      table.currencyId,
      table.validFrom,
      table.validTo,
    ),
  }),
);

// Currency conversion rates (e.g. GBP → EUR, GBP → USD)
export const currencyConversionRate = pim.table(
  "currency_conversion_rate",
  {
    conversionRateId: bigserial("conversion_rate_id", { mode: "number" }).primaryKey(),
    fromCurrencyId: bigint("from_currency_id", { mode: "number" })
      .notNull()
      .references(() => currency.currencyId),
    toCurrencyId: bigint("to_currency_id", { mode: "number" })
      .notNull()
      .references(() => currency.currencyId),
    rate: numeric("rate", { precision: 12, scale: 6 }).notNull(),
    updatedAt: timestamp("updated_at", { mode: "date" }),
  },
  (table) => ({
    fromToUnique: uniqueIndex("uq_conversion_from_to").on(
      table.fromCurrencyId,
      table.toCurrencyId,
    ),
  }),
);

// Warehouse & stock
export const warehouse = pim.table("warehouse", {
  warehouseId: bigserial("warehouse_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name"),
});

export const variantStock = pim.table(
  "product_stock",
  {
    productVariantId: bigint("product_id", { mode: "number" })
      .notNull()
      .references(() => product.productId),
    warehouseId: bigint("warehouse_id", { mode: "number" })
      .notNull()
      .references(() => warehouse.warehouseId),
    qty: integer("qty"),
    binLocation: text("bin_location"),
    lastCountedAt: timestamp("last_counted_at", { mode: "date" }),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productVariantId, table.warehouseId] }),
  }),
);

// Images per variant
export const imageAsset = pim.table("image_asset", {
  imageId: bigserial("image_id", { mode: "number" }).primaryKey(),
  productId: bigint("product_id", { mode: "number" }).references(
    () => product.productId,
  ),
  role: text("role").notNull(),
  url: text("url").notNull(),
  label: text("label"),
  sortOrder: integer("sort_order"),
});

// Dynamic attributes (EAV)
export const attributeDef = pim.table("attribute_def", {
  attributeId: bigserial("attribute_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  label: text("label"),
  dataType: text("data_type"),
  scope: text("scope"),
  magentoSync: boolean("magento_sync").default(false),
  magentoScope: text("magento_scope").notNull().default("global"),
});

export const productAttributeVal = pim.table(
  "product_attribute_val",
  {
    productId: bigint("product_id", { mode: "number" })
      .notNull()
      .references(() => product.productId),
    attributeId: bigint("attribute_id", { mode: "number" })
      .notNull()
      .references(() => attributeDef.attributeId),
    valueText: text("value_text"),
    valueNum: numeric("value_num"),
    valueBool: boolean("value_bool"),
    valueJson: jsonb("value_json"),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productId, table.attributeId] }),
  }),
);

export const variantAttributeVal = pim.table(
  "variant_attribute_val",
  {
    productVariantId: bigint("product_variant_id", { mode: "number" })
      .notNull()
      .references(() => productVariant.productVariantId),
    attributeId: bigint("attribute_id", { mode: "number" })
      .notNull()
      .references(() => attributeDef.attributeId),
    valueText: text("value_text"),
    valueNum: numeric("value_num"),
    valueBool: boolean("value_bool"),
    valueJson: jsonb("value_json"),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productVariantId, table.attributeId] }),
  }),
);

// Team / club / season metadata
export const club = pim.table("club", {
  clubId: bigserial("club_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
  country: text("country"),
  foundedYear: integer("founded_year"),
});

export const competition = pim.table("competition", {
  competitionId: bigserial("competition_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
  country: text("country"),
});

export const season = pim.table("season", {
  seasonId: bigserial("season_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  yearStart: integer("year_start"),
  yearEnd: integer("year_end"),
});

export const department = pim.table("department", {
  departmentId: bigserial("department_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
});

export const kitCategory = pim.table("kit_category", {
  kitCategoryId: bigserial("kit_category_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
});

export const kitClass = pim.table("kit_class", {
  kitClassId: bigserial("kit_class_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull().unique(),
});

export const productTeamMeta = pim.table("product_team_meta", {
  productTeamMetaId: bigserial("product_team_meta_id", { mode: "number" }).primaryKey(),
  productId: bigint("product_id", { mode: "number" }).references(() => product.productId),
  clubId: bigint("club_id", { mode: "number" }).references(() => club.clubId),
  competitionId: bigint("competition_id", { mode: "number" }).references(() => competition.competitionId),
  seasonId: bigint("season_id", { mode: "number" }).references(() => season.seasonId),
  departmentId: bigint("department_id", { mode: "number" }).references(() => department.departmentId),
  kitCategoryId: bigint("kit_category_id", { mode: "number" }).references(
    () => kitCategory.kitCategoryId,
  ),
  kitClassId: bigint("kit_class_id", { mode: "number" }).references(() => kitClass.kitClassId),
  isPrimary: boolean("is_primary"),
});

// Channel product IDs
export const channel = pim.table("channel", {
  channelId: bigserial("channel_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name"),
});

export const variantChannelId = pim.table(
  "variant_channel_id",
  {
    productVariantId: bigint("product_variant_id", { mode: "number" })
      .notNull()
      .references(() => productVariant.productVariantId),
    channelId: bigint("channel_id", { mode: "number" })
      .notNull()
      .references(() => channel.channelId),
    externalProductId: text("external_product_id"),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.productVariantId, table.channelId] }),
  }),
);

// Core product (v2 flat table — maps v1 field names to v2 DB columns)
export const product = pim.table("product", {
  productId: bigserial("product_id", { mode: "number" }).primaryKey(),
  productSku: text("sku").unique(),
  parentSku: text("parent_sku"),
  productType: text("product_type").notNull().default("simple"),
  articleNumber: text("article_number"),
  name: text("name"),
  productDescription: text("product_description"),
  productColourId: integer("product_colour_id").references(() => productColour.productColourId),
  genderId: integer("gender_id").references(() => gender.genderId),
  eraId: bigint("era_id", { mode: "number" }).references(() => era.eraId),
  brandId: integer("brand_id").references(() => brands.brandId),
  productTypeId: integer("product_type_id").references(() => productType.productTypeId),
  productStyle: text("product_style"),
  sizeId: integer("size_id").references(() => productSizes.sizeId),
  conditionId: integer("condition_id").references(() => condition.conditionId),
  conditionDetail: text("condition_detail"),
  barcode: text("barcode").unique(),
  widthCm: integer("width_cm"),
  lengthCm: integer("length_cm"),
  weight: numeric("weight", { precision: 12, scale: 3 }),
  depth: numeric("depth", { precision: 12, scale: 3 }),
  costPrice: numeric("cost_price", { precision: 12, scale: 2 }),
  averageCostPrice: numeric("average_cost_price", { precision: 12, scale: 2 }),
  customerPrice: numeric("customer_price", { precision: 12, scale: 2 }),
  printed: boolean("printed"),
  magentoProductId: integer("magento_product_id"),
  taxClassId: integer("tax_class_id").references(() => taxClass.taxClassId),
  composition: text("composition"),
  countryOfManufacture: text("country_of_manufacture"),
  commodityCode: text("commodity_code"),
  imageCode: text("image_code"),
  enabled: boolean("enabled"),
  sync: boolean("sync").default(false),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
  updatedBy: bigint("updated_by", { mode: "number" }).references(() => appUser.appUserId),
});

export const productVariant = pim.table("product_variant", {
  productVariantId: bigserial("product_variant_id", { mode: "number" }).primaryKey(),
  productId: bigint("product_id", { mode: "number" }).references(() => product.productId),
  productVariantSku: text("product_variant_sku").notNull().unique(),
  sizeId: integer("size_id").references(() => productSizes.sizeId),
  taxClassId: integer("tax_class_id").references(() => taxClass.taxClassId),
  conditionId: integer("condition_id").references(() => condition.conditionId),
  conditionDetail: text("condition_detail"),
  barcode: text("barcode").unique(),
  widthCm: integer("width_cm"),
  lengthCm: integer("length_cm"),
  weight: numeric("weight", { precision: 12, scale: 3 }),
  depth: numeric("depth", { precision: 12, scale: 3 }),
  costPrice: numeric("cost_price", { precision: 12, scale: 2 }),
  averageCostPrice: numeric("average_cost_price", { precision: 12, scale: 2 }),
  customerPrice: numeric("customer_price", { precision: 12, scale: 2 }),
  printed: boolean("printed"),
  magentoProductId: integer("magento_product_id"),
  enabled: boolean("enabled"),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
  updatedBy: bigint("updated_by", { mode: "number" }).references(() => appUser.appUserId),
});

export const variantBarcode = pim.table("variant_barcode", {
  variantBarcodeId: bigserial("variant_barcode_id", { mode: "number" }).primaryKey(),
  variantId: bigint("variant_id", { mode: "number" }).references(
    () => productVariant.productVariantId,
  ),
  barcodeType: text("barcode_type"),
  barcodeValue: text("barcode_value").notNull().unique(),
  isPrimary: boolean("is_primary"),
  status: text("status"),
  source: text("source"),
  verifiedAt: timestamp("verified_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }),
});

// Product grouping
export const productGroup = pim.table("product_group", {
  productGroupId: bigserial("product_group_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull(),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: timestamp("created_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }),
  createdBy: bigint("created_by", { mode: "number" }).references(() => appUser.appUserId),
  updatedBy: bigint("updated_by", { mode: "number" }).references(() => appUser.appUserId),
});

export const productGroupMember = pim.table(
  "product_group_member",
  {
    productGroupMemberId: bigserial("product_group_member_id", { mode: "number" }).primaryKey(),
    productGroupId: bigint("product_group_id", { mode: "number" })
      .notNull()
      .references(() => productGroup.productGroupId),
    productId: bigint("product_id", { mode: "number" })
      .notNull()
      .references(() => product.productId),
    addedAt: timestamp("added_at", { mode: "date" }),
    addedBy: bigint("added_by", { mode: "number" }).references(() => appUser.appUserId),
    startDate: timestamp("start_date", { mode: "date" }),
    endDate: timestamp("end_date", { mode: "date" }),
    live: boolean("live").notNull().default(true),
  },
);

// Rivalries
export const rivalryType = pim.table("rivalry_type", {
  rivalryTypeId: bigserial("rivalry_type_id", { mode: "number" }).primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
});

export const clubRivalry = pim.table(
  "club_rivalry",
  {
    clubRivalryId: bigserial("club_rivalry_id", { mode: "number" }).primaryKey(),
    clubIdA: bigint("club_id_a", { mode: "number" })
      .notNull()
      .references(() => club.clubId),
    clubIdB: bigint("club_id_b", { mode: "number" })
      .notNull()
      .references(() => club.clubId),
    rivalryTypeId: bigint("rivalry_type_id", { mode: "number" })
      .notNull()
      .references(() => rivalryType.rivalryTypeId),
    knownAs: text("known_as"),
    intensity: smallint("intensity"),
    periodStart: date("period_start"),
    periodEnd: date("period_end"),
    isPrimary: boolean("is_primary"),
    notes: text("notes"),
  },
  (table) => ({
    clubPairIdx: index("club_rivalry_pair_idx").on(table.clubIdA, table.clubIdB),
    rivalryTypeIdx: index("club_rivalry_type_idx").on(table.rivalryTypeId),
    periodIdx: index("club_rivalry_period_idx").on(table.periodStart, table.periodEnd),
    pairTypePeriod: uniqueIndex("uq_pair_type_period").on(
      table.clubIdA,
      table.clubIdB,
      table.rivalryTypeId,
      table.periodStart,
      table.periodEnd,
    ),
  }),
);

export const clubRivalsExpanded = pim.table("club_rivals_expanded", {
  clubRivalryId: bigint("club_rivalry_id", { mode: "number" }).references(
    () => clubRivalry.clubRivalryId,
  ),
  clubId: bigint("club_id", { mode: "number" }).references(() => club.clubId),
  rivalClubId: bigint("rival_club_id", { mode: "number" }).references(() => club.clubId),
  rivalryTypeId: bigint("rivalry_type_id", { mode: "number" }).references(
    () => rivalryType.rivalryTypeId,
  ),
  knownAs: text("known_as"),
  intensity: smallint("intensity"),
  periodStart: date("period_start"),
  periodEnd: date("period_end"),
  isPrimary: boolean("is_primary"),
  notes: text("notes"),
});

export const rivalryIntensityRef = pim.table("rivalry_intensity_ref", {
  bandId: bigserial("band_id", { mode: "number" }).primaryKey(),
  label: text("label").notNull(),
  minScore: smallint("min_score").notNull(),
  maxScore: smallint("max_score").notNull(),
});

// Scheduled changes
export const scheduledChange = pim.table("scheduled_change", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  scheduledAt: timestamp("scheduled_at", { mode: "date" }).notNull(),
  endsAt: timestamp("ends_at", { mode: "date" }),
  status: text("status").notNull().default("pending"),
  scopeType: text("scope_type").notNull(),
  scopeGroupId: bigint("scope_group_id", { mode: "number" }).references(() => productGroup.productGroupId),
  createdBy: bigint("created_by", { mode: "number" }).references(() => appUser.appUserId),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
  appliedAt: timestamp("applied_at", { mode: "date" }),
  revertedAt: timestamp("reverted_at", { mode: "date" }),
  errorMessage: text("error_message"),
}, (table) => ({
  statusIdx: index("scheduled_change_status_idx").on(table.status),
  scheduledAtIdx: index("scheduled_change_scheduled_at_idx").on(table.scheduledAt),
}));

export const scheduledChangeItem = pim.table("scheduled_change_item", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  scheduledChangeId: bigint("scheduled_change_id", { mode: "number" })
    .notNull()
    .references(() => scheduledChange.id),
  productId: bigint("product_id", { mode: "number" }).references(() => product.productId),
  variantId: bigint("variant_id", { mode: "number" }).references(() => productVariant.productVariantId),
  entityType: text("entity_type").notNull(),
  fieldName: text("field_name").notNull(),
  newValue: text("new_value"),
  oldValue: text("old_value"),
  changeMode: text("change_mode").default("absolute"),
  status: text("status").notNull().default("pending"),
  errorMessage: text("error_message"),
}, (table) => ({
  changeIdx: index("scheduled_change_item_change_idx").on(table.scheduledChangeId),
}));

// Audit / Payload tables
export const payloads = pim.table("payloads", {
  payloadId: bigserial("payload_id", { mode: "number" }).primaryKey(),
  payloadType: text("payload_type"),
  lastRunDate: timestamp("last_run_date", { mode: "date" }),
  payloadLocation: text("payload_location"),
});

// Type exports for commonly used tables
export type AppUser = typeof appUser.$inferSelect;
export type AppRole = typeof appRole.$inferSelect;
export type AppPermission = typeof appPermission.$inferSelect;
export type ImportJob = typeof importJob.$inferSelect;
export type ImportRow = typeof importRow.$inferSelect;
export type ImportError = typeof importError.$inferSelect;
export type Product = typeof product.$inferSelect;
export type ProductVariant = typeof productVariant.$inferSelect;
export type Store = typeof store.$inferSelect;
export type ProductStore = typeof productStore.$inferSelect;
export type Warehouse = typeof warehouse.$inferSelect;
export type Club = typeof club.$inferSelect;
export type Season = typeof season.$inferSelect;
export type Category = typeof category.$inferSelect;
export type VariantStock = typeof variantStock.$inferSelect;
export type VariantPrice = typeof variantPrice.$inferSelect;
export type CurrencyConversionRate = typeof currencyConversionRate.$inferSelect;
export type Era = typeof era.$inferSelect;
export type ProductGroup = typeof productGroup.$inferSelect;
export type ProductGroupMember = typeof productGroupMember.$inferSelect;
export type ScheduledChange = typeof scheduledChange.$inferSelect;
export type ScheduledChangeItem = typeof scheduledChangeItem.$inferSelect;

// De-normalized product type with reference data (used by UI)
export type ProductWithDetails = {
  productId: number;
  productSku: string | null;
  articleNumber: string | null;
  productDescription: string | null;
  productStyle: string | null;
  composition: string | null;
  countryOfManufacture: string | null;
  commodityCode: string | null;
  imageCode: string | null;
  brandId: number | null;
  brandName: string | null;
  genderId: number | null;
  genderName: string | null;
  productTypeId: number | null;
  productTypeName: string | null;
  productColourId: number | null;
  colourName: string | null;
  teamId: number | null;
  teamName: string | null;
  enabled: boolean | null;
  sync: boolean | null;
  createdAt: Date | null;
  updatedAt: Date | null;
  variantCount: number;
  dataAttribution: number;
  missingFields: string | null;
  totalStock: number;
  groups: string | null;
};

export const alumioSyncLog = pim.table("alumio_sync_log", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  requestData: jsonb("request_data"),
  responseData: jsonb("response_data"),
  httpStatusCode: integer("http_status_code").notNull(),
  responseMessage: text("response_message"),
  skus: text("skus").array(),
  operationType: jsonb("operation_type"),
  errorSource: text("error_source"),
  taskId: text("task_id"),
  duration: real("duration"),
  retryNumber: integer("retry_number"),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
});

export type AlumioOperationTypeEntry = { sku: string; operationType: string };

export type AlumioSyncLog = Omit<typeof alumioSyncLog.$inferSelect, "operationType"> & {
  operationType: AlumioOperationTypeEntry[] | null;
};
export type InsertAlumioSyncLog = Omit<typeof alumioSyncLog.$inferInsert, "operationType"> & {
  operationType: AlumioOperationTypeEntry[] | null;
};

export const alumioSyncQueue = pim.table("alumio_sync_queue", {
  id: bigserial("id", { mode: "number" }).primaryKey(),
  productId: bigint("product_id", { mode: "number" })
    .notNull()
    .references(() => product.productId),
  productVariantId: bigint("product_variant_id", { mode: "number" }).references(
    () => productVariant.productVariantId,
  ),
  operationType: text("operation_type").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
  processedAt: timestamp("processed_at", { mode: "date" }),
}, (table) => ({
  statusIdx: index("alumio_sync_queue_status_idx").on(table.status),
  productIdx: index("alumio_sync_queue_product_idx").on(table.productId),
}));

export type AlumioSyncQueue = typeof alumioSyncQueue.$inferSelect;
export type InsertAlumioSyncQueue = typeof alumioSyncQueue.$inferInsert;

export const workspaceSetting = pim.table("workspace_setting", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow(),
});

export type WorkspaceSetting = typeof workspaceSetting.$inferSelect;

export const apiKey = pim.table("api_key", {
  apiKeyId: bigserial("api_key_id", { mode: "number" }).primaryKey(),
  name: text("name").notNull(),
  keyHash: text("key_hash").notNull().unique(),
  keyPrefix: text("key_prefix").notNull(),
  scopes: text("scopes").array().notNull(),
  active: boolean("active").notNull().default(true),
  lastUsedAt: timestamp("last_used_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
  createdBy: bigint("created_by", { mode: "number" }).references(() => appUser.appUserId),
});

export type ApiKey = typeof apiKey.$inferSelect;
export type InsertApiKey = typeof apiKey.$inferInsert;

export type ProductVariantWithInherited = ProductVariant & {
  brandId: number | null;
  brandName: string | null;
  genderId: number | null;
  genderName: string | null;
  productTypeId: number | null;
  productTypeName: string | null;
  productColourId: number | null;
  colourName: string | null;
  productStyle: string | null;
  composition: string | null;
  countryOfManufacture: string | null;
  commodityCode: string | null;
  imageCode: string | null;
  articleNumber: string | null;
  productVariantDescription: string | null;
  colour: string | null;
  stockLevel: number;
};
