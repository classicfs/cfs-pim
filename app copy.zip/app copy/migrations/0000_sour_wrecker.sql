CREATE TABLE "pim"."app_permission" (
	"app_permission_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text,
	"description" text,
	CONSTRAINT "app_permission_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."app_role" (
	"app_role_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"is_system" boolean,
	"created_at" timestamp,
	"updated_at" timestamp,
	CONSTRAINT "app_role_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."app_role_permission" (
	"app_role_id" bigint NOT NULL,
	"app_permission_id" bigint NOT NULL,
	CONSTRAINT "app_role_permission_app_role_id_app_permission_id_pk" PRIMARY KEY("app_role_id","app_permission_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."app_session" (
	"app_session_id" bigserial PRIMARY KEY NOT NULL,
	"app_user_id" bigint NOT NULL,
	"session_token_hash" text NOT NULL,
	"created_at" timestamp,
	"expires_at" timestamp,
	"revoked_at" timestamp,
	"user_agent" text,
	"ip_address" text,
	CONSTRAINT "app_session_session_token_hash_unique" UNIQUE("session_token_hash")
);
--> statement-breakpoint
CREATE TABLE "pim"."app_user" (
	"app_user_id" bigserial PRIMARY KEY NOT NULL,
	"email" text NOT NULL,
	"google_sub" text NOT NULL,
	"display_name" text,
	"given_name" text,
	"family_name" text,
	"avatar_url" text,
	"status" text NOT NULL,
	"last_login_at" timestamp,
	"created_at" timestamp,
	"updated_at" timestamp,
	CONSTRAINT "app_user_email_unique" UNIQUE("email"),
	CONSTRAINT "app_user_google_sub_unique" UNIQUE("google_sub")
);
--> statement-breakpoint
CREATE TABLE "pim"."app_user_role" (
	"app_user_id" bigint NOT NULL,
	"app_role_id" bigint NOT NULL,
	"assigned_at" timestamp,
	"assigned_by" bigint,
	"assigned_reason" text,
	CONSTRAINT "app_user_role_app_user_id_app_role_id_pk" PRIMARY KEY("app_user_id","app_role_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."attribute_def" (
	"attribute_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"label" text,
	"data_type" text,
	"scope" text,
	CONSTRAINT "attribute_def_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."audit_event" (
	"audit_event_id" bigserial PRIMARY KEY NOT NULL,
	"actor_user_id" bigint,
	"action" text NOT NULL,
	"entity_type" text,
	"entity_id" text,
	"diff_json" jsonb,
	"created_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."auth_identity" (
	"auth_identity_id" bigserial PRIMARY KEY NOT NULL,
	"app_user_id" bigint NOT NULL,
	"provider" text NOT NULL,
	"provider_subject" text NOT NULL,
	"provider_email" text,
	"provider_payload" jsonb,
	"created_at" timestamp,
	"updated_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."brands" (
	"brand_id" integer PRIMARY KEY NOT NULL,
	"brand_grouping" text,
	"brand_name" text
);
--> statement-breakpoint
CREATE TABLE "pim"."category" (
	"category_id" bigserial PRIMARY KEY NOT NULL,
	"parent_id" bigint,
	"name" text NOT NULL,
	"path_key" text NOT NULL,
	CONSTRAINT "category_path_key_unique" UNIQUE("path_key")
);
--> statement-breakpoint
CREATE TABLE "pim"."channel" (
	"channel_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text,
	CONSTRAINT "channel_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."club" (
	"club_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"country" text,
	"founded_year" integer,
	CONSTRAINT "club_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."club_rivalry" (
	"club_rivalry_id" bigserial PRIMARY KEY NOT NULL,
	"club_id_a" bigint NOT NULL,
	"club_id_b" bigint NOT NULL,
	"rivalry_type_id" bigint NOT NULL,
	"known_as" text,
	"intensity" smallint,
	"period_start" date,
	"period_end" date,
	"is_primary" boolean,
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "pim"."club_rivals_expanded" (
	"club_rivalry_id" bigint,
	"club_id" bigint,
	"rival_club_id" bigint,
	"rivalry_type_id" bigint,
	"known_as" text,
	"intensity" smallint,
	"period_start" date,
	"period_end" date,
	"is_primary" boolean,
	"notes" text
);
--> statement-breakpoint
CREATE TABLE "pim"."competition" (
	"competition_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"country" text,
	CONSTRAINT "competition_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."condition" (
	"condition_id" integer PRIMARY KEY NOT NULL,
	"condition_name" text
);
--> statement-breakpoint
CREATE TABLE "pim"."currency" (
	"currency_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text,
	"symbol" text,
	"minor_unit" smallint,
	"enabled" boolean,
	CONSTRAINT "currency_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."department" (
	"department_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	CONSTRAINT "department_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."gender" (
	"gender_id" bigserial PRIMARY KEY NOT NULL,
	"gender_name" text
);
--> statement-breakpoint
CREATE TABLE "pim"."image_asset" (
	"image_id" bigserial PRIMARY KEY NOT NULL,
	"product_variant_id" bigint,
	"role" text NOT NULL,
	"url" text NOT NULL,
	"sort_order" integer
);
--> statement-breakpoint
CREATE TABLE "pim"."import_error" (
	"import_error_id" bigserial PRIMARY KEY NOT NULL,
	"import_row_id" bigint NOT NULL,
	"field_key" text,
	"error_code" text,
	"error_message" text,
	"meta_json" jsonb,
	"created_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."import_job" (
	"import_job_id" bigserial PRIMARY KEY NOT NULL,
	"created_by" bigint,
	"source_type" text,
	"import_type" text NOT NULL,
	"status" text NOT NULL,
	"original_filename" text,
	"file_sha256" text,
	"total_rows" integer,
	"valid_rows" integer,
	"invalid_rows" integer,
	"applied_rows" integer,
	"created_at" timestamp,
	"updated_at" timestamp,
	"applied_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."import_row" (
	"import_row_id" bigserial PRIMARY KEY NOT NULL,
	"import_job_id" bigint NOT NULL,
	"row_number" integer NOT NULL,
	"row_raw" jsonb NOT NULL,
	"row_normalized" jsonb,
	"row_status" text NOT NULL,
	"row_key" text,
	"created_at" timestamp,
	"updated_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."kit_category" (
	"kit_category_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	CONSTRAINT "kit_category_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."kit_class" (
	"kit_class_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	CONSTRAINT "kit_class_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."payloads" (
	"payload_id" bigserial PRIMARY KEY NOT NULL,
	"payload_type" text,
	"last_run_date" timestamp,
	"payload_location" text
);
--> statement-breakpoint
CREATE TABLE "pim"."product" (
	"product_id" bigserial PRIMARY KEY NOT NULL,
	"product_sku" text,
	"article_number" text,
	"product_description" text,
	"product_colour_id" integer,
	"gender_id" integer,
	"brand_id" integer,
	"product_type_id" integer,
	"product_style" integer,
	"composition" text,
	"country_of_manufacture" text,
	"commodity_code" text,
	"image_code" text,
	"enabled" boolean,
	"created_at" timestamp,
	"updated_at" timestamp,
	"updated_by" bigint,
	CONSTRAINT "product_product_sku_unique" UNIQUE("product_sku")
);
--> statement-breakpoint
CREATE TABLE "pim"."product_attribute_val" (
	"product_id" bigint NOT NULL,
	"attribute_id" bigint NOT NULL,
	"value_text" text,
	"value_num" numeric,
	"value_bool" boolean,
	"value_json" jsonb,
	CONSTRAINT "product_attribute_val_product_id_attribute_id_pk" PRIMARY KEY("product_id","attribute_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."product_category" (
	"product_id" bigint NOT NULL,
	"category_id" bigint NOT NULL,
	CONSTRAINT "product_category_product_id_category_id_pk" PRIMARY KEY("product_id","category_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."product_colour" (
	"product_colour_id" bigserial PRIMARY KEY NOT NULL,
	"magento_colour_id" text,
	"magento_colour_name" text,
	"brand_id" integer,
	"brand_colour_id" integer,
	"brand_colour_name" text
);
--> statement-breakpoint
CREATE TABLE "pim"."product_sizes" (
	"size_id" bigserial PRIMARY KEY NOT NULL,
	"magento_size_id" integer,
	"magento_size_short_name" text,
	"magento_size_long_name" text,
	"config_options" text,
	"sizing_category" text
);
--> statement-breakpoint
CREATE TABLE "pim"."product_team_meta" (
	"product_team_meta_id" bigserial PRIMARY KEY NOT NULL,
	"product_id" bigint,
	"club_id" bigint,
	"competition_id" bigint,
	"season_id" bigint,
	"department_id" bigint,
	"kit_category_id" bigint,
	"kit_class_id" bigint,
	"is_primary" boolean
);
--> statement-breakpoint
CREATE TABLE "pim"."product_type" (
	"product_type_id" integer PRIMARY KEY NOT NULL,
	"product_type_name" text
);
--> statement-breakpoint
CREATE TABLE "pim"."product_variant" (
	"product_variant_id" bigserial PRIMARY KEY NOT NULL,
	"product_id" bigint,
	"product_variant_sku" text NOT NULL,
	"size_id" integer,
	"tax_class_id" integer,
	"condition_id" integer,
	"condition_detail" text,
	"barcode" text,
	"width_cm" integer,
	"length_cm" integer,
	"weight" numeric(12, 3),
	"depth" numeric(12, 3),
	"cost_price" numeric(12, 2),
	"average_cost_price" numeric(12, 2),
	"retail_price" numeric(12, 2),
	"special_retail_price" numeric(12, 2),
	"customer_price" numeric(12, 2),
	"printed" boolean,
	"magento_product_id" integer,
	"enabled" boolean,
	"created_at" timestamp,
	"updated_at" timestamp,
	"updated_by" bigint,
	CONSTRAINT "product_variant_product_variant_sku_unique" UNIQUE("product_variant_sku"),
	CONSTRAINT "product_variant_barcode_unique" UNIQUE("barcode")
);
--> statement-breakpoint
CREATE TABLE "pim"."rivalry_intensity_ref" (
	"band_id" bigserial PRIMARY KEY NOT NULL,
	"label" text NOT NULL,
	"min_score" smallint NOT NULL,
	"max_score" smallint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "pim"."rivalry_type" (
	"rivalry_type_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	CONSTRAINT "rivalry_type_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."season" (
	"season_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"year_start" integer,
	"year_end" integer,
	CONSTRAINT "season_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."store" (
	"store_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text,
	CONSTRAINT "store_code_unique" UNIQUE("code")
);
--> statement-breakpoint
CREATE TABLE "pim"."store_currency" (
	"store_id" bigint NOT NULL,
	"currency_id" bigint NOT NULL,
	"is_default" boolean,
	CONSTRAINT "store_currency_store_id_currency_id_pk" PRIMARY KEY("store_id","currency_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."tax_class" (
	"tax_class_id" bigserial PRIMARY KEY NOT NULL,
	"tax_class_name" text NOT NULL,
	CONSTRAINT "tax_class_tax_class_name_unique" UNIQUE("tax_class_name")
);
--> statement-breakpoint
CREATE TABLE "pim"."variant_attribute_val" (
	"product_variant_id" bigint NOT NULL,
	"attribute_id" bigint NOT NULL,
	"value_text" text,
	"value_num" numeric,
	"value_bool" boolean,
	"value_json" jsonb,
	CONSTRAINT "variant_attribute_val_product_variant_id_attribute_id_pk" PRIMARY KEY("product_variant_id","attribute_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."variant_barcode" (
	"variant_barcode_id" bigserial PRIMARY KEY NOT NULL,
	"variant_id" bigint,
	"barcode_type" text,
	"barcode_value" text NOT NULL,
	"is_primary" boolean,
	"status" text,
	"source" text,
	"verified_at" timestamp,
	"created_at" timestamp,
	CONSTRAINT "variant_barcode_barcode_value_unique" UNIQUE("barcode_value")
);
--> statement-breakpoint
CREATE TABLE "pim"."variant_channel_id" (
	"product_variant_id" bigint NOT NULL,
	"channel_id" bigint NOT NULL,
	"external_product_id" text,
	CONSTRAINT "variant_channel_id_product_variant_id_channel_id_pk" PRIMARY KEY("product_variant_id","channel_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."variant_price" (
	"variant_price_id" bigserial PRIMARY KEY NOT NULL,
	"product_variant_id" bigint,
	"currency_id" bigint,
	"cost_price" numeric(12, 2),
	"average_cost_price" numeric(12, 2),
	"retail_price" numeric(12, 2),
	"special_retail_price" numeric(12, 2),
	"customer_price" numeric(12, 2),
	"valid_from" timestamp,
	"valid_to" timestamp
);
--> statement-breakpoint
CREATE TABLE "pim"."variant_stock" (
	"product_variant_id" bigint NOT NULL,
	"warehouse_id" bigint NOT NULL,
	"qty" integer,
	"bin_location" text,
	"last_counted_at" timestamp,
	CONSTRAINT "variant_stock_product_variant_id_warehouse_id_pk" PRIMARY KEY("product_variant_id","warehouse_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."warehouse" (
	"warehouse_id" bigserial PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text,
	CONSTRAINT "warehouse_code_unique" UNIQUE("code")
);
--> statement-breakpoint
ALTER TABLE "pim"."app_role_permission" ADD CONSTRAINT "app_role_permission_app_role_id_app_role_app_role_id_fk" FOREIGN KEY ("app_role_id") REFERENCES "pim"."app_role"("app_role_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."app_role_permission" ADD CONSTRAINT "app_role_permission_app_permission_id_app_permission_app_permission_id_fk" FOREIGN KEY ("app_permission_id") REFERENCES "pim"."app_permission"("app_permission_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."app_session" ADD CONSTRAINT "app_session_app_user_id_app_user_app_user_id_fk" FOREIGN KEY ("app_user_id") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."app_user_role" ADD CONSTRAINT "app_user_role_app_user_id_app_user_app_user_id_fk" FOREIGN KEY ("app_user_id") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."app_user_role" ADD CONSTRAINT "app_user_role_app_role_id_app_role_app_role_id_fk" FOREIGN KEY ("app_role_id") REFERENCES "pim"."app_role"("app_role_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."app_user_role" ADD CONSTRAINT "app_user_role_assigned_by_app_user_app_user_id_fk" FOREIGN KEY ("assigned_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."audit_event" ADD CONSTRAINT "audit_event_actor_user_id_app_user_app_user_id_fk" FOREIGN KEY ("actor_user_id") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."auth_identity" ADD CONSTRAINT "auth_identity_app_user_id_app_user_app_user_id_fk" FOREIGN KEY ("app_user_id") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."category" ADD CONSTRAINT "category_parent_id_category_category_id_fk" FOREIGN KEY ("parent_id") REFERENCES "pim"."category"("category_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivalry" ADD CONSTRAINT "club_rivalry_club_id_a_club_club_id_fk" FOREIGN KEY ("club_id_a") REFERENCES "pim"."club"("club_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivalry" ADD CONSTRAINT "club_rivalry_club_id_b_club_club_id_fk" FOREIGN KEY ("club_id_b") REFERENCES "pim"."club"("club_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivalry" ADD CONSTRAINT "club_rivalry_rivalry_type_id_rivalry_type_rivalry_type_id_fk" FOREIGN KEY ("rivalry_type_id") REFERENCES "pim"."rivalry_type"("rivalry_type_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivals_expanded" ADD CONSTRAINT "club_rivals_expanded_club_rivalry_id_club_rivalry_club_rivalry_id_fk" FOREIGN KEY ("club_rivalry_id") REFERENCES "pim"."club_rivalry"("club_rivalry_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivals_expanded" ADD CONSTRAINT "club_rivals_expanded_club_id_club_club_id_fk" FOREIGN KEY ("club_id") REFERENCES "pim"."club"("club_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivals_expanded" ADD CONSTRAINT "club_rivals_expanded_rival_club_id_club_club_id_fk" FOREIGN KEY ("rival_club_id") REFERENCES "pim"."club"("club_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."club_rivals_expanded" ADD CONSTRAINT "club_rivals_expanded_rivalry_type_id_rivalry_type_rivalry_type_id_fk" FOREIGN KEY ("rivalry_type_id") REFERENCES "pim"."rivalry_type"("rivalry_type_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."image_asset" ADD CONSTRAINT "image_asset_product_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("product_variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."import_error" ADD CONSTRAINT "import_error_import_row_id_import_row_import_row_id_fk" FOREIGN KEY ("import_row_id") REFERENCES "pim"."import_row"("import_row_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."import_job" ADD CONSTRAINT "import_job_created_by_app_user_app_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."import_row" ADD CONSTRAINT "import_row_import_job_id_import_job_import_job_id_fk" FOREIGN KEY ("import_job_id") REFERENCES "pim"."import_job"("import_job_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_product_colour_id_product_colour_product_colour_id_fk" FOREIGN KEY ("product_colour_id") REFERENCES "pim"."product_colour"("product_colour_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_gender_id_gender_gender_id_fk" FOREIGN KEY ("gender_id") REFERENCES "pim"."gender"("gender_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_brand_id_brands_brand_id_fk" FOREIGN KEY ("brand_id") REFERENCES "pim"."brands"("brand_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_product_type_id_product_type_product_type_id_fk" FOREIGN KEY ("product_type_id") REFERENCES "pim"."product_type"("product_type_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_updated_by_app_user_app_user_id_fk" FOREIGN KEY ("updated_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_attribute_val" ADD CONSTRAINT "product_attribute_val_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_attribute_val" ADD CONSTRAINT "product_attribute_val_attribute_id_attribute_def_attribute_id_fk" FOREIGN KEY ("attribute_id") REFERENCES "pim"."attribute_def"("attribute_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_category" ADD CONSTRAINT "product_category_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_category" ADD CONSTRAINT "product_category_category_id_category_category_id_fk" FOREIGN KEY ("category_id") REFERENCES "pim"."category"("category_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_club_id_club_club_id_fk" FOREIGN KEY ("club_id") REFERENCES "pim"."club"("club_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_competition_id_competition_competition_id_fk" FOREIGN KEY ("competition_id") REFERENCES "pim"."competition"("competition_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_season_id_season_season_id_fk" FOREIGN KEY ("season_id") REFERENCES "pim"."season"("season_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_department_id_department_department_id_fk" FOREIGN KEY ("department_id") REFERENCES "pim"."department"("department_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_kit_category_id_kit_category_kit_category_id_fk" FOREIGN KEY ("kit_category_id") REFERENCES "pim"."kit_category"("kit_category_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_team_meta" ADD CONSTRAINT "product_team_meta_kit_class_id_kit_class_kit_class_id_fk" FOREIGN KEY ("kit_class_id") REFERENCES "pim"."kit_class"("kit_class_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_variant" ADD CONSTRAINT "product_variant_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_variant" ADD CONSTRAINT "product_variant_size_id_product_sizes_size_id_fk" FOREIGN KEY ("size_id") REFERENCES "pim"."product_sizes"("size_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_variant" ADD CONSTRAINT "product_variant_tax_class_id_tax_class_tax_class_id_fk" FOREIGN KEY ("tax_class_id") REFERENCES "pim"."tax_class"("tax_class_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_variant" ADD CONSTRAINT "product_variant_condition_id_condition_condition_id_fk" FOREIGN KEY ("condition_id") REFERENCES "pim"."condition"("condition_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_variant" ADD CONSTRAINT "product_variant_updated_by_app_user_app_user_id_fk" FOREIGN KEY ("updated_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."store_currency" ADD CONSTRAINT "store_currency_store_id_store_store_id_fk" FOREIGN KEY ("store_id") REFERENCES "pim"."store"("store_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."store_currency" ADD CONSTRAINT "store_currency_currency_id_currency_currency_id_fk" FOREIGN KEY ("currency_id") REFERENCES "pim"."currency"("currency_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_attribute_val" ADD CONSTRAINT "variant_attribute_val_product_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("product_variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_attribute_val" ADD CONSTRAINT "variant_attribute_val_attribute_id_attribute_def_attribute_id_fk" FOREIGN KEY ("attribute_id") REFERENCES "pim"."attribute_def"("attribute_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_barcode" ADD CONSTRAINT "variant_barcode_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_channel_id" ADD CONSTRAINT "variant_channel_id_product_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("product_variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_channel_id" ADD CONSTRAINT "variant_channel_id_channel_id_channel_channel_id_fk" FOREIGN KEY ("channel_id") REFERENCES "pim"."channel"("channel_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_price" ADD CONSTRAINT "variant_price_product_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("product_variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_price" ADD CONSTRAINT "variant_price_currency_id_currency_currency_id_fk" FOREIGN KEY ("currency_id") REFERENCES "pim"."currency"("currency_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_stock" ADD CONSTRAINT "variant_stock_product_variant_id_product_variant_product_variant_id_fk" FOREIGN KEY ("product_variant_id") REFERENCES "pim"."product_variant"("product_variant_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."variant_stock" ADD CONSTRAINT "variant_stock_warehouse_id_warehouse_warehouse_id_fk" FOREIGN KEY ("warehouse_id") REFERENCES "pim"."warehouse"("warehouse_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "uq_provider_subject" ON "pim"."auth_identity" USING btree ("provider","provider_subject");--> statement-breakpoint
CREATE INDEX "auth_identity_app_user_id" ON "pim"."auth_identity" USING btree ("app_user_id");--> statement-breakpoint
CREATE INDEX "club_rivalry_pair_idx" ON "pim"."club_rivalry" USING btree ("club_id_a","club_id_b");--> statement-breakpoint
CREATE INDEX "club_rivalry_type_idx" ON "pim"."club_rivalry" USING btree ("rivalry_type_id");--> statement-breakpoint
CREATE INDEX "club_rivalry_period_idx" ON "pim"."club_rivalry" USING btree ("period_start","period_end");--> statement-breakpoint
CREATE UNIQUE INDEX "uq_pair_type_period" ON "pim"."club_rivalry" USING btree ("club_id_a","club_id_b","rivalry_type_id","period_start","period_end");--> statement-breakpoint
CREATE UNIQUE INDEX "import_row_job_row_unique" ON "pim"."import_row" USING btree ("import_job_id","row_number");--> statement-breakpoint
CREATE INDEX "import_row_job_status_idx" ON "pim"."import_row" USING btree ("import_job_id","row_status");--> statement-breakpoint
CREATE INDEX "variant_price_variant_currency_idx" ON "pim"."variant_price" USING btree ("product_variant_id","currency_id");--> statement-breakpoint
CREATE UNIQUE INDEX "uq_variant_currency_period" ON "pim"."variant_price" USING btree ("product_variant_id","currency_id","valid_from","valid_to");