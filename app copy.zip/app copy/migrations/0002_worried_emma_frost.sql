CREATE TABLE "pim"."era" (
	"era_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"start_year" integer NOT NULL,
	"end_year" integer NOT NULL,
	CONSTRAINT "era_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE "pim"."product_group" (
	"product_group_id" bigserial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"status" text NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"created_at" timestamp,
	"updated_at" timestamp,
	"created_by" bigint,
	"updated_by" bigint
);
--> statement-breakpoint
CREATE TABLE "pim"."product_group_member" (
	"product_group_id" bigint NOT NULL,
	"product_id" bigint NOT NULL,
	"added_at" timestamp,
	"added_by" bigint,
	CONSTRAINT "product_group_member_product_group_id_product_id_pk" PRIMARY KEY("product_group_id","product_id")
);
--> statement-breakpoint
CREATE TABLE "pim"."product_store" (
	"product_id" bigint NOT NULL,
	"store_id" bigint NOT NULL,
	"enabled" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "product_store_product_id_store_id_pk" PRIMARY KEY("product_id","store_id")
);
--> statement-breakpoint
ALTER TABLE "pim"."product" ADD COLUMN "era_id" bigint;--> statement-breakpoint
ALTER TABLE "pim"."product_group" ADD CONSTRAINT "product_group_created_by_app_user_app_user_id_fk" FOREIGN KEY ("created_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_group" ADD CONSTRAINT "product_group_updated_by_app_user_app_user_id_fk" FOREIGN KEY ("updated_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD CONSTRAINT "product_group_member_product_group_id_product_group_product_group_id_fk" FOREIGN KEY ("product_group_id") REFERENCES "pim"."product_group"("product_group_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD CONSTRAINT "product_group_member_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD CONSTRAINT "product_group_member_added_by_app_user_app_user_id_fk" FOREIGN KEY ("added_by") REFERENCES "pim"."app_user"("app_user_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_store" ADD CONSTRAINT "product_store_product_id_product_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "pim"."product"("product_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product_store" ADD CONSTRAINT "product_store_store_id_store_store_id_fk" FOREIGN KEY ("store_id") REFERENCES "pim"."store"("store_id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pim"."product" ADD CONSTRAINT "product_era_id_era_era_id_fk" FOREIGN KEY ("era_id") REFERENCES "pim"."era"("era_id") ON DELETE no action ON UPDATE no action;