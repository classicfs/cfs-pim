CREATE TABLE IF NOT EXISTS pim.workspace_setting (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO pim.workspace_setting (key, value) VALUES (
  'sync_required_fields',
  '["productDescription","brandId","productTypeId","genderId","productColourId"]'::jsonb
) ON CONFLICT (key) DO NOTHING;
