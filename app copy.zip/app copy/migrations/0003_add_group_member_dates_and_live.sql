ALTER TABLE "pim"."product_group_member" DROP CONSTRAINT "product_group_member_product_group_id_product_id_pk";
--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD COLUMN "product_group_member_id" bigserial PRIMARY KEY;
--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD COLUMN "start_date" timestamp;
--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD COLUMN "end_date" timestamp;
--> statement-breakpoint
ALTER TABLE "pim"."product_group_member" ADD COLUMN "live" boolean DEFAULT true NOT NULL;
