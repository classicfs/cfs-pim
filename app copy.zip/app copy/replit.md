# Product Inventory Management System

## Overview

This is a full-stack product inventory management system designed to manage product catalogs with features such as manual product creation, CSV import capabilities, advanced filtering and search, and data completeness tracking. The system supports both "Configurable Products" (with variants like different sizes or conditions) and "Simple Products" (standalone items). It aims to provide a robust solution for inventory management, enhancing efficiency and data accuracy.

### Image Management

Images are linked at the **product level** (not variant level) via the `image_asset` table. This allows images to be shared across all variants of a product.

**Image Fields**:
- `url` - Image URL
- `role` - One of: base, small, thumbnail, additional, swatch
- `label` - Optional title/label for the image (TEXT, nullable)
- `sortOrder` - Display order (must be sequential - no gaps allowed)

**Listing Sheet Import Support**: Images can be imported via CSV with these columns:
- `product_sku` (or `productSku`, `Product SKU`, `sku`, `SKU`) - Links to the product by product-level SKU (not variant SKU)
- `base_image` / `baseImage` - Base image URL(s), comma-separated
- `small_image` / `smallImage` - Small image URL(s), comma-separated
- `thumbnail_image` / `thumbnailImage` - Thumbnail image URL(s), comma-separated
- `additional_images` / `additionalImages` - Additional image URL(s), comma-separated
- `label` / `Label` / `image_label` / `imageLabel` - Optional label/title for the image

Sort order validation ensures sequential numbering. If you specify sort_order=3 but 1 and 2 don't exist, it will be auto-assigned to the next available sequential number.

**Images Page**: View and manage all product images at `/images` (accessible via sidebar under Catalogs). Features:
- Table with Preview, Product SKU, Description, Label, Scope/Role, Order, URL columns
- "Add Image" wizard dialog to create images with product SKU search, label, role, and URL fields
- Role and SKU filtering

**API Endpoints**:
- `GET /api/images` — List all images with optional role/SKU filters
- `POST /api/images` — Create a new image (requires productId, url, role; label optional; validates role against allowed values)

### Category Management

Categories are organized in a hierarchical tree structure with parent-child relationships. Categories have:
- `categoryId` - Primary key
- `parentId` - Reference to parent category (null for root categories)
- `name` - Category display name
- `pathKey` - Full hierarchical path (e.g., "Default/International Teams/European/Germany")

**Categories Page**: Manage all product categories at `/categories` (accessible via sidebar under Catalogs). Features:
- Tree view with expandable/collapsible nodes
- Create new categories with optional parent assignment
- View products assigned to each category
- Delete categories (orphans children to root level)

**Listing Sheet Import Support**: Categories can be imported via CSV with these columns:
- `product_sku` - Links to the product
- `categories` - Comma-separated category paths, each path delimited by `/` (e.g., "Default/International Teams/European/Germany,Default/Printed Shirts/Current Stars")

When importing, categories are automatically created if they don't exist, maintaining the hierarchical structure based on the path.

### Authorization & Role Management

The app uses a role-based access control (RBAC) system with these database tables:
- `app_permission` — 22 granular permissions organized by domain (catalog, import, category, pricing, stock, store, image, refdata, user, role)
- `app_role` — Named roles with code, name, description
- `app_role_permission` — Maps permissions to roles (many-to-many)
- `app_user_role` — Assigns roles to users (many-to-many)

**Permission Domains**: catalog (view/create/edit/delete), import (upload/approve), category (view/manage), pricing (view/manage), stock (view/manage), store (view/manage), image (view/manage), refdata (view/manage), user (view/manage), role (manage), user (assign_role)

**Management UI**: Settings page > Access Control tab. Create roles with the "New role" dialog, assign permissions using domain-grouped checkboxes with select-all per domain. Edit existing roles inline. Users tab allows assigning roles to users.

**API Endpoints**:
- `GET /api/workspace/roles` — List all roles with their permissions
- `GET /api/workspace/permissions` — List all permissions
- `POST /api/workspace/roles` — Create a new role with permission IDs
- `PUT /api/workspace/roles/:code` — Update role name, description, and permissions
- `POST /api/workspace/users/:userId/roles` — Assign a role to a user

### Alumio Sync Logs

Alumio integration sends sync results to the PIM via a POST endpoint. Each log entry records:
- `requestData` (JSONB) — Original request payload
- `responseData` (JSONB) — Response payload
- `httpStatusCode` (integer) — HTTP status code from the sync
- `responseMessage` (text) — Success/error message
- `skus` (text array) — SKU(s) involved in the sync
- `operationType` (text) — "create" or "update"
- `createdAt` (timestamp) — When the sync occurred

**API Endpoints**:
- `POST /api/alumio/sync-log` — Write a sync log entry (requires `x-api-key` header matching `ALUMIO_API_KEY` secret)
- `GET /api/alumio/sync-logs` — Read sync logs with optional filters (`operationType`, `statusFilter`, `skuSearch`, `limit`, `offset`)

**Sync Logs Page**: View all sync logs at `/sync-logs` (accessible via sidebar under Feeds). Features:
- Filterable by operation type (create/update), status (success/error), and SKU search
- Expandable rows to view full request/response JSON data
- Paginated results

### Alumio Sync Queue

The `alumio_sync_queue` table captures product and variant changes so an external script can periodically pick them up and push them to Magento via Alumio.

**Table columns** (`pim.alumio_sync_queue`):
- `id` (bigserial PK)
- `product_id` (bigint, NOT NULL, FK to product)
- `product_variant_id` (bigint, nullable, FK to product_variant)
- `operation_type` (text) — "product_create", "product_update", "variant_create", "variant_update", "category_change", "image_update"
- `status` (text, default "pending") — "pending", "processing", "sent", "failed"
- `created_at` (timestamp)
- `processed_at` (timestamp, nullable)

**Automatic population**: Queue entries are automatically inserted when:
- A product is created (`createProduct`) — inserts `product_create` + `category_change` (if categories provided)
- A product is updated (`updateProduct`) — inserts `product_update`
- A variant is created (`createProductVariant`) — inserts `variant_create`
- A variant is updated (`updateVariant`) — inserts `variant_update`
- A product is duplicated (`duplicateProduct`) — inserts `product_create` + `variant_create` + `category_change`
- Categories are reassigned on a product (`assignProductToCategories`) — inserts `category_change`
- Categories are assigned during CSV import — inserts `category_change`

**Dedup logic**: `insertSyncQueueEntry` checks for an existing entry with the same `productId` + `productVariantId` + `operationType` in `pending`/`failed` status before inserting. Different operation types for the same product (e.g., `product_update` and `category_change`) are tracked independently.

**Sync Required Fields Validation**: Products must have all configured required fields populated before sync can be enabled. The required fields are configurable via the "Sync Settings" tab in Workspace Settings (defaults: Description, Brand, Product Type, Gender, Colour). Available fields include: Description, Article Number, Brand, Product Type, Gender, Colour, Era, Style, Composition, Country of Manufacture, Commodity Code, Image Code. If any required fields are missing:
- The sync toggle on the product detail page is disabled with a warning icon showing which fields are missing
- Bulk "Enable Sync" on the catalog page skips incomplete products and reports which were skipped (by SKU)
- If a product has sync enabled and a required field is subsequently cleared during editing, sync is automatically disabled
- The product details API response includes `syncRequiredMissing` (string array) listing any missing required field labels

**Configuration storage**: The `pim.workspace_setting` table (key-value with JSONB values) stores the configured sync required fields under the key `sync_required_fields`. API: `GET /api/workspace/sync-required-fields` returns `{ selectedFields, availableFields }`, `PUT /api/workspace/sync-required-fields` accepts `{ fields: string[] }`.

**Manual Resync**: Products can be manually resynced via a "Resync" button available on both the product catalog page (icon button per row) and the product detail page (header button). This inserts a `product_update` entry into the sync queue.

**API Endpoints** (for the external sync script):
- `GET /api/alumio/sync-queue?status=pending&limit=100&offset=0` — Fetch queue entries by status
- `PATCH /api/alumio/sync-queue/status` — Update status of entries. Body: `{ ids: [1,2,3], status: "processing" }`
- `POST /api/products/:id/resync` — Manually add a product to the sync queue for the next sync cycle

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tool**: React 18 with TypeScript and Vite for rapid development and optimized builds. Wouter is used for lightweight client-side routing.

**UI Component System**: Leverages shadcn/ui (built on Radix UI) and Tailwind CSS for a consistent, modern, and responsive interface inspired by Material Design and Linear. It includes a theme system for dark/light modes.

**State Management**: TanStack Query manages server state, caching, and data synchronization, while local React state handles UI-specific interactions.

**Key Design Decisions**:
- Component-based architecture with reusable UI primitives.
- Custom design system with HSL color tokens.
- Responsive layout using a mobile-first approach.
- Sidebar navigation with collapsible desktop view and drawer for mobile.

**Key Features**:
- **Catalog Page**: Expandable product rows to display nested variants, multi-select functionality for batch operations, dynamic column visibility, advanced filtering options, compact rows (py-1), and Excel-style column resizing (drag right edge of any header). Uses `table-layout: fixed` with captured initial widths for precise resize control.
- **Groups Page**: Dialog for creating product groups with real-time search, multi-select product tables, and robust validation. Displays existing groups with product counts. Group members table has compact rows (py-1) and Excel-style column resizing matching the catalog table.
- **Export Page**: CSV export with filters, standard product field selection, and custom attribute column selection. Live preview table shows 5 sample rows with total count before exporting. Backend validates attribute IDs are product-scope. CSV headers use friendly labels. Endpoints: `POST /api/export/preview` (5 sample rows + count), `POST /api/export/products` (full CSV download). Both accept `filters`, `columns`, and `attributeColumns` (array of attribute IDs).
- **Import Feed Page**: Asynchronous background import processing with status tracking, detailed import batch table, multi-file CSV upload dialog with preview, and status polling.
- **Reference Data Import Page**: Allows importing data into various reference tables (e.g., Teams, Brands, Seasons) with CSV upload, automatic header conversion, and clear import results (inserted/updated counts, errors).

### Backend Architecture

**Server Framework**: Express.js with TypeScript for a RESTful API structure.

**Request Processing**: Includes JSON/URL-encoded body parsing, request logging, and centralized error handling.

**File Upload Handling**: Utilizes Multer for CSV file uploads with in-memory storage and PapaParse for CSV parsing and validation.

**Comprehensive Import System**:
- **Upload Stage**: Accepts multiple CSVs (products, categories, images, listings), parses them, and stores data in staging tables (`stg_products`, `stg_categories`, `stg_images`, `stg_listings`).
- **Preview Stage**: Displays counts and sample data from staging tables for user verification.
- **Confirm Stage**: Fire-and-forget — responds immediately while processing runs asynchronously in the background. Processes staged data row-by-row including product creation, variant generation, inventory management, category tree building, image processing, attribute parsing, and pricing updates across 20+ tables.
- **User Tracking**: Import jobs track which user uploaded the file via the `created_by` field, linking to `app_user`.
- **Status Tracking**: Individual row statuses (pending, invalid, applied, error) with error messages stored in `import_error` table. Job-level counters track validRows, invalidRows, and appliedRows.
- **Real-time Progress**: In-memory `ImportProgressTracker` tracks per-row progress during background processing. Progress API endpoints (`/api/imports/progress`, `/api/imports/:batchId/progress`) enable the frontend to poll for live status. A floating progress widget in the bottom-right corner shows a progress bar, per-SKU success/error entries, and toast notifications on completion. Progress data auto-cleans 60 seconds after completion.

### Data Storage & Database

**ORM & Database**: Drizzle ORM provides type-safe database operations with PostgreSQL (Neon serverless database) for scalable storage.

**Schema Design**: Includes core tables like `product`, `product_variant`, `category`, `brand`, and `club`, alongside `variant_stock` and `variant_price` for multi-warehouse and multi-store support. Staging tables manage temporary data during imports.

**Data Operations**: Shared schema definitions, Zod validation schemas, and type inference ensure compile-time safety.

**Completeness Calculation**: Server-side calculation based on field population and weighted scoring for data quality.

### Public API & API Key Management (Mar 2026)

A read-only public API secured by API key authentication. Allows external systems to pull product data.

**Database Table** (`pim.api_key`):
- `api_key_id` (bigserial PK)
- `name` (text) — Human-readable label
- `key_hash` (text, unique) — SHA-256 hash of the raw key
- `key_prefix` (text) — First 12 chars for display
- `scopes` (text array) — Permitted data scopes
- `active` (boolean, default true)
- `last_used_at` (timestamp)
- `created_at`, `created_by`

**Available Scopes**: products, variants, pricing, stock, categories, brands, reference-data, images

**Public API Endpoints** (all require `x-api-key` header):
- `GET /api/public/products` — Paginated product list (?page, ?limit, ?search, ?brandId, ?categoryId, ?enabled)
- `GET /api/public/products/:id` — Full product details with variants (incl. variant attributes), categories, images, team meta, and product-level custom attributes
- `GET /api/public/products/:id/variants` — Variant list for a product
- `GET /api/public/products/:id/attributes` — Custom (EAV) attributes for a product
- `GET /api/public/variants/:id/attributes` — Custom (EAV) attributes for a variant
- `GET /api/public/variants/:id/prices` — Variant pricing with currency info
- `GET /api/public/variants/:id/stock` — Variant stock levels
- `GET /api/public/categories` — Full category tree
- `GET /api/public/brands` — All brands
- `GET /api/public/clubs` — Clubs (?limit)
- `GET /api/public/stores` — All stores
- `GET /api/public/attributes` — Custom attribute definitions
- `GET /api/public/images` — Paginated images (?page, ?limit, ?role, ?search)
- `GET /api/public/reference/genders|product-types|conditions|sizes|colours|eras|warehouses|currencies`

**API Key Management Endpoints** (session-authenticated):
- `GET /api/api-keys` — List all keys (hash excluded)
- `POST /api/api-keys` — Create key (returns raw key once)
- `PATCH /api/api-keys/:id` — Update name/scopes/active
- `DELETE /api/api-keys/:id` — Delete key
- `GET /api/api-keys/scopes` — List available scopes

**Frontend**: `/api-keys` page (sidebar "API Keys" link) with key management table, create dialog with scope selection, inline documentation panel, and one-time key reveal.

**Files**: `server/publicApi.ts` (public routes + middleware), `client/src/pages/api-keys.tsx`

## Recent Changes

### Product-Level Tax Class (Mar 2026)
The `pim.product` table now includes a `tax_class_id` column (integer, nullable, FK to `pim.tax_class`). This allows assigning a tax class at the product level in addition to the existing variant-level tax class.

**UI**: The product detail page now shows a "Tax Class" dropdown in the Product Information card, alongside Product Colour, Gender, and Era. Editable when in edit mode.

### Attribute Magento Scope (Mar 2026)
The `pim.attribute_def` table now includes a `magento_scope` column (text, NOT NULL, default 'global') with a CHECK constraint limiting values to `global`, `website`, or `store_view`. This controls the Magento scope level at which the attribute operates.

**UI**: The Custom Attributes table on the Attributes page now shows a "Magento Scope" dropdown per attribute, allowing inline editing. The create form also includes a Magento Scope selector (defaults to Global).

### Store Website Code (Mar 2026)
The `pim.store` table now includes a `website_code` column (text, NOT NULL). This field is displayed in the Store overview table and is required when creating or editing stores via the UI or API.

**Existing store mappings**: LDN→LDN_SHOP, MCR→MCRSHOP, NYC→RETAIL, MMI→RETAIL, LAX→PLACEHOLDER, LDN2→PLACEHOLDER, US→US, EU→EU, DEFAULT→BASE.

### Product Group Membership Tracking (Mar 2026)
The `product_group_member` table now supports historical membership tracking with three new columns:
- `start_date` (timestamp) — When the product was added to the group
- `end_date` (timestamp) — When the product was removed from the group (null if still active)
- `live` (boolean, default true) — Whether the product currently inherits group-level changes

The composite primary key `(product_group_id, product_id)` has been replaced with a surrogate `product_group_member_id` (bigserial), allowing multiple membership instances per product-group pair (e.g., a product removed from a group and later re-added gets a new row).

**Behavior**:
- Product counts on the groups list only count `live = true` members
- Scheduled changes scoped to a group only apply to `live = true` members
- When toggling a member's `live` status to `false`, the `end_date` is automatically set to the current timestamp
- Non-live (historical) members appear greyed out in the group detail table

**API Endpoints**:
- `PATCH /api/groups/:id/members/:memberId` — Update a member's `live` status (body: `{ live: boolean }`)

**Frontend**: Group detail product table now shows Start Date, End Date, and a Live toggle switch per member.

### Scheduled Changes (Mar 2026)
Schedule future changes to individual products or entire product groups. A background processor polls every 60 seconds and applies due changes automatically, then queues affected products for Alumio/Magento sync.

**Database Tables** (`pim.scheduled_change`, `pim.scheduled_change_item`):
- `scheduled_change` — batch metadata: name, description, scheduled_at, ends_at (optional auto-revert time), status (pending/applied/cancelled/failed/reverted), scope_type (products/group), scope_group_id, created_by, reverted_at
- `scheduled_change_item` — individual field changes: entity_type, field_name, new_value, old_value, change_mode (absolute/percentage), product_id, status

**Schedulable Fields**:
- Product fields: description, enabled, sync, productStyle (text — style name like "Home", "Away", etc.), composition, countryOfManufacture, commodityCode, imageCode, articleNumber
- Price fields: retailPrice_{CURRENCY_CODE}, specialRetailPrice_{CURRENCY_CODE} (e.g. retailPrice_GBP, specialRetailPrice_EUR) — applied to all variants of each product via `upsertVariantPrice`. Special price fields support two change modes:
  - `absolute` (default): set special price to the exact value specified
  - `percentage`: set special price to X% off the retail price (e.g., `15` reads the current retail price and sets special price to 85% of it). Retail price is never modified by percentage mode.
- Group membership: add_to_group — adds selected products to a target group at the scheduled time, with optional membership end date. Uses scopeType `add_to_group`, entityType `group_membership`.

**Time-Limited (Auto-Revert) Changes**: When `endsAt` is set, the processor automatically reverts applied changes once the end date is reached. Old values are stored as JSON-serialized per-variant price maps in `old_value` for accurate multi-variant revert. Status changes to `reverted` and `reverted_at` is set.

**API Endpoints**:
- `POST /api/scheduled-changes` — Create a new scheduled change with items (accepts `endsAt`, items accept `changeMode`)
- `GET /api/scheduled-changes` — List all scheduled changes (optional status filter)
- `GET /api/scheduled-changes/:id` — Get details with items
- `PUT /api/scheduled-changes/:id` — Update metadata (only if pending)
- `POST /api/scheduled-changes/:id/cancel` — Cancel a pending change

**Frontend**: `/scheduled-changes` page with list view, detail view, and 3-step creation wizard. Step 1 includes a "Change Type" selector (Field Changes or Add Products to Group) plus an optional "End Date" (auto-revert). For field changes: step 2 is scope/products, step 3 is field definitions with "Same for all" or "Per product" modes and an Absolute/Percentage mode selector for price fields. For add-to-group: step 2 is product selection, step 3 is target group and optional end date. Price fields (retail/special) are dynamically populated from configured currencies. Accessible via sidebar.

**Background Processor**: `server/scheduledChangeProcessor.ts` — polls every 60s, applies due changes using existing storage methods, reverts expired time-limited changes, inserts sync queue entries for affected products.

### Product Copy & Paste (Feb 2026)
Copy/paste functionality on the catalog page. Click the copy icon on any product row to copy it to a clipboard. A "Paste" button appears in the toolbar to create a duplicate. Deep-copies all related data: variants, prices, stock (set to 0), categories, images, attributes, team metadata, stores, variant attributes, and variant channels. SKU gets "-COPY" suffix, barcodes/Magento IDs are cleared. API: `POST /api/products/:id/duplicate`.

### Product Style Dropdown (Feb 2026)
Product style field changed from numeric input to a named dropdown with 10 options: Home (1), Away (2), Third (3), Training (4), Goalkeeper (5), Special (6), Retro (7), Classic (8), Replica (9), Authentic (10). Used in both product creation dialog and product detail page via `PRODUCT_STYLE_OPTIONS` constant.

### Brand-Aware Colour Display (Feb 2026)
Colour dropdowns and displays now show brand names to disambiguate duplicates (e.g., "Black (Nike)" vs "Black (Adidas)"). The `getProductColours()` storage method joins the brands table. Applied in product creation dialog, product detail page, and attributes page.

### Multi-Category Product Creation (Feb 2026)
Product creation dialog supports selecting multiple categories via a dropdown with badge chips. Inline category creation is available. Backend accepts `categoryIds` array in the create product endpoint and inserts multiple `productCategory` rows.

### Variant SKU Filtering (Feb 2026)
Product details API now excludes variants whose SKU matches the configurable product's SKU from the variant list.

## External Dependencies

**Database & Storage**:
- Neon Serverless PostgreSQL
- Drizzle ORM and Drizzle Kit

**UI Component Libraries**:
- Radix UI
- shadcn/ui
- Lucide React (Icons)

**Form & Validation**:
- React Hook Form
- Zod
- @hookform/resolvers

**Data Management**:
- TanStack Query
- PapaParse (CSV parsing)
- Multer (File uploads)

**Styling & Theming**:
- Tailwind CSS
- class-variance-authority
- tailwind-merge & clsx

**Development Tools**:
- Vite
- TypeScript
- ESBuild
- tsx

**Font Resources**:
- Google Fonts (Inter)