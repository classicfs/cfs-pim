import { storage } from "./storage";
import { productGroupMember, product, currency, scheduledChange, scheduledChangeItem } from "@shared/schema_v2";
import { db } from "./db";
import { and, eq, lte, asc, isNull } from "drizzle-orm";

const POLL_INTERVAL_MS = 60_000;

const PRODUCT_FIELD_MAP: Record<string, string> = {
  description: "productDescription",
  productDescription: "productDescription",
  status: "enabled",
  enabled: "enabled",
  sync: "sync",
  productStyle: "productStyle",
  composition: "composition",
  countryOfManufacture: "countryOfManufacture",
  commodityCode: "commodityCode",
  imageCode: "imageCode",
  articleNumber: "articleNumber",
  brandId: "brandId",
  genderId: "genderId",
  productTypeId: "productTypeId",
  productColourId: "productColourId",
  eraId: "eraId",
};

function coerceValue(fieldName: string, rawValue: string | null): any {
  if (rawValue === null || rawValue === "") return null;

  const numericFields = new Set([
    "brandId", "genderId", "productTypeId", "productColourId",
    "eraId",
  ]);
  const booleanFields = new Set(["enabled", "sync"]);

  if (numericFields.has(fieldName)) {
    const n = Number(rawValue);
    return isNaN(n) ? null : n;
  }
  if (booleanFields.has(fieldName)) {
    return rawValue === "true" || rawValue === "1";
  }
  return rawValue;
}

async function resolveProductIds(change: any): Promise<number[]> {
  if (change.scopeType === "group" && change.scopeGroupId) {
    const members = await db
      .select({ productId: productGroupMember.productId })
      .from(productGroupMember)
      .where(and(
        eq(productGroupMember.productGroupId, change.scopeGroupId),
        eq(productGroupMember.live, true),
      ));
    return members.map((m) => m.productId);
  }
  return [];
}

async function applyProductFieldChange(
  productId: number,
  fieldName: string,
  newValue: string | null,
): Promise<void> {
  const mappedField = PRODUCT_FIELD_MAP[fieldName];
  if (!mappedField) {
    throw new Error(`Unknown product field: ${fieldName}`);
  }
  const coerced = coerceValue(mappedField, newValue);
  await storage.updateProduct(productId, { [mappedField]: coerced });
}

async function resolveCurrencyId(currencyCode: string): Promise<number> {
  const [cur] = await db
    .select({ currencyId: currency.currencyId })
    .from(currency)
    .where(eq(currency.code, currencyCode))
    .limit(1);
  if (!cur) {
    throw new Error(`Currency not found: ${currencyCode}`);
  }
  return cur.currencyId;
}

async function getProductVariantIds(productId: number): Promise<number[]> {
  const variants = await db
    .select({ productVariantId: productVariant.productVariantId })
    .from(productVariant)
    .where(eq(productVariant.productId, productId));
  return variants.map((v) => v.productVariantId);
}

async function getCurrentVariantPrice(
  variantId: number,
  currencyId: number,
  priceField: "retailPrice" | "specialRetailPrice",
): Promise<string | null> {
  const [row] = await db
    .select({
      retailPrice: variantPrice.retailPrice,
      specialRetailPrice: variantPrice.specialRetailPrice,
    })
    .from(variantPrice)
    .where(and(
      eq(variantPrice.productVariantId, variantId),
      eq(variantPrice.currencyId, currencyId),
    ))
    .limit(1);
  if (!row) return null;
  return priceField === "retailPrice" ? row.retailPrice : row.specialRetailPrice;
}

function calculateDiscountedPrice(retailPrice: string, discountPercent: number): string {
  const retail = Number(retailPrice);
  if (isNaN(retail)) return retailPrice;
  const specialPrice = retail * (1 - discountPercent / 100);
  return Math.max(0, specialPrice).toFixed(2);
}

async function applyVariantPriceChange(
  productId: number,
  fieldName: string,
  newValue: string | null,
  changeMode: string | null,
): Promise<{ oldPrices: Map<number, string | null>; newPrices: Map<number, string | null> }> {
  const match = fieldName.match(/^(retailPrice|specialRetailPrice)_([A-Z]{3})$/);
  if (!match) {
    throw new Error(`Invalid price field format: ${fieldName}`);
  }

  const [, priceField, currencyCode] = match;
  const currencyId = await resolveCurrencyId(currencyCode);
  const variantIds = await getProductVariantIds(productId);
  const oldPrices = new Map<number, string | null>();
  const newPrices = new Map<number, string | null>();

  if (variantIds.length === 0) {
    throw new Error(`Product ${productId} has no variants to update prices for`);
  }

  const isPercentage = changeMode === "percentage";

  for (const variantId of variantIds) {
    if (isPercentage && priceField === "specialRetailPrice" && newValue !== null) {
      const currentSpecialPrice = await getCurrentVariantPrice(variantId, currencyId, "specialRetailPrice");
      oldPrices.set(variantId, currentSpecialPrice);

      const retailPrice = await getCurrentVariantPrice(variantId, currencyId, "retailPrice");
      let finalValue: string | null = null;
      if (retailPrice !== null) {
        const discountPercent = Number(newValue);
        if (!isNaN(discountPercent)) {
          finalValue = calculateDiscountedPrice(retailPrice, discountPercent);
        }
      }
      newPrices.set(variantId, finalValue);

      await storage.upsertVariantPrice({
        productVariantId: variantId,
        currencyId,
        specialRetailPrice: finalValue,
      });
    } else {
      const currentPrice = await getCurrentVariantPrice(
        variantId,
        currencyId,
        priceField as "retailPrice" | "specialRetailPrice",
      );
      oldPrices.set(variantId, currentPrice);
      newPrices.set(variantId, newValue);

      const priceUpdate: {
        productVariantId: number;
        currencyId: number;
        retailPrice?: string | null;
        specialRetailPrice?: string | null;
      } = {
        productVariantId: variantId,
        currencyId,
      };

      if (priceField === "retailPrice") {
        priceUpdate.retailPrice = newValue;
      } else {
        priceUpdate.specialRetailPrice = newValue;
      }

      await storage.upsertVariantPrice(priceUpdate);
    }
  }

  return { oldPrices, newPrices };
}

function serializeOldPrices(oldPrices: Map<number, string | null>): string {
  const obj: Record<string, string | null> = {};
  for (const [variantId, price] of oldPrices) {
    obj[String(variantId)] = price;
  }
  return JSON.stringify(obj);
}

function deserializeOldPrices(serialized: string | null): Map<number, string | null> {
  const result = new Map<number, string | null>();
  if (!serialized) return result;
  try {
    const obj = JSON.parse(serialized);
    for (const [key, value] of Object.entries(obj)) {
      result.set(Number(key), value as string | null);
    }
  } catch {
    return result;
  }
  return result;
}

async function revertVariantPriceChange(
  productId: number,
  fieldName: string,
  oldValue: string | null,
): Promise<void> {
  const match = fieldName.match(/^(retailPrice|specialRetailPrice)_([A-Z]{3})$/);
  if (!match) return;

  const [, priceField, currencyCode] = match;
  const currencyId = await resolveCurrencyId(currencyCode);

  const perVariantPrices = deserializeOldPrices(oldValue);

  if (perVariantPrices.size > 0) {
    for (const [variantId, price] of perVariantPrices) {
      const priceUpdate: {
        productVariantId: number;
        currencyId: number;
        retailPrice?: string | null;
        specialRetailPrice?: string | null;
      } = {
        productVariantId: variantId,
        currencyId,
      };

      if (priceField === "retailPrice") {
        priceUpdate.retailPrice = price;
      } else {
        priceUpdate.specialRetailPrice = price;
      }

      await storage.upsertVariantPrice(priceUpdate);
    }
  } else {
    const variantIds = await getProductVariantIds(productId);
    for (const variantId of variantIds) {
      const priceUpdate: {
        productVariantId: number;
        currencyId: number;
        retailPrice?: string | null;
        specialRetailPrice?: string | null;
      } = {
        productVariantId: variantId,
        currencyId,
      };

      if (priceField === "retailPrice") {
        priceUpdate.retailPrice = oldValue;
      } else {
        priceUpdate.specialRetailPrice = oldValue;
      }

      await storage.upsertVariantPrice(priceUpdate);
    }
  }
}

async function revertProductFieldChange(
  productId: number,
  fieldName: string,
  oldValue: string | null,
): Promise<void> {
  const mappedField = PRODUCT_FIELD_MAP[fieldName];
  if (!mappedField) return;
  const coerced = coerceValue(mappedField, oldValue);
  await storage.updateProduct(productId, { [mappedField]: coerced });
}

async function expireGroupMembers(): Promise<void> {
  try {
    const now = new Date();
    const expired = await db
      .update(productGroupMember)
      .set({ live: false })
      .where(and(
        eq(productGroupMember.live, true),
        lte(productGroupMember.endDate, now),
      ))
      .returning({ productGroupMemberId: productGroupMember.productGroupMemberId, productId: productGroupMember.productId });

    if (expired.length > 0) {
      console.log(`[ScheduledChanges] Auto-expired ${expired.length} group member(s)`);
    }
  } catch (err) {
    console.error("[ScheduledChanges] Error expiring group members:", err);
  }
}

async function revertExpiredChanges(): Promise<void> {
  try {
    const now = new Date();
    const expiredChanges = await db
      .select()
      .from(scheduledChange)
      .where(and(
        eq(scheduledChange.status, "applied"),
        lte(scheduledChange.endsAt, now),
        isNull(scheduledChange.revertedAt),
      ))
      .orderBy(asc(scheduledChange.endsAt));

    for (const change of expiredChanges) {
      console.log(`[ScheduledChanges] Reverting expired change #${change.id}: "${change.name}"`);

      try {
        const items = await db
          .select()
          .from(scheduledChangeItem)
          .where(and(
            eq(scheduledChangeItem.scheduledChangeId, change.id),
            eq(scheduledChangeItem.status, "applied"),
          ))
          .orderBy(asc(scheduledChangeItem.id));

        let groupProductIds: number[] = [];
        if (change.scopeType === "group" && change.scopeGroupId) {
          groupProductIds = await resolveProductIds(change);
        }

        const affectedProductIds = new Set<number>();
        let hasErrors = false;

        for (const item of items) {
          try {
            if (item.entityType === "variant_price") {
              const perVariantPrices = deserializeOldPrices(item.oldValue);
              if (perVariantPrices.size > 0) {
                await revertVariantPriceChange(0, item.fieldName, item.oldValue);
                for (const pid of groupProductIds) {
                  affectedProductIds.add(pid);
                }
                if (item.productId) {
                  affectedProductIds.add(item.productId);
                }
              } else if (item.productId) {
                await revertVariantPriceChange(item.productId, item.fieldName, item.oldValue);
                affectedProductIds.add(item.productId);
              }
            } else if (item.entityType === "product") {
              if (item.productId) {
                await revertProductFieldChange(item.productId, item.fieldName, item.oldValue);
                affectedProductIds.add(item.productId);
              } else if (change.scopeType === "group" && groupProductIds.length > 0) {
                for (const pid of groupProductIds) {
                  await revertProductFieldChange(pid, item.fieldName, item.oldValue);
                  affectedProductIds.add(pid);
                }
              }
            }
          } catch (revertErr: any) {
            console.error(`[ScheduledChanges] Error reverting item #${item.id}:`, revertErr);
            hasErrors = true;
          }
        }

        for (const pid of affectedProductIds) {
          try {
            await storage.insertSyncQueueEntry({
              productId: pid,
              operationType: "product_update",
            });
          } catch (syncErr) {
            console.error(`[ScheduledChanges] Failed to queue sync for product ${pid}:`, syncErr);
          }
        }

        await db
          .update(scheduledChange)
          .set({
            status: "reverted",
            revertedAt: now,
            updatedAt: now,
            errorMessage: hasErrors ? "Some items failed to revert" : null,
          })
          .where(eq(scheduledChange.id, change.id));

        console.log(`[ScheduledChanges] Reverted change #${change.id}, affected ${affectedProductIds.size} products`);
      } catch (changeErr: any) {
        console.error(`[ScheduledChanges] Failed to revert change #${change.id}:`, changeErr);
        await db
          .update(scheduledChange)
          .set({
            status: "failed",
            errorMessage: `Revert failed: ${changeErr.message || "Unknown error"}`,
            updatedAt: now,
          })
          .where(eq(scheduledChange.id, change.id));
      }
    }
  } catch (err) {
    console.error("[ScheduledChanges] Error in revert processor:", err);
  }
}

async function processDueChanges(): Promise<void> {
  try {
    const dueChanges = await storage.getDueScheduledChanges();

    for (const change of dueChanges) {
      console.log(`[ScheduledChanges] Processing change #${change.id}: "${change.name}"`);

      try {
        const items = await storage.getScheduledChangeItems(change.id);

        let groupProductIds: number[] = [];
        if (change.scopeType === "group") {
          groupProductIds = await resolveProductIds(change);
        }

        const affectedProductIds = new Set<number>();
        let hasErrors = false;

        for (const item of items) {
          try {
            if (item.entityType === "product") {
              if (item.productId) {
                await applyProductFieldChange(item.productId, item.fieldName, item.newValue);
                affectedProductIds.add(item.productId);
                await storage.applyScheduledChangeItem(item.id, "applied");
              } else if (change.scopeType === "group" && groupProductIds.length > 0) {
                for (const pid of groupProductIds) {
                  await applyProductFieldChange(pid, item.fieldName, item.newValue);
                  affectedProductIds.add(pid);
                }
                await storage.applyScheduledChangeItem(item.id, "applied");
              } else {
                await storage.applyScheduledChangeItem(item.id, "error", "No product ID to apply change to");
                hasErrors = true;
              }
            } else if (item.entityType === "variant_price") {
              const changeMode = item.changeMode || "absolute";

              if (item.productId) {
                const { oldPrices, newPrices } = await applyVariantPriceChange(item.productId, item.fieldName, item.newValue, changeMode);
                affectedProductIds.add(item.productId);

                const serializedOldPrices = serializeOldPrices(oldPrices);
                const computedNewValue = changeMode === "percentage"
                  ? serializeOldPrices(newPrices)
                  : item.newValue;
                await db
                  .update(scheduledChangeItem)
                  .set({ status: "applied", oldValue: serializedOldPrices, newValue: computedNewValue })
                  .where(eq(scheduledChangeItem.id, item.id));
              } else if (change.scopeType === "group" && groupProductIds.length > 0) {
                const allOldPrices = new Map<number, string | null>();
                const allNewPrices = new Map<number, string | null>();
                for (const pid of groupProductIds) {
                  const { oldPrices, newPrices } = await applyVariantPriceChange(pid, item.fieldName, item.newValue, changeMode);
                  for (const [vid, price] of oldPrices) {
                    allOldPrices.set(vid, price);
                  }
                  for (const [vid, price] of newPrices) {
                    allNewPrices.set(vid, price);
                  }
                  affectedProductIds.add(pid);
                }
                const serializedOldPrices = serializeOldPrices(allOldPrices);
                const computedNewValue = changeMode === "percentage"
                  ? serializeOldPrices(allNewPrices)
                  : item.newValue;
                await db
                  .update(scheduledChangeItem)
                  .set({ status: "applied", oldValue: serializedOldPrices, newValue: computedNewValue })
                  .where(eq(scheduledChangeItem.id, item.id));
              } else {
                await storage.applyScheduledChangeItem(item.id, "error", "No product ID to apply price change to");
                hasErrors = true;
              }
            } else if (item.entityType === "group_membership") {
              if (change.scopeGroupId && item.productId) {
                const endDate = item.newValue ? new Date(item.newValue) : null;
                await storage.addProductsToGroup(change.scopeGroupId, [item.productId], endDate);
                await storage.applyScheduledChangeItem(item.id, "applied");
              } else {
                await storage.applyScheduledChangeItem(item.id, "error", "Missing group or product ID for group membership change");
                hasErrors = true;
              }
            } else {
              await storage.applyScheduledChangeItem(item.id, "error", `Unsupported entity type: ${item.entityType}`);
              hasErrors = true;
            }
          } catch (itemErr: any) {
            console.error(`[ScheduledChanges] Error applying item #${item.id}:`, itemErr);
            await storage.applyScheduledChangeItem(item.id, "error", itemErr.message || "Unknown error");
            hasErrors = true;
          }
        }

        for (const pid of affectedProductIds) {
          try {
            await storage.insertSyncQueueEntry({
              productId: pid,
              operationType: "product_update",
            });
          } catch (syncErr) {
            console.error(`[ScheduledChanges] Failed to queue sync for product ${pid}:`, syncErr);
          }
        }

        if (hasErrors) {
          await storage.markScheduledChangeFailed(change.id, "Some items failed to apply");
        } else {
          await storage.markScheduledChangeApplied(change.id);
        }

        console.log(`[ScheduledChanges] Completed change #${change.id}, affected ${affectedProductIds.size} products`);
      } catch (changeErr: any) {
        console.error(`[ScheduledChanges] Failed to process change #${change.id}:`, changeErr);
        await storage.markScheduledChangeFailed(change.id, changeErr.message || "Unknown error");
      }
    }
  } catch (err) {
    console.error("[ScheduledChanges] Error in processor loop:", err);
  }
}

let intervalHandle: ReturnType<typeof setInterval> | null = null;

export function startScheduledChangeProcessor(): void {
  if (intervalHandle) return;

  console.log("[ScheduledChanges] Processor started (polling every 60s)");
  expireGroupMembers();
  processDueChanges();
  revertExpiredChanges();

  intervalHandle = setInterval(async () => {
    await expireGroupMembers();
    await processDueChanges();
    await revertExpiredChanges();
  }, POLL_INTERVAL_MS);
}

export function stopScheduledChangeProcessor(): void {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
    console.log("[ScheduledChanges] Processor stopped");
  }
}
