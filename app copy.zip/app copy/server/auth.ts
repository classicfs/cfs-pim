import type { Express, NextFunction, Request, Response } from "express";
import session from "express-session";
import passport from "passport";
import {
  Strategy as GoogleStrategy,
  type Profile,
  type VerifyCallback,
  type AuthenticateOptionsGoogle,
} from "passport-google-oauth20";
import createMemoryStore from "memorystore";
import { and, eq, sql } from "drizzle-orm";
import { dbReady } from "./db";
import { appRole, appUser, appUserRole, authIdentity } from "@shared/schema_v2";

type AuthedUser = {
  id: number;
  displayName: string;
  email: string;
  photo?: string;
  domain?: string;
  username?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  departmentId?: number | null;
  isActive: boolean;
  roles: Array<{
    roleId: number;
    assignedBy: number | null;
    assignedAt: string | null;
  }>;
  role?: string | null;
};


declare global {
  // Extend the Express user to include the fields we care about from Google
  namespace Express {
    interface User extends AuthedUser {}
  }
}

const MemoryStore = createMemoryStore(session);

function getRequiredEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function decodeState(stateParam: unknown): string {
  if (typeof stateParam !== "string") return "/";
  try {
    const parsed = JSON.parse(Buffer.from(stateParam, "base64url").toString("utf8"));
    const candidate = typeof parsed?.next === "string" ? parsed.next : "/";
    return candidate.startsWith("/") ? candidate : "/";
  } catch {
    return "/";
  }
}

function extractDomain(profile: Profile, email: string): string | undefined {
  // Google Workspace exposes the hosted domain on the hd claim
  const domainFromProfile = (profile._json as { hd?: string } | undefined)?.hd;
  if (domainFromProfile) return domainFromProfile;
  return email.includes("@") ? email.split("@")[1] : undefined;
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || "dev-session-secret";
  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const callbackURL = "/auth/google/callback";
  const allowedWorkspaceDomain = process.env.GOOGLE_WORKSPACE_DOMAIN;

  if (!googleClientId || !googleClientSecret) {
    const localUser: AuthedUser = {
      id: 1,
      displayName: "Josh",
      email: "josh@classicfootballshirts.co.uk",
      isActive: true,
      roles: [],
      role: null,
    };

    app.get("/api/auth/me", async (_req: Request, res: Response) => {
      try {
        // Look up the actual user from the DB so the id matches
        const db = await dbReady;
        const [dbUser] = await db
          .select()
          .from(appUser)
          .where(eq(appUser.email, localUser.email))
          .limit(1);
        if (dbUser) {
          localUser.id = Number(dbUser.appUserId);
        }
        const user = await buildAuthedUserFromDb(localUser.id, localUser);
        res.json(user);
      } catch (error) {
        console.error("Error loading current user:", error);
        res.status(500).json({ message: "Failed to load user" });
      }
    });

    app.post("/api/auth/logout", (_req: Request, res: Response) => {
      res.status(204).end();
    });

    return;
  }

  const requiredGoogleClientId = getRequiredEnv("GOOGLE_CLIENT_ID");
  const requiredGoogleClientSecret = getRequiredEnv("GOOGLE_CLIENT_SECRET");

  app.use(
    session({
      store: new MemoryStore({ checkPeriod: 86_400_000 }), // prune expired sessions daily
      secret: sessionSecret,
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 1000 * 60 * 60 * 8, // 8 hours
        sameSite: "lax",
        secure: app.get("env") === "production",
      },
    }),
  );

  passport.serializeUser((user, done) => {
    done(null, user);
  });

  passport.deserializeUser((user: Express.User, done) => {
    done(null, user);
  });

  passport.use(
    new GoogleStrategy(
      {
        clientID: requiredGoogleClientId,
        clientSecret: requiredGoogleClientSecret,
        callbackURL,
      },
      async (_accessToken: string, _refreshToken: string, profile: Profile, done: VerifyCallback) => {
        try {
          const email = profile.emails?.[0]?.value;
          if (!email) {
            return done(null, false, { message: "Email address is required" });
          }

          const domain = extractDomain(profile, email);
          if (allowedWorkspaceDomain && domain !== allowedWorkspaceDomain) {
            return done(null, false, { message: "Unauthorized workspace domain" });
          }

          const user = await syncUserProfile(profile, email, domain);
          return done(null, user);
        } catch (error) {
          return done(error as Error);
        }
      },
    ),
  );

  app.use(passport.initialize());
  app.use(passport.session());

  app.get(
    "/auth/google",
    (req, res, next) => {
      const nextParam = typeof req.query.next === "string" ? req.query.next : "/";
      const nextPath = nextParam.startsWith("/") ? nextParam : "/";
      const state = Buffer.from(JSON.stringify({ next: nextPath })).toString("base64url");

      const options: AuthenticateOptionsGoogle = {
        scope: ["profile", "email"],
        state,
        hd: allowedWorkspaceDomain,
      };

      passport.authenticate("google", options)(req, res, next);
    },
  );

  app.get(
    "/auth/google/callback",
    passport.authenticate("google", {
      failureRedirect: "/login",
      session: true,
    }),
    (req, res) => {
      const nextPath = decodeState(req.query.state);
      res.redirect(nextPath);
    },
  );

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await buildAuthedUserFromDb(req.user.id, req.user);
      res.json(user);
    } catch (error) {
      console.error("Error loading current user:", error);
      res.status(500).json({ message: "Failed to load user" });
    }
  });

  app.post("/api/auth/logout", (req: Request, res: Response, next: NextFunction) => {
    req.logout((err) => {
      if (err) return next(err);
      req.session?.destroy(() => {
        res.status(204).end();
      });
    });
  });

  app.use("/api", async (req, res, next) => {
    if (req.path.startsWith("/auth/")) {
      return next();
    }

    if (req.path.startsWith("/alumio/")) {
      return next();
    }

    if (req.path.startsWith("/public/")) {
      return next();
    }

    if (req.isAuthenticated?.()) {
      return next();
    }

    // LOCAL DEV BYPASS: auto-authenticate as the test user when no Google auth is configured
    if (process.env.NODE_ENV === "development" && !process.env.GOOGLE_CLIENT_ID) {
      const db = await dbReady;
      const [testUser] = await db
        .select()
        .from(appUser)
        .where(eq(appUser.email, "josh@classicfootballshirts.co.uk"))
        .limit(1);

      if (testUser) {
        (req as any).user = {
          id: Number(testUser.appUserId),
          displayName: testUser.displayName ?? "Josh",
          email: testUser.email,
          isActive: true,
          roles: [],
        };
        return next();
      }
    }

    return res.status(401).json({ message: "Not authenticated" });
  });
}

async function buildAuthedUserFromDb(
  userId: number,
  fallback: AuthedUser,
): Promise<AuthedUser> {
  const db = await dbReady;
  const [userRecord] = await db
    .select()
    .from(appUser)
    .where(eq(appUser.appUserId, userId))
    .limit(1);

  if (!userRecord) {
    return fallback;
  }

  const roleAssignments = await db
    .select({
      roleId: appUserRole.appRoleId,
      assignedBy: appUserRole.assignedBy,
      assignedAt: appUserRole.assignedAt,
      roleCode: appRole.code,
      roleName: appRole.name,
    })
    .from(appUserRole)
    .leftJoin(appRole, eq(appUserRole.appRoleId, appRole.appRoleId))
    .where(eq(appUserRole.appUserId, userRecord.appUserId));

  const roles = roleAssignments.map((assignment) => ({
    roleId: Number(assignment.roleId),
    assignedBy: assignment.assignedBy ?? null,
    assignedAt: assignment.assignedAt ? assignment.assignedAt.toISOString() : null,
  }));

  const email = userRecord.email;
  const domain = email.includes("@") ? email.split("@")[1] : undefined;

  return {
    id: Number(userRecord.appUserId),
    displayName: userRecord.displayName ?? fallback.displayName ?? email,
    email,
    photo: userRecord.avatarUrl ?? fallback.photo,
    domain: fallback.domain ?? domain,
    username: email.split("@")[0],
    firstName: userRecord.givenName ?? fallback.firstName,
    lastName: userRecord.familyName ?? fallback.lastName,
    departmentId: fallback.departmentId ?? null,
    isActive: userRecord.status === "active",
    roles,
    role: roleAssignments[0]?.roleName ?? roleAssignments[0]?.roleCode ?? null,
  };
}

async function syncUserProfile(profile: Profile, email: string, domain?: string): Promise<AuthedUser> {
  const db = await dbReady;
  const now = new Date();
  const googleSub = profile.id;
  const avatarUrl = profile.photos?.[0]?.value;
  const firstName = profile.name?.givenName ?? null;
  const lastName = profile.name?.familyName ?? null;
  const displayName =
    [firstName, lastName].filter(Boolean).join(" ").trim() || profile.displayName || email;
  const connectionResult = await db.execute(
    sql`SELECT current_database() AS db, current_user AS user`,
  );
  const connectionInfo = (connectionResult as { rows?: Array<{ db: string; user: string }> }).rows?.[0];
  console.log("[auth] db connection", connectionInfo);

  const [existingIdentity] = await db
    .select()
    .from(authIdentity)
    .where(and(eq(authIdentity.provider, "google"), eq(authIdentity.providerSubject, googleSub)))
    .limit(1);

  let userRecord: typeof appUser.$inferSelect | undefined;

  if (existingIdentity) {
    const [existingUser] = await db
      .select()
      .from(appUser)
      .where(eq(appUser.appUserId, existingIdentity.appUserId))
      .limit(1);
    userRecord = existingUser;
  } else {
    const [bySub] = await db
      .select()
      .from(appUser)
      .where(eq(appUser.googleSub, googleSub))
      .limit(1);
    const [byEmail] = await db
      .select()
      .from(appUser)
      .where(eq(appUser.email, email))
      .limit(1);
    userRecord = bySub ?? byEmail;
  }

  if (userRecord) {
    const [updatedUser] = await db
      .update(appUser)
      .set({
        email,
        googleSub,
        displayName,
        givenName: firstName,
        familyName: lastName,
        avatarUrl,
        lastLoginAt: now,
        updatedAt: now,
      })
      .where(eq(appUser.appUserId, userRecord.appUserId))
      .returning();
    userRecord = updatedUser ?? userRecord;
  } else {
    const [insertedUser] = await db
      .insert(appUser)
      .values({
        email,
        googleSub,
        displayName,
        givenName: firstName,
        familyName: lastName,
        avatarUrl,
        status: "active",
        lastLoginAt: now,
        createdAt: now,
        updatedAt: now,
      })
      .returning();
    userRecord = insertedUser;
  }

  if (existingIdentity) {
    await db
      .update(authIdentity)
      .set({
        appUserId: userRecord!.appUserId,
        providerEmail: email,
        providerPayload: profile._json ?? null,
        updatedAt: now,
      })
      .where(eq(authIdentity.authIdentityId, existingIdentity.authIdentityId));
  } else {
    await db.insert(authIdentity).values({
      appUserId: userRecord!.appUserId,
      provider: "google",
      providerSubject: googleSub,
      providerEmail: email,
      providerPayload: profile._json ?? null,
      createdAt: now,
      updatedAt: now,
    });
  }

  const roleAssignments = await db
    .select({
      roleId: appUserRole.appRoleId,
      assignedBy: appUserRole.assignedBy,
      assignedAt: appUserRole.assignedAt,
      roleCode: appRole.code,
      roleName: appRole.name,
    })
    .from(appUserRole)
    .leftJoin(appRole, eq(appUserRole.appRoleId, appRole.appRoleId))
    .where(eq(appUserRole.appUserId, userRecord!.appUserId));

  const roles = roleAssignments.map((assignment) => ({
    roleId: Number(assignment.roleId),
    assignedBy: assignment.assignedBy ?? null,
    assignedAt: assignment.assignedAt ? assignment.assignedAt.toISOString() : null,
  }));

  return {
    id: Number(userRecord!.appUserId),
    displayName: userRecord!.displayName ?? displayName ?? email,
    email: userRecord!.email,
    photo: userRecord!.avatarUrl ?? avatarUrl ?? undefined,
    domain,
    username: userRecord!.email.split("@")[0],
    firstName: userRecord!.givenName ?? firstName,
    lastName: userRecord!.familyName ?? lastName,
    departmentId: null,
    isActive: userRecord!.status === "active",
    roles,
    role: roleAssignments[0]?.roleName ?? roleAssignments[0]?.roleCode ?? null,
  };
}
