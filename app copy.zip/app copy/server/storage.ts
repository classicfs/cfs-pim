import { EventEmitter } from "events";

export interface ImportProgressEntry {
  sku: string;
  status: "success" | "error";
  message?: string;
  timestamp: number;
}

export interface ImportProgress {
  batchId: string;
  totalRows: number;
  processedRows: number;
  appliedRows: number;
  errorRows: number;
  status: "processing" | "completed" | "failed";
  entries: ImportProgressEntry[];
}

class ImportProgressTracker extends EventEmitter {
  private progress = new Map<string, ImportProgress>();

  start(batchId: string, totalRows: number) {
    this.progress.set(batchId, {
      batchId,
      totalRows,
      processedRows: 0,
      appliedRows: 0,
      errorRows: 0,
      status: "processing",
      entries: [],
    });
  }

  addEntry(batchId: string, entry: ImportProgressEntry) {
    const p = this.progress.get(batchId);
    if (!p) return;
    p.processedRows++;
    if (entry.status === "success") p.appliedRows++;
    else p.errorRows++;
    p.entries.push(entry);
    if (p.entries.length > 100) p.entries.shift();
  }

  complete(batchId: string, status: "completed" | "failed") {
    const p = this.progress.get(batchId);
    if (p) p.status = status;
  }

  get(batchId: string): ImportProgress | undefined {
    return this.progress.get(batchId);
  }

  getAll(): ImportProgress[] {
    return Array.from(this.progress.values());
  }

  getActive(): ImportProgress[] {
    return Array.from(this.progress.values()).filter(p => p.status === "processing");
  }

  remove(batchId: string) {
    this.progress.delete(batchId);
  }
}

export const importProgressTracker = new ImportProgressTracker();

import {
  brands,
  category,
  alumioSyncLog,
  club,
  competition,
  department,
  condition,
  gender,
  taxClass,
  attributeDef,
  productAttributeVal,
  variantAttributeVal,
  appPermission,
  appRole,
  appRolePermission,
  appUser,
  appUserRole,
  importJob,
  importError,
  importRow,
  kitCategory,
  kitClass,
  clubRivalry,
  product,
  productCategory,
  productColour,
  productSizes,
  productTeamMeta,
  productType,
  rivalryType,
  productVariant,
  currency,
  era,
  season,
  store,
  productStore,
  storeCurrency,
  clubRivalsExpanded,
  currencyConversionRate,
  imageAsset,
  variantChannelId,
  variantBarcode,
  variantPrice,
  variantStock,
  warehouse,
  productGroup,
  productGroupMember,
  type Product,
  type ProductVariant,
  type Store,
  type Warehouse,
  type VariantStock,
  type VariantPrice,
  type Club,
  type Season,
  type Category,
  type ImportJob,
  alumioSyncQueue,
  scheduledChange,
  scheduledChangeItem,
  type AlumioSyncLog,
  type InsertAlumioSyncLog,
  type AlumioSyncQueue,
  type InsertAlumioSyncQueue,
  type ScheduledChange,
  type ScheduledChangeItem,
  workspaceSetting,
  apiKey,
  type ApiKey,
} from "@shared/schema";
import { product as productV2, productPrice as productPriceV2, productAttributeVal as productAttributeValV2 } from "@shared/schema_v2";
import { db } from "./db";
import { and, asc, desc, eq, gte, ilike, inArray, isNull, lte, ne, or, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";

type StagingErrorInput = {
  fieldKey: string;
  errorCode: string;
  errorMessage: string;
  metaJson?: Record<string, any> | null;
};

type ImportAttributeOption = {
  key: string;
  label: string;
  aliases?: string[];
  source: "core" | "attribute";
};

type CatalogAttributeFilter = {
  field?: string;
  operator?: string;
  value?: any;
  source?: "product" | "variant" | "attribute";
  attributeId?: number;
  dataType?: string | null;
  scope?: string | null;
};

const PRODUCT_FIELDS = new Set([
  "productSku",
  "articleNumber",
  "productDescription",
  "productColourId",
  "genderId",
  "brandId",
  "productTypeId",
  "productStyle",
  "composition",
  "countryOfManufacture",
  "commodityCode",
  "imageCode",
  "enabled",
  "sync",
  "eraId",
]);

const PRODUCT_VARIANT_FIELDS = new Set([
  "productVariantSku",
  "productId",
  "sizeId",
  "taxClassId",
  "conditionId",
  "conditionDetail",
  "barcode",
  "widthCm",
  "lengthCm",
  "weight",
  "depth",
  "costPrice",
  "averageCostPrice",
  "customerPrice",
  "printed",
  "magentoProductId",
  "enabled",
]);

const INTEGER_FIELDS = new Set([
  "productColourId",
  "genderId",
  "brandId",
  "productTypeId",
  "productStyle",
  "productId",
  "sizeId",
  "taxClassId",
  "conditionId",
  "widthCm",
  "lengthCm",
  "magentoProductId",
  "eraId",
]);

const DECIMAL_FIELDS = new Set([
  "weight",
  "depth",
  "costPrice",
  "averageCostPrice",
  "customerPrice",
]);

const BOOLEAN_FIELDS = new Set(["enabled", "printed", "sync"]);
const ATTRIBUTE_IGNORE_FIELDS = new Set([
  ...PRODUCT_FIELDS,
  ...PRODUCT_VARIANT_FIELDS,
  "sku",
  "additionalAttributes",
  "club",
  "clubId",
  "clubName",
  "team",
  "teamId",
  "teamName",
  "brand",
  "brandName",
  "productType",
  "productTypeName",
  "colour",
  "color",
  "productColourName",
  "productColour",
  "gender",
  "genderName",
  "size",
  "sizeName",
  "sizeShortName",
  "sizeLongName",
  "magentoSizeId",
  "era",
  "eraName",
  "productStyleName",
  "productWebsites",
  "product_websites",
  "imageUrl",
  "image_url",
  "imageRole",
  "image_role",
  "imageSortOrder",
  "image_sort_order",
  "storeViewCode",
  "store_view_code",
  "taxClassName",
  "tax_class_name",
  "attributeSetCode",
  "attribute_set_code",
  "department",
  "brandN",
  "teams",
  "sizeProduct",
  "prodcat",
  "defects",
  "commodityComposition",
  "countryofmanufacturer",
  "seasons",
  "seasonName",
]);

const PRICE_COLUMN_REGEX = /^(price|retailPrice|retail_price|specialPrice|costPrice|special_price|cost_price|specialRetailPrice|special_retail_price)[-_]?[a-zA-Z]{3}$/i;
const BARE_PRICE_FIELDS = new Set(["price", "cost"]);

function shouldIgnoreAsAttribute(key: string): boolean {
  if (ATTRIBUTE_IGNORE_FIELDS.has(key)) return true;
  if (PRICE_COLUMN_REGEX.test(key)) return true;
  if (BARE_PRICE_FIELDS.has(key)) return true;
  return false;
}

const CORE_IMPORT_ATTRIBUTE_OPTIONS: ImportAttributeOption[] = [
  { key: "productVariantSku", label: "Product Variant SKU", aliases: ["sku", "productVariantSku", "product_variant_sku"], source: "core" },
  { key: "productSku", label: "Product SKU", aliases: ["productSku", "product_sku", "parentSku", "parent_sku"], source: "core" },
  { key: "name", label: "Name", aliases: ["name", "productName", "product_name"], source: "core" },
  { key: "qty", label: "Quantity", aliases: ["qty", "quantity", "stock_qty", "stockQty", "original_quantity", "originalQuantity"], source: "core" },
  { key: "articleNumber", label: "Article Number", aliases: ["articleNumber", "article_number"], source: "core" },
  { key: "productDescription", label: "Product Description", aliases: ["productDescription", "product_description"], source: "core" },
  {
    key: "clubName",
    label: "Club",
    aliases: ["club", "clubId", "clubName", "team", "teamId", "teamName", "club_name", "club_id", "team_name", "team_id", "teams"],
    source: "core",
  },
  { key: "brandName", label: "Brand", aliases: ["brand", "brandId", "brandName", "brand_name", "brand_id", "brandN", "brand_n"], source: "core" },
  { key: "productTypeName", label: "Product Type", aliases: ["productType", "productTypeId", "productTypeName", "product_type", "product_type_id", "product_type_name"], source: "core" },
  { key: "genderName", label: "Gender", aliases: ["gender", "genderId", "genderName", "gender_name", "gender_id"], source: "core" },
  { key: "productColourName", label: "Product Colour", aliases: ["productColour", "productColourId", "productColourName", "colour", "color", "product_colour", "product_colour_id", "product_colour_name", "product_color"], source: "core" },
  { key: "productStyle", label: "Product Style", aliases: ["productStyle", "product_style", "productstyle", "productStyleName", "product_style_name"], source: "core" },
  { key: "eraName", label: "Era", aliases: ["era", "eraId", "eraName", "era_name", "era_id"], source: "core" },
  { key: "composition", label: "Composition", aliases: ["composition", "commodityComposition", "commodity_composition"], source: "core" },
  { key: "countryOfManufacture", label: "Country Of Manufacture", aliases: ["countryOfManufacture", "country_of_manufacture", "countryofmanufacturer", "country_of_manufacturer", "countryOfManufacturer"], source: "core" },
  { key: "commodityCode", label: "Commodity Code", aliases: ["commodityCode", "commodity_code"], source: "core" },
  { key: "imageCode", label: "Image Code", aliases: ["imageCode", "image_code"], source: "core" },
  { key: "enabled", label: "Enabled", aliases: ["enabled", "status"], source: "core" },
  { key: "productId", label: "Product", aliases: ["productId", "product_id"], source: "core" },
  {
    key: "sizeName",
    label: "Size",
    aliases: ["size", "sizeId", "sizeName", "sizeShortName", "sizeLongName", "magentoSizeId", "size_name", "size_id", "size_short_name", "size_long_name", "magento_size_id", "sizeProduct", "size_product"],
    source: "core",
  },
  { key: "taxClassId", label: "Tax Class", aliases: ["taxClassId", "tax_class_id", "Tax Class", "tax_class", "TaxClass", "taxClassName", "tax_class_name"], source: "core" },
  { key: "conditionId", label: "Condition", aliases: ["conditionId", "condition_id", "condition", "product_condition", "prodcat"], source: "core" },
  { key: "conditionDetail", label: "Condition Detail", aliases: ["conditionDetail", "condition_detail", "defects"], source: "core" },
  { key: "barcode", label: "Barcode", source: "core" },
  { key: "widthCm", label: "Width Cm", aliases: ["widthCm", "width_cm"], source: "core" },
  { key: "lengthCm", label: "Length Cm", aliases: ["lengthCm", "length_cm"], source: "core" },
  { key: "weight", label: "Weight", source: "core" },
  { key: "depth", label: "Depth", source: "core" },
  { key: "price", label: "Price (Retail)", aliases: ["price"], source: "core" },
  { key: "cost", label: "Cost", aliases: ["cost"], source: "core" },
  { key: "costPrice", label: "Cost Price", aliases: ["costPrice", "cost_price"], source: "core" },
  { key: "averageCostPrice", label: "Average Cost Price", aliases: ["averageCostPrice", "average_cost_price"], source: "core" },
  { key: "customerPrice", label: "Customer Price", aliases: ["customerPrice", "customer_price"], source: "core" },
  { key: "printed", label: "Printed", source: "core" },
  { key: "magentoProductId", label: "Magento Product Id", aliases: ["magentoProductId", "magento_product_id"], source: "core" },
  { key: "departmentName", label: "Department", aliases: ["department", "departmentId", "departmentName", "department_name", "department_id"], source: "core" },
  { key: "competitionName", label: "Competition", aliases: ["competition", "competitionId", "competitionName", "competition_name", "competition_id"], source: "core" },
  { key: "seasonName", label: "Season", aliases: ["season", "seasonId", "seasonName", "season_name", "season_id", "seasons"], source: "core" },
  { key: "kitCategoryName", label: "Kit Category", aliases: ["kitCategory", "kitCategoryId", "kitCategoryName", "kit_category", "kit_category_id", "kit_category_name"], source: "core" },
  { key: "kitClassName", label: "Kit Class", aliases: ["kitClass", "kitClassId", "kitClassName", "kit_class", "kit_class_id", "kit_class_name"], source: "core" },
  { key: "channelName", label: "Channel", aliases: ["channel", "channelId", "channelName", "channel_name", "channel_id"], source: "core" },
  { key: "categories", label: "Categories", aliases: ["categories", "category", "categoryPaths"], source: "core" },
  { key: "productWebsites", label: "Product Websites", aliases: ["productWebsites", "product_websites"], source: "core" },
  { key: "baseImage", label: "Base Image", aliases: ["baseImage", "base_image"], source: "core" },
  { key: "smallImage", label: "Small Image", aliases: ["smallImage", "small_image"], source: "core" },
  { key: "thumbnailImage", label: "Thumbnail Image", aliases: ["thumbnailImage", "thumbnail_image"], source: "core" },
  { key: "additionalImages", label: "Additional Images", aliases: ["additionalImages", "additional_images"], source: "core" },
  { key: "storeViewCode", label: "Store View Code", aliases: ["storeViewCode", "store_view_code"], source: "core" },
];

function normalizeBooleanValue(value: any): boolean | null {
  if (value === null || value === undefined) return null;
  if (typeof value === "boolean") return value;
  const raw = String(value).trim().toLowerCase();
  if (raw === "") return null;
  if (["1", "true", "yes", "y"].includes(raw)) return true;
  if (["0", "false", "no", "n"].includes(raw)) return false;
  return null;
}

function normalizeNumberValue(value: any, integerOnly: boolean): number | null {
  if (value === null || value === undefined) return null;
  const raw = String(value).trim();
  if (raw === "") return null;
  const parsed = integerOnly ? Number.parseInt(raw, 10) : Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeDataValues(data: Record<string, any>): Record<string, any> {
  const normalized: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (INTEGER_FIELDS.has(key)) {
      normalized[key] = normalizeNumberValue(value, true);
      continue;
    }
    if (DECIMAL_FIELDS.has(key)) {
      normalized[key] = normalizeNumberValue(value, false);
      continue;
    }
    if (BOOLEAN_FIELDS.has(key)) {
      normalized[key] = normalizeBooleanValue(value);
      continue;
    }
    if (value === null || value === undefined) {
      normalized[key] = value;
      continue;
    }
    const raw = String(value);
    if (key === "barcode" && raw.trim() !== "" && /^\d+(\.\d+)?[eE]\+?\d+$/i.test(raw.trim())) {
      try {
        const sciStr = raw.trim();
        const match = sciStr.match(/^(\d+)(?:\.(\d+))?[eE]\+?(\d+)$/i);
        if (match) {
          const intPart = match[1];
          const fracPart = match[2] || "";
          const exp = parseInt(match[3], 10);
          const digits = intPart + fracPart;
          const neededZeros = exp - fracPart.length;
          if (neededZeros >= 0) {
            normalized[key] = digits + "0".repeat(neededZeros);
          } else {
            normalized[key] = null;
          }
          continue;
        }
      } catch {}
    }
    normalized[key] = raw.trim() === "" ? null : value;
  }
  return normalized;
}

function removeNullishValues(data: Record<string, any>): Record<string, any> {
  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value === null || value === undefined) continue;
    cleaned[key] = value;
  }
  return cleaned;
}

function normalizeAttributeCode(value: string): string {
  const trimmed = value.trim().replace(/\*+$/g, "");
  if (!trimmed) return trimmed;
  // Insert underscores between camelCase boundaries: "urlKey" → "url_Key" → "url_key"
  const withUnderscores = trimmed
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")  // camelCase boundary
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2"); // consecutive caps: "HTMLParser" → "HTML_Parser"
  return withUnderscores.replace(/[^\w]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
}

function labelizeAttributeCode(value: string): string {
  const cleaned = value
    .replace(/_/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .trim();
  if (!cleaned) return value;
  return cleaned
    .split(" ")
    .filter((part) => part)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function toMagentoScope(value: string | null | undefined): "global" | "website" | "store_view" {
  if (!value) return "global";
  const normalized = String(value).trim().toLowerCase();
  if (normalized === "website") return "website";
  if (normalized === "store_view") return "store_view";
  return "global";
}

function coerceFilterValue(value: any, dataType: string | null | undefined): any {
  if (value === null || value === undefined) return null;
  if (dataType === "number") {
    return normalizeNumberValue(value, false);
  }
  if (dataType === "boolean") {
    return normalizeBooleanValue(value);
  }
  if (dataType === "date") {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  return String(value);
}

function buildFilterCondition(
  expr: ReturnType<typeof sql> | any,
  operator: string,
  value: any,
  dataType: string | null | undefined,
): ReturnType<typeof sql> | null {
  if (!operator) return null;
  const normalizedOperator = operator.trim();

  if (normalizedOperator === "isEmpty") {
    if (dataType === "text" || dataType === "json") {
      return sql`${expr} is null OR ${expr} = ''`;
    }
    return sql`${expr} is null`;
  }
  if (normalizedOperator === "isNotEmpty") {
    if (dataType === "text" || dataType === "json") {
      return sql`${expr} is not null AND ${expr} <> ''`;
    }
    return sql`${expr} is not null`;
  }

  if (value === null || value === undefined || value === "") {
    return null;
  }

  if (normalizedOperator === "contains") {
    const like = `%${String(value)}%`;
    return sql`CAST(${expr} AS TEXT) ILIKE ${like}`;
  }

  if (normalizedOperator === "eq") {
    return sql`${expr} = ${value}`;
  }
  if (normalizedOperator === "neq") {
    return sql`${expr} <> ${value}`;
  }
  if (normalizedOperator === "gt") {
    return sql`${expr} > ${value}`;
  }
  if (normalizedOperator === "gte") {
    return sql`${expr} >= ${value}`;
  }
  if (normalizedOperator === "lt") {
    return sql`${expr} < ${value}`;
  }
  if (normalizedOperator === "lte") {
    return sql`${expr} <= ${value}`;
  }

  return null;
}

function buildImportAttributeOptions(
  attributeDefs: Array<{ code: string; label: string | null; attributeId?: number | null }>,
  extraOptions?: ImportAttributeOption[],
): ImportAttributeOption[] {
  const optionMap = new Map<string, ImportAttributeOption>();
  for (const option of CORE_IMPORT_ATTRIBUTE_OPTIONS) {
    optionMap.set(option.key, option);
  }
  if (extraOptions) {
    for (const option of extraOptions) {
      if (!optionMap.has(option.key)) {
        optionMap.set(option.key, option);
      }
    }
  }
  for (const def of attributeDefs) {
    const code = def.code?.trim();
    if (!code) continue;
    if (optionMap.has(code)) continue;
    const aliases = [code];
    if (def.attributeId !== null && def.attributeId !== undefined) {
      aliases.push(String(def.attributeId));
    }
    optionMap.set(code, {
      key: code,
      label: def.label?.trim() || labelizeAttributeCode(code),
      aliases,
      source: "attribute",
    });
  }

  return Array.from(optionMap.values()).sort((a, b) =>
    a.label.localeCompare(b.label, "en"),
  );
}

function parseAdditionalAttributes(value: any): Record<string, string> {
  if (value === null || value === undefined) return {};
  if (typeof value !== "string") return {};
  const raw = value.trim();
  if (!raw) return {};
  const entries = raw.split(",");
  const parsed: Record<string, string> = {};
  for (const entry of entries) {
    const trimmed = entry.trim();
    if (!trimmed) continue;
    const equalsIndex = trimmed.indexOf("=");
    if (equalsIndex === -1) continue;
    const key = trimmed.slice(0, equalsIndex).trim();
    const val = trimmed.slice(equalsIndex + 1).trim();
    if (!key) continue;
    parsed[key] = val;
  }
  return parsed;
}

function inferAttributeValue(value: any): {
  dataType: "text" | "number" | "boolean" | "json";
  valueText: string | null;
  valueNum: number | null;
  valueBool: boolean | null;
  valueJson: any | null;
} | null {
  if (value === null || value === undefined) return null;

  if (typeof value === "object") {
    return {
      dataType: "json",
      valueText: null,
      valueNum: null,
      valueBool: null,
      valueJson: value,
    };
  }

  const raw = String(value).trim();
  if (raw === "") return null;

  const boolValue = normalizeBooleanValue(raw);
  if (boolValue !== null) {
    return {
      dataType: "boolean",
      valueText: null,
      valueNum: null,
      valueBool: boolValue,
      valueJson: null,
    };
  }

  const numericValue = normalizeNumberValue(raw, false);
  if (numericValue !== null) {
    return {
      dataType: "number",
      valueText: null,
      valueNum: numericValue,
      valueBool: null,
      valueJson: null,
    };
  }

  if ((raw.startsWith("{") && raw.endsWith("}")) || (raw.startsWith("[") && raw.endsWith("]"))) {
    try {
      const parsed = JSON.parse(raw);
      return {
        dataType: "json",
        valueText: null,
        valueNum: null,
        valueBool: null,
        valueJson: parsed,
      };
    } catch {
      // fall through to text
    }
  }

  return {
    dataType: "text",
    valueText: raw,
    valueNum: null,
    valueBool: null,
    valueJson: null,
  };
}

function coerceAttributeValue(
  value: any,
  dataType: string | null,
): { valueText: string | null; valueNum: number | null; valueBool: boolean | null; valueJson: any | null } | null {
  if (value === null || value === undefined) return null;
  const raw = typeof value === "string" ? value.trim() : value;
  if (typeof raw === "string" && raw === "") return null;

  if (!dataType) {
    const inferred = inferAttributeValue(raw);
    return inferred
      ? {
          valueText: inferred.valueText,
          valueNum: inferred.valueNum,
          valueBool: inferred.valueBool,
          valueJson: inferred.valueJson,
        }
      : null;
  }

  if (dataType === "number") {
    const parsed = normalizeNumberValue(raw, false);
    if (parsed === null) {
      throw new Error("Invalid attribute number value");
    }
    return { valueText: null, valueNum: parsed, valueBool: null, valueJson: null };
  }

  if (dataType === "boolean") {
    const parsed = normalizeBooleanValue(raw);
    if (parsed === null) {
      throw new Error("Invalid attribute boolean value");
    }
    return { valueText: null, valueNum: null, valueBool: parsed, valueJson: null };
  }

  if (dataType === "json") {
    if (typeof raw === "string") {
      try {
        const parsed = JSON.parse(raw);
        return { valueText: null, valueNum: null, valueBool: null, valueJson: parsed };
      } catch (error) {
        throw new Error("Invalid attribute JSON value");
      }
    }
    return { valueText: null, valueNum: null, valueBool: null, valueJson: raw };
  }

  return { valueText: String(raw), valueNum: null, valueBool: null, valueJson: null };
}

export interface ProductFilters {
  search?: string;
  brandId?: number;
  categoryId?: number;
  clubId?: number;
  seasonId?: number;
  departmentId?: number;
  enabled?: boolean;
  attributeFilters?: Array<{
    field?: string;
    operator?: string;
    value?: any;
    source?: "product" | "variant" | "attribute";
    attributeId?: number;
    dataType?: string | null;
    scope?: string | null;
  }>;
  sortBy?: string;
  order?: string;
  startDate?: string;
  endDate?: string;
  stockLevel?: string;
  minAttribution?: number;
  limit?: number;
  offset?: number;
}

export interface CreateProductInput {
  productSku: string;
  productDescription: string;
  articleNumber?: string | null;
  productColourId?: number | null;
  genderId?: number | null;
  brandId?: number | null;
  productTypeId?: number | null;
  productStyle?: string | null;
  taxClassId?: number | null;
  clubId?: number | null;
  composition?: string | null;
  countryOfManufacture?: string | null;
  commodityCode?: string | null;
  imageCode?: string | null;
  categoryId?: number | null;
  categoryIds?: number[] | null;
  enabled?: boolean;
  sync?: boolean;
  // Simple product variant fields (auto-create variant when productType is 'simple')
  variantSku?: string | null;
  sizeId?: number | null;
  taxClassId?: number | null;
  conditionId?: number | null;
  barcode?: string | null;
  weight?: number | null;
  costPrice?: number | null;
  retailPrice?: number | null;
  specialRetailPrice?: number | null;
  stockQty?: number | null;
  warehouseId?: number | null;
}

export interface CreateVariantInput {
  productId: number;
  productVariantSku: string;
  sizeId?: number | null;
  taxClassId?: number | null;
  conditionId?: number | null;
  conditionDetail?: string | null;
  barcode?: string | null;
  widthCm?: number | null;
  lengthCm?: number | null;
  weight?: number | null;
  depth?: number | null;
  costPrice?: number | null;
  averageCostPrice?: number | null;
  customerPrice?: number | null;
  printed?: boolean | null;
  magentoProductId?: number | null;
  enabled?: boolean;
}

export interface IStorage {
  getDashboardMetrics(): Promise<{
    totalProducts: number;
    totalVariants: number;
    totalStock: number;
    storeCount: number;
    averageDataAttribution: number;
  }>;
  getProductStatusCounts(): Promise<{
    enabled: number;
    disabled: number;
  }>;
  getProductActivityCounts(startDate: Date, endDate: Date): Promise<{
    created: number;
    updated: number;
    unchanged: number;
    total: number;
  }>;
  getProductMissingAttributeCounts(attributeKey: string): Promise<{
    missing: number;
    total: number;
  }>;

  getProducts(limit?: number): Promise<Product[]>;
  getProductsWithFilters(filters: ProductFilters): Promise<any[]>;
  getProductsCount(filters: ProductFilters): Promise<number>;
  getProduct(productId: number): Promise<Product | undefined>;
  getProductWithAttribution(productId: number): Promise<any>;
  updateProduct(productId: number, updates: Partial<Product>): Promise<void>;
  setProductPrimaryTeam(productId: number, clubId: number | null): Promise<void>;
  getProductVariants(productId: number): Promise<any[]>;
  getVariant(variantId: number): Promise<ProductVariant | undefined>;
  updateVariant(variantId: number, updates: Partial<ProductVariant>): Promise<void>;
  createProduct(input: CreateProductInput): Promise<{ productId: number }>;
  createProductVariant(input: CreateVariantInput): Promise<{ productVariantId: number }>;
  createClub(input: { name: string; country?: string | null; foundedYear?: number | null }): Promise<any>;
  getClubByName(name: string): Promise<any | null>;
  updateClub(input: { clubId: number; name: string; country?: string | null; foundedYear?: number | null }): Promise<any>;
  deleteClub(clubId: number): Promise<void>;
  createGender(input: { genderName: string }): Promise<any>;
  updateGender(input: { genderId: number; genderName: string }): Promise<any>;
  deleteGender(genderId: number): Promise<void>;
  createBrand(input: { brandId?: number | null; brandName: string; brandGrouping?: string | null }): Promise<any>;
  createProductType(input: { productTypeId?: number | null; productTypeName: string }): Promise<any>;
  createCondition(input: { conditionId?: number | null; conditionName: string }): Promise<any>;
  createTaxClass(input: { taxClassName: string }): Promise<any>;
  createProductColour(input: {
    magentoColourName?: string | null;
    magentoColourId?: string | null;
    brandId?: number | null;
    brandColourId?: number | null;
    brandColourName?: string | null;
  }): Promise<any>;
  createSize(input: {
    magentoSizeId?: number | null;
    magentoSizeShortName?: string | null;
    magentoSizeLongName?: string | null;
    configOptions?: string | null;
    sizingCategory?: string | null;
  }): Promise<any>;
  updateBrand(input: { brandId: number; brandName: string; brandGrouping?: string | null }): Promise<any>;
  deleteBrand(brandId: number): Promise<void>;
  updateProductType(input: { productTypeId: number; productTypeName: string }): Promise<any>;
  deleteProductType(productTypeId: number): Promise<void>;
  updateCondition(input: { conditionId: number; conditionName: string }): Promise<any>;
  deleteCondition(conditionId: number): Promise<void>;
  updateTaxClass(input: { taxClassId: number; taxClassName: string }): Promise<any>;
  deleteTaxClass(taxClassId: number): Promise<void>;
  updateProductColour(input: {
    productColourId: number;
    magentoColourName?: string | null;
    magentoColourId?: string | null;
    brandId?: number | null;
    brandColourId?: number | null;
    brandColourName?: string | null;
  }): Promise<any>;
  deleteProductColour(productColourId: number): Promise<void>;
  updateSize(input: {
    sizeId: number;
    magentoSizeId?: number | null;
    magentoSizeShortName?: string | null;
    magentoSizeLongName?: string | null;
    configOptions?: string | null;
    sizingCategory?: string | null;
  }): Promise<any>;
  deleteSize(sizeId: number): Promise<void>;

  getVariantStock(variantId: number): Promise<VariantStock[]>;
  getVariantPrices(variantId: number): Promise<VariantPrice[]>;
  getVariantPricesWithCurrency(variantId: number): Promise<any[]>;
  getProductPricesWithStores(productId: number): Promise<any[]>;
  upsertVariantPrice(input: {
    productVariantId: number;
    currencyId: number;
    retailPrice?: string | null;
    specialRetailPrice?: string | null;
    costPrice?: string | null;
    isManualOverride?: boolean;
  }): Promise<void>;

  getConversionRates(): Promise<any[]>;
  upsertConversionRate(input: {
    fromCurrencyId: number;
    toCurrencyId: number;
    rate: string;
  }): Promise<void>;
  autoConvertPricesFromBase(variantId: number, baseCurrencyCode?: string): Promise<void>;

  getStores(): Promise<Store[]>;
  createStore(input: { code: string; name?: string | null; websiteCode: string }): Promise<Store>;
  updateStore(storeId: number, input: { code?: string; name?: string | null; websiteCode?: string }): Promise<Store>;
  getProductStores(productId: number): Promise<any[]>;
  setProductStores(productId: number, storeIds: number[]): Promise<void>;
  getStoreProductCounts(): Promise<Array<{ storeId: number; productCount: number }>>;
  getCurrencies(): Promise<any[]>;
  getStoreCurrencies(): Promise<any[]>;
  setStoreDefaultCurrency(storeId: number, currencyId: number): Promise<void>;
  getWarehouses(): Promise<Warehouse[]>;
  getBrands(): Promise<any[]>;
  getProductTypes(): Promise<any[]>;
  getProductStyles(): Promise<string[]>;
  getProductColours(): Promise<any[]>;
  getGenders(): Promise<any[]>;
  getSizes(): Promise<any[]>;
  getTaxClasses(): Promise<any[]>;
  getConditions(): Promise<any[]>;
  getAttributeDefs(): Promise<any[]>;
  createAttributeDef(input: {
    code: string;
    label?: string | null;
    dataType?: string | null;
    magentoSync?: boolean;
    magentoScope?: string | null;
  }): Promise<any>;
  updateAttributeDef(attributeId: number, updates: { magentoSync?: boolean; label?: string | null; magentoScope?: string | null }): Promise<any>;
  deleteAttributeDef(attributeId: number): Promise<void>;
  getProductAttributes(productId: number, storeId?: number | null): Promise<any[]>;
  getBulkProductAttributes(productIds: number[], attributeIds: number[]): Promise<any[]>;
  getVariantAttributes(variantId: number): Promise<any[]>;
  setProductAttributeValue(input: { productId: number; attributeId: number; value: any; storeId?: number | null }): Promise<void>;
  setVariantAttributeValue(input: { variantId: number; attributeId: number; value: any }): Promise<void>;
  deleteProductAttributeValue(input: { productId: number; attributeId: number; storeId?: number | null }): Promise<void>;
  deleteVariantAttributeValue(input: { variantId: number; attributeId: number }): Promise<void>;
  deleteProduct(productId: number): Promise<void>;
  deleteProducts(productIds: number[]): Promise<void>;
  duplicateProduct(productId: number): Promise<{ productId: number; productSku: string }>;
  attachSimpleProductsToConfigurable(configurableProductId: number, simpleProductIds: number[]): Promise<{ attached: number; removed: number }>;
  detachVariantToNewProduct(configurableProductId: number, variantId: number): Promise<{ newProductId: number; newProductSku: string }>;
  getClubs(limit?: number): Promise<Club[]>;
  getClubRivalries(clubId: number): Promise<{ club: Club; rivals: any[] } | null>;
  createEra(input: { name: string; startYear: number; endYear: number }): Promise<any>;
  updateEra(input: { eraId: number; name: string; startYear: number; endYear: number }): Promise<any>;
  deleteEra(eraId: number): Promise<void>;
  getEras(): Promise<any[]>;
  updateClubRivalry(input: {
    clubRivalryId: number;
    rivalryTypeId?: number | null;
    knownAs?: string | null;
    intensity?: number | null;
    periodStart?: Date | null;
    periodEnd?: Date | null;
    isPrimary?: boolean | null;
    notes?: string | null;
  }): Promise<any | null>;
  createClubRivalry(input: {
    clubIdA: number;
    clubIdB: number;
    rivalryTypeId: number;
    knownAs?: string | null;
    intensity?: number | null;
    periodStart?: Date | null;
    periodEnd?: Date | null;
    isPrimary?: boolean | null;
    notes?: string | null;
  }): Promise<any>;
  getRivalryTypes(): Promise<any[]>;
  createRivalryType(input: {
    code: string;
    name: string;
    description?: string | null;
  }): Promise<any>;
  updateRivalryType(input: {
    rivalryTypeId: number;
    code: string;
    name: string;
    description?: string | null;
  }): Promise<any | null>;
  getSeasons(): Promise<Season[]>;
  getCategories(): Promise<Category[]>;
  getCategoryById(categoryId: number): Promise<Category | null>;
  getCategoryByPathKey(pathKey: string): Promise<Category | null>;
  createCategory(input: { name: string; pathKey: string; parentId?: number | null }): Promise<Category>;
  updateCategory(categoryId: number, input: { name?: string; parentId?: number | null }): Promise<Category | null>;
  deleteCategory(categoryId: number): Promise<void>;
  getProductsByCategory(categoryId: number): Promise<any[]>;
  getCategoriesForProduct(productId: number): Promise<Category[]>;
  assignProductToCategories(productId: number, categoryIds: number[]): Promise<void>;
  getOrCreateCategoryByPath(path: string): Promise<Category>;
  getDepartments(): Promise<any[]>;

  getProductTeamMeta(productId: number): Promise<any[]>;
  getImportAttributeOptions(): Promise<ImportAttributeOption[]>;

  clearStaging(batchId: string): Promise<void>;
  clearStagingRows(batchId: string): Promise<void>;
  insertStagingRows(
    importJobId: number,
    loadedAt: Date,
    sourceBlob: string,
    rows: Array<{ data: any; status: "pending" | "invalid"; errors?: StagingErrorInput[] }>,
  ): Promise<void>;
  getStagingSummary(batchId: string): Promise<any>;
  getStagingRows(batchId: string, limit: number, offset: number): Promise<any>;
  updateStagingRow(batchId: string, rowNumber: number, data: any, rawData?: any): Promise<void>;
  applyImportColumnMapping(batchId: string, mapping: Record<string, string | null>): Promise<void>;
  confirmImport(batchId: string): Promise<void>;
  processImport(batchId: string): Promise<void>;

  createImportBatch(
    batchId: string,
    fileNames: string,
    totalRows: number,
    userId?: number | null,
  ): Promise<ImportJob>;
  getImportBatches(): Promise<ImportJob[]>;
  getImportBatch(batchId: string): Promise<ImportJob | null>;
  updateImportBatchStatus(
    batchId: string,
    status: string,
    updates?: { processedProducts?: number; errorMessage?: string; completedAt?: Date },
  ): Promise<void>;

  createProductGroup(name: string, description: string | null, productIds: number[]): Promise<any>;
  getProductGroups(): Promise<any[]>;
  getProductGroup(groupId: number): Promise<any | null>;
  updateProductGroup(input: { groupId: number; name: string; description?: string | null; status?: string | null }): Promise<any>;
  getProductGroupProducts(groupId: number): Promise<any[]>;
  addProductsToGroup(groupId: number, productIds: number[], endDate?: Date | null): Promise<any[]>;
  updateProductGroupMember(groupId: number, memberId: number, updates: { live?: boolean; endDate?: Date | null }): Promise<any>;
  updateProductGroupMembersEndDate(groupId: number, memberIds: number[], endDate: Date | null): Promise<number>;
  deleteProductGroupMembers(groupId: number, memberIds: number[]): Promise<number>;
  reactivateProductGroupMember(groupId: number, memberId: number): Promise<any>;
  deleteProductGroup(groupId: number): Promise<void>;

  getWorkspaceUsers(): Promise<any[]>;
  getWorkspaceRoles(): Promise<any[]>;
  getWorkspacePermissions(): Promise<any[]>;
  assignWorkspaceUserRole(input: {
    userId: number;
    roleCode: string;
    assignedBy?: number | null;
  }): Promise<any>;
  updateWorkspaceRole(input: {
    code: string;
    name: string;
    description?: string | null;
    permissionIds: number[];
  }): Promise<any>;
  createWorkspaceRole(input: {
    code: string;
    name: string;
    description?: string | null;
    permissionIds: number[];
  }): Promise<any>;

  // Reference data imports
  getReferenceTableTypes(): Promise<Array<{ code: string; name: string; columns: Array<{ key: string; label: string; required: boolean }> }>>;
  importReferenceData(tableType: string, rows: any[]): Promise<{ inserted: number; updated: number; errors: string[] }>;

  // Image management
  getProductImages(productId: number): Promise<any[]>;
  getAllImages(options?: { limit?: number; offset?: number; search?: string; role?: string }): Promise<{ images: any[]; total: number }>;
  createImage(data: { productId: number; url: string; role: string; label?: string | null }): Promise<any>;
  deleteImage(imageId: number): Promise<void>;
  importImagesCsv(rows: Array<Record<string, string>>): Promise<{ imported: number; skipped: number; errors: string[] }>;

  createSyncLog(data: InsertAlumioSyncLog): Promise<AlumioSyncLog>;
  getSyncLogs(options?: {
    limit?: number;
    offset?: number;
    operationType?: string;
    statusFilter?: string;
    skuSearch?: string;
  }): Promise<{ logs: AlumioSyncLog[]; total: number }>;

  insertSyncQueueEntry(entry: { productId: number; productVariantId?: number | null; operationType: string }): Promise<AlumioSyncQueue>;
  resyncProductWithVariants(productId: number): Promise<{ productEntry: AlumioSyncQueue; variantEntries: AlumioSyncQueue[] }>;
  getSyncQueueEntries(options?: { status?: string; limit?: number; offset?: number }): Promise<{ entries: AlumioSyncQueue[]; total: number }>;
  updateSyncQueueStatus(ids: number[], status: string): Promise<void>;

  createScheduledChange(input: {
    name: string;
    description?: string | null;
    scheduledAt: Date;
    endsAt?: Date | null;
    scopeType: string;
    scopeGroupId?: number | null;
    productIds?: number[];
    items: Array<{
      entityType: string;
      fieldName: string;
      newValue?: string | null;
      oldValue?: string | null;
      changeMode?: string | null;
    }>;
    createdBy?: number | null;
  }): Promise<ScheduledChange>;
  getScheduledChanges(filters?: { status?: string }): Promise<any[]>;
  getScheduledChange(id: number): Promise<any | null>;
  getScheduledChangeItems(scheduledChangeId: number): Promise<ScheduledChangeItem[]>;
  updateScheduledChange(id: number, updates: { name?: string; description?: string | null; scheduledAt?: Date }): Promise<ScheduledChange | null>;
  cancelScheduledChange(id: number): Promise<boolean>;
  getDueScheduledChanges(): Promise<ScheduledChange[]>;
  applyScheduledChangeItem(itemId: number, status: string, errorMessage?: string | null): Promise<void>;
  markScheduledChangeApplied(id: number): Promise<void>;
  markScheduledChangeFailed(id: number, errorMessage: string): Promise<void>;

  getWorkspaceSetting(key: string): Promise<any>;
  setWorkspaceSetting(key: string, value: any): Promise<void>;

  getApiKeys(): Promise<ApiKey[]>;
  getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined>;
  createApiKey(input: { name: string; keyHash: string; keyPrefix: string; scopes: string[]; createdBy?: number | null }): Promise<ApiKey>;
  updateApiKey(apiKeyId: number, updates: { name?: string; scopes?: string[]; active?: boolean }): Promise<ApiKey | undefined>;
  deleteApiKey(apiKeyId: number): Promise<void>;
  touchApiKeyLastUsed(apiKeyId: number): Promise<void>;
}

const dataAttributionCalc = sql<number>`
  (
    CASE WHEN ${product.productSku} IS NOT NULL AND ${product.productSku} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.articleNumber} IS NOT NULL AND ${product.articleNumber} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.productDescription} IS NOT NULL AND ${product.productDescription} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.productColourId} IS NOT NULL THEN 1 ELSE 0 END +
    CASE WHEN ${product.genderId} IS NOT NULL THEN 1 ELSE 0 END +
    CASE WHEN ${product.brandId} IS NOT NULL THEN 1 ELSE 0 END +
    CASE WHEN ${product.productTypeId} IS NOT NULL THEN 1 ELSE 0 END +
    CASE WHEN ${product.productStyle} IS NOT NULL THEN 1 ELSE 0 END +
    CASE WHEN ${product.composition} IS NOT NULL AND ${product.composition} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.countryOfManufacture} IS NOT NULL AND ${product.countryOfManufacture} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.commodityCode} IS NOT NULL AND ${product.commodityCode} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.imageCode} IS NOT NULL AND ${product.imageCode} != '' THEN 1 ELSE 0 END +
    CASE WHEN ${product.enabled} IS NOT NULL THEN 1 ELSE 0 END
  ) * 100 / 13
`;

const missingFieldsCalc = sql<string>`
  ARRAY_TO_STRING(
    ARRAY_REMOVE(ARRAY[
      CASE WHEN ${product.productSku} IS NULL OR ${product.productSku} = '' THEN 'SKU' ELSE NULL END,
      CASE WHEN ${product.articleNumber} IS NULL OR ${product.articleNumber} = '' THEN 'Article Number' ELSE NULL END,
      CASE WHEN ${product.productDescription} IS NULL OR ${product.productDescription} = '' THEN 'Description' ELSE NULL END,
      CASE WHEN ${product.productColourId} IS NULL THEN 'Colour' ELSE NULL END,
      CASE WHEN ${product.genderId} IS NULL THEN 'Gender' ELSE NULL END,
      CASE WHEN ${product.brandId} IS NULL THEN 'Brand' ELSE NULL END,
      CASE WHEN ${product.productTypeId} IS NULL THEN 'Product Type' ELSE NULL END,
      CASE WHEN ${product.productStyle} IS NULL THEN 'Style' ELSE NULL END,
      CASE WHEN ${product.composition} IS NULL OR ${product.composition} = '' THEN 'Composition' ELSE NULL END,
      CASE WHEN ${product.countryOfManufacture} IS NULL OR ${product.countryOfManufacture} = '' THEN 'Country' ELSE NULL END,
      CASE WHEN ${product.commodityCode} IS NULL OR ${product.commodityCode} = '' THEN 'Commodity Code' ELSE NULL END,
      CASE WHEN ${product.imageCode} IS NULL OR ${product.imageCode} = '' THEN 'Image Code' ELSE NULL END,
      CASE WHEN ${product.enabled} IS NULL THEN 'Status' ELSE NULL END
    ], NULL),
    ', '
  )
`;

const variantCountCalc = sql<number>`(
  SELECT COUNT(*)::int
  FROM ${product} AS child
  WHERE child.parent_sku = ${product.productSku}
)`;

const totalStockCalc = sql<number>`(
  SELECT COALESCE(SUM(${variantStock.qty}), 0)::int
  FROM ${variantStock}
  WHERE ${variantStock.productVariantId} = ${product.productId}
)`;

const variantStockCalc = sql<number>`(
  SELECT COALESCE(SUM(${variantStock.qty}), 0)::int
  FROM ${variantStock}
  WHERE ${variantStock.productVariantId} = ${product.productId}
)`;

function parseImportJobId(batchId: string): number | null {
  const trimmed = batchId.trim();
  if (!trimmed) return null;
  const numeric = Number(trimmed);
  if (!Number.isNaN(numeric)) return numeric;
  const match = trimmed.match(/(\d+)/);
  return match ? Number(match[1]) : null;
}

export class DatabaseStorage implements IStorage {
  async getDashboardMetrics() {
    const [productsCount] = await db.select({ count: sql<number>`count(*)::int` }).from(product);
    const [variantsCount] = await db.select({ count: sql<number>`count(*)::int` }).from(product).where(sql`${product.parentSku} IS NOT NULL`);
    const [stockSum] = await db.select({ total: sql<number>`COALESCE(sum(${variantStock.qty}), 0)::int` }).from(variantStock);
    const [storesCount] = await db.select({ count: sql<number>`count(*)::int` }).from(store);
    const [avgAttribution] = await db
      .select({ avgAttribution: sql<number>`AVG(${dataAttributionCalc})::int` })
      .from(product);

    return {
      totalProducts: productsCount?.count || 0,
      totalVariants: variantsCount?.count || 0,
      totalStock: stockSum?.total || 0,
      storeCount: storesCount?.count || 0,
      averageDataAttribution: avgAttribution?.avgAttribution || 0,
    };
  }

  async getProductStatusCounts() {
    const [statusCounts] = await db
      .select({
        enabled: sql<number>`count(*) filter (where ${product.enabled} is true)::int`,
        disabled: sql<number>`count(*) filter (where ${product.enabled} is false or ${product.enabled} is null)::int`,
      })
      .from(product);

    return {
      enabled: statusCounts?.enabled || 0,
      disabled: statusCounts?.disabled || 0,
    };
  }

  async getProductActivityCounts(startDate: Date, endDate: Date) {
    const [counts] = await db
      .select({
        total: sql<number>`count(*)::int`,
        created: sql<number>`count(*) filter (where ${product.createdAt} >= ${startDate} and ${product.createdAt} <= ${endDate})::int`,
        updated: sql<number>`count(*) filter (where ${product.updatedAt} >= ${startDate} and ${product.updatedAt} <= ${endDate} and (${product.createdAt} is null or ${product.createdAt} < ${startDate} or ${product.createdAt} > ${endDate}))::int`,
      })
      .from(product);

    const created = counts?.created || 0;
    const updated = counts?.updated || 0;
    const total = counts?.total || 0;
    const unchanged = Math.max(total - created - updated, 0);

    return {
      created,
      updated,
      unchanged,
      total,
    };
  }

  async getProductMissingAttributeCounts(attributeKey: string) {
    let missingCondition: ReturnType<typeof sql>;
    switch (attributeKey) {
      case "images":
        missingCondition = sql`(
          SELECT count(DISTINCT ${imageAsset.role})
          FROM ${imageAsset}
          WHERE ${imageAsset.productId} = ${product.productId}
            AND ${imageAsset.role} IN ('base', 'thumbnail', 'small')
        ) < 3`;
        break;
      case "brand":
        missingCondition = sql`${product.brandId} is null`;
        break;
      case "description":
        missingCondition = sql`${product.productDescription} is null or ${product.productDescription} = ''`;
        break;
      case "composition":
        missingCondition = sql`${product.composition} is null or ${product.composition} = ''`;
        break;
      case "country":
        missingCondition = sql`${product.countryOfManufacture} is null or ${product.countryOfManufacture} = ''`;
        break;
      case "productType":
        missingCondition = sql`${product.productTypeId} is null`;
        break;
      default:
        missingCondition = sql`(
          SELECT count(DISTINCT ${imageAsset.role})
          FROM ${imageAsset}
          WHERE ${imageAsset.productId} = ${product.productId}
            AND ${imageAsset.role} IN ('base', 'thumbnail', 'small')
        ) < 3`;
        break;
    }

    const [counts] = await db
      .select({
        total: sql<number>`count(*)::int`,
        missing: sql<number>`count(*) filter (where ${missingCondition})::int`,
      })
      .from(product);

    return {
      missing: counts?.missing || 0,
      total: counts?.total || 0,
    };
  }

  async getProducts(limit: number = 100): Promise<Product[]> {
    return await db.select().from(product).limit(limit).orderBy(desc(product.createdAt));
  }

  async getProductsWithFilters(filters: ProductFilters): Promise<any[]> {
    const {
      search,
      brandId,
      categoryId,
      clubId,
      seasonId,
      departmentId,
      enabled,
      attributeFilters = [],
      sortBy,
      order = "asc",
      startDate,
      endDate,
      stockLevel,
      minAttribution,
      limit = 50,
      offset = 0,
    } = filters;

    const conditions: Array<ReturnType<typeof sql>> = [];
    const normalizedAttributeFilters: CatalogAttributeFilter[] = Array.isArray(attributeFilters)
      ? attributeFilters
      : [];
    const attributeFilterIds = normalizedAttributeFilters
      .map((filter) => (filter.attributeId ? Number(filter.attributeId) : null))
      .filter((id): id is number => Boolean(id));
    const sortAttributeId =
      sortBy && sortBy.startsWith("attr:") ? Number(sortBy.replace("attr:", "")) : null;
    const attributeIds = Array.from(
      new Set([...(attributeFilterIds ?? []), ...(sortAttributeId ? [sortAttributeId] : [])]),
    );
    const attributeDefs = attributeIds.length
      ? await db
          .select({
            attributeId: attributeDef.attributeId,
            dataType: attributeDef.dataType,
          })
          .from(attributeDef)
          .where(inArray(attributeDef.attributeId, attributeIds))
      : [];
    const attributeDefMap = new Map(
      attributeDefs.map((def) => [Number(def.attributeId), { dataType: def.dataType }]),
    );

    if (search) {
      const like = `%${search}%`;
      conditions.push(
        or(
          ilike(product.productSku, like),
          ilike(product.productDescription, like),
          ilike(brands.brandName, like),
        )!,
      );
    }

    if (brandId) conditions.push(eq(product.brandId, brandId));
    if (enabled !== undefined) conditions.push(eq(product.enabled, enabled));

    if (startDate) conditions.push(gte(product.createdAt, new Date(startDate)));
    if (endDate) conditions.push(lte(product.createdAt, new Date(endDate)));

    if (categoryId) {
      conditions.push(sql`EXISTS (
        SELECT 1 FROM ${productCategory}
        WHERE ${productCategory.productId} = ${product.productId}
          AND ${productCategory.categoryId} = ${categoryId}
      )`);
    }

    if (clubId || seasonId || departmentId) {
      conditions.push(sql`EXISTS (
        SELECT 1 FROM ${productTeamMeta}
        WHERE ${productTeamMeta.productId} = ${product.productId}
        ${clubId ? sql`AND ${productTeamMeta.clubId} = ${clubId}` : sql``}
        ${seasonId ? sql`AND ${productTeamMeta.seasonId} = ${seasonId}` : sql``}
        ${departmentId ? sql`AND ${productTeamMeta.departmentId} = ${departmentId}` : sql``}
      )`);
    }

    if (minAttribution !== undefined) {
      conditions.push(sql`${dataAttributionCalc} >= ${minAttribution}`);
    }

    if (stockLevel) {
      if (stockLevel === "out_of_stock") {
        conditions.push(sql`${totalStockCalc} <= 0`);
      }
      if (stockLevel === "low_stock") {
        conditions.push(sql`${totalStockCalc} > 0 AND ${totalStockCalc} < 10`);
      }
      if (stockLevel === "in_stock") {
        conditions.push(sql`${totalStockCalc} >= 10`);
      }
    }

    const teamNameCalc = sql<string | null>`
      (SELECT ${club.name}
       FROM ${productTeamMeta}
       LEFT JOIN ${club} ON ${club.clubId} = ${productTeamMeta.clubId}
       WHERE ${productTeamMeta.productId} = ${product.productId}
       ORDER BY ${productTeamMeta.isPrimary} DESC NULLS LAST, ${productTeamMeta.productTeamMetaId} ASC
       LIMIT 1)
    `;

    const imageRoleCountCalc = sql<number>`(
      SELECT count(DISTINCT ${imageAsset.role})
      FROM ${imageAsset}
      WHERE ${imageAsset.productId} = ${product.productId}
        AND ${imageAsset.role} IN ('base', 'thumbnail', 'small')
    )`;

    const conditionNameCalc = sql<string | null>`
      (SELECT ${condition.conditionName}
       FROM ${condition}
       WHERE ${condition.conditionId} = ${product.conditionId})
    `;

    const seasonNameCalc = sql<string | null>`
      (SELECT s.season_name
       FROM ${productTeamMeta} ptm
       JOIN pim.season s ON s.season_id = ptm.season_id
       WHERE ptm.product_id = ${product.productId}
       ORDER BY ptm.is_primary DESC NULLS LAST, ptm.product_team_meta_id ASC
       LIMIT 1)
    `;

    const productFieldMap: Record<string, any> = {
      productSku: product.productSku,
      name: product.name,
      productDescription: product.productDescription,
      articleNumber: product.articleNumber,
      brandName: brands.brandName,
      genderName: gender.genderName,
      productTypeName: productType.productTypeName,
      colourName: productColour.magentoColourName,
      eraName: era.name,
      teamName: teamNameCalc,
      conditionName: conditionNameCalc,
      seasonName: seasonNameCalc,
      enabled: product.enabled,
      sync: product.sync,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
      dataAttribution: dataAttributionCalc,
      totalStock: totalStockCalc,
      variantCount: variantCountCalc,
      productStyle: product.productStyle,
      composition: product.composition,
      countryOfManufacture: product.countryOfManufacture,
      commodityCode: product.commodityCode,
      imageCode: product.imageCode,
      missingFields: missingFieldsCalc,
      imageRoleCount: imageRoleCountCalc,
    };

    const variantFieldMap: Record<string, any> = {
      variantCostPrice: productVariant.costPrice,
      variantAverageCostPrice: productVariant.averageCostPrice,
      variantCustomerPrice: productVariant.customerPrice,
      variantPrinted: productVariant.printed,
      variantEnabled: productVariant.enabled,
      variantBarcode: productVariant.barcode,
      variantSizeId: productVariant.sizeId,
      variantConditionId: productVariant.conditionId,
      variantTaxClassId: productVariant.taxClassId,
    };

    for (const filter of normalizedAttributeFilters) {
      const operator = filter.operator ?? "";
      const source = filter.source ?? "product";
      if (source === "product") {
        const expr = productFieldMap[filter.field ?? ""];
        if (!expr) continue;
        const value = coerceFilterValue(filter.value, filter.dataType ?? "text");
        const condition = buildFilterCondition(expr, operator, value, filter.dataType ?? "text");
        if (condition) conditions.push(condition);
        continue;
      }
      if (source === "variant") {
        const expr = variantFieldMap[filter.field ?? ""];
        if (!expr) continue;
        const value = coerceFilterValue(filter.value, filter.dataType ?? "text");
        const condition = buildFilterCondition(expr, operator, value, filter.dataType ?? "text");
        if (!condition) continue;
        conditions.push(sql`EXISTS (
          SELECT 1 FROM ${productVariant}
          WHERE ${productVariant.productId} = ${product.productId}
            AND ${condition}
        )`);
        continue;
      }
      if (source === "attribute") {
        const attributeId = filter.attributeId ? Number(filter.attributeId) : null;
        if (!attributeId) continue;
        const def = attributeDefMap.get(attributeId);
        const dataType = def?.dataType ?? filter.dataType ?? "text";
        const value = coerceFilterValue(filter.value, dataType);
        const valueColumn =
          dataType === "number"
            ? productAttributeVal.valueNum
            : dataType === "boolean"
              ? productAttributeVal.valueBool
              : dataType === "json"
                ? productAttributeVal.valueJson
                : productAttributeVal.valueText;

        const condition = buildFilterCondition(valueColumn, operator, value, dataType);
        if (!condition) continue;

        {
          conditions.push(sql`EXISTS (
            SELECT 1
            FROM ${productAttributeVal}
            WHERE ${productAttributeVal.productId} = ${product.productId}
              AND ${productAttributeVal.attributeId} = ${attributeId}
              AND ${condition}
          )`);
        }
      }
    }

    const whereClause = conditions.length ? and(...conditions) : undefined;

    const thumbnailUrlCalc = sql<string | null>`
      (SELECT ${imageAsset.url}
       FROM ${imageAsset}
       WHERE ${imageAsset.productId} = ${product.productId}
       ORDER BY CASE ${imageAsset.role}
         WHEN 'thumbnail' THEN 1
         WHEN 'small' THEN 2
         WHEN 'base' THEN 3
         ELSE 4
       END, ${imageAsset.sortOrder} ASC NULLS LAST
       LIMIT 1)
    `;

    const teamIdCalc = sql<number | null>`
      (SELECT ${productTeamMeta.clubId}
       FROM ${productTeamMeta}
       WHERE ${productTeamMeta.productId} = ${product.productId}
       ORDER BY ${productTeamMeta.isPrimary} DESC NULLS LAST, ${productTeamMeta.productTeamMetaId} ASC
       LIMIT 1)
    `;
    const sortExpr = (() => {
      if (!sortBy) return product.createdAt;

      if (sortBy.startsWith("product:")) {
        const field = sortBy.replace("product:", "");
        return productFieldMap[field] ?? product.createdAt;
      }

      if (sortBy.startsWith("variant:")) {
        const field = sortBy.replace("variant:", "");
        const expr = variantFieldMap[field];
        if (!expr) return product.createdAt;
        return sql`(
          SELECT MIN(${expr})
          FROM ${productVariant}
          WHERE ${productVariant.productId} = ${product.productId}
        )`;
      }

      if (sortBy.startsWith("attr:")) {
        const attributeId = Number(sortBy.replace("attr:", ""));
        if (!Number.isFinite(attributeId)) return product.createdAt;
        const [def] = attributeDefs.filter((item) => Number(item.attributeId) === attributeId);
        const dataType = def?.dataType ?? "text";
        const valueColumn =
          dataType === "number"
            ? productAttributeVal.valueNum
            : dataType === "boolean"
              ? productAttributeVal.valueBool
              : dataType === "json"
                ? productAttributeVal.valueJson
                : productAttributeVal.valueText;

        return sql`(
          SELECT ${valueColumn}
          FROM ${productAttributeVal}
          WHERE ${productAttributeVal.productId} = ${product.productId}
            AND ${productAttributeVal.attributeId} = ${attributeId}
          LIMIT 1
        )`;
      }

      if (sortBy === "sku") return product.productSku;
      if (sortBy === "description") return product.productDescription;
      if (sortBy === "attribution") return dataAttributionCalc;
      if (sortBy === "team") return teamNameCalc;

      return product.createdAt;
    })();

    const orderByExpr = order === "desc" ? desc(sortExpr) : asc(sortExpr);

    const rows = await db
      .select({
        productId: product.productId,
        productSku: product.productSku,
        name: product.name,
        articleNumber: product.articleNumber,
        productDescription: product.productDescription,
        productStyle: product.productStyle,
        composition: product.composition,
        countryOfManufacture: product.countryOfManufacture,
        commodityCode: product.commodityCode,
        imageCode: product.imageCode,
        productColourId: product.productColourId,
        genderId: product.genderId,
        eraId: product.eraId,
        eraName: era.name,
        brandId: product.brandId,
        productTypeId: product.productTypeId,
        enabled: product.enabled,
        sync: product.sync,
        createdAt: product.createdAt,
        updatedAt: product.updatedAt,
        brandName: brands.brandName,
        genderName: gender.genderName,
        productTypeName: productType.productTypeName,
        colourName: productColour.magentoColourName,
        teamId: teamIdCalc,
        teamName: teamNameCalc,
        variantCount: variantCountCalc,
        dataAttribution: dataAttributionCalc,
        missingFields: missingFieldsCalc,
        totalStock: totalStockCalc,
        groups: sql<string | null>`
          (SELECT string_agg(pg.name, ', ' ORDER BY pg.name)
           FROM ${productGroupMember} pgm
           JOIN ${productGroup} pg ON pg.product_group_id = pgm.product_group_id
           WHERE pgm.product_id = ${product.productId} AND pgm.live = true)
        `,
        thumbnailUrl: thumbnailUrlCalc,
      })
      .from(product)
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .leftJoin(gender, eq(product.genderId, gender.genderId))
      .leftJoin(productType, eq(product.productTypeId, productType.productTypeId))
      .leftJoin(productColour, eq(product.productColourId, productColour.productColourId))
      .leftJoin(era, eq(product.eraId, era.eraId))
      .where(whereClause)
      .orderBy(orderByExpr)
      .limit(limit)
      .offset(offset);

    return rows;
  }

  async getProductsCount(filters: ProductFilters): Promise<number> {
    const {
      search,
      brandId,
      categoryId,
      clubId,
      seasonId,
      departmentId,
      enabled,
      attributeFilters = [],
      startDate,
      endDate,
      stockLevel,
      minAttribution,
    } = filters;

    const conditions: Array<ReturnType<typeof sql>> = [];
    const normalizedAttributeFilters: CatalogAttributeFilter[] = Array.isArray(attributeFilters)
      ? attributeFilters
      : [];
    const attributeFilterIds = normalizedAttributeFilters
      .map((filter) => (filter.attributeId ? Number(filter.attributeId) : null))
      .filter((id): id is number => Boolean(id));
    const attributeIds = Array.from(new Set(attributeFilterIds));
    const attributeDefsForCount = attributeIds.length
      ? await db
          .select({
            attributeId: attributeDef.attributeId,
            dataType: attributeDef.dataType,
          })
          .from(attributeDef)
          .where(inArray(attributeDef.attributeId, attributeIds))
      : [];
    const attributeDefMap = new Map(
      attributeDefsForCount.map((def) => [Number(def.attributeId), { dataType: def.dataType }]),
    );

    if (search) {
      const like = `%${search}%`;
      conditions.push(
        or(
          ilike(product.productSku, like),
          ilike(product.productDescription, like),
          ilike(brands.brandName, like),
        )!,
      );
    }

    if (brandId) conditions.push(eq(product.brandId, brandId));
    if (enabled !== undefined) conditions.push(eq(product.enabled, enabled));

    if (startDate) conditions.push(gte(product.createdAt, new Date(startDate)));
    if (endDate) conditions.push(lte(product.createdAt, new Date(endDate)));

    if (categoryId) {
      conditions.push(sql`EXISTS (
        SELECT 1 FROM ${productCategory}
        WHERE ${productCategory.productId} = ${product.productId}
          AND ${productCategory.categoryId} = ${categoryId}
      )`);
    }

    if (clubId || seasonId || departmentId) {
      conditions.push(sql`EXISTS (
        SELECT 1 FROM ${productTeamMeta}
        WHERE ${productTeamMeta.productId} = ${product.productId}
        ${clubId ? sql`AND ${productTeamMeta.clubId} = ${clubId}` : sql``}
        ${seasonId ? sql`AND ${productTeamMeta.seasonId} = ${seasonId}` : sql``}
        ${departmentId ? sql`AND ${productTeamMeta.departmentId} = ${departmentId}` : sql``}
      )`);
    }

    if (minAttribution !== undefined) {
      conditions.push(sql`${dataAttributionCalc} >= ${minAttribution}`);
    }

    if (stockLevel) {
      if (stockLevel === "out_of_stock") {
        conditions.push(sql`${totalStockCalc} <= 0`);
      }
      if (stockLevel === "low_stock") {
        conditions.push(sql`${totalStockCalc} > 0 AND ${totalStockCalc} < 10`);
      }
      if (stockLevel === "in_stock") {
        conditions.push(sql`${totalStockCalc} >= 10`);
      }
    }

    const imageRoleCountCalc = sql<number>`(
      SELECT count(DISTINCT ${imageAsset.role})
      FROM ${imageAsset}
      WHERE ${imageAsset.productId} = ${product.productId}
        AND ${imageAsset.role} IN ('base', 'thumbnail', 'small')
    )`;

    const productFieldMap: Record<string, any> = {
      productSku: product.productSku,
      name: product.name,
      productDescription: product.productDescription,
      articleNumber: product.articleNumber,
      brandName: brands.brandName,
      genderName: gender.genderName,
      productTypeName: productType.productTypeName,
      colourName: productColour.magentoColourName,
      enabled: product.enabled,
      sync: product.sync,
      createdAt: product.createdAt,
      updatedAt: product.updatedAt,
      dataAttribution: dataAttributionCalc,
      totalStock: totalStockCalc,
      variantCount: variantCountCalc,
      productStyle: product.productStyle,
      composition: product.composition,
      countryOfManufacture: product.countryOfManufacture,
      commodityCode: product.commodityCode,
      imageCode: product.imageCode,
      missingFields: missingFieldsCalc,
      imageRoleCount: imageRoleCountCalc,
    };

    const variantFieldMap: Record<string, any> = {
      variantCostPrice: productVariant.costPrice,
      variantAverageCostPrice: productVariant.averageCostPrice,
      variantCustomerPrice: productVariant.customerPrice,
      variantPrinted: productVariant.printed,
      variantEnabled: productVariant.enabled,
      variantBarcode: productVariant.barcode,
      variantSizeId: productVariant.sizeId,
      variantConditionId: productVariant.conditionId,
      variantTaxClassId: productVariant.taxClassId,
    };

    for (const filter of normalizedAttributeFilters) {
      const operator = filter.operator ?? "";
      const source = filter.source ?? "product";
      if (source === "product") {
        const expr = productFieldMap[filter.field ?? ""];
        if (!expr) continue;
        const value = coerceFilterValue(filter.value, filter.dataType ?? "text");
        const condition = buildFilterCondition(expr, operator, value, filter.dataType ?? "text");
        if (condition) conditions.push(condition);
        continue;
      }
      if (source === "variant") {
        const expr = variantFieldMap[filter.field ?? ""];
        if (!expr) continue;
        const value = coerceFilterValue(filter.value, filter.dataType ?? "text");
        const condition = buildFilterCondition(expr, operator, value, filter.dataType ?? "text");
        if (!condition) continue;
        conditions.push(sql`EXISTS (
          SELECT 1 FROM ${productVariant}
          WHERE ${productVariant.productId} = ${product.productId}
            AND ${condition}
        )`);
        continue;
      }
      if (source === "attribute") {
        const attributeId = filter.attributeId ? Number(filter.attributeId) : null;
        if (!attributeId) continue;
        const def = attributeDefMap.get(attributeId);
        const dataType = def?.dataType ?? filter.dataType ?? "text";
        const value = coerceFilterValue(filter.value, dataType);
        const valueColumn =
          dataType === "number"
            ? productAttributeVal.valueNum
            : dataType === "boolean"
              ? productAttributeVal.valueBool
              : dataType === "json"
                ? productAttributeVal.valueJson
                : productAttributeVal.valueText;

        const condition = buildFilterCondition(valueColumn, operator, value, dataType);
        if (!condition) continue;

        {
          conditions.push(sql`EXISTS (
            SELECT 1
            FROM ${productAttributeVal}
            WHERE ${productAttributeVal.productId} = ${product.productId}
              AND ${productAttributeVal.attributeId} = ${attributeId}
              AND ${condition}
          )`);
        }
      }
    }

    const whereClause = conditions.length ? and(...conditions) : undefined;

    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(product)
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .leftJoin(gender, eq(product.genderId, gender.genderId))
      .leftJoin(productType, eq(product.productTypeId, productType.productTypeId))
      .leftJoin(productColour, eq(product.productColourId, productColour.productColourId))
      .where(whereClause);

    return result?.count || 0;
  }

  async getProduct(productId: number): Promise<Product | undefined> {
    const [result] = await db.select().from(product).where(eq(product.productId, productId)).limit(1);
    return result;
  }

  async getProductWithAttribution(productId: number): Promise<any> {
    const [result] = await db
      .select({
        productId: product.productId,
        productSku: product.productSku,
        name: product.name,
        parentSku: product.parentSku,
        articleNumber: product.articleNumber,
        productDescription: product.productDescription,
        productStyle: product.productStyle,
        taxClassId: product.taxClassId,
        composition: product.composition,
        countryOfManufacture: product.countryOfManufacture,
        commodityCode: product.commodityCode,
        imageCode: product.imageCode,
        productColourId: product.productColourId,
        genderId: product.genderId,
        eraId: product.eraId,
        eraName: era.name,
        brandId: product.brandId,
        productTypeId: product.productTypeId,
        enabled: product.enabled,
        sync: product.sync,
        createdAt: product.createdAt,
        updatedAt: product.updatedAt,
        brandName: brands.brandName,
        genderName: gender.genderName,
        productTypeName: productType.productTypeName,
        colourName: productColour.magentoColourName,
        variantCount: variantCountCalc,
        dataAttribution: dataAttributionCalc,
        missingFields: missingFieldsCalc,
        totalStock: totalStockCalc,
      })
      .from(product)
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .leftJoin(gender, eq(product.genderId, gender.genderId))
      .leftJoin(productType, eq(product.productTypeId, productType.productTypeId))
      .leftJoin(productColour, eq(product.productColourId, productColour.productColourId))
      .leftJoin(era, eq(product.eraId, era.eraId))
      .where(eq(product.productId, productId))
      .limit(1);

    return result ?? null;
  }

  async updateProduct(productId: number, updates: Partial<Product>): Promise<void> {
    await db
      .update(product)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(product.productId, productId));

    try {
      await this.insertSyncQueueEntry({
        productId,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for product_update:", e);
    }
  }

  async setProductPrimaryTeam(productId: number, clubId: number | null): Promise<void> {
    await db.transaction(async (tx) => {
      if (clubId !== null) {
        const [team] = await tx
          .select({ id: club.clubId })
          .from(club)
          .where(eq(club.clubId, clubId))
          .limit(1);
        if (!team) {
          throw new Error("Team not found");
        }
      }

      await tx
        .update(productTeamMeta)
        .set({ isPrimary: false })
        .where(eq(productTeamMeta.productId, productId));

      if (clubId === null) {
        await tx
          .update(product)
          .set({ updatedAt: new Date() })
          .where(eq(product.productId, productId));
        return;
      }

      const [existing] = await tx
        .select({ id: productTeamMeta.productTeamMetaId })
        .from(productTeamMeta)
        .where(
          and(eq(productTeamMeta.productId, productId), eq(productTeamMeta.clubId, clubId)),
        )
        .limit(1);

      if (existing) {
        await tx
          .update(productTeamMeta)
          .set({ isPrimary: true })
          .where(eq(productTeamMeta.productTeamMetaId, existing.id));
        await tx
          .update(product)
          .set({ updatedAt: new Date() })
          .where(eq(product.productId, productId));
        return;
      }

      await tx.insert(productTeamMeta).values({
        productId,
        clubId,
        isPrimary: true,
      });

      await tx
        .update(product)
        .set({ updatedAt: new Date() })
        .where(eq(product.productId, productId));
    });

    try {
      await this.insertSyncQueueEntry({
        productId,
        productVariantId: null,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for team assignment:", e);
    }
  }

  async updateVariant(variantId: number, updates: Partial<ProductVariant>): Promise<void> {
    if (!variantId) return;

    const [existing] = await db
      .select({
        productVariantId: productVariant.productVariantId,
        barcode: productVariant.barcode,
      })
      .from(productVariant)
      .where(eq(productVariant.productVariantId, variantId))
      .limit(1);
    if (!existing) {
      throw new Error("Variant not found");
    }

    const checkExists = async <T extends { id: number | null }>(
      table: any,
      column: any,
      id: number | null | undefined,
      errorMessage: string,
    ) => {
      if (!id) return;
      const [found] = await db.select({ id: column }).from(table).where(eq(column, id)).limit(1);
      if (!found) {
        throw new Error(errorMessage);
      }
    };

    await checkExists(productSizes, productSizes.sizeId, updates.sizeId ?? null, "Size not found");
    await checkExists(taxClass, taxClass.taxClassId, updates.taxClassId ?? null, "Tax class not found");
    await checkExists(condition, condition.conditionId, updates.conditionId ?? null, "Condition not found");

    if (updates.barcode && updates.barcode !== existing.barcode) {
      const [barcodeMatch] = await db
        .select({ productVariantId: productVariant.productVariantId })
        .from(productVariant)
        .where(eq(productVariant.barcode, updates.barcode))
        .limit(1);
      if (barcodeMatch) {
        throw new Error("Barcode already exists");
      }
    }

    const normalizedUpdates = normalizeDataValues(updates as Record<string, any>);
    if (normalizedUpdates.enabled === null) {
      delete normalizedUpdates.enabled;
    }
    if (normalizedUpdates.printed === null) {
      delete normalizedUpdates.printed;
    }

    await db
      .update(productVariant)
      .set({
        ...normalizedUpdates,
        updatedAt: new Date(),
      })
      .where(eq(productVariant.productVariantId, variantId));

    try {
      const [variantRow] = await db
        .select({ productId: productVariant.productId })
        .from(productVariant)
        .where(eq(productVariant.productVariantId, variantId))
        .limit(1);
      if (variantRow?.productId) {
        await this.insertSyncQueueEntry({
          productId: variantRow.productId,
          productVariantId: variantId,
          operationType: "variant_update",
        });
      }
    } catch (e) {
      console.error("Failed to insert sync queue entry for variant_update:", e);
    }
  }

  async createProduct(input: CreateProductInput): Promise<{ productId: number }> {
    const sku = input.productSku.trim();

    if (!sku) {
      throw new Error("SKU is required");
    }

    const result = await db.transaction(async (tx) => {
      const checkExists = async <T extends { id: number | null }>(
        table: any,
        column: any,
        id: number | null | undefined,
        errorMessage: string,
      ) => {
        if (!id) return;
        const [existing] = await tx.select({ id: column }).from(table).where(eq(column, id)).limit(1);
        if (!existing) {
          throw new Error(errorMessage);
        }
      };

      await checkExists(category, category.categoryId, input.categoryId ?? null, "Category not found");
      await checkExists(productColour, productColour.productColourId, input.productColourId ?? null, "Product colour not found");
      await checkExists(gender, gender.genderId, input.genderId ?? null, "Gender not found");
      await checkExists(brands, brands.brandId, input.brandId ?? null, "Brand not found");
      await checkExists(productType, productType.productTypeId, input.productTypeId ?? null, "Product type not found");
      await checkExists(club, club.clubId, input.clubId ?? null, "Team not found");
      const [existingProduct] = await tx
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, sku))
        .limit(1);
      if (existingProduct) {
        throw new Error("Product SKU already exists");
      }

      const now = new Date();
      const [createdProduct] = await tx
        .insert(product)
        .values({
          productSku: sku,
          articleNumber: input.articleNumber || null,
          productDescription: input.productDescription,
          productColourId: input.productColourId ?? null,
          genderId: input.genderId ?? null,
          brandId: input.brandId ?? null,
          productTypeId: input.productTypeId ?? null,
          productStyle: input.productStyle ?? null,
          taxClassId: input.taxClassId ?? null,
          composition: input.composition || null,
          countryOfManufacture: input.countryOfManufacture || null,
          commodityCode: input.commodityCode || null,
          imageCode: input.imageCode || null,
          enabled: input.enabled ?? true,
          sync: input.sync ?? false,
          createdAt: now,
          updatedAt: now,
        })
        .returning({ productId: product.productId });

      if (!createdProduct) {
        throw new Error("Failed to create product");
      }

      const allCategoryIds = input.categoryIds && input.categoryIds.length > 0
        ? input.categoryIds
        : input.categoryId ? [input.categoryId] : [];
      for (const catId of allCategoryIds) {
        await tx.insert(productCategory).values({
          productId: createdProduct.productId,
          categoryId: catId,
        });
      }

      if (input.clubId) {
        await tx.insert(productTeamMeta).values({
          productId: createdProduct.productId,
          clubId: input.clubId,
          isPrimary: true,
        });
      }

      let productVariantId: number | null = null;
      if (input.productTypeId) {
        const [productTypeRow] = await tx
          .select({ productTypeName: productType.productTypeName })
          .from(productType)
          .where(eq(productType.productTypeId, input.productTypeId))
          .limit(1);

        if (productTypeRow?.productTypeName?.toLowerCase() === "simple") {
          // Use provided variantSku or fall back to productSku
          const variantSku = input.variantSku?.trim() || sku;

          const [createdVariant] = await tx
            .insert(productVariant)
            .values({
              productId: createdProduct.productId,
              productVariantSku: variantSku,
              sizeId: input.sizeId ?? null,
              taxClassId: input.taxClassId ?? null,
              conditionId: input.conditionId ?? null,
              barcode: input.barcode || null,
              weight: input.weight ? String(input.weight) : null,
              costPrice: input.costPrice ? String(input.costPrice) : null,
              enabled: input.enabled ?? true,
              createdAt: now,
              updatedAt: now,
            })
            .returning({ productVariantId: productVariant.productVariantId });

          if (createdVariant) {
            productVariantId = Number(createdVariant.productVariantId);

            const hasAnyPrice = (input.retailPrice != null) || (input.specialRetailPrice != null) || (input.costPrice != null);
            if (hasAnyPrice) {
              const [defaultCurrency] = await tx
                .select({ currencyId: currency.currencyId })
                .from(currency)
                .limit(1);
              if (defaultCurrency) {
                await tx.insert(variantPrice).values({
                  productVariantId: createdVariant.productVariantId,
                  currencyId: defaultCurrency.currencyId,
                  costPrice: input.costPrice != null ? String(input.costPrice) : null,
                  retailPrice: input.retailPrice != null ? String(input.retailPrice) : null,
                  specialRetailPrice: input.specialRetailPrice != null ? String(input.specialRetailPrice) : null,
                });
              }
            }

            if (input.stockQty !== null && input.stockQty !== undefined) {
              const warehouseId = input.warehouseId ?? 1;
              await tx.insert(variantStock).values({
                productVariantId: createdVariant.productVariantId,
                warehouseId,
                qty: input.stockQty,
              });
            }
          }
        }
      }

      return {
        productId: Number(createdProduct.productId),
        productVariantId,
      };
    });

    const isSyncEnabled = input.sync === true;
    if (isSyncEnabled) {
      try {
        await this.insertSyncQueueEntry({
          productId: result.productId,
          productVariantId: result.productVariantId,
          operationType: "product_create",
        });
      } catch (e) {
        console.error("Failed to insert sync queue entry for product_create:", e);
      }

      const allCategoryIds = input.categoryIds && input.categoryIds.length > 0
        ? input.categoryIds
        : input.categoryId ? [input.categoryId] : [];
      if (allCategoryIds.length > 0) {
        try {
          await this.insertSyncQueueEntry({
            productId: result.productId,
            productVariantId: null,
            operationType: "category_change",
          });
        } catch (e) {
          console.error("Failed to insert sync queue entry for category_change on create:", e);
        }
      }
    }

    return result;
  }

  async createProductVariant(input: CreateVariantInput): Promise<{ productVariantId: number }> {
    const variantSku = input.productVariantSku.trim();

    if (!variantSku) {
      throw new Error("Variant SKU is required");
    }

    const result = await db.transaction(async (tx) => {
      const checkExists = async <T extends { id: number | null }>(
        table: any,
        column: any,
        id: number | null | undefined,
        errorMessage: string,
      ) => {
        if (!id) return;
        const [existing] = await tx.select({ id: column }).from(table).where(eq(column, id)).limit(1);
        if (!existing) {
          throw new Error(errorMessage);
        }
      };

      const [existingProduct] = await tx
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productId, input.productId))
        .limit(1);
      if (!existingProduct) {
        throw new Error("Product not found");
      }

      await checkExists(productSizes, productSizes.sizeId, input.sizeId ?? null, "Size not found");
      await checkExists(taxClass, taxClass.taxClassId, input.taxClassId ?? null, "Tax class not found");
      await checkExists(condition, condition.conditionId, input.conditionId ?? null, "Condition not found");

      const [existingVariant] = await tx
        .select({ productVariantId: productVariant.productVariantId })
        .from(productVariant)
        .where(eq(productVariant.productVariantSku, variantSku))
        .limit(1);
      if (existingVariant) {
        throw new Error("Variant SKU already exists");
      }

      if (input.barcode) {
        const [existingBarcode] = await tx
          .select({ productVariantId: productVariant.productVariantId })
          .from(productVariant)
          .where(eq(productVariant.barcode, input.barcode))
          .limit(1);
        if (existingBarcode) {
          throw new Error("Barcode already exists");
        }
      }

      const now = new Date();
      const [createdVariant] = await tx
        .insert(productVariant)
        .values({
          productId: input.productId,
          productVariantSku: variantSku,
          sizeId: input.sizeId ?? null,
          taxClassId: input.taxClassId ?? null,
          conditionId: input.conditionId ?? null,
          conditionDetail: input.conditionDetail || null,
          barcode: input.barcode || null,
          widthCm: input.widthCm ?? null,
          lengthCm: input.lengthCm ?? null,
          weight: input.weight ?? null,
          depth: input.depth ?? null,
          costPrice: input.costPrice ?? null,
          averageCostPrice: input.averageCostPrice ?? null,
          customerPrice: input.customerPrice ?? null,
          printed: input.printed ?? false,
          magentoProductId: input.magentoProductId ?? null,
          enabled: input.enabled ?? true,
          createdAt: now,
          updatedAt: now,
        })
        .returning({ productVariantId: productVariant.productVariantId });

      if (!createdVariant) {
        throw new Error("Failed to create product variant");
      }

      return { productVariantId: Number(createdVariant.productVariantId) };
    });

    const [parentProduct] = await db
      .select({ sync: product.sync })
      .from(product)
      .where(eq(product.productId, input.productId))
      .limit(1);
    if (parentProduct?.sync) {
      try {
        await this.insertSyncQueueEntry({
          productId: input.productId,
          productVariantId: result.productVariantId,
          operationType: "variant_create",
        });
      } catch (e) {
        console.error("Failed to insert sync queue entry for variant_create:", e);
      }
    }

    return result;
  }

  async getProductVariants(productId: number): Promise<any[]> {
    // In v2 flat schema, "variants" are child products whose parent_sku matches this product's sku.
    // First get the parent product's SKU
    const [parentProduct] = await db
      .select({ sku: product.productSku })
      .from(product)
      .where(eq(product.productId, productId))
      .limit(1);
    if (!parentProduct?.sku) return [];

    // Query child products that reference this parent via parent_sku
    const childAlias = product;
    return await db
      .select({
        productVariantId: product.productId,
        productVariantSku: product.productSku,
        productId: product.productId,
        sizeId: product.sizeId,
        conditionId: product.conditionId,
        enabled: product.enabled,
        sizeName: productSizes.magentoSizeLongName,
        sizeShortName: productSizes.magentoSizeShortName,
        conditionName: condition.conditionName,
        brandId: product.brandId,
        brandName: brands.brandName,
        genderId: product.genderId,
        genderName: gender.genderName,
        productTypeId: product.productTypeId,
        productTypeName: productType.productTypeName,
        productColourId: product.productColourId,
        colourName: productColour.magentoColourName,
        productStyle: product.productStyle,
        composition: product.composition,
        countryOfManufacture: product.countryOfManufacture,
        commodityCode: product.commodityCode,
        imageCode: product.imageCode,
        articleNumber: product.articleNumber,
        name: product.name,
        productVariantDescription: product.productDescription,
        colour: productColour.magentoColourName,
        stockLevel: variantStockCalc,
      })
      .from(product)
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .leftJoin(gender, eq(product.genderId, gender.genderId))
      .leftJoin(productType, eq(product.productTypeId, productType.productTypeId))
      .leftJoin(productColour, eq(product.productColourId, productColour.productColourId))
      .leftJoin(productSizes, eq(product.sizeId, productSizes.sizeId))
      .leftJoin(condition, eq(product.conditionId, condition.conditionId))
      .where(eq(product.parentSku, parentProduct.sku))
      .orderBy(desc(product.createdAt));
  }

  async getVariant(variantId: number): Promise<any | undefined> {
    // In v2, variants are just products — look up by productId
    const [result] = await db
      .select()
      .from(product)
      .where(eq(product.productId, variantId))
      .limit(1);
    return result;
  }

  async getVariantStock(variantId: number): Promise<VariantStock[]> {
    return await db.select().from(variantStock).where(eq(variantStock.productVariantId, variantId));
  }

  async getVariantPrices(variantId: number): Promise<any[]> {
    // In v2, prices are in product_price table keyed by product_id
    return await db.select().from(productPriceV2).where(eq(productPriceV2.productId, variantId));
  }

  async getVariantPricesWithCurrency(variantId: number): Promise<any[]> {
    return await db
      .select({
        variantPriceId: productPriceV2.productPriceId,
        productVariantId: productPriceV2.productId,
        currencyId: productPriceV2.currencyId,
        currencyCode: currency.code,
        currencyName: currency.name,
        currencySymbol: currency.symbol,
        costPrice: productPriceV2.costPrice,
        averageCostPrice: productPriceV2.averageCostPrice,
        retailPrice: productPriceV2.retailPrice,
        specialRetailPrice: productPriceV2.specialRetailPrice,
        isManualOverride: productPriceV2.isManualOverride,
        validFrom: productPriceV2.validFrom,
        validTo: productPriceV2.validTo,
      })
      .from(productPriceV2)
      .leftJoin(currency, eq(productPriceV2.currencyId, currency.currencyId))
      .where(eq(productPriceV2.productId, variantId));
  }

  async getProductPricesWithStores(productId: number): Promise<any[]> {
    // Get all prices for this product with currency info
    const prices = await db
      .select({
        productPriceId: productPriceV2.productPriceId,
        productId: productPriceV2.productId,
        currencyId: productPriceV2.currencyId,
        currencyCode: currency.code,
        currencyName: currency.name,
        currencySymbol: currency.symbol,
        costPrice: productPriceV2.costPrice,
        averageCostPrice: productPriceV2.averageCostPrice,
        retailPrice: productPriceV2.retailPrice,
        specialRetailPrice: productPriceV2.specialRetailPrice,
        customerPrice: productPriceV2.customerPrice,
        isManualOverride: productPriceV2.isManualOverride,
        validFrom: productPriceV2.validFrom,
        validTo: productPriceV2.validTo,
      })
      .from(productPriceV2)
      .leftJoin(currency, eq(productPriceV2.currencyId, currency.currencyId))
      .where(eq(productPriceV2.productId, productId))
      .orderBy(asc(currency.code));

    // Get store-currency mappings to know which stores use which currencies
    const storeCurrencyMappings = await db
      .select({
        storeId: storeCurrency.storeId,
        currencyId: storeCurrency.currencyId,
        isDefault: storeCurrency.isDefault,
        storeCode: store.code,
        storeName: store.name,
      })
      .from(storeCurrency)
      .innerJoin(store, eq(storeCurrency.storeId, store.storeId))
      .orderBy(asc(store.code));

    // Enrich prices with store info
    return prices.map((price) => {
      const storeMatches = storeCurrencyMappings
        .filter((sc) => Number(sc.currencyId) === Number(price.currencyId) && sc.isDefault)
        .map((sc) => ({ storeId: Number(sc.storeId), code: sc.storeCode, name: sc.storeName }));
      return {
        ...price,
        stores: storeMatches,
      };
    });
  }

  async upsertVariantPrice(input: {
    productVariantId: number;
    currencyId: number;
    retailPrice?: string | null;
    specialRetailPrice?: string | null;
    costPrice?: string | null;
    isManualOverride?: boolean;
  }): Promise<void> {
    const [existing] = await db
      .select({ variantPriceId: variantPrice.variantPriceId })
      .from(variantPrice)
      .where(
        and(
          eq(variantPrice.productVariantId, input.productVariantId),
          eq(variantPrice.currencyId, input.currencyId),
          isNull(variantPrice.validFrom),
          isNull(variantPrice.validTo)
        )
      )
      .limit(1);

    const isManual = input.isManualOverride ?? false;

    if (existing) {
      await db
        .update(variantPrice)
        .set({
          retailPrice: input.retailPrice,
          specialRetailPrice: input.specialRetailPrice,
          costPrice: input.costPrice,
          isManualOverride: isManual,
        })
        .where(eq(variantPrice.variantPriceId, existing.variantPriceId));
    } else {
      await db.insert(variantPrice).values({
        productVariantId: input.productVariantId,
        currencyId: input.currencyId,
        retailPrice: input.retailPrice,
        specialRetailPrice: input.specialRetailPrice,
        costPrice: input.costPrice,
        isManualOverride: isManual,
      });
    }

    try {
      const variant = await this.getVariant(input.productVariantId);
      if (variant) {
        await this.insertSyncQueueEntry({
          productId: Number(variant.productId),
          productVariantId: input.productVariantId,
          operationType: "variant_update",
        });
      }
    } catch (e) {
      console.error("Failed to insert sync queue entry for price update:", e);
    }
  }

  async getConversionRates(): Promise<any[]> {
    const fromCurrency = alias(currency, "from_currency");
    const toCurrency = alias(currency, "to_currency");
    return await db
      .select({
        conversionRateId: currencyConversionRate.conversionRateId,
        fromCurrencyId: currencyConversionRate.fromCurrencyId,
        toCurrencyId: currencyConversionRate.toCurrencyId,
        fromCurrencyCode: fromCurrency.code,
        toCurrencyCode: toCurrency.code,
        rate: currencyConversionRate.rate,
        updatedAt: currencyConversionRate.updatedAt,
      })
      .from(currencyConversionRate)
      .leftJoin(fromCurrency, eq(currencyConversionRate.fromCurrencyId, fromCurrency.currencyId))
      .leftJoin(toCurrency, eq(currencyConversionRate.toCurrencyId, toCurrency.currencyId))
      .orderBy(asc(currencyConversionRate.fromCurrencyId), asc(currencyConversionRate.toCurrencyId));
  }

  async upsertConversionRate(input: {
    fromCurrencyId: number;
    toCurrencyId: number;
    rate: string;
  }): Promise<void> {
    const [existing] = await db
      .select({ conversionRateId: currencyConversionRate.conversionRateId })
      .from(currencyConversionRate)
      .where(
        and(
          eq(currencyConversionRate.fromCurrencyId, input.fromCurrencyId),
          eq(currencyConversionRate.toCurrencyId, input.toCurrencyId),
        )
      )
      .limit(1);

    if (existing) {
      await db
        .update(currencyConversionRate)
        .set({
          rate: input.rate,
          updatedAt: new Date(),
        })
        .where(eq(currencyConversionRate.conversionRateId, existing.conversionRateId));
    } else {
      await db.insert(currencyConversionRate).values({
        fromCurrencyId: input.fromCurrencyId,
        toCurrencyId: input.toCurrencyId,
        rate: input.rate,
        updatedAt: new Date(),
      });
    }
  }

  async autoConvertPricesFromBase(variantId: number, baseCurrencyCode: string = "GBP"): Promise<void> {
    const [baseCurrency] = await db
      .select({ currencyId: currency.currencyId })
      .from(currency)
      .where(sql`upper(${currency.code}) = ${baseCurrencyCode.toUpperCase()}`)
      .limit(1);

    if (!baseCurrency) return;

    const [basePrice] = await db
      .select({
        retailPrice: variantPrice.retailPrice,
        specialRetailPrice: variantPrice.specialRetailPrice,
        costPrice: variantPrice.costPrice,
      })
      .from(variantPrice)
      .where(
        and(
          eq(variantPrice.productVariantId, variantId),
          eq(variantPrice.currencyId, baseCurrency.currencyId),
        )
      )
      .limit(1);

    if (!basePrice) return;

    const rates = await db
      .select({
        toCurrencyId: currencyConversionRate.toCurrencyId,
        rate: currencyConversionRate.rate,
        toCurrencyCode: currency.code,
      })
      .from(currencyConversionRate)
      .innerJoin(currency, eq(currency.currencyId, currencyConversionRate.toCurrencyId))
      .where(eq(currencyConversionRate.fromCurrencyId, baseCurrency.currencyId));

    for (const rateRow of rates) {
      const rate = Number(rateRow.rate);
      if (!Number.isFinite(rate) || rate <= 0) continue;

      const [existingPrice] = await db
        .select({
          variantPriceId: variantPrice.variantPriceId,
          isManualOverride: variantPrice.isManualOverride,
        })
        .from(variantPrice)
        .where(
          and(
            eq(variantPrice.productVariantId, variantId),
            eq(variantPrice.currencyId, rateRow.toCurrencyId),
          )
        )
        .limit(1);

      if (existingPrice?.isManualOverride) continue;

      const isUSD = rateRow.toCurrencyCode?.toUpperCase() === "USD";

      const convertStraight = (val: string | null): string | null => {
        if (!val) return null;
        const num = Number(val);
        if (!Number.isFinite(num)) return null;
        return (num * rate).toFixed(2);
      };

      const convertRoundUp5 = (val: string | null): string | null => {
        if (!val) return null;
        const num = Number(val);
        if (!Number.isFinite(num) || num <= 0) return null;
        const rawCents = Math.round(num * rate * 100);
        const fiveDollarCents = 500;
        const roundedUpCents = Math.ceil(rawCents / fiveDollarCents) * fiveDollarCents;
        const finalCents = roundedUpCents - 1;
        if (finalCents <= 0) return "4.99";
        return (finalCents / 100).toFixed(2);
      };

      const convertRetailOrSpecial = isUSD ? convertRoundUp5 : convertStraight;

      const convertedRetail = convertRetailOrSpecial(basePrice.retailPrice);
      const convertedSpecial = convertRetailOrSpecial(basePrice.specialRetailPrice);
      const convertedCost = convertStraight(basePrice.costPrice);

      if (existingPrice) {
        await db
          .update(variantPrice)
          .set({
            retailPrice: convertedRetail,
            specialRetailPrice: convertedSpecial,
            costPrice: convertedCost,
            isManualOverride: false,
          })
          .where(eq(variantPrice.variantPriceId, existingPrice.variantPriceId));
      } else {
        await db.insert(variantPrice).values({
          productVariantId: variantId,
          currencyId: rateRow.toCurrencyId,
          retailPrice: convertedRetail,
          specialRetailPrice: convertedSpecial,
          costPrice: convertedCost,
          isManualOverride: false,
        });
      }
    }
  }

  async getStores(): Promise<Store[]> {
    return await db.select().from(store).orderBy(asc(store.code));
  }

  async createStore(input: { code: string; name?: string | null; websiteCode: string }): Promise<Store> {
    const trimmedCode = input.code.trim();
    if (!trimmedCode) {
      throw new Error("Store code is required");
    }

    const trimmedWebsiteCode = input.websiteCode.trim();
    if (!trimmedWebsiteCode) {
      throw new Error("Website code is required");
    }

    const [existing] = await db
      .select({ storeId: store.storeId })
      .from(store)
      .where(eq(store.code, trimmedCode))
      .limit(1);

    if (existing) {
      throw new Error("Store code already exists");
    }

    const [created] = await db
      .insert(store)
      .values({ code: trimmedCode, name: input.name ?? null, websiteCode: trimmedWebsiteCode })
      .returning();

    if (!created) {
      throw new Error("Failed to create store");
    }

    return created;
  }

  async updateStore(storeId: number, input: { code?: string; name?: string | null; websiteCode?: string }): Promise<Store> {
    const [existing] = await db
      .select()
      .from(store)
      .where(eq(store.storeId, storeId))
      .limit(1);

    if (!existing) {
      throw new Error("Store not found");
    }

    const updateValues: Partial<{ code: string; name: string | null; websiteCode: string }> = {};

    if (input.code !== undefined) {
      const trimmedCode = input.code.trim();
      if (!trimmedCode) {
        throw new Error("Store code cannot be empty");
      }
      if (trimmedCode !== existing.code) {
        const [duplicate] = await db
          .select({ storeId: store.storeId })
          .from(store)
          .where(eq(store.code, trimmedCode))
          .limit(1);
        if (duplicate) {
          throw new Error("Store code already exists");
        }
        updateValues.code = trimmedCode;
      }
    }

    if (input.name !== undefined) {
      updateValues.name = input.name;
    }

    if (input.websiteCode !== undefined) {
      const trimmedWebsiteCode = input.websiteCode.trim();
      if (!trimmedWebsiteCode) {
        throw new Error("Website code cannot be empty");
      }
      updateValues.websiteCode = trimmedWebsiteCode;
    }

    if (Object.keys(updateValues).length === 0) {
      return existing;
    }

    const [updated] = await db
      .update(store)
      .set(updateValues)
      .where(eq(store.storeId, storeId))
      .returning();

    if (!updated) {
      throw new Error("Failed to update store");
    }

    return updated;
  }

  async getProductStores(productId: number): Promise<any[]> {
    const results = await db
      .select({
        storeId: productStore.storeId,
        storeCode: store.code,
        storeName: store.name,
        enabled: productStore.enabled,
        createdAt: productStore.createdAt,
      })
      .from(productStore)
      .innerJoin(store, eq(productStore.storeId, store.storeId))
      .where(eq(productStore.productId, productId))
      .orderBy(asc(store.code));
    
    return results;
  }

  async setProductStores(productId: number, storeIds: number[]): Promise<void> {
    await db.transaction(async (tx) => {
      await tx
        .delete(productStore)
        .where(eq(productStore.productId, productId));

      if (storeIds.length > 0) {
        await tx.insert(productStore).values(
          storeIds.map((storeId) => ({
            productId,
            storeId,
            enabled: true,
          }))
        );
      }
    });

    try {
      await this.insertSyncQueueEntry({
        productId,
        productVariantId: null,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for store assignment:", e);
    }
  }

  async getStoreProductCounts(): Promise<Array<{ storeId: number; productCount: number }>> {
    const results = await db
      .select({
        storeId: productStore.storeId,
        productCount: sql<number>`count(distinct ${productStore.productId})::int`,
      })
      .from(productStore)
      .where(eq(productStore.enabled, true))
      .groupBy(productStore.storeId);
    return results;
  }

  async getCurrencies(): Promise<any[]> {
    return await db
      .select({
        currencyId: currency.currencyId,
        code: currency.code,
        name: currency.name,
        symbol: currency.symbol,
        minorUnit: currency.minorUnit,
        enabled: currency.enabled,
      })
      .from(currency)
      .orderBy(asc(currency.code));
  }

  async getStoreCurrencies(): Promise<any[]> {
    return await db
      .select({
        storeId: storeCurrency.storeId,
        currencyId: storeCurrency.currencyId,
        isDefault: storeCurrency.isDefault,
        code: currency.code,
        name: currency.name,
        symbol: currency.symbol,
      })
      .from(storeCurrency)
      .leftJoin(currency, eq(storeCurrency.currencyId, currency.currencyId))
      .orderBy(asc(storeCurrency.storeId), asc(currency.code));
  }

  async setStoreDefaultCurrency(storeId: number, currencyId: number): Promise<void> {
    const [storeRow] = await db
      .select({ storeId: store.storeId })
      .from(store)
      .where(eq(store.storeId, storeId))
      .limit(1);

    if (!storeRow) {
      throw new Error("Store not found");
    }

    const [currencyRow] = await db
      .select({ currencyId: currency.currencyId })
      .from(currency)
      .where(eq(currency.currencyId, currencyId))
      .limit(1);

    if (!currencyRow) {
      throw new Error("Currency not found");
    }

    await db.transaction(async (tx) => {
      await tx
        .update(storeCurrency)
        .set({ isDefault: false })
        .where(eq(storeCurrency.storeId, storeId));

      const [existing] = await tx
        .select({ storeId: storeCurrency.storeId })
        .from(storeCurrency)
        .where(and(eq(storeCurrency.storeId, storeId), eq(storeCurrency.currencyId, currencyId)))
        .limit(1);

      if (existing) {
        await tx
          .update(storeCurrency)
          .set({ isDefault: true })
          .where(and(eq(storeCurrency.storeId, storeId), eq(storeCurrency.currencyId, currencyId)));
      } else {
        await tx.insert(storeCurrency).values({ storeId, currencyId, isDefault: true });
      }
    });
  }

  async getWarehouses(): Promise<Warehouse[]> {
    return await db.select().from(warehouse).orderBy(asc(warehouse.code));
  }

  async getBrands(): Promise<any[]> {
    return await db
      .select({
        brandId: brands.brandId,
        brandName: brands.brandName,
        brandGrouping: brands.brandGrouping,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(brands)
      .leftJoin(product, eq(product.brandId, brands.brandId))
      .groupBy(brands.brandId, brands.brandName, brands.brandGrouping)
      .orderBy(asc(brands.brandName));
  }

  async getProductTypes(): Promise<any[]> {
    return await db
      .select({
        productTypeId: productType.productTypeId,
        productTypeName: productType.productTypeName,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(productType)
      .leftJoin(product, eq(product.productTypeId, productType.productTypeId))
      .groupBy(productType.productTypeId, productType.productTypeName)
      .orderBy(asc(productType.productTypeName));
  }

  async getProductStyles(): Promise<string[]> {
    const styles = await db
      .select({ productStyle: product.productStyle })
      .from(product)
      .where(sql`${product.productStyle} is not null`)
      .groupBy(product.productStyle)
      .orderBy(asc(product.productStyle));

    return styles
      .map((row) => row.productStyle)
      .filter((style): style is string => style !== null);
  }

  async getProductStylesWithCounts(): Promise<any[]> {
    return await db
      .select({
        productStyle: product.productStyle,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(product)
      .where(sql`${product.productStyle} IS NOT NULL AND ${product.productStyle} != ''`)
      .groupBy(product.productStyle)
      .orderBy(asc(product.productStyle));
  }

  async getProductColours(): Promise<any[]> {
    return await db
      .select({
        productColourId: productColour.productColourId,
        magentoColourId: productColour.magentoColourId,
        magentoColourName: productColour.magentoColourName,
        brandId: productColour.brandId,
        brandColourId: productColour.brandColourId,
        brandColourName: productColour.brandColourName,
        brandName: brands.brandName,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(productColour)
      .leftJoin(brands, eq(productColour.brandId, brands.brandId))
      .leftJoin(product, eq(product.productColourId, productColour.productColourId))
      .groupBy(
        productColour.productColourId,
        productColour.magentoColourId,
        productColour.magentoColourName,
        productColour.brandId,
        productColour.brandColourId,
        productColour.brandColourName,
        brands.brandName,
      )
      .orderBy(asc(productColour.magentoColourName));
  }

  async getGenders(): Promise<any[]> {
    try {
      return await db
        .select({
          genderId: gender.genderId,
          genderName: gender.genderName,
          productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
          variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
        })
        .from(gender)
        .leftJoin(product, eq(product.genderId, gender.genderId))
        .groupBy(gender.genderId, gender.genderName)
        .orderBy(asc(gender.genderName));
    } catch (error) {
      return await db.select().from(gender).orderBy(asc(gender.genderName));
    }
  }

  async getSizes(): Promise<any[]> {
    return await db
      .select()
      .from(productSizes)
      .orderBy(asc(productSizes.magentoSizeLongName));
  }

  async getTaxClasses(): Promise<any[]> {
    return await db
      .select({
        taxClassId: taxClass.taxClassId,
        taxClassName: taxClass.taxClassName,
      })
      .from(taxClass)
      .orderBy(asc(taxClass.taxClassName));
  }

  async getConditions(): Promise<any[]> {
    return await db
      .select({
        conditionId: condition.conditionId,
        conditionName: condition.conditionName,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(condition)
      .leftJoin(product, eq(product.conditionId, condition.conditionId))
      .groupBy(condition.conditionId, condition.conditionName)
      .orderBy(asc(condition.conditionName));
  }

  async getAttributeDefs(): Promise<any[]> {
    return await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        label: attributeDef.label,
        dataType: attributeDef.dataType,
        magentoSync: attributeDef.magentoSync,
        magentoScope: attributeDef.magentoScope,
      })
      .from(attributeDef)
      .orderBy(asc(attributeDef.code));
  }

  async createAttributeDef(input: {
    code: string;
    label?: string | null;
    dataType?: string | null;
    magentoSync?: boolean;
    magentoScope?: string | null;
  }): Promise<any> {
    const normalizedCode = normalizeAttributeCode(input.code);
    if (!normalizedCode) {
      throw new Error("Attribute code is required");
    }
    const [existing] = await db
      .select({ attributeId: attributeDef.attributeId })
      .from(attributeDef)
      .where(eq(attributeDef.code, normalizedCode))
      .limit(1);
    if (existing) {
      throw new Error("Attribute code already exists");
    }

    const fallbackLabel = labelizeAttributeCode(normalizedCode);
    const validMagentoScope = toMagentoScope(input.magentoScope);
    const [created] = await db
      .insert(attributeDef)
      .values({
        code: normalizedCode,
        label: input.label?.trim() || fallbackLabel,
        dataType: input.dataType ?? null,
        magentoSync: input.magentoSync ?? false,
        magentoScope: validMagentoScope,
      })
      .returning();
    return created;
  }

  async updateAttributeDef(attributeId: number, updates: { magentoSync?: boolean; label?: string | null; magentoScope?: string | null }): Promise<any> {
    const setValues: Record<string, any> = {};
    if (typeof updates.magentoSync === "boolean") {
      setValues.magentoSync = updates.magentoSync;
    }
    if (updates.label !== undefined) {
      setValues.label = updates.label;
    }
    if (updates.magentoScope !== undefined) {
      setValues.magentoScope = toMagentoScope(updates.magentoScope);
    }
    if (Object.keys(setValues).length === 0) {
      const [existing] = await db.select().from(attributeDef).where(eq(attributeDef.attributeId, attributeId)).limit(1);
      return existing;
    }
    const [updated] = await db
      .update(attributeDef)
      .set(setValues)
      .where(eq(attributeDef.attributeId, attributeId))
      .returning();
    return updated;
  }

  async deleteAttributeDef(attributeId: number): Promise<void> {
    await db.transaction(async (tx) => {
      await tx
        .delete(productAttributeVal)
        .where(eq(productAttributeVal.attributeId, attributeId));
      await tx
        .delete(variantAttributeVal)
        .where(eq(variantAttributeVal.attributeId, attributeId));
      await tx.delete(attributeDef).where(eq(attributeDef.attributeId, attributeId));
    });
  }

  async getProductAttributes(productId: number, storeId?: number | null): Promise<any[]> {
    const conditions = [eq(productAttributeValV2.productId, productId)];
    if (storeId !== undefined && storeId !== null) {
      // Return both global (store_id IS NULL) and store-specific values for a specific store
      conditions.push(
        or(
          isNull(productAttributeValV2.storeId),
          eq(productAttributeValV2.storeId, storeId),
        )!,
      );
    }
    // When no storeId specified, return ALL attributes (global + all store-scoped)
    return await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        label: attributeDef.label,
        dataType: attributeDef.dataType,
        storeId: productAttributeValV2.storeId,
        valueText: productAttributeValV2.valueText,
        valueNum: productAttributeValV2.valueNum,
        valueBool: productAttributeValV2.valueBool,
        valueJson: productAttributeValV2.valueJson,
      })
      .from(productAttributeValV2)
      .innerJoin(attributeDef, eq(productAttributeValV2.attributeId, attributeDef.attributeId))
      .where(and(...conditions))
      .orderBy(asc(attributeDef.code));
  }

  async getBulkProductAttributes(productIds: number[], attributeIds: number[]): Promise<any[]> {
    if (productIds.length === 0 || attributeIds.length === 0) return [];
    return await db
      .select({
        productId: productAttributeVal.productId,
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        label: attributeDef.label,
        dataType: attributeDef.dataType,
        valueText: productAttributeVal.valueText,
        valueNum: productAttributeVal.valueNum,
        valueBool: productAttributeVal.valueBool,
        valueJson: productAttributeVal.valueJson,
      })
      .from(productAttributeVal)
      .innerJoin(attributeDef, eq(productAttributeVal.attributeId, attributeDef.attributeId))
      .where(
        and(
          inArray(productAttributeVal.productId, productIds),
          inArray(productAttributeVal.attributeId, attributeIds),
        )
      );
  }

  async getVariantAttributes(variantId: number): Promise<any[]> {
    return await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        label: attributeDef.label,
        dataType: attributeDef.dataType,
        valueText: variantAttributeVal.valueText,
        valueNum: variantAttributeVal.valueNum,
        valueBool: variantAttributeVal.valueBool,
        valueJson: variantAttributeVal.valueJson,
      })
      .from(variantAttributeVal)
      .innerJoin(attributeDef, eq(variantAttributeVal.attributeId, attributeDef.attributeId))
      .where(eq(variantAttributeVal.productVariantId, variantId))
      .orderBy(asc(attributeDef.code));
  }

  async setProductAttributeValue(input: {
    productId: number;
    attributeId: number;
    value: any;
    storeId?: number | null;
  }): Promise<void> {
    const [def] = await db
      .select({
        attributeId: attributeDef.attributeId,
        dataType: attributeDef.dataType,
      })
      .from(attributeDef)
      .where(eq(attributeDef.attributeId, input.attributeId))
      .limit(1);
    if (!def) {
      throw new Error("Attribute not found");
    }

    const storeId = input.storeId ?? null;
    const storeCondition = storeId !== null
      ? eq(productAttributeValV2.storeId, storeId)
      : isNull(productAttributeValV2.storeId);

    const coerced = coerceAttributeValue(input.value, def.dataType ?? null);
    if (!coerced) {
      await db
        .delete(productAttributeValV2)
        .where(
          and(
            eq(productAttributeValV2.productId, input.productId),
            eq(productAttributeValV2.attributeId, input.attributeId),
            storeCondition,
          ),
        );
      await db
        .update(product)
        .set({ updatedAt: new Date() })
        .where(eq(product.productId, input.productId));
      return;
    }

    // Use raw SQL for upsert since the unique index uses COALESCE
    const pool = (db as any)._.session?.client;
    if (pool) {
      await pool.query(
        `INSERT INTO pim.product_attribute_val (product_id, attribute_id, store_id, value_text, value_num, value_bool, value_json)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (product_id, attribute_id, COALESCE(store_id, 0))
         DO UPDATE SET value_text = $4, value_num = $5, value_bool = $6, value_json = $7`,
        [
          input.productId,
          input.attributeId,
          storeId,
          coerced.valueText ?? null,
          coerced.valueNum ?? null,
          coerced.valueBool ?? null,
          coerced.valueJson ? JSON.stringify(coerced.valueJson) : null,
        ],
      );
    } else {
      // Fallback: delete + insert
      await db
        .delete(productAttributeValV2)
        .where(
          and(
            eq(productAttributeValV2.productId, input.productId),
            eq(productAttributeValV2.attributeId, input.attributeId),
            storeCondition,
          ),
        );
      await db
        .insert(productAttributeValV2)
        .values({
          productId: input.productId,
          attributeId: input.attributeId,
          storeId: storeId,
          valueText: coerced.valueText,
          valueNum: coerced.valueNum != null ? String(coerced.valueNum) : null,
          valueBool: coerced.valueBool,
          valueJson: coerced.valueJson,
        });
    }

    await db
      .update(product)
      .set({ updatedAt: new Date() })
      .where(eq(product.productId, input.productId));

    try {
      await this.insertSyncQueueEntry({
        productId: input.productId,
        productVariantId: null,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for product attribute:", e);
    }
  }

  async setVariantAttributeValue(input: {
    variantId: number;
    attributeId: number;
    value: any;
  }): Promise<void> {
    const [def] = await db
      .select({
        attributeId: attributeDef.attributeId,
        dataType: attributeDef.dataType,
      })
      .from(attributeDef)
      .where(eq(attributeDef.attributeId, input.attributeId))
      .limit(1);
    if (!def) {
      throw new Error("Attribute not found");
    }

    const coerced = coerceAttributeValue(input.value, def.dataType ?? null);
    if (!coerced) {
      await db
        .delete(variantAttributeVal)
        .where(
          and(
            eq(variantAttributeVal.productVariantId, input.variantId),
            eq(variantAttributeVal.attributeId, input.attributeId),
          ),
        );
      return;
    }

    await db
      .insert(variantAttributeVal)
      .values({
        productVariantId: input.variantId,
        attributeId: input.attributeId,
        ...coerced,
      })
      .onConflictDoUpdate({
        target: [variantAttributeVal.productVariantId, variantAttributeVal.attributeId],
        set: {
          valueText: coerced.valueText,
          valueNum: coerced.valueNum,
          valueBool: coerced.valueBool,
          valueJson: coerced.valueJson,
        },
      });

    try {
      const variant = await this.getVariant(input.variantId);
      if (variant) {
        await this.insertSyncQueueEntry({
          productId: Number(variant.productId),
          productVariantId: input.variantId,
          operationType: "variant_update",
        });
      }
    } catch (e) {
      console.error("Failed to insert sync queue entry for variant attribute:", e);
    }
  }

  async deleteProductAttributeValue(input: {
    productId: number;
    attributeId: number;
    storeId?: number | null;
  }): Promise<void> {
    const storeCondition = (input.storeId !== undefined && input.storeId !== null)
      ? eq(productAttributeValV2.storeId, input.storeId)
      : isNull(productAttributeValV2.storeId);
    await db
      .delete(productAttributeValV2)
      .where(
        and(
          eq(productAttributeValV2.productId, input.productId),
          eq(productAttributeValV2.attributeId, input.attributeId),
          storeCondition,
        ),
      );

    try {
      await this.insertSyncQueueEntry({
        productId: input.productId,
        productVariantId: null,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for delete product attribute:", e);
    }
  }

  async deleteVariantAttributeValue(input: {
    variantId: number;
    attributeId: number;
  }): Promise<void> {
    await db
      .delete(variantAttributeVal)
      .where(
        and(
          eq(variantAttributeVal.productVariantId, input.variantId),
          eq(variantAttributeVal.attributeId, input.attributeId),
        ),
      );

    try {
      const variant = await this.getVariant(input.variantId);
      if (variant) {
        await this.insertSyncQueueEntry({
          productId: Number(variant.productId),
          productVariantId: input.variantId,
          operationType: "variant_update",
        });
      }
    } catch (e) {
      console.error("Failed to insert sync queue entry for delete variant attribute:", e);
    }
  }

  async deleteProduct(productId: number): Promise<void> {
    await this.deleteProducts([productId]);
  }

  async deleteProducts(productIds: number[]): Promise<void> {
    const ids = productIds.filter((id) => Number.isFinite(id));
    if (ids.length === 0) {
      return;
    }

    try {
      for (const id of ids) {
        await this.insertSyncQueueEntry({
          productId: id,
          productVariantId: null,
          operationType: "product_delete",
        });
      }
    } catch (e) {
      console.error("Failed to insert sync queue entry for product delete:", e);
    }

    await db.transaction(async (tx) => {
      const variantIds = await tx
        .select({ id: productVariant.productVariantId })
        .from(productVariant)
        .where(inArray(productVariant.productId, ids));
      const variantIdList = variantIds.map((row) => Number(row.id));

      if (variantIdList.length > 0) {
        await tx
          .delete(scheduledChangeItem)
          .where(inArray(scheduledChangeItem.variantId, variantIdList));
        await tx
          .delete(alumioSyncQueue)
          .where(inArray(alumioSyncQueue.productVariantId, variantIdList));
        await tx
          .delete(variantAttributeVal)
          .where(inArray(variantAttributeVal.productVariantId, variantIdList));
        await tx
          .delete(variantStock)
          .where(inArray(variantStock.productVariantId, variantIdList));
        await tx
          .delete(variantPrice)
          .where(inArray(variantPrice.productVariantId, variantIdList));
        await tx
          .delete(variantChannelId)
          .where(inArray(variantChannelId.productVariantId, variantIdList));
        await tx
          .delete(variantBarcode)
          .where(inArray(variantBarcode.variantId, variantIdList));
        await tx
          .delete(productVariant)
          .where(inArray(productVariant.productVariantId, variantIdList));
      }

      await tx
        .delete(productAttributeVal)
        .where(inArray(productAttributeVal.productId, ids));
      await tx
        .delete(imageAsset)
        .where(inArray(imageAsset.productId, ids));
      await tx
        .delete(productCategory)
        .where(inArray(productCategory.productId, ids));
      await tx
        .delete(productTeamMeta)
        .where(inArray(productTeamMeta.productId, ids));
      await tx
        .delete(productGroupMember)
        .where(inArray(productGroupMember.productId, ids));
      await tx
        .delete(productStore)
        .where(inArray(productStore.productId, ids));
      await tx
        .delete(scheduledChangeItem)
        .where(inArray(scheduledChangeItem.productId, ids));
      await tx
        .delete(alumioSyncQueue)
        .where(inArray(alumioSyncQueue.productId, ids));
      await tx.delete(product).where(inArray(product.productId, ids));
    });
  }

  async duplicateProduct(productId: number): Promise<{ productId: number; productSku: string }> {
    const [sourceProduct] = await db
      .select()
      .from(product)
      .where(eq(product.productId, productId))
      .limit(1);

    if (!sourceProduct) {
      throw new Error("Product not found");
    }

    const baseSku = sourceProduct.productSku || "PRODUCT";
    let newSku = `${baseSku}-COPY`;
    let counter = 1;
    while (true) {
      const [existing] = await db
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, newSku))
        .limit(1);
      if (!existing) break;
      counter++;
      newSku = `${baseSku}-COPY-${counter}`;
    }

    const now = new Date();

    const result = await db.transaction(async (tx) => {
      const [newProduct] = await tx
        .insert(product)
        .values({
          productSku: newSku,
          articleNumber: sourceProduct.articleNumber,
          productDescription: sourceProduct.productDescription
            ? `${sourceProduct.productDescription} (Copy)`
            : null,
          productColourId: sourceProduct.productColourId,
          genderId: sourceProduct.genderId,
          eraId: sourceProduct.eraId,
          brandId: sourceProduct.brandId,
          productTypeId: sourceProduct.productTypeId,
          productStyle: sourceProduct.productStyle,
          composition: sourceProduct.composition,
          countryOfManufacture: sourceProduct.countryOfManufacture,
          commodityCode: sourceProduct.commodityCode,
          imageCode: sourceProduct.imageCode,
          enabled: sourceProduct.enabled,
          createdAt: now,
          updatedAt: now,
        })
        .returning({ productId: product.productId });

      const newProductId = newProduct.productId;

      const categories = await tx
        .select()
        .from(productCategory)
        .where(eq(productCategory.productId, productId));
      for (const cat of categories) {
        await tx.insert(productCategory).values({
          productId: newProductId,
          categoryId: cat.categoryId,
        });
      }

      const teamMetas = await tx
        .select()
        .from(productTeamMeta)
        .where(eq(productTeamMeta.productId, productId));
      for (const tm of teamMetas) {
        await tx.insert(productTeamMeta).values({
          productId: newProductId,
          clubId: tm.clubId,
          competitionId: tm.competitionId,
          seasonId: tm.seasonId,
          departmentId: tm.departmentId,
          kitCategoryId: tm.kitCategoryId,
          kitClassId: tm.kitClassId,
          isPrimary: tm.isPrimary,
        });
      }

      const images = await tx
        .select()
        .from(imageAsset)
        .where(eq(imageAsset.productId, productId));
      for (const img of images) {
        await tx.insert(imageAsset).values({
          productId: newProductId,
          role: img.role,
          url: img.url,
          sortOrder: img.sortOrder,
        });
      }

      const prodAttrs = await tx
        .select()
        .from(productAttributeVal)
        .where(eq(productAttributeVal.productId, productId));
      for (const attr of prodAttrs) {
        await tx.insert(productAttributeVal).values({
          productId: newProductId,
          attributeId: attr.attributeId,
          valueText: attr.valueText,
          valueNum: attr.valueNum,
          valueBool: attr.valueBool,
          valueJson: attr.valueJson,
        });
      }

      const stores = await tx
        .select()
        .from(productStore)
        .where(eq(productStore.productId, productId));
      for (const s of stores) {
        await tx.insert(productStore).values({
          productId: newProductId,
          storeId: s.storeId,
          enabled: s.enabled,
        });
      }

      const newVariantIds: number[] = [];

      const variants = await tx
        .select()
        .from(productVariant)
        .where(eq(productVariant.productId, productId));

      for (const v of variants) {
        let variantSku = `${v.productVariantSku}-COPY`;
        let vc = 1;
        while (true) {
          const [ex] = await tx
            .select({ id: productVariant.productVariantId })
            .from(productVariant)
            .where(eq(productVariant.productVariantSku, variantSku))
            .limit(1);
          if (!ex) break;
          vc++;
          variantSku = `${v.productVariantSku}-COPY-${vc}`;
        }

        const [newVariant] = await tx
          .insert(productVariant)
          .values({
            productId: newProductId,
            productVariantSku: variantSku,
            sizeId: v.sizeId,
            taxClassId: v.taxClassId,
            conditionId: v.conditionId,
            conditionDetail: v.conditionDetail,
            barcode: null,
            widthCm: v.widthCm,
            lengthCm: v.lengthCm,
            weight: v.weight,
            depth: v.depth,
            costPrice: v.costPrice,
            averageCostPrice: v.averageCostPrice,
            customerPrice: v.customerPrice,
            printed: v.printed,
            magentoProductId: null,
            enabled: v.enabled,
            createdAt: now,
            updatedAt: now,
          })
          .returning({ productVariantId: productVariant.productVariantId });

        const newVariantId = newVariant.productVariantId;
        newVariantIds.push(newVariantId);

        const prices = await tx
          .select()
          .from(variantPrice)
          .where(eq(variantPrice.productVariantId, v.productVariantId));
        for (const p of prices) {
          await tx.insert(variantPrice).values({
            productVariantId: newVariantId,
            currencyId: p.currencyId,
            costPrice: p.costPrice,
            averageCostPrice: p.averageCostPrice,
            retailPrice: p.retailPrice,
            specialRetailPrice: p.specialRetailPrice,
            customerPrice: p.customerPrice,
            isManualOverride: p.isManualOverride,
            validFrom: p.validFrom,
            validTo: p.validTo,
          });
        }

        const stocks = await tx
          .select()
          .from(variantStock)
          .where(eq(variantStock.productVariantId, v.productVariantId));
        for (const s of stocks) {
          await tx.insert(variantStock).values({
            productVariantId: newVariantId,
            warehouseId: s.warehouseId,
            qty: 0,
            binLocation: s.binLocation,
          });
        }

        const vAttrs = await tx
          .select()
          .from(variantAttributeVal)
          .where(eq(variantAttributeVal.productVariantId, v.productVariantId));
        for (const va of vAttrs) {
          await tx.insert(variantAttributeVal).values({
            productVariantId: newVariantId,
            attributeId: va.attributeId,
            valueText: va.valueText,
            valueNum: va.valueNum,
            valueBool: va.valueBool,
            valueJson: va.valueJson,
          });
        }

        const vChannels = await tx
          .select()
          .from(variantChannelId)
          .where(eq(variantChannelId.productVariantId, v.productVariantId));
        for (const vc2 of vChannels) {
          await tx.insert(variantChannelId).values({
            productVariantId: newVariantId,
            channelId: vc2.channelId,
            externalProductId: null,
          });
        }
      }

      return { productId: newProductId, productSku: newSku, variantIds: newVariantIds };
    });

    const [dupProduct] = await db
      .select({ sync: product.sync })
      .from(product)
      .where(eq(product.productId, result.productId))
      .limit(1);
    if (dupProduct?.sync) {
      try {
        await this.insertSyncQueueEntry({
          productId: result.productId,
          productVariantId: null,
          operationType: "product_create",
        });
        for (const vid of result.variantIds) {
          await this.insertSyncQueueEntry({
            productId: result.productId,
            productVariantId: vid,
            operationType: "variant_create",
          });
        }
        await this.insertSyncQueueEntry({
          productId: result.productId,
          productVariantId: null,
          operationType: "category_change",
        });
      } catch (e) {
        console.error("Failed to insert sync queue entries for duplicated product:", e);
      }
    }

    return { productId: result.productId, productSku: result.productSku };
  }

  async attachSimpleProductsToConfigurable(
    configurableProductId: number,
    simpleProductIds: number[],
  ): Promise<{ attached: number; removed: number }> {
    const ids = simpleProductIds.filter((id) => Number.isFinite(id) && id !== configurableProductId);
    if (ids.length === 0) return { attached: 0, removed: 0 };

    const result = await db.transaction(async (tx) => {
      const [parentProduct] = await tx
        .select({ productId: product.productId, productTypeId: product.productTypeId })
        .from(product)
        .where(eq(product.productId, configurableProductId))
        .limit(1);
      if (!parentProduct) throw new Error("Target product not found");

      const simpleTypeRow = await tx
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(ilike(productType.productTypeName, "simple"))
        .limit(1);
      const simpleTypeId = simpleTypeRow[0]?.productTypeId ?? null;

      const configurableTypeRow = await tx
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(ilike(productType.productTypeName, "configurable"))
        .limit(1);
      const configurableTypeId = configurableTypeRow[0]?.productTypeId ?? null;

      if (configurableTypeId && parentProduct.productTypeId !== configurableTypeId) {
        await tx
          .update(product)
          .set({ productTypeId: configurableTypeId, updatedAt: new Date() })
          .where(eq(product.productId, configurableProductId));
      }

      let attached = 0;
      let removed = 0;
      const now = new Date();

      for (const simpleId of ids) {
        if (simpleTypeId !== null) {
          const [sourceProduct] = await tx
            .select({ productTypeId: product.productTypeId })
            .from(product)
            .where(eq(product.productId, simpleId))
            .limit(1);
          if (!sourceProduct) continue;
          if (sourceProduct.productTypeId !== null && sourceProduct.productTypeId !== simpleTypeId) continue;
        }

        const variants = await tx
          .select({ productVariantId: productVariant.productVariantId })
          .from(productVariant)
          .where(eq(productVariant.productId, simpleId));

        if (variants.length === 0) continue;

        const variantIdList = variants.map((v) => Number(v.productVariantId));

        await tx
          .update(productVariant)
          .set({ productId: configurableProductId, updatedAt: now })
          .where(inArray(productVariant.productVariantId, variantIdList));
        attached += variantIdList.length;

        const remainingVariants = await tx
          .select({ productVariantId: productVariant.productVariantId })
          .from(productVariant)
          .where(eq(productVariant.productId, simpleId));

        if (remainingVariants.length === 0) {
          await tx.delete(productAttributeVal).where(eq(productAttributeVal.productId, simpleId));
          await tx.delete(imageAsset).where(eq(imageAsset.productId, simpleId));
          await tx.delete(productCategory).where(eq(productCategory.productId, simpleId));
          await tx.delete(productTeamMeta).where(eq(productTeamMeta.productId, simpleId));
          await tx.delete(productGroupMember).where(eq(productGroupMember.productId, simpleId));
          await tx.delete(productStore).where(eq(productStore.productId, simpleId));
          await tx.delete(alumioSyncQueue).where(eq(alumioSyncQueue.productId, simpleId));
          await tx.delete(product).where(eq(product.productId, simpleId));
          removed++;
        }
      }

      return { attached, removed };
    });

    try {
      await this.insertSyncQueueEntry({
        productId: configurableProductId,
        productVariantId: null,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for attach:", e);
    }

    return result;
  }

  async detachVariantToNewProduct(
    configurableProductId: number,
    variantId: number,
  ): Promise<{ newProductId: number; newProductSku: string }> {
    const result = await db.transaction(async (tx) => {
      const [parentProduct] = await tx
        .select()
        .from(product)
        .where(eq(product.productId, configurableProductId))
        .limit(1);
      if (!parentProduct) throw new Error("Parent product not found");

      const configurableTypeRow = await tx
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(ilike(productType.productTypeName, "configurable"))
        .limit(1);
      const configurableTypeId = configurableTypeRow[0]?.productTypeId ?? null;
      if (!configurableTypeId) {
        throw new Error("Configurable product type not found in system");
      }
      if (parentProduct.productTypeId !== configurableTypeId) {
        throw new Error("Can only detach variants from configurable products");
      }

      const [variant] = await tx
        .select()
        .from(productVariant)
        .where(
          and(
            eq(productVariant.productVariantId, variantId),
            eq(productVariant.productId, configurableProductId),
          ),
        )
        .limit(1);
      if (!variant) throw new Error("Variant not found on this product");

      const allVariants = await tx
        .select({ productVariantId: productVariant.productVariantId })
        .from(productVariant)
        .where(eq(productVariant.productId, configurableProductId));
      if (allVariants.length <= 1) {
        throw new Error("Cannot detach the last variant from a product");
      }

      const simpleTypeRow = await tx
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(ilike(productType.productTypeName, "simple"))
        .limit(1);
      const simpleTypeId = simpleTypeRow[0]?.productTypeId ?? null;

      const newSku = variant.productVariantSku;
      if (!newSku || newSku.trim() === "") {
        throw new Error("Variant has no SKU");
      }
      const [existingSku] = await tx
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, newSku))
        .limit(1);
      if (existingSku) throw new Error(`Product with SKU "${newSku}" already exists`);

      const now = new Date();
      const [newProduct] = await tx
        .insert(product)
        .values({
          productSku: newSku,
          articleNumber: parentProduct.articleNumber,
          productDescription: parentProduct.productDescription,
          productColourId: parentProduct.productColourId,
          genderId: parentProduct.genderId,
          eraId: parentProduct.eraId,
          brandId: parentProduct.brandId,
          productTypeId: simpleTypeId,
          productStyle: parentProduct.productStyle,
          composition: parentProduct.composition,
          countryOfManufacture: parentProduct.countryOfManufacture,
          commodityCode: parentProduct.commodityCode,
          imageCode: parentProduct.imageCode,
          enabled: parentProduct.enabled,
          createdAt: now,
          updatedAt: now,
        })
        .returning({ productId: product.productId });

      if (!newProduct) throw new Error("Failed to create new product");

      const parentCategories = await tx
        .select({ categoryId: productCategory.categoryId })
        .from(productCategory)
        .where(eq(productCategory.productId, configurableProductId));
      for (const cat of parentCategories) {
        await tx.insert(productCategory).values({
          productId: newProduct.productId,
          categoryId: cat.categoryId,
        });
      }

      const parentTeams = await tx
        .select()
        .from(productTeamMeta)
        .where(eq(productTeamMeta.productId, configurableProductId));
      for (const team of parentTeams) {
        await tx.insert(productTeamMeta).values({
          productId: newProduct.productId,
          clubId: team.clubId,
          isPrimary: team.isPrimary,
        });
      }

      const parentStores = await tx
        .select()
        .from(productStore)
        .where(eq(productStore.productId, configurableProductId));
      for (const store of parentStores) {
        await tx.insert(productStore).values({
          productId: newProduct.productId,
          storeId: store.storeId,
        });
      }

      const parentAttrs = await tx
        .select()
        .from(productAttributeVal)
        .where(eq(productAttributeVal.productId, configurableProductId));
      for (const attr of parentAttrs) {
        await tx.insert(productAttributeVal).values({
          productId: newProduct.productId,
          attributeId: attr.attributeId,
          valueText: attr.valueText,
          valueNum: attr.valueNum,
          valueBool: attr.valueBool,
          valueJson: attr.valueJson,
        });
      }

      await tx
        .update(productVariant)
        .set({ productId: newProduct.productId, updatedAt: now })
        .where(eq(productVariant.productVariantId, variantId));

      return { newProductId: Number(newProduct.productId), newProductSku: newSku };
    });

    try {
      await this.insertSyncQueueEntry({
        productId: configurableProductId,
        productVariantId: variantId,
        operationType: "product_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for detach:", e);
    }

    return result;
  }

  async createClub(input: { name: string; country?: string | null; foundedYear?: number | null }): Promise<any> {
    const [created] = await db
      .insert(club)
      .values({
        name: input.name,
        country: input.country ?? null,
        foundedYear: input.foundedYear ?? null,
      })
      .returning();
    return created;
  }

  async getClubByName(name: string): Promise<any | null> {
    const [existing] = await db
      .select()
      .from(club)
      .where(sql`lower(${club.name}) = lower(${name})`)
      .limit(1);
    return existing ?? null;
  }

  async createGender(input: { genderName: string }): Promise<any> {
    const [created] = await db
      .insert(gender)
      .values({ genderName: input.genderName })
      .returning();
    return created;
  }

  async createBrand(input: { brandId?: number | null; brandName: string; brandGrouping?: string | null }): Promise<any> {
    let brandId = input.brandId ?? null;
    if (!brandId) {
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${brands.brandId})::int` })
        .from(brands);
      brandId = (row?.maxId ?? 0) + 1;
    }
    const [created] = await db
      .insert(brands)
      .values({
        brandId,
        brandName: input.brandName,
        brandGrouping: input.brandGrouping ?? null,
      })
      .returning();
    return created;
  }

  async createProductType(input: { productTypeId?: number | null; productTypeName: string }): Promise<any> {
    let productTypeId = input.productTypeId ?? null;
    if (!productTypeId) {
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${productType.productTypeId})::int` })
        .from(productType);
      productTypeId = (row?.maxId ?? 0) + 1;
    }
    const [created] = await db
      .insert(productType)
      .values({
        productTypeId,
        productTypeName: input.productTypeName,
      })
      .returning();
    return created;
  }

  async createCondition(input: { conditionId?: number | null; conditionName: string }): Promise<any> {
    let conditionId = input.conditionId ?? null;
    if (!conditionId) {
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${condition.conditionId})::int` })
        .from(condition);
      conditionId = (row?.maxId ?? 0) + 1;
    }
    const [created] = await db
      .insert(condition)
      .values({
        conditionId,
        conditionName: input.conditionName,
      })
      .returning();
    return created;
  }

  async createTaxClass(input: { taxClassName: string }): Promise<any> {
    const [created] = await db
      .insert(taxClass)
      .values({ taxClassName: input.taxClassName })
      .returning();
    return created;
  }

  async createProductColour(input: {
    magentoColourName?: string | null;
    magentoColourId?: string | null;
    brandId?: number | null;
    brandColourId?: number | null;
    brandColourName?: string | null;
  }): Promise<any> {
    const [created] = await db
      .insert(productColour)
      .values({
        magentoColourName: input.magentoColourName ?? null,
        magentoColourId: input.magentoColourId ?? null,
        brandId: input.brandId ?? null,
        brandColourId: input.brandColourId ?? null,
        brandColourName: input.brandColourName ?? null,
      })
      .returning();
    return created;
  }

  async createSize(input: {
    magentoSizeId?: number | null;
    magentoSizeShortName?: string | null;
    magentoSizeLongName?: string | null;
    configOptions?: string | null;
    sizingCategory?: string | null;
  }): Promise<any> {
    const [created] = await db
      .insert(productSizes)
      .values({
        magentoSizeId: input.magentoSizeId ?? null,
        magentoSizeShortName: input.magentoSizeShortName ?? null,
        magentoSizeLongName: input.magentoSizeLongName ?? null,
        configOptions: input.configOptions ?? null,
        sizingCategory: input.sizingCategory ?? null,
      })
      .returning();
    return created;
  }

  async updateBrand(input: { brandId: number; brandName: string; brandGrouping?: string | null }): Promise<any> {
    const [updated] = await db
      .update(brands)
      .set({
        brandName: input.brandName,
        brandGrouping: input.brandGrouping ?? null,
      })
      .where(eq(brands.brandId, input.brandId))
      .returning();
    return updated;
  }

  async deleteBrand(brandId: number): Promise<void> {
    await db.delete(brands).where(eq(brands.brandId, brandId));
  }

  async updateProductType(input: { productTypeId: number; productTypeName: string }): Promise<any> {
    const [updated] = await db
      .update(productType)
      .set({ productTypeName: input.productTypeName })
      .where(eq(productType.productTypeId, input.productTypeId))
      .returning();
    return updated;
  }

  async deleteProductType(productTypeId: number): Promise<void> {
    await db.delete(productType).where(eq(productType.productTypeId, productTypeId));
  }

  async updateCondition(input: { conditionId: number; conditionName: string }): Promise<any> {
    const [updated] = await db
      .update(condition)
      .set({ conditionName: input.conditionName })
      .where(eq(condition.conditionId, input.conditionId))
      .returning();
    return updated;
  }

  async deleteCondition(conditionId: number): Promise<void> {
    await db.delete(condition).where(eq(condition.conditionId, conditionId));
  }

  async updateTaxClass(input: { taxClassId: number; taxClassName: string }): Promise<any> {
    const [updated] = await db
      .update(taxClass)
      .set({ taxClassName: input.taxClassName })
      .where(eq(taxClass.taxClassId, input.taxClassId))
      .returning();
    return updated;
  }

  async deleteTaxClass(taxClassId: number): Promise<void> {
    await db.delete(taxClass).where(eq(taxClass.taxClassId, taxClassId));
  }

  async updateProductColour(input: {
    productColourId: number;
    magentoColourName?: string | null;
    magentoColourId?: string | null;
    brandId?: number | null;
    brandColourId?: number | null;
    brandColourName?: string | null;
  }): Promise<any> {
    const [updated] = await db
      .update(productColour)
      .set({
        magentoColourName: input.magentoColourName ?? null,
        magentoColourId: input.magentoColourId ?? null,
        brandId: input.brandId ?? null,
        brandColourId: input.brandColourId ?? null,
        brandColourName: input.brandColourName ?? null,
      })
      .where(eq(productColour.productColourId, input.productColourId))
      .returning();
    return updated;
  }

  async deleteProductColour(productColourId: number): Promise<void> {
    await db.delete(productColour).where(eq(productColour.productColourId, productColourId));
  }

  async updateSize(input: {
    sizeId: number;
    magentoSizeId?: number | null;
    magentoSizeShortName?: string | null;
    magentoSizeLongName?: string | null;
    configOptions?: string | null;
    sizingCategory?: string | null;
  }): Promise<any> {
    const [updated] = await db
      .update(productSizes)
      .set({
        magentoSizeId: input.magentoSizeId ?? null,
        magentoSizeShortName: input.magentoSizeShortName ?? null,
        magentoSizeLongName: input.magentoSizeLongName ?? null,
        configOptions: input.configOptions ?? null,
        sizingCategory: input.sizingCategory ?? null,
      })
      .where(eq(productSizes.sizeId, input.sizeId))
      .returning();
    return updated;
  }

  async deleteSize(sizeId: number): Promise<void> {
    await db.delete(productSizes).where(eq(productSizes.sizeId, sizeId));
  }

  async updateClub(input: { clubId: number; name: string; country?: string | null; foundedYear?: number | null }): Promise<any> {
    const [updated] = await db
      .update(club)
      .set({
        name: input.name,
        country: input.country ?? null,
        foundedYear: input.foundedYear ?? null,
      })
      .where(eq(club.clubId, input.clubId))
      .returning();
    return updated;
  }

  async deleteClub(clubId: number): Promise<void> {
    await db.delete(club).where(eq(club.clubId, clubId));
  }

  async updateGender(input: { genderId: number; genderName: string }): Promise<any> {
    const [updated] = await db
      .update(gender)
      .set({ genderName: input.genderName })
      .where(eq(gender.genderId, input.genderId))
      .returning();
    return updated;
  }

  async deleteGender(genderId: number): Promise<void> {
    await db.delete(gender).where(eq(gender.genderId, genderId));
  }

  async getClubs(limit?: number): Promise<any[]> {
    try {
      const baseQuery = db
        .select({
          clubId: club.clubId,
          name: club.name,
          country: club.country,
          foundedYear: club.foundedYear,
          productCount: sql<number>`COUNT(DISTINCT ${productTeamMeta.productId})::int`,
          variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
        })
        .from(club)
        .leftJoin(productTeamMeta, eq(productTeamMeta.clubId, club.clubId))
        .leftJoin(product, eq(product.productId, productTeamMeta.productId))
        .groupBy(club.clubId, club.name, club.country, club.foundedYear)
        .orderBy(asc(club.name));

      if (typeof limit === "number") {
        return await baseQuery.limit(limit);
      }

      return await baseQuery;
    } catch (error) {
      const baseQuery = db.select().from(club).orderBy(asc(club.name));
      if (typeof limit === "number") {
        return await baseQuery.limit(limit);
      }
      return await baseQuery;
    }
  }

  async createEra(input: { name: string; startYear: number; endYear: number }): Promise<any> {
    const [created] = await db
      .insert(era)
      .values({
        name: input.name,
        startYear: input.startYear,
        endYear: input.endYear,
      })
      .returning();
    return created;
  }

  async updateEra(input: { eraId: number; name: string; startYear: number; endYear: number }): Promise<any> {
    const [updated] = await db
      .update(era)
      .set({
        name: input.name,
        startYear: input.startYear,
        endYear: input.endYear,
      })
      .where(eq(era.eraId, input.eraId))
      .returning();
    return updated;
  }

  async deleteEra(eraId: number): Promise<void> {
    await db.delete(era).where(eq(era.eraId, eraId));
  }

  async getEras(): Promise<any[]> {
    return await db
      .select({
        eraId: era.eraId,
        name: era.name,
        startYear: era.startYear,
        endYear: era.endYear,
        productCount: sql<number>`COUNT(DISTINCT ${product.productId})::int`,
        variantCount: sql<number>`COUNT(DISTINCT CASE WHEN ${product.parentSku} IS NOT NULL THEN ${product.productId} END)::int`,
      })
      .from(era)
      .leftJoin(product, eq(product.eraId, era.eraId))
      .groupBy(era.eraId, era.name, era.startYear, era.endYear)
      .orderBy(asc(era.startYear), asc(era.endYear));
  }

  async getClubRivalries(clubId: number): Promise<{ club: Club; rivals: any[] } | null> {
    const [baseClub] = await db
      .select({
        clubId: club.clubId,
        name: club.name,
        country: club.country,
        foundedYear: club.foundedYear,
      })
      .from(club)
      .where(eq(club.clubId, clubId))
      .limit(1);

    if (!baseClub) return null;

    const rivalClub = alias(club, "rival_club");
    const rivalProductCount = sql<number>`(
      SELECT COUNT(DISTINCT ${productTeamMeta.productId})::int
      FROM ${productTeamMeta}
      WHERE ${productTeamMeta.clubId} = ${clubRivalsExpanded.rivalClubId}
    )`;

    const rivals = await db
      .select({
        clubRivalryId: clubRivalsExpanded.clubRivalryId,
        rivalClubId: clubRivalsExpanded.rivalClubId,
        rivalClubName: rivalClub.name,
        rivalryTypeId: clubRivalsExpanded.rivalryTypeId,
        rivalryTypeName: rivalryType.name,
        knownAs: clubRivalsExpanded.knownAs,
        intensity: clubRivalsExpanded.intensity,
        periodStart: clubRivalsExpanded.periodStart,
        periodEnd: clubRivalsExpanded.periodEnd,
        isPrimary: clubRivalsExpanded.isPrimary,
        notes: clubRivalsExpanded.notes,
        rivalProductCount,
      })
      .from(clubRivalsExpanded)
      .leftJoin(rivalClub, eq(clubRivalsExpanded.rivalClubId, rivalClub.clubId))
      .leftJoin(rivalryType, eq(clubRivalsExpanded.rivalryTypeId, rivalryType.rivalryTypeId))
      .where(eq(clubRivalsExpanded.clubId, clubId))
      .orderBy(asc(rivalClub.name));

    return { club: baseClub, rivals };
  }

  async updateClubRivalry(input: {
    clubRivalryId: number;
    rivalryTypeId?: number | null;
    knownAs?: string | null;
    intensity?: number | null;
    periodStart?: Date | null;
    periodEnd?: Date | null;
    isPrimary?: boolean | null;
    notes?: string | null;
  }): Promise<any | null> {
    const [updated] = await db
      .update(clubRivalry)
      .set({
        rivalryTypeId: input.rivalryTypeId ?? undefined,
        knownAs: input.knownAs ?? undefined,
        intensity: input.intensity ?? undefined,
        periodStart: input.periodStart ?? undefined,
        periodEnd: input.periodEnd ?? undefined,
        isPrimary: input.isPrimary ?? undefined,
        notes: input.notes ?? undefined,
      })
      .where(eq(clubRivalry.clubRivalryId, input.clubRivalryId))
      .returning();
    return updated ?? null;
  }

  async createClubRivalry(input: {
    clubIdA: number;
    clubIdB: number;
    rivalryTypeId: number;
    knownAs?: string | null;
    intensity?: number | null;
    periodStart?: Date | null;
    periodEnd?: Date | null;
    isPrimary?: boolean | null;
    notes?: string | null;
  }): Promise<any> {
    const [created] = await db
      .insert(clubRivalry)
      .values({
        clubIdA: input.clubIdA,
        clubIdB: input.clubIdB,
        rivalryTypeId: input.rivalryTypeId,
        knownAs: input.knownAs ?? null,
        intensity: input.intensity ?? null,
        periodStart: input.periodStart ?? null,
        periodEnd: input.periodEnd ?? null,
        isPrimary: input.isPrimary ?? null,
        notes: input.notes ?? null,
      })
      .returning();
    return created;
  }

  async getRivalryTypes(): Promise<any[]> {
    return await db.select().from(rivalryType).orderBy(asc(rivalryType.name));
  }

  async createRivalryType(input: {
    code: string;
    name: string;
    description?: string | null;
  }): Promise<any> {
    const [created] = await db
      .insert(rivalryType)
      .values({
        code: input.code,
        name: input.name,
        description: input.description ?? null,
      })
      .returning();
    return created;
  }

  async updateRivalryType(input: {
    rivalryTypeId: number;
    code: string;
    name: string;
    description?: string | null;
  }): Promise<any | null> {
    const [updated] = await db
      .update(rivalryType)
      .set({
        code: input.code,
        name: input.name,
        description: input.description ?? null,
      })
      .where(eq(rivalryType.rivalryTypeId, input.rivalryTypeId))
      .returning();
    return updated ?? null;
  }

  async getSeasons(): Promise<Season[]> {
    return await db.select().from(season).orderBy(desc(season.yearStart));
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(category).orderBy(asc(category.pathKey));
  }

  async getCategoryById(categoryId: number): Promise<Category | null> {
    const [cat] = await db
      .select()
      .from(category)
      .where(eq(category.categoryId, categoryId))
      .limit(1);
    return cat ?? null;
  }

  async getCategoryByPathKey(pathKey: string): Promise<Category | null> {
    const [cat] = await db
      .select()
      .from(category)
      .where(eq(category.pathKey, pathKey))
      .limit(1);
    return cat ?? null;
  }

  async createCategory(input: { name: string; pathKey: string; parentId?: number | null }): Promise<Category> {
    const [created] = await db
      .insert(category)
      .values({
        name: input.name,
        pathKey: input.pathKey,
        parentId: input.parentId ?? null,
      })
      .returning();
    return created;
  }

  async updateCategory(categoryId: number, input: { name?: string; parentId?: number | null }): Promise<Category | null> {
    const existing = await this.getCategoryById(categoryId);
    if (!existing) return null;
    
    const newName = input.name !== undefined ? input.name : existing.name;
    const newParentId = input.parentId !== undefined ? input.parentId : existing.parentId;
    
    let newPathKey = newName;
    if (newParentId !== null) {
      const parent = await this.getCategoryById(newParentId);
      if (parent) {
        newPathKey = `${parent.pathKey}/${newName}`;
      }
    }
    
    if (newPathKey !== existing.pathKey) {
      const existingWithPath = await this.getCategoryByPathKey(newPathKey);
      if (existingWithPath && existingWithPath.categoryId !== categoryId) {
        throw new Error("Category with this path already exists");
      }
    }
    
    const oldPathKey = existing.pathKey;
    
    const [updated] = await db
      .update(category)
      .set({ name: newName, parentId: newParentId, pathKey: newPathKey })
      .where(eq(category.categoryId, categoryId))
      .returning();
    
    if (oldPathKey !== newPathKey) {
      const descendants = await db
        .select()
        .from(category)
        .where(sql`${category.pathKey} LIKE ${oldPathKey + '/%'}`);
      
      for (const desc of descendants) {
        const updatedDescPath = desc.pathKey.replace(oldPathKey, newPathKey);
        await db
          .update(category)
          .set({ pathKey: updatedDescPath })
          .where(eq(category.categoryId, desc.categoryId));
      }
    }
    
    return updated ?? null;
  }

  async deleteCategory(categoryId: number): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.delete(productCategory).where(eq(productCategory.categoryId, categoryId));
      await tx.update(category).set({ parentId: null }).where(eq(category.parentId, categoryId));
      await tx.delete(category).where(eq(category.categoryId, categoryId));
    });
  }

  async getProductsByCategory(categoryId: number): Promise<any[]> {
    return await db
      .select({
        productId: product.productId,
        productSku: product.productSku,
        productDescription: product.productDescription,
        enabled: product.enabled,
        brandName: brands.brandName,
      })
      .from(productCategory)
      .innerJoin(product, eq(productCategory.productId, product.productId))
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .where(eq(productCategory.categoryId, categoryId))
      .orderBy(asc(product.productSku));
  }

  async getCategoriesForProduct(productId: number): Promise<Category[]> {
    return await db
      .select({
        categoryId: category.categoryId,
        parentId: category.parentId,
        name: category.name,
        pathKey: category.pathKey,
      })
      .from(productCategory)
      .innerJoin(category, eq(productCategory.categoryId, category.categoryId))
      .where(eq(productCategory.productId, productId))
      .orderBy(asc(category.pathKey));
  }

  async assignProductToCategories(productId: number, categoryIds: number[]): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.delete(productCategory).where(eq(productCategory.productId, productId));
      if (categoryIds.length > 0) {
        await tx.insert(productCategory).values(
          categoryIds.map((categoryId) => ({ productId, categoryId }))
        );
      }
    });

    try {
      await this.insertSyncQueueEntry({
        productId,
        productVariantId: null,
        operationType: "category_change",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for category assignment:", e);
    }
  }

  async getOrCreateCategoryByPath(path: string): Promise<Category> {
    const parts = path.split("/").filter(p => p.trim() !== "");
    if (parts.length === 0) throw new Error("Invalid category path");
    
    let parentId: number | null = null;
    let currentPath = "";
    let cat: Category | null = null;
    
    for (const part of parts) {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      cat = await this.getCategoryByPathKey(currentPath);
      
      if (!cat) {
        cat = await this.createCategory({
          name: part,
          pathKey: currentPath,
          parentId,
        });
      }
      parentId = cat.categoryId;
    }
    
    return cat!;
  }

  async getDepartments(): Promise<any[]> {
    return await db.select().from(department).orderBy(asc(department.name));
  }

  async getProductTeamMeta(productId: number): Promise<any[]> {
    return await db
      .select({
        productTeamMetaId: productTeamMeta.productTeamMetaId,
        productId: productTeamMeta.productId,
        clubId: productTeamMeta.clubId,
        clubName: club.name,
        competitionId: productTeamMeta.competitionId,
        competitionName: competition.name,
        seasonId: productTeamMeta.seasonId,
        seasonCode: season.code,
        departmentId: productTeamMeta.departmentId,
        departmentName: department.name,
        kitCategoryId: productTeamMeta.kitCategoryId,
        kitCategoryName: kitCategory.name,
        kitClassId: productTeamMeta.kitClassId,
        kitClassName: kitClass.name,
        isPrimary: productTeamMeta.isPrimary,
      })
      .from(productTeamMeta)
      .leftJoin(club, eq(productTeamMeta.clubId, club.clubId))
      .leftJoin(competition, eq(productTeamMeta.competitionId, competition.competitionId))
      .leftJoin(season, eq(productTeamMeta.seasonId, season.seasonId))
      .leftJoin(department, eq(productTeamMeta.departmentId, department.departmentId))
      .leftJoin(kitCategory, eq(productTeamMeta.kitCategoryId, kitCategory.kitCategoryId))
      .leftJoin(kitClass, eq(productTeamMeta.kitClassId, kitClass.kitClassId))
      .where(eq(productTeamMeta.productId, productId));
  }

  async getImportAttributeOptions(): Promise<ImportAttributeOption[]> {
    const attributeDefs = await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        label: attributeDef.label,
      })
      .from(attributeDef)
      .orderBy(asc(attributeDef.label));

    const currencies = await db
      .select({ code: currency.code, name: currency.name })
      .from(currency)
      .orderBy(asc(currency.code));

    const currencyPriceOptions: ImportAttributeOption[] = [];
    for (const cur of currencies) {
      const code = cur.code?.trim().toUpperCase();
      if (!code) continue;
      const lower = code.toLowerCase();
      const label = cur.name?.trim() || code;
      currencyPriceOptions.push({
        key: `price${code.charAt(0)}${lower.slice(1)}`,
        label: `Price ${code} (Retail)`,
        aliases: [`price${code.charAt(0)}${lower.slice(1)}`, `price_${lower}`, `price_${code}`, `retailPrice${code.charAt(0)}${lower.slice(1)}`, `retail_price_${lower}`, `retail_price_${code}`],
        source: "core",
      });
      currencyPriceOptions.push({
        key: `specialPrice${code.charAt(0)}${lower.slice(1)}`,
        label: `Special Price ${code}`,
        aliases: [`specialPrice${code.charAt(0)}${lower.slice(1)}`, `special_price_${lower}`, `special_price_${code}`, `specialRetailPrice${code.charAt(0)}${lower.slice(1)}`, `special_retail_price_${lower}`, `special_retail_price_${code}`],
        source: "core",
      });
      currencyPriceOptions.push({
        key: `costPrice${code.charAt(0)}${lower.slice(1)}`,
        label: `Cost Price ${code}`,
        aliases: [`costPrice${code.charAt(0)}${lower.slice(1)}`, `cost_price_${lower}`, `cost_price_${code}`],
        source: "core",
      });
    }

    return buildImportAttributeOptions(attributeDefs, currencyPriceOptions);
  }

  async clearStaging(batchId: string): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;
    await db.delete(importError).where(
      sql`${importError.importRowId} in (select ${importRow.importRowId} from ${importRow} where ${importRow.importJobId} = ${importJobId})`,
    );
    await db.delete(importRow).where(eq(importRow.importJobId, importJobId));
    await db.delete(importJob).where(eq(importJob.importJobId, importJobId));
  }

  async clearStagingRows(batchId: string): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;
    await db.delete(importError).where(
      sql`${importError.importRowId} in (select ${importRow.importRowId} from ${importRow} where ${importRow.importJobId} = ${importJobId})`,
    );
    await db.delete(importRow).where(eq(importRow.importJobId, importJobId));
  }

  async insertStagingRows(
    importJobId: number,
    loadedAt: Date,
    sourceBlob: string,
    rows: Array<{ data: any; status: "pending" | "invalid"; errors?: StagingErrorInput[] }>,
  ): Promise<void> {
    if (!rows.length) return;

    const fileName = sourceBlob || "listing-sheet.csv";
    const [rowOffset] = await db
      .select({ max: sql<number>`COALESCE(MAX(${importRow.rowNumber}), 0)::int` })
      .from(importRow)
      .where(eq(importRow.importJobId, importJobId));
    const startIndex = (rowOffset?.max || 0) + 1;

    const payloads = rows.map((row, index) => ({
      importJobId,
      rowNumber: startIndex + index,
      rowRaw: { data: row.data, rawData: row.data, source: fileName },
      rowStatus: row.status,
      createdAt: loadedAt,
      updatedAt: loadedAt,
    }));

    const inserted = await db.insert(importRow).values(payloads).returning({
      importRowId: importRow.importRowId,
      rowNumber: importRow.rowNumber,
    });

    const errorsToInsert: Array<{
      importRowId: number;
      fieldKey: string;
      errorCode: string;
      errorMessage: string;
      metaJson?: Record<string, any> | null;
      createdAt: Date;
    }> = [];
    rows.forEach((row, index) => {
      if (!row.errors?.length) return;
      const rowNumber = startIndex + index;
      const target = inserted.find((item) => item.rowNumber === rowNumber);
      if (!target) return;
      for (const error of row.errors) {
        errorsToInsert.push({
          importRowId: Number(target.importRowId),
          fieldKey: error.fieldKey,
          errorCode: error.errorCode,
          errorMessage: error.errorMessage,
          metaJson: error.metaJson ?? null,
          createdAt: loadedAt,
        });
      }
    });

    if (errorsToInsert.length > 0) {
      await db.insert(importError).values(errorsToInsert);
    }
  }

  async getStagingSummary(batchId: string): Promise<any> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return null;

    const [job] = await db
      .select()
      .from(importJob)
      .where(eq(importJob.importJobId, importJobId))
      .limit(1);
    if (!job) return null;

    const [totalRows] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(eq(importRow.importJobId, importJobId));

    const [invalidRows] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(
        and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "invalid")),
      );

    const [validRows] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(
        and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "pending")),
      );

    const [updatedRows] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .leftJoin(
        productV2,
        sql`${productV2.sku} = COALESCE(${importRow.rowRaw} ->> 'productVariantSku', ${importRow.rowRaw} -> 'data' ->> 'productVariantSku', ${importRow.rowRaw} ->> 'sku', ${importRow.rowRaw} -> 'data' ->> 'sku')`,
      )
      .where(
        and(
          eq(importRow.importJobId, importJobId),
          eq(importRow.rowStatus, "pending"),
          sql`${productV2.productId} is not null`,
        ),
      );

    const [newRows] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .leftJoin(
        productV2,
        sql`${productV2.sku} = COALESCE(${importRow.rowRaw} ->> 'productVariantSku', ${importRow.rowRaw} -> 'data' ->> 'productVariantSku', ${importRow.rowRaw} ->> 'sku', ${importRow.rowRaw} -> 'data' ->> 'sku')`,
      )
      .where(
        and(
          eq(importRow.importJobId, importJobId),
          eq(importRow.rowStatus, "pending"),
          sql`${productV2.productId} is null`,
        ),
      );

    const sampleRows = await db
      .select({ rowRaw: importRow.rowRaw })
      .from(importRow)
      .where(eq(importRow.importJobId, importJobId))
      .orderBy(asc(importRow.rowNumber))
      .limit(5);

    // Extract columnOrder from the first row if available
    let columnOrder: string[] = [];
    if (sampleRows.length > 0) {
      const firstRowRaw = sampleRows[0].rowRaw as any;
      const firstRowData = firstRowRaw?.data ?? firstRowRaw;
      if (firstRowData?._columnOrder && Array.isArray(firstRowData._columnOrder)) {
        columnOrder = firstRowData._columnOrder;
      }
    }

    return {
      batchId: String(importJobId),
      loadedAt: job.createdAt?.toISOString() ?? new Date().toISOString(),
      status: job.status,
      columnOrder,
      counts: {
        totalRows: totalRows?.count || 0,
        validRows: validRows?.count || 0,
        invalidRows: invalidRows?.count || 0,
        newRows: newRows?.count || 0,
        updatedRows: updatedRows?.count || 0,
      },
      sampleRows: sampleRows.map((row) => {
        const data = (row.rowRaw as any)?.data ?? row.rowRaw;
        if (data && data._imageFormat === "true") {
          const { _imageFormat, productSku, productVariantSku, ...visibleData } = data;
          return visibleData;
        }
        return data;
      }),
    };
  }

  async getStagingRows(batchId: string, limit: number, offset: number): Promise<any> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return null;

    const rows = await db
      .select({
        importRowId: importRow.importRowId,
        rowNumber: importRow.rowNumber,
        rowStatus: importRow.rowStatus,
        rowRaw: importRow.rowRaw,
      })
      .from(importRow)
      .where(eq(importRow.importJobId, importJobId))
      .orderBy(asc(importRow.rowNumber))
      .limit(limit)
      .offset(offset);

    const rowIds = rows.map((row) => row.importRowId);
    const errors = rowIds.length
      ? await db
          .select({
            importRowId: importError.importRowId,
            fieldKey: importError.fieldKey,
            errorCode: importError.errorCode,
            errorMessage: importError.errorMessage,
          })
          .from(importError)
          .where(inArray(importError.importRowId, rowIds))
      : [];

    const errorMap = new Map<number, Array<{ fieldKey: string; errorCode: string; errorMessage: string }>>();
    for (const error of errors) {
      const id = Number(error.importRowId);
      const list = errorMap.get(id) ?? [];
      list.push({
        fieldKey: error.fieldKey ?? "",
        errorCode: error.errorCode ?? "",
        errorMessage: error.errorMessage ?? "",
      });
      errorMap.set(id, list);
    }

    // Extract columnOrder from the first row if available
    let columnOrder: string[] = [];
    if (rows.length > 0) {
      const firstRowRaw = rows[0].rowRaw as any;
      const firstRowData = firstRowRaw?.data ?? firstRowRaw;
      if (firstRowData?._columnOrder && Array.isArray(firstRowData._columnOrder)) {
        columnOrder = firstRowData._columnOrder;
      }
    }

    return {
      columnOrder,
      rows: rows.map((row) => {
        let rowData = (row.rowRaw as any)?.data ?? {};
        let rawData = (row.rowRaw as any)?.rawData ?? (row.rowRaw as any)?.data ?? {};
        if (rowData && rowData._imageFormat === "true") {
          const { _imageFormat: _f1, productSku: _p1, productVariantSku: _v1, ...visibleData } = rowData;
          const { _imageFormat: _f2, productSku: _p2, productVariantSku: _v2, ...visibleRaw } = rawData;
          rowData = visibleData;
          rawData = visibleRaw;
        }
        // Remove _columnOrder from data if present (it's metadata, not user data)
        if (rowData._columnOrder) {
          const { _columnOrder, ...cleanData } = rowData;
          rowData = cleanData;
        }
        if (rawData._columnOrder) {
          const { _columnOrder, ...cleanRawData } = rawData;
          rawData = cleanRawData;
        }
        return {
          rowNumber: row.rowNumber,
          rowStatus: row.rowStatus,
          data: rowData,
          rawData: rawData,
          source: (row.rowRaw as any)?.source ?? null,
          errors: errorMap.get(Number(row.importRowId)) ?? [],
        };
      }),
    };
  }

  async applyImportColumnMapping(
    batchId: string,
    mapping: Record<string, string | null>,
  ): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;

    const mappingEntries = Object.entries(mapping ?? {});
    if (mappingEntries.length === 0) return;

    const now = new Date();
    await db.transaction(async (tx) => {
      const lockResult = await tx.execute(
        sql`select pg_try_advisory_xact_lock(${importJobId}) as locked`,
      );
      const locked = Array.isArray(lockResult)
        ? (lockResult[0] as any)?.locked
        : (lockResult as any)?.rows?.[0]?.locked;
      if (!locked) {
        throw new Error("Column mapping already in progress");
      }

      const rows = await tx
        .select({
          importRowId: importRow.importRowId,
          rowRaw: importRow.rowRaw,
        })
        .from(importRow)
        .where(eq(importRow.importJobId, importJobId));

      console.log(`[Import] applyImportColumnMapping: mapping entries:`, mappingEntries);
      for (const row of rows) {
        const existingRaw = (row.rowRaw as any) ?? {};
        const sourceData = existingRaw.rawData ?? existingRaw.data ?? {};
        
        // Start with all source data preserved (unmapped columns stay as-is)
        const mappedData: Record<string, any> = { ...sourceData };

        // Apply explicit column renames from the mapping
        for (const [sourceKey, targetKey] of mappingEntries) {
          if (!targetKey) continue;
          if (!Object.prototype.hasOwnProperty.call(sourceData, sourceKey)) continue;
          const value = (sourceData as Record<string, any>)[sourceKey];
          if (value === undefined) continue;
          // Add the mapped target key with the value
          mappedData[targetKey] = value;
        }

        console.log(`[Import] Row ${row.importRowId}: sourceData keys:`, Object.keys(sourceData).slice(0, 5));
        console.log(`[Import] Row ${row.importRowId}: mappedData:`, JSON.stringify(mappedData).slice(0, 200));
        const skuValue = mappedData.productVariantSku;
        const productSkuValue = mappedData.productSku;
        console.log(`[Import] Row ${row.importRowId}: skuValue=${skuValue}, productSkuValue=${productSkuValue}`);
        const hasSku =
          skuValue !== undefined && skuValue !== null && String(skuValue).trim() !== "";
        const hasProductSku =
          productSkuValue !== undefined &&
          productSkuValue !== null &&
          String(productSkuValue).trim() !== "";
        const rowStatus = hasSku || hasProductSku ? "pending" : "invalid";

        await tx
          .update(importRow)
          .set({
            rowRaw: { ...existingRaw, data: mappedData, rawData: sourceData },
            rowStatus,
            updatedAt: now,
          })
          .where(eq(importRow.importRowId, row.importRowId));

        await tx.delete(importError).where(eq(importError.importRowId, row.importRowId));

        if (!hasSku && !hasProductSku) {
          await tx.insert(importError).values({
            importRowId: row.importRowId,
            fieldKey: "productVariantSku",
            errorCode: "required",
            errorMessage: "product_variant_sku or product_sku is required",
            createdAt: now,
          });
        }
      }
    });
  }

  async updateStagingRow(batchId: string, rowNumber: number, data: any, rawData?: any): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;

    const [row] = await db
      .select({
        importRowId: importRow.importRowId,
        rowRaw: importRow.rowRaw,
      })
      .from(importRow)
      .where(and(eq(importRow.importJobId, importJobId), eq(importRow.rowNumber, rowNumber)))
      .limit(1);
    if (!row) return;

    const existingRaw = (row.rowRaw as any) ?? {};
    const updatedRaw = { ...existingRaw, data };
    if (rawData !== undefined) {
      updatedRaw.rawData = rawData;
    }
    const skuValue = data?.productVariantSku;
    const productSkuValue = data?.productSku;
    const hasSku = skuValue !== undefined && skuValue !== null && String(skuValue).trim() !== "";
    const hasProductSku =
      productSkuValue !== undefined &&
      productSkuValue !== null &&
      String(productSkuValue).trim() !== "";
    const rowStatus = hasSku || hasProductSku ? "pending" : "invalid";

    await db
      .update(importRow)
      .set({
        rowRaw: updatedRaw,
        rowStatus,
        updatedAt: new Date(),
      })
      .where(eq(importRow.importRowId, row.importRowId));

    await db.delete(importError).where(eq(importError.importRowId, row.importRowId));

    if (!hasSku && !hasProductSku) {
      await db.insert(importError).values({
        importRowId: row.importRowId,
        fieldKey: "productVariantSku",
        errorCode: "required",
        errorMessage: "product_variant_sku or product_sku is required",
        createdAt: new Date(),
      });
    }
  }

  async setImportJobStatus(batchId: string, status: string): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;
    await db
      .update(importJob)
      .set({ status, updatedAt: new Date() })
      .where(eq(importJob.importJobId, importJobId));
  }

  async confirmImport(batchId: string): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;

    // Count valid (pending) and invalid rows
    const [validCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "pending")));
    
    const [invalidCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "invalid")));

    await db
      .update(importJob)
      .set({
        status: "validated",
        validRows: validCount?.count ?? 0,
        invalidRows: invalidCount?.count ?? 0,
        updatedAt: new Date(),
      })
      .where(eq(importJob.importJobId, importJobId));
  }

  async processImport(batchId: string): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;

    try {
    const attributeDefs = await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        dataType: attributeDef.dataType,
        label: attributeDef.label,
      })
      .from(attributeDef);
    const attributeDefMap = new Map<string, typeof attributeDefs[number] & { attributeId: number }>();
    const attributeDefRawMap = new Map<string, typeof attributeDefs[number] & { attributeId: number }>();
    const attributeDefById = new Map<number, typeof attributeDefs[number] & { attributeId: number }>();
    for (const def of attributeDefs) {
      const normalizedCode = def.code ? normalizeAttributeCode(def.code) : "";
      const normalizedKey = normalizedCode ? normalizedCode.toLowerCase() : "";
      if (!normalizedKey) continue;
      const normalizedDef = {
        ...def,
        attributeId: Number(def.attributeId),
        code: normalizedCode,
      };
      attributeDefMap.set(normalizedKey, normalizedDef);
      attributeDefRawMap.set(def.code?.trim().toLowerCase() ?? normalizedKey, normalizedDef);
      attributeDefById.set(Number(def.attributeId), normalizedDef);
    }

    const rows = await db
      .select({
        importRowId: importRow.importRowId,
        rowNumber: importRow.rowNumber,
        rowStatus: importRow.rowStatus,
        rowRaw: importRow.rowRaw,
      })
      .from(importRow)
      .where(
        and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "pending")),
      )
      .orderBy(asc(importRow.rowNumber));

    let appliedRows = 0;
    let errorRows = 0;
    const now = new Date();
    
    // Count validation-phase invalid rows directly from the database
    const [invalidRowCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(and(eq(importRow.importJobId, importJobId), eq(importRow.rowStatus, "invalid")));
    const validationInvalidRows = invalidRowCount?.count ?? 0;

    const resolveGenderId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const [existing] = await db
        .select({ genderId: gender.genderId })
        .from(gender)
        .where(eq(gender.genderName, String(value).trim()))
        .limit(1);
      if (existing) return Number(existing.genderId);
      const [created] = await db
        .insert(gender)
        .values({ genderName: String(value).trim() })
        .returning({ genderId: gender.genderId });
      return created ? Number(created.genderId) : null;
    };

    const PRODUCT_STYLE_ID_TO_NAME: Record<number, string> = {
      1: "Home",
      2: "Away",
      3: "Third",
      4: "Training",
      5: "Goalkeeper",
      6: "Special",
      7: "Retro",
      8: "Classic",
      9: "Replica",
      10: "Authentic",
    };

    const PRODUCT_STYLE_VALID_NAMES = new Set(
      Object.values(PRODUCT_STYLE_ID_TO_NAME).map(n => n.toLowerCase())
    );

    const resolveProductStyle = (value: any): string | null => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        const name = PRODUCT_STYLE_ID_TO_NAME[Number(value)];
        return name ?? null;
      }
      const trimmed = String(value).trim();
      if (PRODUCT_STYLE_VALID_NAMES.has(trimmed.toLowerCase())) {
        const entry = Object.values(PRODUCT_STYLE_ID_TO_NAME).find(
          n => n.toLowerCase() === trimmed.toLowerCase()
        );
        return entry ?? trimmed;
      }
      return trimmed;
    };

    const resolveEraId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ eraId: era.eraId })
        .from(era)
        .where(sql`lower(${era.name}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.eraId);
      return null;
    };

    const resolveBrandId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ brandId: brands.brandId })
        .from(brands)
        .where(sql`lower(${brands.brandName}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.brandId);
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${brands.brandId})::int` })
        .from(brands);
      const nextId = (row?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(brands)
        .values({ brandId: nextId, brandName: trimmed })
        .returning({ brandId: brands.brandId });
      return created ? Number(created.brandId) : null;
    };

    const resolveProductTypeId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(sql`lower(${productType.productTypeName}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.productTypeId);
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${productType.productTypeId})::int` })
        .from(productType);
      const nextId = (row?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(productType)
        .values({ productTypeId: nextId, productTypeName: trimmed })
        .returning({ productTypeId: productType.productTypeId });
      return created ? Number(created.productTypeId) : null;
    };

    const resolveClubId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ clubId: club.clubId })
        .from(club)
        .where(sql`lower(${club.name}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.clubId);
      const [created] = await db
        .insert(club)
        .values({ name: trimmed })
        .returning({ clubId: club.clubId });
      return created ? Number(created.clubId) : null;
    };

    const resolveConditionId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ conditionId: condition.conditionId })
        .from(condition)
        .where(sql`lower(${condition.conditionName}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.conditionId);
      // Auto-create condition if not found
      const [maxRow] = await db
        .select({ maxId: sql<number>`MAX(${condition.conditionId})::int` })
        .from(condition);
      const nextId = (maxRow?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(condition)
        .values({ conditionId: nextId, conditionName: trimmed })
        .returning({ conditionId: condition.conditionId });
      return created ? Number(created.conditionId) : null;
    };

    const resolveSeasonId = async (value: any): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ seasonId: season.seasonId })
        .from(season)
        .where(sql`lower(${season.code}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.seasonId);
      // Auto-create season from code (e.g. "2005-06")
      const yearMatch = trimmed.match(/^(\d{4})[-/](\d{2,4})$/);
      const yearStart = yearMatch ? Number(yearMatch[1]) : null;
      const yearEnd = yearMatch
        ? (yearMatch[2].length === 2 ? Number(yearMatch[1].substring(0, 2) + yearMatch[2]) : Number(yearMatch[2]))
        : null;
      const [created] = await db
        .insert(season)
        .values({ code: trimmed, yearStart, yearEnd })
        .returning({ seasonId: season.seasonId });
      return created ? Number(created.seasonId) : null;
    };

    const resolveStoreIds = async (value: any): Promise<number[]> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return [];
      }
      const codes = String(value)
        .split(",")
        .map((c) => c.trim())
        .filter((c) => c.length > 0);
      if (codes.length === 0) return [];
      
      const storeIds: number[] = [];
      for (const code of codes) {
        const [existing] = await db
          .select({ storeId: store.storeId })
          .from(store)
          .where(sql`lower(${store.code}) = lower(${code})`)
          .limit(1);
        if (existing) {
          storeIds.push(Number(existing.storeId));
        } else {
          console.log(`[Import] Store code "${code}" not found - skipping`);
        }
      }
      return storeIds;
    };

    const resolveCurrencyId = async (code: string): Promise<number | null> => {
      if (!code || code.trim() === "") return null;
      const trimmed = code.trim().toUpperCase();
      const [existing] = await db
        .select({ currencyId: currency.currencyId })
        .from(currency)
        .where(sql`upper(${currency.code}) = ${trimmed}`)
        .limit(1);
      return existing ? Number(existing.currencyId) : null;
    };

    // Store lookup cache for store-scoped imports (e.g. US sheet)
    const storeCache = new Map<string, { storeId: number; defaultCurrencyCode: string | null }>();
    const resolveStoreByViewCode = async (viewCode: string): Promise<{ storeId: number; defaultCurrencyCode: string | null } | null> => {
      const trimmed = viewCode.trim().toUpperCase();
      if (storeCache.has(trimmed)) return storeCache.get(trimmed)!;
      const [storeRow] = await db
        .select({ storeId: store.storeId, code: store.code })
        .from(store)
        .where(sql`upper(${store.code}) = ${trimmed}`)
        .limit(1);
      if (!storeRow) return null;
      // Find the default currency for this store
      const [sc] = await db
        .select({ currencyCode: currency.code })
        .from(storeCurrency)
        .innerJoin(currency, eq(storeCurrency.currencyId, currency.currencyId))
        .where(and(eq(storeCurrency.storeId, storeRow.storeId), eq(storeCurrency.isDefault, true)))
        .limit(1);
      const result = { storeId: Number(storeRow.storeId), defaultCurrencyCode: sc?.currencyCode ?? null };
      storeCache.set(trimmed, result);
      return result;
    };

    // Raw SQL upsert for store-scoped EAV attributes (uses COALESCE unique index)
    const upsertProductAttributeVal = async (
      productId: number,
      attributeId: number,
      storeId: number | null,
      values: { valueText?: string | null; valueNum?: string | number | null; valueBool?: boolean | null; valueJson?: any },
    ) => {
      const numStr = values.valueNum != null ? String(values.valueNum) : null;
      const pool = (db as any)._.session?.client;
      if (pool) {
        await pool.query(
          `INSERT INTO pim.product_attribute_val (product_id, attribute_id, store_id, value_text, value_num, value_bool, value_json)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (product_id, attribute_id, COALESCE(store_id, 0))
           DO UPDATE SET value_text = $4, value_num = $5, value_bool = $6, value_json = $7`,
          [
            productId,
            attributeId,
            storeId,
            values.valueText ?? null,
            values.valueNum ?? null,
            values.valueBool ?? null,
            values.valueJson ? JSON.stringify(values.valueJson) : null,
          ],
        );
      } else {
        // Fallback: delete + insert
        const storeCondition = storeId !== null
          ? eq(productAttributeValV2.storeId, storeId)
          : isNull(productAttributeValV2.storeId);
        await db.delete(productAttributeValV2).where(
          and(
            eq(productAttributeValV2.productId, productId),
            eq(productAttributeValV2.attributeId, attributeId),
            storeCondition,
          ),
        );
        await db.insert(productAttributeValV2).values({
          productId,
          attributeId,
          storeId,
          valueText: values.valueText ?? null,
          valueNum: values.valueNum != null ? String(values.valueNum) : null,
          valueBool: values.valueBool ?? null,
          valueJson: values.valueJson ?? null,
        });
      }
    };

    // Columns that should be stored as store-scoped EAV when storeViewCode is present
    const STORE_SCOPED_ATTR_CODES = new Set(["meta_description", "url_key", "tax_class_name"]);

    const extractCurrencyPrices = (data: Record<string, any>): Array<{
      currencyCode: string;
      retailPrice: string | null;
      specialRetailPrice: string | null;
      costPrice: string | null;
    }> => {
      const foundCurrencies = new Map<string, {
        retailPrice: string | null;
        specialRetailPrice: string | null;
        costPrice: string | null;
      }>();

      const priceRegex = /^(price|retailPrice|retail_price|specialPrice|costPrice|special_price|cost_price|specialRetailPrice|special_retail_price)[-_]?([a-zA-Z]{3})$/i;

      // Handle bare "price" and "cost" columns as GBP (default currency for DATA rows)
      const barePrice = data.price ?? data.Price;
      const bareCost = data.cost ?? data.Cost ?? data.costPrice ?? data.cost_price;
      if (barePrice !== undefined && barePrice !== null && String(barePrice).trim() !== "") {
        const trimmedVal = String(barePrice).trim();
        if (trimmedVal !== "__EMPTY__VALUE__" && !isNaN(Number(trimmedVal))) {
          if (!foundCurrencies.has("GBP")) {
            foundCurrencies.set("GBP", { retailPrice: null, specialRetailPrice: null, costPrice: null });
          }
          foundCurrencies.get("GBP")!.retailPrice = trimmedVal;
        }
      }
      if (bareCost !== undefined && bareCost !== null && String(bareCost).trim() !== "") {
        const trimmedVal = String(bareCost).trim();
        if (trimmedVal !== "__EMPTY__VALUE__" && !isNaN(Number(trimmedVal))) {
          if (!foundCurrencies.has("GBP")) {
            foundCurrencies.set("GBP", { retailPrice: null, specialRetailPrice: null, costPrice: null });
          }
          foundCurrencies.get("GBP")!.costPrice = trimmedVal;
        }
      }

      for (const [key, val] of Object.entries(data)) {
        if (val === undefined || val === null || String(val).trim() === "") continue;
        // Skip bare price/cost — already handled above
        if (key === "price" || key === "Price" || key === "cost" || key === "Cost") continue;
        const match = key.match(priceRegex);
        if (!match) continue;
        const prefix = match[1].toLowerCase().replace(/_/g, "");
        const code = match[2].toUpperCase();
        if (!foundCurrencies.has(code)) {
          foundCurrencies.set(code, { retailPrice: null, specialRetailPrice: null, costPrice: null });
        }
        const entry = foundCurrencies.get(code)!;
        const trimmedVal = String(val).trim();
        if (trimmedVal === "" || trimmedVal === "__EMPTY__VALUE__" || isNaN(Number(trimmedVal))) continue;
        if (prefix === "price" || prefix === "retailprice") {
          entry.retailPrice = trimmedVal;
        } else if (prefix === "specialprice" || prefix === "specialretailprice") {
          entry.specialRetailPrice = trimmedVal;
        } else if (prefix === "costprice") {
          entry.costPrice = trimmedVal;
        }
      }

      return Array.from(foundCurrencies.entries()).map(([code, prices]) => ({
        currencyCode: code,
        ...prices,
      }));
    };

    const resolveProductColourId = async (value: any, brandId?: number | null): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const nameMatch = sql`lower(${productColour.magentoColourName}) = lower(${trimmed})`;
      const brandMatch =
        brandId !== null && brandId !== undefined
          ? sql`${productColour.brandId} = ${brandId}`
          : undefined;
      const [existing] = await db
        .select({ productColourId: productColour.productColourId })
        .from(productColour)
        .where(brandMatch ? and(nameMatch, brandMatch) : nameMatch)
        .limit(1);
      if (existing) return Number(existing.productColourId);
      let brandColourId: number | null = null;
      if (brandId !== null && brandId !== undefined) {
        const [row] = await db
          .select({ maxId: sql<number>`MAX(${productColour.brandColourId})::int` })
          .from(productColour)
          .where(eq(productColour.brandId, brandId));
        brandColourId = (row?.maxId ?? 0) + 1;
      }
      const [created] = await db
        .insert(productColour)
        .values({
          magentoColourName: trimmed,
          brandId: brandId ?? null,
          brandColourId,
        })
        .returning({ productColourId: productColour.productColourId });
      return created ? Number(created.productColourId) : null;
    };

    const resolveSizeId = async (
      value: any,
      sizeNames: { shortName?: string | null; longName?: string | null },
    ): Promise<number | null> => {
      if (value === null || value === undefined || String(value).trim() === "") {
        return null;
      }

      const raw = String(value).trim();
      const numeric = /^\d+$/.test(raw) ? Number(raw) : null;

      if (numeric !== null) {
        const [existingById] = await db
          .select({ sizeId: productSizes.sizeId })
          .from(productSizes)
          .where(eq(productSizes.sizeId, numeric))
          .limit(1);
        if (existingById) return Number(existingById.sizeId);

        const [existingByMagento] = await db
          .select({ sizeId: productSizes.sizeId })
          .from(productSizes)
          .where(eq(productSizes.magentoSizeId, numeric))
          .limit(1);
        if (existingByMagento) return Number(existingByMagento.sizeId);

        const [created] = await db
          .insert(productSizes)
          .values({
            magentoSizeId: numeric,
            magentoSizeShortName: sizeNames.shortName ?? null,
            magentoSizeLongName: sizeNames.longName ?? null,
          })
          .returning({ sizeId: productSizes.sizeId });
        return created ? Number(created.sizeId) : null;
      }

      const trimmed = raw;
      const [existingByName] = await db
        .select({ sizeId: productSizes.sizeId })
        .from(productSizes)
        .where(
          or(
            sql`lower(${productSizes.magentoSizeShortName}) = lower(${trimmed})`,
            sql`lower(${productSizes.magentoSizeLongName}) = lower(${trimmed})`,
          ),
        )
        .limit(1);
      if (existingByName) return Number(existingByName.sizeId);

      const [created] = await db
        .insert(productSizes)
        .values({
          magentoSizeShortName: sizeNames.shortName ?? trimmed,
          magentoSizeLongName: sizeNames.longName ?? trimmed,
        })
        .returning({ sizeId: productSizes.sizeId });
      return created ? Number(created.sizeId) : null;
    };

    const resolveAttributeDef = async (
      rawKey: string,
      label: string,
      inferredDataType: "text" | "number" | "boolean" | "json",
    ): Promise<{ attributeId: number; dataType: string | null } | null> => {
      const normalizedKey = normalizeAttributeCode(rawKey).toLowerCase();
      const rawLookup = rawKey.trim().toLowerCase();
      const existing =
        attributeDefMap.get(normalizedKey) ?? attributeDefRawMap.get(rawLookup);
      if (!existing) {
        console.log(`[Import] resolveAttributeDef: No match found for rawKey="${rawKey}", normalizedKey="${normalizedKey}", rawLookup="${rawLookup}"`);
        console.log(`[Import] attributeDefMap keys sample:`, Array.from(attributeDefMap.keys()).slice(0, 10));
        console.log(`[Import] attributeDefRawMap keys sample:`, Array.from(attributeDefRawMap.keys()).slice(0, 10));
        return null;
      }
      console.log(`[Import] resolveAttributeDef: Found match for rawKey="${rawKey}" -> attributeId=${existing.attributeId}`);
      if (!existing.dataType || !existing.label) {
        const nextDataType = existing.dataType ?? inferredDataType;
        const nextLabel = existing.label ?? label;
        await db
          .update(attributeDef)
          .set({ dataType: nextDataType, label: nextLabel })
          .where(eq(attributeDef.attributeId, existing.attributeId));
        const updated = { ...existing, dataType: nextDataType, label: nextLabel };
        attributeDefMap.set(normalizedKey, updated);
        attributeDefRawMap.set(rawLookup || normalizedKey, updated);
        return updated;
      }
      return existing;
    };

    // Track image sort orders assigned during this import run (per product)
    const importImageSortOrders = new Map<number, Set<number>>();

    for (const row of rows) {
      const currentRowId = Number(row.importRowId);
      
      try {
      const data = (row.rowRaw as any)?.data ?? {};

      if (data._imageFormat === "true") {
        const imgSku = data.sku || data.productSku || data.productVariantSku || "";
        const trimmedImgSku = String(imgSku).trim();
        if (!trimmedImgSku) {
          await db.update(importRow).set({ rowStatus: "applied", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          importProgressTracker.addEntry(batchId, { sku: `Row ${row.rowNumber}`, status: "success", message: "Skipped - no SKU", timestamp: Date.now() });
          continue;
        }

        const [imgProduct] = await db.select({ productId: product.productId }).from(product).where(eq(product.productSku, trimmedImgSku)).limit(1);
        let imgProductId: number | null = imgProduct ? Number(imgProduct.productId) : null;

        if (!imgProductId) {
          const [imgVariant] = await db.select({ productId: productVariant.productId }).from(productVariant).where(eq(productVariant.productVariantSku, trimmedImgSku)).limit(1);
          if (imgVariant?.productId) imgProductId = Number(imgVariant.productId);
        }

        if (!imgProductId) {
          await db.update(importRow).set({ rowStatus: "applied", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          importProgressTracker.addEntry(batchId, { sku: trimmedImgSku, status: "success", message: "Skipped - product not found for image import", timestamp: Date.now() });
          continue;
        }

        const imgRoleMappings: Array<{ key: string; role: string }> = [
          { key: "baseImage", role: "base" },
          { key: "smallImage", role: "small" },
          { key: "thumbnailImage", role: "thumbnail" },
        ];
        const imgLabel = (data.label || data.Label || data.image_label || data.imageLabel || "").toString().trim() || null;
        const imageEntries: Array<{ url: string; role: string; label: string | null }> = [];
        for (const { key, role } of imgRoleMappings) {
          const url = data[key];
          if (url && String(url).trim()) {
            imageEntries.push({ url: String(url).trim(), role, label: imgLabel });
          }
        }
        const additionalRaw = data.additionalImages;
        if (additionalRaw && String(additionalRaw).trim()) {
          const additionalUrls = String(additionalRaw).split(",").map((u: string) => u.trim()).filter(Boolean);
          for (const url of additionalUrls) {
            imageEntries.push({ url, role: "additional", label: imgLabel });
          }
        }

        for (const entry of imageEntries) {
          const existingImages = await db.select({ sortOrder: imageAsset.sortOrder }).from(imageAsset).where(eq(imageAsset.productId, imgProductId)).orderBy(asc(imageAsset.sortOrder));
          const dbOrders = new Set(existingImages.map(img => img.sortOrder ?? 0));
          const importOrders = importImageSortOrders.get(imgProductId) ?? new Set<number>();
          const allAssignedOrders = new Set([...dbOrders, ...importOrders]);
          let validSortOrder = 1;
          while (allAssignedOrders.has(validSortOrder)) validSortOrder++;
          if (!importImageSortOrders.has(imgProductId)) importImageSortOrders.set(imgProductId, new Set());
          importImageSortOrders.get(imgProductId)!.add(validSortOrder);

          const [existingImage] = await db.select({ imageId: imageAsset.imageId }).from(imageAsset).where(and(eq(imageAsset.productId, imgProductId), eq(imageAsset.url, entry.url), eq(imageAsset.role, entry.role))).limit(1);
          if (existingImage) {
            await db.update(imageAsset).set({ sortOrder: validSortOrder, label: entry.label }).where(eq(imageAsset.imageId, existingImage.imageId));
          } else {
            await db.insert(imageAsset).values({ productId: imgProductId, url: entry.url, role: entry.role, label: entry.label, sortOrder: validSortOrder });
          }
        }

        const [imgProductSync] = await db.select({ sync: product.sync }).from(product).where(eq(product.productId, imgProductId)).limit(1);
        if (imgProductSync?.sync) {
          try {
            await this.insertSyncQueueEntry({
              productId: Number(imgProductId),
              productVariantId: null,
              operationType: "image_update",
            });
          } catch (e) {
            console.error("Failed to insert sync queue entry for image import:", e);
          }
        }

        await db.update(importRow).set({ rowStatus: "applied", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
        appliedRows += 1;
        importProgressTracker.addEntry(batchId, { sku: trimmedImgSku, status: "success", message: `${imageEntries.length} image(s) applied`, timestamp: Date.now() });
        continue;
      }

      const lowerKeyMap = new Map<string, any>(
        Object.entries(data).map(([key, value]) => [key.toLowerCase(), value]),
      );
      const getDataValue = (keys: string[]): any => {
        for (const key of keys) {
          if (key in data) return data[key];
          const lowerFirst = key ? key.charAt(0).toLowerCase() + key.slice(1) : key;
          if (lowerFirst && lowerFirst in data) return data[lowerFirst];
          const lowerKey = key.toLowerCase();
          if (lowerKeyMap.has(lowerKey)) return lowerKeyMap.get(lowerKey);
        }
        return null;
      };
      const sku = data.productVariantSku;
      const productSku = data.productSku;
      const hasVariantSku = sku !== undefined && sku !== null && String(sku).trim() !== "";
      const hasProductSku =
        productSku !== undefined && productSku !== null && String(productSku).trim() !== "";

      // ── Store-scoped override row (e.g. US sheet) ──────────────────
      const storeViewCodeValue = getDataValue(["storeViewCode", "store_view_code"]);
      if (storeViewCodeValue && String(storeViewCodeValue).trim() !== "") {
        const storeInfo = await resolveStoreByViewCode(String(storeViewCodeValue));
        if (!storeInfo) {
          console.log(`[Import] Store-scoped row skipped: unknown store_view_code="${storeViewCodeValue}"`);
          await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          importProgressTracker.addEntry(batchId, { sku: String(productSku || sku || ""), status: "error", message: `Unknown store view code: ${storeViewCodeValue}`, timestamp: Date.now() });
          continue;
        }

        // Resolve the product by SKU
        const lookupSku = String(productSku || sku || "").trim();
        if (!lookupSku) {
          await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          importProgressTracker.addEntry(batchId, { sku: "", status: "error", message: "SKU is required for store-scoped override rows", timestamp: Date.now() });
          continue;
        }

        const [existingProduct] = await db
          .select({ productId: product.productId })
          .from(product)
          .where(eq(product.productSku, lookupSku))
          .limit(1);

        if (!existingProduct) {
          console.log(`[Import] Store-scoped row skipped: product not found for SKU="${lookupSku}"`);
          await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          importProgressTracker.addEntry(batchId, { sku: lookupSku, status: "error", message: `Product not found for SKU: ${lookupSku}. Import the DATA sheet first.`, timestamp: Date.now() });
          continue;
        }

        const storeProductId = Number(existingProduct.productId);
        const { storeId, defaultCurrencyCode } = storeInfo;

        // 1. Store-scoped EAV attributes (meta_description, url_key, tax_class_name)
        const storeScopedFields: Array<{ code: string; keys: string[] }> = [
          { code: "meta_description", keys: ["metaDescription", "meta_description"] },
          { code: "url_key", keys: ["urlKey", "url_key"] },
          { code: "tax_class_name", keys: ["taxClassName", "tax_class_name"] },
        ];
        for (const field of storeScopedFields) {
          const value = getDataValue(field.keys);
          if (value === null || value === undefined || String(value).trim() === "") continue;
          const attrDef = attributeDefMap.get(field.code) ?? attributeDefRawMap.get(field.code);
          if (!attrDef) {
            console.log(`[Import] Store-scoped attribute "${field.code}" skipped: no attribute_def found`);
            continue;
          }
          console.log(`[Import] Setting store-scoped attribute: product=${storeProductId}, attr=${field.code}, store=${storeId}, value="${value}"`);
          await upsertProductAttributeVal(storeProductId, attrDef.attributeId, storeId, {
            valueText: String(value).trim(),
          });
        }

        // 2. Store-scoped prices (price → retailPrice, cost → costPrice in the store's default currency)
        const priceValue = getDataValue(["price"]);
        const costValue = getDataValue(["cost"]);
        if ((priceValue || costValue) && defaultCurrencyCode) {
          const currencyId = await resolveCurrencyId(defaultCurrencyCode);
          if (currencyId) {
            // Find the variant for this product (Classic = simple, so variant SKU = product SKU)
            const [variantRow] = await db
              .select({ productVariantId: productVariant.productVariantId })
              .from(productVariant)
              .where(eq(productVariant.productId, storeProductId))
              .limit(1);
            if (variantRow) {
              const retailStr = priceValue != null && String(priceValue).trim() !== "" ? String(priceValue).trim() : null;
              const costStr = costValue != null && String(costValue).trim() !== "" ? String(costValue).trim() : null;
              console.log(`[Import] Setting store-currency price: variant=${variantRow.productVariantId}, currency=${defaultCurrencyCode}, retail=${retailStr}, cost=${costStr}`);
              await this.upsertVariantPrice({
                productVariantId: Number(variantRow.productVariantId),
                currencyId,
                retailPrice: retailStr,
                costPrice: costStr,
                isManualOverride: true,
              });
            } else {
              console.log(`[Import] Store-scoped price skipped: no variant found for product ${storeProductId}`);
            }
          } else {
            console.log(`[Import] Store-scoped price skipped: currency "${defaultCurrencyCode}" not found`);
          }
        }

        // 3. Also process any remaining attributes as store-scoped EAV
        for (const [key, value] of Object.entries(data)) {
          const canonicalKey = key ? key.charAt(0).toLowerCase() + key.slice(1) : key;
          if (shouldIgnoreAsAttribute(canonicalKey)) continue;
          if (PRODUCT_FIELDS.has(canonicalKey) || PRODUCT_VARIANT_FIELDS.has(canonicalKey)) continue;
          const normalizedKey = normalizeAttributeCode(canonicalKey);
          if (!normalizedKey) continue;
          // Skip the ones we already handled above
          if (STORE_SCOPED_ATTR_CODES.has(normalizedKey.toLowerCase())) continue;

          const attrDef = attributeDefMap.get(normalizedKey.toLowerCase()) ?? attributeDefRawMap.get(normalizedKey.toLowerCase());
          if (!attrDef) continue;
          const inferred = inferAttributeValue(value);
          if (!inferred) continue;
          console.log(`[Import] Setting store-scoped EAV: product=${storeProductId}, attr=${normalizedKey}, store=${storeId}`);
          await upsertProductAttributeVal(storeProductId, attrDef.attributeId, storeId, inferred);
        }

        await db.update(importRow).set({ rowStatus: "applied", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
        appliedRows += 1;
        importProgressTracker.addEntry(batchId, { sku: lookupSku, status: "success", message: `Store-scoped overrides applied (store: ${storeViewCodeValue})`, timestamp: Date.now() });
        continue;
      }
      // ── End store-scoped override handling ──────────────────────────

      const genderValue = getDataValue(["gender", "genderName"]);
      const resolvedGenderId = data.genderId ?? (await resolveGenderId(genderValue));

      const eraValue = getDataValue(["era", "eraName", "eraId"]);
      console.log(`[Import] Era lookup: eraValue="${eraValue}", data.eraId=${data.eraId}`);
      const resolvedEraId = data.eraId ?? (await resolveEraId(eraValue));
      console.log(`[Import] Era resolved: resolvedEraId=${resolvedEraId}`);

      const productStyleValue = getDataValue(["productStyle", "productStyleName"]);
      const resolvedProductStyle = resolveProductStyle(productStyleValue);

      const productData: Record<string, any> = {};
      const variantData: Record<string, any> = {};
      const attributeValues = new Map<string, { rawKey: string; value: any }>();

      const FIELD_ALIAS_MAP: Record<string, string> = {
        "brandN": "brandName",
        "teams": "clubName",
        "sizeProduct": "sizeName",
        "commodityComposition": "composition",
        "countryofmanufacturer": "countryOfManufacture",
      };

      for (const [key, value] of Object.entries(data)) {
        let canonicalKey = key ? key.charAt(0).toLowerCase() + key.slice(1) : key;
        canonicalKey = FIELD_ALIAS_MAP[canonicalKey] || canonicalKey;
        if (PRODUCT_FIELDS.has(canonicalKey)) productData[canonicalKey] = value;
        if (PRODUCT_VARIANT_FIELDS.has(canonicalKey)) variantData[canonicalKey] = value;
        if (!shouldIgnoreAsAttribute(canonicalKey)) {
          const normalizedKey = normalizeAttributeCode(canonicalKey);
          if (normalizedKey) {
            console.log(`[Import] Collecting attribute from data: key="${key}", canonicalKey="${canonicalKey}", normalizedKey="${normalizedKey.toLowerCase()}"`);
            attributeValues.set(normalizedKey.toLowerCase(), { rawKey: canonicalKey, value });
          }
        }
      }

      const additionalAttributes = parseAdditionalAttributes(data.additionalAttributes);
      for (const [key, value] of Object.entries(additionalAttributes)) {
        const normalizedKey = normalizeAttributeCode(key);
        const normalizedKeyLower = normalizedKey ? normalizedKey.toLowerCase() : "";
        if (
          !normalizedKeyLower ||
          attributeValues.has(normalizedKeyLower) ||
          shouldIgnoreAsAttribute(normalizedKey)
        ) {
          continue;
        }
        attributeValues.set(normalizedKeyLower, { rawKey: key, value });
      }

      const brandValue = getDataValue(["brandName", "brand", "brandN"]);
      const parsedBrandId = normalizeNumberValue(data.brandId, true);
      const resolvedBrandId = parsedBrandId ?? (await resolveBrandId(brandValue));

      const colourValue = getDataValue([
        "productColourName",
        "productColour",
        "colour",
        "color",
      ]);
      const parsedColourId = normalizeNumberValue(data.productColourId, true);
      const resolvedProductColourId =
        parsedColourId ?? (await resolveProductColourId(colourValue, resolvedBrandId));
      const productTypeNameValue = getDataValue(["productTypeName"]);
      const productTypeValue = getDataValue(["productType"]);
      const parsedProductTypeId = normalizeNumberValue(data.productTypeId, true);
      const resolvedProductTypeId =
        parsedProductTypeId ?? (await resolveProductTypeId(productTypeNameValue ?? productTypeValue));

      const sizeValue = getDataValue(["size", "sizeName", "sizeShortName", "sizeLongName", "sizeProduct"]);
      const parsedSizeId = normalizeNumberValue(data.sizeId, true);
      const parsedMagentoSizeId = normalizeNumberValue(data.magentoSizeId, true);
      const resolvedSizeId = await resolveSizeId(
        parsedSizeId ?? parsedMagentoSizeId ?? sizeValue,
        {
          shortName: getDataValue(["sizeShortName"]),
          longName: getDataValue(["sizeLongName", "sizeName", "size"]),
        },
      );

      const clubValue = getDataValue(["clubName", "club", "team", "teamName", "teams"]);
      const resolvedClubId = await resolveClubId(clubValue);

      // Resolve season from "seasons" column (e.g. "2005-06")
      const seasonValue = getDataValue(["seasons", "season", "seasonName", "seasonId"]);
      const resolvedSeasonId = await resolveSeasonId(seasonValue);

      // Resolve condition from prodcat (name) or conditionId (numeric)
      const conditionValue = getDataValue(["conditionId", "prodcat", "condition", "product_condition"]);
      const resolvedConditionId = await resolveConditionId(conditionValue);
      if (resolvedConditionId) {
        variantData.conditionId = resolvedConditionId;
      }

      // Map defects → conditionDetail
      const defectsValue = getDataValue(["conditionDetail", "defects"]);
      if (defectsValue !== null && defectsValue !== undefined && String(defectsValue).trim() !== "") {
        variantData.conditionDetail = String(defectsValue).trim();
      }

      const productWebsitesValue = getDataValue(["productWebsites", "product_websites"]);
      const resolvedStoreIds = await resolveStoreIds(productWebsitesValue);

      const hasSizeInput =
        parsedSizeId !== null ||
        parsedMagentoSizeId !== null ||
        (sizeValue !== null && String(sizeValue).trim() !== "");
      if (hasSizeInput) {
        variantData.sizeId = resolvedSizeId;
      }

      const normalizedProductData = normalizeDataValues(productData);
      const normalizedVariantData = normalizeDataValues(variantData);
      const updateProductData = removeNullishValues(normalizedProductData);
      const updateVariantData = removeNullishValues(normalizedVariantData);

      if (resolvedGenderId) {
        normalizedProductData.genderId = resolvedGenderId;
        updateProductData.genderId = resolvedGenderId;
      }
      if (resolvedProductColourId) {
        normalizedProductData.productColourId = resolvedProductColourId;
        updateProductData.productColourId = resolvedProductColourId;
      }
      if (resolvedBrandId) {
        normalizedProductData.brandId = resolvedBrandId;
        updateProductData.brandId = resolvedBrandId;
      }
      if (resolvedProductTypeId) {
        normalizedProductData.productTypeId = resolvedProductTypeId;
        updateProductData.productTypeId = resolvedProductTypeId;
      }
      if (resolvedEraId) {
        normalizedProductData.eraId = resolvedEraId;
        updateProductData.eraId = resolvedEraId;
      }
      if (resolvedProductStyle) {
        normalizedProductData.productStyle = resolvedProductStyle;
        updateProductData.productStyle = resolvedProductStyle;
      }

      delete normalizedVariantData.productId;

      const isConfigurable =
        typeof productTypeValue === "string" &&
        productTypeValue.toLowerCase().includes("configurable");
      const hasConfigurableVariations =
        data.configurableVariations !== undefined &&
        data.configurableVariations !== null &&
        String(data.configurableVariations).trim() !== "";
      // All attributes are now product-level (variant table removed)

      if (!hasVariantSku && hasProductSku) {
        const normalizedProductSku = String(productSku).trim();
        normalizedProductData.productSku = normalizedProductSku;

        const [existingProduct] = await db
          .select({
            productId: product.productId,
          })
          .from(product)
          .where(eq(product.productSku, normalizedProductSku))
          .limit(1);

        let resolvedProductId: number | null = null;
        if (existingProduct) {
          resolvedProductId = Number(existingProduct.productId);
          console.log(`[Import] Updating product ${existingProduct.productId} with:`, JSON.stringify(updateProductData));
          const updateResult = await db
            .update(product)
            .set({ ...updateProductData, updatedAt: now })
            .where(eq(product.productId, existingProduct.productId))
            .returning({ eraId: product.eraId });
          console.log(`[Import] Update result for product ${existingProduct.productId}:`, JSON.stringify(updateResult));
        } else {
          const categoriesValue = getDataValue(["categories", "category"]);
          const hasCategoriesData = categoriesValue && String(categoriesValue).trim() !== "";
          const productFieldsToSet = { ...updateProductData };
          delete productFieldsToSet.updatedAt;
          const hasProductFieldsToSet = Object.keys(productFieldsToSet).length > 0;

          if (!hasProductFieldsToSet && hasCategoriesData) {
            console.log(`[Import] Skipping product creation for SKU "${normalizedProductSku}" - category-only row and product does not exist`);
            resolvedProductId = null;
          } else {
            if (normalizedProductData.enabled === null || normalizedProductData.enabled === undefined) {
              normalizedProductData.enabled = true;
            }
            const [createdProduct] = await db
              .insert(product)
              .values({ ...normalizedProductData, createdAt: now, updatedAt: now })
              .returning({ productId: product.productId });
            resolvedProductId = createdProduct ? Number(createdProduct.productId) : null;
          }
        }

        if (resolvedProductId && attributeValues.size > 0) {
          for (const entry of attributeValues.values()) {
            const inferred = inferAttributeValue(entry.value);
            if (!inferred) continue;
            let def = null as
              | { attributeId: number; dataType: string | null }
              | null;
            if (/^\d+$/.test(entry.rawKey)) {
              def = attributeDefById.get(Number(entry.rawKey)) ?? null;
            } else {
              const label = labelizeAttributeCode(entry.rawKey);
              def = await resolveAttributeDef(entry.rawKey, label, inferred.dataType);
            }
            if (!def) {
              console.log(`[Import] Skipping attribute "${entry.rawKey}" - no definition found`);
              continue;
            }
            console.log(`[Import] Inserting product attribute: productId=${resolvedProductId}, attributeId=${def.attributeId}, rawKey="${entry.rawKey}", value="${entry.value}"`);
            await upsertProductAttributeVal(resolvedProductId, def.attributeId, null, {
              valueText: inferred.valueText,
              valueNum: inferred.valueNum,
              valueBool: inferred.valueBool,
              valueJson: inferred.valueJson,
            });
          }
        }

        if (resolvedProductId && resolvedClubId !== null) {
          await this.setProductPrimaryTeam(resolvedProductId, resolvedClubId);
          // Update season on the primary team meta record if resolved
          if (resolvedSeasonId !== null) {
            await db
              .update(productTeamMeta)
              .set({ seasonId: resolvedSeasonId })
              .where(
                and(
                  eq(productTeamMeta.productId, resolvedProductId),
                  eq(productTeamMeta.clubId, resolvedClubId),
                  eq(productTeamMeta.isPrimary, true),
                ),
              );
          }
        }

        if (resolvedProductId && resolvedStoreIds.length > 0) {
          await this.setProductStores(resolvedProductId, resolvedStoreIds);
        }

        // For simple products (product-only rows), auto-create a variant using the product SKU
        // Check by resolved product type ID or by name match
        let isSimpleProduct = false;
        if (resolvedProductTypeId) {
          const [productTypeRow] = await db
            .select({ productTypeName: productType.productTypeName })
            .from(productType)
            .where(eq(productType.productTypeId, resolvedProductTypeId))
            .limit(1);
          isSimpleProduct = productTypeRow?.productTypeName?.toLowerCase() === "simple";
        } else if (typeof productTypeValue === "string") {
          isSimpleProduct = productTypeValue.toLowerCase() === "simple";
        }

        if (isSimpleProduct && resolvedProductId) {
          const normalizedProductSku = String(productSku).trim();

          // Check if variant already exists
          const [existingVariant] = await db
            .select({ productVariantId: productVariant.productVariantId })
            .from(productVariant)
            .where(eq(productVariant.productVariantSku, normalizedProductSku))
            .limit(1);

          if (existingVariant) {
            // Update existing variant
            await db
              .update(productVariant)
              .set({ ...updateVariantData, updatedAt: now })
              .where(eq(productVariant.productVariantId, existingVariant.productVariantId));
          } else {
            // Create new variant for simple product
            if (normalizedVariantData.enabled === null || normalizedVariantData.enabled === undefined) {
              normalizedVariantData.enabled = true;
            }
            const [createdVariant] = await db
              .insert(productVariant)
              .values({
                ...normalizedVariantData,
                productId: resolvedProductId,
                productVariantSku: normalizedProductSku,
                createdAt: now,
                updatedAt: now,
              })
              .returning({ productVariantId: productVariant.productVariantId });

            if (createdVariant) {
              // Handle stock and pricing for the new variant
              const resolvedVariantId = Number(createdVariant.productVariantId);

              // Create stock record if qty provided
              const qtyValue = getDataValue(["qty", "stock", "stockQty", "quantity"]);
              if (qtyValue !== null && String(qtyValue).trim() !== "") {
                const qty = Number(qtyValue);
                if (!isNaN(qty)) {
                  await db
                    .insert(variantStock)
                    .values({
                      productVariantId: resolvedVariantId,
                      warehouseId: 1, // Default to MAIN warehouse
                      qty,
                    })
                    .onConflictDoUpdate({
                      target: [variantStock.productVariantId, variantStock.warehouseId],
                      set: { qty },
                    });
                }
              }

              console.log(`[Import] Created variant for simple product: variantId=${resolvedVariantId}, sku="${normalizedProductSku}"`);
            }
          }
        }

        // Process categories for product-only imports
        const categoriesValue = getDataValue(["categories", "category"]);
        if (resolvedProductId && categoriesValue && String(categoriesValue).trim() !== "") {
          const categoryPaths = String(categoriesValue).split(",").map(p => p.trim()).filter(p => p !== "");
          const categoryIds: number[] = [];
          
          for (const path of categoryPaths) {
            try {
              const cat = await this.getOrCreateCategoryByPath(path);
              categoryIds.push(cat.categoryId);
            } catch (err) {
              console.error(`[Import] Failed to create/find category for path "${path}":`, err);
            }
          }
          
          if (categoryIds.length > 0) {
            const existingAssignments = await db
              .select({ categoryId: productCategory.categoryId })
              .from(productCategory)
              .where(eq(productCategory.productId, resolvedProductId));
            
            const existingCategoryIds = new Set(existingAssignments.map(a => a.categoryId));
            const newCategoryIds = categoryIds.filter(id => !existingCategoryIds.has(id));
            
            if (newCategoryIds.length > 0) {
              await db.insert(productCategory).values(
                newCategoryIds.map(categoryId => ({ productId: resolvedProductId, categoryId }))
              ).onConflictDoNothing();

              const [catProductSync] = await db.select({ sync: product.sync }).from(product).where(eq(product.productId, resolvedProductId)).limit(1);
              if (catProductSync?.sync) {
                try {
                  await this.insertSyncQueueEntry({
                    productId: Number(resolvedProductId),
                    productVariantId: null,
                    operationType: "category_change",
                  });
                } catch (e) {
                  console.error("Failed to insert sync queue entry for category import:", e);
                }
              }
            }
            
            console.log(`[Import] Assigned ${categoryIds.length} categories to product ${resolvedProductId}`);
          }
        }

        await db
          .update(importRow)
          .set({ rowStatus: "applied", updatedAt: now })
          .where(eq(importRow.importRowId, currentRowId));

        appliedRows += 1;

        const productOnlySku = (row.rowRaw as any)?.data?.productSku || `Row ${row.rowNumber}`;
        importProgressTracker.addEntry(batchId, {
          sku: String(productOnlySku),
          status: "success",
          timestamp: Date.now(),
        });

        continue;
      }

      if (!hasVariantSku) {
        await db
          .update(importRow)
          .set({ rowStatus: "applied", updatedAt: now })
          .where(eq(importRow.importRowId, currentRowId));
        appliedRows += 1;

        importProgressTracker.addEntry(batchId, {
          sku: `Row ${row.rowNumber}`,
          status: "success",
          timestamp: Date.now(),
        });

        continue;
      }

      const [existingVariant] = await db
        .select({
          productVariantId: productVariant.productVariantId,
          productId: productVariant.productId,
        })
        .from(productVariant)
        .where(eq(productVariant.productVariantSku, String(sku).trim()))
        .limit(1);

      let resolvedProductId: number | null = null;
      let resolvedVariantId: number | null = null;

      if (existingVariant) {
        resolvedVariantId = Number(existingVariant.productVariantId);
        resolvedProductId = existingVariant.productId ? Number(existingVariant.productId) : null;

        if (Object.keys(updateVariantData).length > 0) {
          await db
            .update(productVariant)
            .set({ ...updateVariantData, updatedAt: now })
            .where(eq(productVariant.productVariantId, existingVariant.productVariantId));
        }
      } else {
        let productId: number | null = null;
        const candidateSku = normalizedProductData.productSku;
        if (candidateSku) {
          const [existingProduct] = await db
            .select({ productId: product.productId })
            .from(product)
            .where(eq(product.productSku, String(candidateSku)))
            .limit(1);
          if (existingProduct) {
            productId = Number(existingProduct.productId);
          } else {
            console.warn(`[Import] Parent product "${candidateSku}" not found for variant "${String(sku).trim()}" - variant will be created without a parent`);
          }
        }

        if (!hasProductSku && !productId) {
          const simpleTypeId = await resolveProductTypeId("simple");
          const variantSkuStr = String(sku).trim();
          const [existingSimple] = await db
            .select({ productId: product.productId })
            .from(product)
            .where(eq(product.productSku, variantSkuStr))
            .limit(1);
          if (existingSimple) {
            productId = Number(existingSimple.productId);
            console.log(`[Import] Found existing simple product for orphan variant "${variantSkuStr}" -> productId=${productId}`);
          } else {
            const simpleProductData: Record<string, any> = {
              productSku: variantSkuStr,
              productDescription: normalizedProductData.productDescription || null,
              productTypeId: simpleTypeId || null,
              brandId: resolvedBrandId || null,
              genderId: resolvedGenderId || null,
              productColourId: resolvedProductColourId || null,
              eraId: resolvedEraId || null,
              enabled: true,
              createdAt: now,
              updatedAt: now,
            };
            const [createdSimple] = await db
              .insert(product)
              .values(simpleProductData)
              .returning({ productId: product.productId });
            if (createdSimple) {
              productId = Number(createdSimple.productId);
              console.log(`[Import] Created simple product for orphan variant "${variantSkuStr}" -> productId=${productId}`);
            }
          }
        }

        if (normalizedVariantData.enabled === null || normalizedVariantData.enabled === undefined) {
          normalizedVariantData.enabled = true;
        }
        if (normalizedVariantData.printed === null || normalizedVariantData.printed === undefined) {
          normalizedVariantData.printed = false;
        }
        if (normalizedVariantData.barcode) {
          const [barcodeOwner] = await db
            .select({ productVariantSku: productVariant.productVariantSku })
            .from(productVariant)
            .where(eq(productVariant.barcode, String(normalizedVariantData.barcode)))
            .limit(1);
          if (barcodeOwner && barcodeOwner.productVariantSku !== String(sku).trim()) {
            normalizedVariantData.barcode = null;
          }
        }
        const [createdVariant] = await db
          .insert(productVariant)
          .values({
            ...normalizedVariantData,
            productId,
            productVariantSku: String(sku).trim(),
            createdAt: now,
            updatedAt: now,
          })
          .onConflictDoUpdate({
            target: [productVariant.productVariantSku],
            set: {
              ...normalizedVariantData,
              productId,
              updatedAt: now,
            },
          })
          .returning({ productVariantId: productVariant.productVariantId });
        resolvedVariantId = createdVariant ? Number(createdVariant.productVariantId) : null;
        resolvedProductId = productId;
      }

      if (resolvedProductId && resolvedClubId !== null) {
        await this.setProductPrimaryTeam(resolvedProductId, resolvedClubId);
        // Update season on the primary team meta record if resolved
        if (resolvedSeasonId !== null) {
          await db
            .update(productTeamMeta)
            .set({ seasonId: resolvedSeasonId })
            .where(
              and(
                eq(productTeamMeta.productId, resolvedProductId),
                eq(productTeamMeta.clubId, resolvedClubId),
                eq(productTeamMeta.isPrimary, true),
              ),
            );
        }
      }

      if (resolvedProductId && resolvedStoreIds.length > 0) {
        await this.setProductStores(resolvedProductId, resolvedStoreIds);
      }

      if (resolvedVariantId) {
        const currencyPrices = extractCurrencyPrices(data);
        const uploadedCurrencyCodes = currencyPrices.map(cp => cp.currencyCode.toUpperCase());
        const hasOnlyGbp = uploadedCurrencyCodes.length === 1 && uploadedCurrencyCodes[0] === "GBP";
        const hasNonGbpCurrencies = uploadedCurrencyCodes.some(c => c !== "GBP");

        for (const cp of currencyPrices) {
          const currencyId = await resolveCurrencyId(cp.currencyCode);
          if (currencyId) {
            const isManual = hasNonGbpCurrencies && cp.currencyCode.toUpperCase() !== "GBP";
            await this.upsertVariantPrice({
              productVariantId: resolvedVariantId,
              currencyId,
              retailPrice: cp.retailPrice,
              specialRetailPrice: cp.specialRetailPrice,
              costPrice: cp.costPrice,
              isManualOverride: isManual,
            });
          }
        }

        if (hasOnlyGbp || uploadedCurrencyCodes.includes("GBP")) {
          await this.autoConvertPricesFromBase(resolvedVariantId, "GBP");
        }

        if (resolvedProductId && currencyPrices.length > 0) {
          const siblingVariants = await db
            .select({ productVariantId: productVariant.productVariantId })
            .from(productVariant)
            .where(
              and(
                eq(productVariant.productId, resolvedProductId),
                ne(productVariant.productVariantId, resolvedVariantId)
              )
            );

          for (const sibling of siblingVariants) {
            const siblingId = Number(sibling.productVariantId);
            let insertedNewGbpPrice = false;

            for (const cp of currencyPrices) {
              const currencyId = await resolveCurrencyId(cp.currencyCode);
              if (!currencyId) continue;

              const existingPrice = await db
                .select({ variantPriceId: variantPrice.variantPriceId })
                .from(variantPrice)
                .where(
                  and(
                    eq(variantPrice.productVariantId, siblingId),
                    eq(variantPrice.currencyId, currencyId)
                  )
                )
                .limit(1);

              if (existingPrice.length === 0) {
                const isManual = hasNonGbpCurrencies && cp.currencyCode.toUpperCase() !== "GBP";
                await this.upsertVariantPrice({
                  productVariantId: siblingId,
                  currencyId,
                  retailPrice: cp.retailPrice,
                  specialRetailPrice: cp.specialRetailPrice,
                  costPrice: cp.costPrice,
                  isManualOverride: isManual,
                });
                if (cp.currencyCode.toUpperCase() === "GBP") {
                  insertedNewGbpPrice = true;
                }
              }
            }

            if (insertedNewGbpPrice) {
              await this.autoConvertPricesFromBase(siblingId, "GBP");
            }
          }
        }
      }

      if (attributeValues.size > 0 && resolvedProductId) {
        for (const entry of attributeValues.values()) {
          const inferred = inferAttributeValue(entry.value);
          if (!inferred) continue;
          let def = null as
            | { attributeId: number; dataType: string | null }
            | null;
          if (/^\d+$/.test(entry.rawKey)) {
            def = attributeDefById.get(Number(entry.rawKey)) ?? null;
          } else {
            const label = labelizeAttributeCode(entry.rawKey);
            def = await resolveAttributeDef(entry.rawKey, label, inferred.dataType);
          }
          if (!def) {
            continue;
          }
          await upsertProductAttributeVal(resolvedProductId, def.attributeId, null, {
            valueText: inferred.valueText,
            valueNum: inferred.valueNum,
            valueBool: inferred.valueBool,
            valueJson: inferred.valueJson,
          });
        }
      }

      // Process image URL if provided
      const imageUrlValue = getDataValue(["imageUrl", "image_url"]);
      const imageRoleValue = getDataValue(["imageRole", "image_role"]);
      const imageSortOrderValue = getDataValue(["imageSortOrder", "image_sort_order"]);

      if (resolvedProductId && imageUrlValue && String(imageUrlValue).trim() !== "") {
        const imageUrl = String(imageUrlValue).trim();
        const imageRole = imageRoleValue ? String(imageRoleValue).trim() : "main";
        let requestedSortOrder = 1;

        if (imageSortOrderValue !== null && imageSortOrderValue !== undefined && String(imageSortOrderValue).trim() !== "") {
          const parsedOrder = parseInt(String(imageSortOrderValue), 10);
          if (!isNaN(parsedOrder) && parsedOrder >= 1) {
            requestedSortOrder = parsedOrder;
          }
        }

        // Get existing images from DB for this product
        const existingImages = await db
          .select({ sortOrder: imageAsset.sortOrder })
          .from(imageAsset)
          .where(eq(imageAsset.productId, resolvedProductId))
          .orderBy(asc(imageAsset.sortOrder));

        // Combine DB sort orders with import-run assigned sort orders
        const dbOrders = new Set(existingImages.map(img => img.sortOrder ?? 0));
        const importOrders = importImageSortOrders.get(resolvedProductId) ?? new Set<number>();
        const allAssignedOrders = new Set([...dbOrders, ...importOrders]);

        // Find the next available sequential sort order (always assign sequentially)
        let validSortOrder = 1;
        while (allAssignedOrders.has(validSortOrder)) {
          validSortOrder++;
        }

        // If requested order is available and sequential, use it; otherwise use next available
        if (requestedSortOrder === validSortOrder) {
          // Requested order matches next sequential - use it
        } else if (requestedSortOrder > validSortOrder) {
          // Requested order would create a gap - use next available instead
          console.log(`[Import] Image sort order ${requestedSortOrder} would create gap for product ${resolvedProductId}, using ${validSortOrder} instead`);
        } else if (allAssignedOrders.has(requestedSortOrder)) {
          // Requested order already taken - use next available
          console.log(`[Import] Image sort order ${requestedSortOrder} already assigned for product ${resolvedProductId}, using ${validSortOrder} instead`);
        } else {
          // Requested order is valid and available
          validSortOrder = requestedSortOrder;
        }

        // Track this sort order for subsequent rows in this import
        if (!importImageSortOrders.has(resolvedProductId)) {
          importImageSortOrders.set(resolvedProductId, new Set());
        }
        importImageSortOrders.get(resolvedProductId)!.add(validSortOrder);

        // Check if image with this URL already exists for the product
        const [existingImage] = await db
          .select({ imageId: imageAsset.imageId })
          .from(imageAsset)
          .where(and(
            eq(imageAsset.productId, resolvedProductId),
            eq(imageAsset.url, imageUrl)
          ))
          .limit(1);

        if (existingImage) {
          // Update existing image
          await db
            .update(imageAsset)
            .set({
              role: imageRole,
              sortOrder: validSortOrder,
            })
            .where(eq(imageAsset.imageId, existingImage.imageId));
        } else {
          // Insert new image
          await db
            .insert(imageAsset)
            .values({
              productId: resolvedProductId,
              role: imageRole,
              url: imageUrl,
              sortOrder: validSortOrder,
            });
        }

        console.log(`[Import] Processed image for product ${resolvedProductId}: url="${imageUrl}", role="${imageRole}", sortOrder=${validSortOrder}`);

        const [imgSyncCheck] = await db.select({ sync: product.sync }).from(product).where(eq(product.productId, resolvedProductId)).limit(1);
        if (imgSyncCheck?.sync) {
          try {
            await this.insertSyncQueueEntry({
              productId: Number(resolvedProductId),
              productVariantId: null,
              operationType: "image_update",
            });
          } catch (e) {
            console.error("Failed to insert sync queue entry for image update:", e);
          }
        }
      }

      const categoriesValue = getDataValue(["categories", "category"]);
      if (resolvedProductId && categoriesValue && String(categoriesValue).trim() !== "") {
        const categoryPaths = String(categoriesValue).split(",").map(p => p.trim()).filter(p => p !== "");
        const categoryIds: number[] = [];
        
        for (const path of categoryPaths) {
          try {
            const cat = await this.getOrCreateCategoryByPath(path);
            categoryIds.push(cat.categoryId);
          } catch (err) {
            console.error(`[Import] Failed to create/find category for path "${path}":`, err);
          }
        }
        
        if (categoryIds.length > 0) {
          const existingAssignments = await db
            .select({ categoryId: productCategory.categoryId })
            .from(productCategory)
            .where(eq(productCategory.productId, resolvedProductId));
          
          const existingCategoryIds = new Set(existingAssignments.map(a => a.categoryId));
          const newCategoryIds = categoryIds.filter(id => !existingCategoryIds.has(id));
          
          if (newCategoryIds.length > 0) {
            await db.insert(productCategory).values(
              newCategoryIds.map(categoryId => ({ productId: resolvedProductId, categoryId }))
            ).onConflictDoNothing();

            const [catSyncCheck] = await db.select({ sync: product.sync }).from(product).where(eq(product.productId, resolvedProductId)).limit(1);
            if (catSyncCheck?.sync) {
              try {
                await this.insertSyncQueueEntry({
                  productId: Number(resolvedProductId),
                  productVariantId: null,
                  operationType: "category_change",
                });
              } catch (e) {
                console.error("Failed to insert sync queue entry for category import:", e);
              }
            }
          }
          
          console.log(`[Import] Assigned ${categoryIds.length} categories to product ${resolvedProductId}`);
        }
      }

      // Mark this row as successfully applied
      await db
        .update(importRow)
        .set({ rowStatus: "applied", updatedAt: now })
        .where(eq(importRow.importRowId, currentRowId));

      appliedRows += 1;

      const rowSku = (row.rowRaw as any)?.data?.productVariantSku || (row.rowRaw as any)?.data?.productSku || `Row ${row.rowNumber}`;
      importProgressTracker.addEntry(batchId, {
        sku: String(rowSku),
        status: "success",
        timestamp: Date.now(),
      });

      } catch (rowError: any) {
        console.error(`[Import] Error processing row ${row.rowNumber}:`, rowError);
        
        await db
          .update(importRow)
          .set({ rowStatus: "error", updatedAt: now })
          .where(eq(importRow.importRowId, currentRowId));

        await db.insert(importError).values({
          importRowId: currentRowId,
          fieldKey: null,
          errorCode: "processing_error",
          errorMessage: rowError?.message || "Unknown error during row processing",
          createdAt: now,
        });

        const errorSku = (row.rowRaw as any)?.data?.productVariantSku || (row.rowRaw as any)?.data?.productSku || `Row ${row.rowNumber}`;
        importProgressTracker.addEntry(batchId, {
          sku: String(errorSku),
          status: "error",
          message: rowError?.message || "Unknown error",
          timestamp: Date.now(),
        });

        errorRows += 1;
      }
    }

    // Determine final job status based on results
    // Total issues = validation-phase invalid rows + processing errors
    const totalInvalidRows = validationInvalidRows + errorRows;
    
    // Use only standard status values: "uploaded", "validated", "applied", "failed"
    // Note: The invalidRows count in the job captures the total number of problematic rows
    // If there were any issues but also some successes, we still mark as "applied"
    // The invalidRows > 0 signals to the UI that there were problems
    let finalStatus = "applied";
    if (appliedRows === 0) {
      // No rows were successfully applied - mark as failed
      finalStatus = "failed";
    }

    await db
      .update(importJob)
      .set({
        status: finalStatus,
        appliedAt: now,
        updatedAt: now,
        appliedRows,
        validRows: appliedRows,
        invalidRows: totalInvalidRows,
      })
      .where(eq(importJob.importJobId, importJobId));

    await this.clearStagingRows(batchId);

    importProgressTracker.complete(batchId, finalStatus === "failed" ? "failed" : "completed");

    setTimeout(() => importProgressTracker.remove(batchId), 60000);
    } catch (fatalError) {
      console.error("[Import] Fatal error in processImport:", fatalError);
      await db
        .update(importJob)
        .set({
          status: "failed",
          updatedAt: new Date(),
        })
        .where(eq(importJob.importJobId, importJobId));
      importProgressTracker.complete(batchId, "failed");
      setTimeout(() => importProgressTracker.remove(batchId), 60000);
    }
  }

  async createImportBatch(
    _batchId: string,
    fileNames: string,
    totalRows: number,
    userId?: number | null,
  ): Promise<ImportJob> {
    const now = new Date();
    const [job] = await db
      .insert(importJob)
      .values({
        createdBy: userId ?? null,
        sourceType: "csv",
        importType: "listing_sheets",
        status: "uploaded",
        originalFilename: fileNames,
        totalRows,
        validRows: null,
        invalidRows: null,
        appliedRows: null,
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    return job;
  }

  async getImportBatches(): Promise<ImportJob[]> {
    return await db.select().from(importJob).orderBy(desc(importJob.createdAt));
  }

  async getImportBatchesWithUser(): Promise<Array<ImportJob & { uploadedByName: string | null }>> {
    const results = await db
      .select({
        importJobId: importJob.importJobId,
        createdBy: importJob.createdBy,
        sourceType: importJob.sourceType,
        importType: importJob.importType,
        status: importJob.status,
        originalFilename: importJob.originalFilename,
        fileSha256: importJob.fileSha256,
        totalRows: importJob.totalRows,
        validRows: importJob.validRows,
        invalidRows: importJob.invalidRows,
        appliedRows: importJob.appliedRows,
        createdAt: importJob.createdAt,
        updatedAt: importJob.updatedAt,
        appliedAt: importJob.appliedAt,
        uploadedByName: appUser.displayName,
      })
      .from(importJob)
      .leftJoin(appUser, eq(importJob.createdBy, appUser.appUserId))
      .orderBy(desc(importJob.createdAt));
    return results;
  }

  async getImportBatch(batchId: string): Promise<ImportJob | null> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return null;

    const [job] = await db
      .select()
      .from(importJob)
      .where(eq(importJob.importJobId, importJobId))
      .limit(1);
    return job ?? null;
  }

  async updateImportBatchStatus(
    batchId: string,
    status: string,
    updates?: { processedProducts?: number; errorMessage?: string; completedAt?: Date },
  ): Promise<void> {
    const importJobId = parseImportJobId(batchId);
    if (!importJobId) return;

    await db
      .update(importJob)
      .set({
        status,
        appliedRows: updates?.processedProducts ?? undefined,
        updatedAt: new Date(),
        appliedAt: updates?.completedAt ?? undefined,
      })
      .where(eq(importJob.importJobId, importJobId));
  }

  async createProductGroup(name: string, description: string | null, productIds: number[]): Promise<any> {
    const createdAt = new Date();
    const result = await db.transaction(async (tx) => {
      const [group] = await tx
        .insert(productGroup)
        .values({
          name,
          description,
          status: "active",
          isSystem: false,
          createdAt,
          updatedAt: createdAt,
        })
        .returning();

      if (!group) {
        throw new Error("Failed to create group");
      }

      if (productIds.length) {
        await tx.insert(productGroupMember).values(
          productIds.map((productId) => ({
            productGroupId: group.productGroupId,
            productId,
            addedAt: createdAt,
            startDate: createdAt,
            live: true,
          })),
        );
      }

      return group;
    });

    return {
      groupId: result.productGroupId,
      name: result.name,
      description: result.description,
      createdAt: result.createdAt,
    };
  }

  async getProductGroups(): Promise<any[]> {
    const result = await db.execute(sql`
      SELECT
        pg.product_group_id AS "groupId",
        pg.name,
        pg.description,
        pg.created_at AS "createdAt",
        (
          SELECT COUNT(*)::int
          FROM pim.product_group_member pgm
          WHERE pgm.product_group_id = pg.product_group_id
            AND pgm.live = true
        ) AS "productCount"
      FROM pim.product_group pg
      ORDER BY pg.name ASC
    `);
    return result.rows;
  }

  async getProductGroup(groupId: number): Promise<any | null> {
    const result = await db.execute(sql`
      SELECT
        pg.product_group_id AS "groupId",
        pg.name,
        pg.description,
        pg.status,
        pg.is_system AS "isSystem",
        pg.created_at AS "createdAt",
        pg.updated_at AS "updatedAt",
        (
          SELECT COUNT(*)::int
          FROM pim.product_group_member pgm
          WHERE pgm.product_group_id = pg.product_group_id
            AND pgm.live = true
        ) AS "productCount"
      FROM pim.product_group pg
      WHERE pg.product_group_id = ${groupId}
      LIMIT 1
    `);
    return result.rows[0] ?? null;
  }

  async updateProductGroup(input: {
    groupId: number;
    name: string;
    description?: string | null;
    status?: string | null;
  }): Promise<any> {
    const [updated] = await db
      .update(productGroup)
      .set({
        name: input.name,
        description: input.description ?? null,
        status: input.status ?? undefined,
        updatedAt: new Date(),
      })
      .where(eq(productGroup.productGroupId, input.groupId))
      .returning();
    return updated;
  }

  async getProductGroupProducts(groupId: number): Promise<any[]> {
    return await db
      .select({
        productGroupMemberId: productGroupMember.productGroupMemberId,
        productId: product.productId,
        productSku: product.productSku,
        productDescription: product.productDescription,
        brandName: brands.brandName,
        enabled: product.enabled,
        startDate: productGroupMember.startDate,
        endDate: productGroupMember.endDate,
        live: productGroupMember.live,
      })
      .from(productGroupMember)
      .innerJoin(product, eq(productGroupMember.productId, product.productId))
      .leftJoin(brands, eq(product.brandId, brands.brandId))
      .where(eq(productGroupMember.productGroupId, groupId))
      .orderBy(desc(productGroupMember.live), asc(product.productDescription));
  }

  async addProductsToGroup(groupId: number, productIds: number[], endDate?: Date | null): Promise<any[]> {
    const existingLive = await db
      .select({ productId: productGroupMember.productId })
      .from(productGroupMember)
      .where(and(
        eq(productGroupMember.productGroupId, groupId),
        eq(productGroupMember.live, true),
        inArray(productGroupMember.productId, productIds),
      ));
    const alreadyLiveIds = new Set(existingLive.map(r => r.productId));
    const newProductIds = productIds.filter(id => !alreadyLiveIds.has(id));
    if (newProductIds.length === 0) return [];

    const now = new Date();
    const rows = await db
      .insert(productGroupMember)
      .values(
        newProductIds.map((productId) => ({
          productGroupId: groupId,
          productId,
          addedAt: now,
          startDate: now,
          endDate: endDate ?? null,
          live: true,
        })),
      )
      .returning();
    return rows;
  }

  async updateProductGroupMembersEndDate(groupId: number, memberIds: number[], endDate: Date | null): Promise<number> {
    const result = await db
      .update(productGroupMember)
      .set({ endDate })
      .where(and(
        eq(productGroupMember.productGroupId, groupId),
        inArray(productGroupMember.productGroupMemberId, memberIds),
        eq(productGroupMember.live, true),
      ))
      .returning();
    return result.length;
  }

  async updateProductGroupMember(groupId: number, memberId: number, updates: { live?: boolean; endDate?: Date | null }): Promise<any> {
    const [updated] = await db
      .update(productGroupMember)
      .set(updates)
      .where(and(
        eq(productGroupMember.productGroupMemberId, memberId),
        eq(productGroupMember.productGroupId, groupId),
      ))
      .returning();
    return updated;
  }

  async deleteProductGroupMembers(groupId: number, memberIds: number[]): Promise<number> {
    const result = await db
      .delete(productGroupMember)
      .where(and(
        eq(productGroupMember.productGroupId, groupId),
        inArray(productGroupMember.productGroupMemberId, memberIds),
      ))
      .returning();
    return result.length;
  }

  async reactivateProductGroupMember(groupId: number, memberId: number): Promise<any> {
    const [existing] = await db
      .select()
      .from(productGroupMember)
      .where(and(
        eq(productGroupMember.productGroupMemberId, memberId),
        eq(productGroupMember.productGroupId, groupId),
      ));
    if (!existing) return null;

    const [alreadyLive] = await db
      .select({ productGroupMemberId: productGroupMember.productGroupMemberId })
      .from(productGroupMember)
      .where(and(
        eq(productGroupMember.productGroupId, groupId),
        eq(productGroupMember.productId, existing.productId),
        eq(productGroupMember.live, true),
      ))
      .limit(1);
    if (alreadyLive) return alreadyLive;

    const now = new Date();
    const [newMember] = await db
      .insert(productGroupMember)
      .values({
        productGroupId: groupId,
        productId: existing.productId,
        addedAt: now,
        startDate: now,
        live: true,
      })
      .returning();
    return newMember;
  }

  async deleteProductGroup(groupId: number): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.execute(
        sql`UPDATE pim.scheduled_change SET scope_group_id = NULL WHERE scope_group_id = ${groupId}`
      );
      await tx
        .delete(productGroupMember)
        .where(eq(productGroupMember.productGroupId, groupId));
      await tx
        .delete(productGroup)
        .where(eq(productGroup.productGroupId, groupId));
    });
  }

  async getWorkspaceUsers(): Promise<any[]> {
    const rows = await db
      .select({
        appUserId: appUser.appUserId,
        displayName: appUser.displayName,
        email: appUser.email,
        status: appUser.status,
        lastLoginAt: appUser.lastLoginAt,
        roleName: appRole.name,
      })
      .from(appUser)
      .leftJoin(appUserRole, eq(appUser.appUserId, appUserRole.appUserId))
      .leftJoin(appRole, eq(appUserRole.appRoleId, appRole.appRoleId))
      .orderBy(desc(appUser.lastLoginAt));

    const userMap = new Map<number, any>();
    for (const row of rows) {
      const id = Number(row.appUserId);
      const existing = userMap.get(id);
      if (!existing) {
        userMap.set(id, {
          id,
          name: row.displayName ?? row.email,
          email: row.email,
          department: null,
          roles: row.roleName ? [row.roleName] : [],
          status: row.status,
          lastLogin: row.lastLoginAt ? row.lastLoginAt.toISOString() : null,
        });
      } else if (row.roleName && !existing.roles.includes(row.roleName)) {
        existing.roles.push(row.roleName);
      }
    }

    return Array.from(userMap.values());
  }

  async getWorkspaceRoles(): Promise<any[]> {
    const rows = await db
      .select({
        roleId: appRole.appRoleId,
        roleCode: appRole.code,
        roleName: appRole.name,
        roleDescription: appRole.description,
        permissionId: appPermission.appPermissionId,
        permissionName: appPermission.name,
        permissionCode: appPermission.code,
        permissionDescription: appPermission.description,
      })
      .from(appRole)
      .leftJoin(appRolePermission, eq(appRole.appRoleId, appRolePermission.appRoleId))
      .leftJoin(appPermission, eq(appRolePermission.appPermissionId, appPermission.appPermissionId))
      .orderBy(asc(appRole.name));

    const roleMap = new Map<number, any>();
    for (const row of rows) {
      const id = Number(row.roleId);
      const existing = roleMap.get(id);
      if (!existing) {
        roleMap.set(id, {
          id: row.roleCode ?? String(row.roleId),
          name: row.roleName ?? row.roleCode ?? "Role",
          description: row.roleDescription ?? "",
          permissions: [],
        });
      }

      if (row.permissionCode || row.permissionName) {
        const permissions = roleMap.get(id).permissions as Array<any>;
        permissions.push({
          id: Number(row.permissionId),
          code: row.permissionCode ?? "",
          name: row.permissionName ?? row.permissionCode ?? "Permission",
          description: row.permissionDescription ?? "",
        });
      }
    }

    return Array.from(roleMap.values());
  }

  async getWorkspacePermissions(): Promise<any[]> {
    return await db
      .select({
        id: appPermission.appPermissionId,
        code: appPermission.code,
        name: appPermission.name,
        description: appPermission.description,
      })
      .from(appPermission)
      .orderBy(asc(appPermission.name));
  }

  async createWorkspaceRole(input: {
    code: string;
    name: string;
    description?: string | null;
    permissionIds: number[];
  }): Promise<any> {
    const now = new Date();
    const [role] = await db
      .insert(appRole)
      .values({
        code: input.code,
        name: input.name,
        description: input.description ?? null,
        isSystem: false,
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    if (!role) {
      throw new Error("Failed to create role");
    }

    if (input.permissionIds.length > 0) {
      await db.insert(appRolePermission).values(
        input.permissionIds.map((permissionId) => ({
          appRoleId: role.appRoleId,
          appPermissionId: permissionId,
        })),
      );
    }

    return role;
  }

  async assignWorkspaceUserRole(input: {
    userId: number;
    roleCode: string;
    assignedBy?: number | null;
  }): Promise<any> {
    const [role] = await db
      .select({ appRoleId: appRole.appRoleId })
      .from(appRole)
      .where(eq(appRole.code, input.roleCode))
      .limit(1);

    if (!role) {
      throw new Error("Role not found");
    }

    const now = new Date();
    await db
      .insert(appUserRole)
      .values({
        appUserId: input.userId,
        appRoleId: role.appRoleId,
        assignedAt: now,
        assignedBy: input.assignedBy ?? null,
      })
      .onConflictDoNothing();

    return { success: true };
  }

  async updateWorkspaceRole(input: {
    code: string;
    name: string;
    description?: string | null;
    permissionIds: number[];
  }): Promise<any> {
    const now = new Date();
    const [role] = await db
      .select({ appRoleId: appRole.appRoleId })
      .from(appRole)
      .where(eq(appRole.code, input.code))
      .limit(1);

    if (!role) {
      throw new Error("Role not found");
    }

    await db
      .update(appRole)
      .set({
        name: input.name,
        description: input.description ?? null,
        updatedAt: now,
      })
      .where(eq(appRole.appRoleId, role.appRoleId));

    await db.delete(appRolePermission).where(eq(appRolePermission.appRoleId, role.appRoleId));

    if (input.permissionIds.length > 0) {
      await db.insert(appRolePermission).values(
        input.permissionIds.map((permissionId) => ({
          appRoleId: role.appRoleId,
          appPermissionId: permissionId,
        })),
      );
    }

    return { success: true };
  }

  async getReferenceTableTypes(): Promise<Array<{ code: string; name: string; columns: Array<{ key: string; label: string; required: boolean }> }>> {
    return [
      {
        code: "club",
        name: "Teams / Clubs",
        columns: [
          { key: "name", label: "Name", required: true },
          { key: "country", label: "Country", required: false },
          { key: "foundedYear", label: "Founded Year", required: false },
        ],
      },
      {
        code: "competition",
        name: "Competitions",
        columns: [
          { key: "name", label: "Name", required: true },
          { key: "country", label: "Country", required: false },
        ],
      },
      {
        code: "season",
        name: "Seasons",
        columns: [
          { key: "code", label: "Code", required: true },
          { key: "yearStart", label: "Year Start", required: false },
          { key: "yearEnd", label: "Year End", required: false },
        ],
      },
      {
        code: "brand",
        name: "Brands",
        columns: [
          { key: "brandName", label: "Brand Name", required: true },
          { key: "brandGrouping", label: "Brand Grouping", required: false },
        ],
      },
      {
        code: "era",
        name: "Eras",
        columns: [
          { key: "name", label: "Name", required: true },
          { key: "startYear", label: "Start Year", required: true },
          { key: "endYear", label: "End Year", required: true },
        ],
      },
      {
        code: "department",
        name: "Departments",
        columns: [
          { key: "name", label: "Name", required: true },
        ],
      },
      {
        code: "kitCategory",
        name: "Kit Categories",
        columns: [
          { key: "name", label: "Name", required: true },
        ],
      },
      {
        code: "kitClass",
        name: "Kit Classes",
        columns: [
          { key: "name", label: "Name", required: true },
        ],
      },
      {
        code: "channel",
        name: "Channels",
        columns: [
          { key: "code", label: "Code", required: true },
          { key: "name", label: "Name", required: false },
        ],
      },
      {
        code: "gender",
        name: "Genders",
        columns: [
          { key: "genderName", label: "Gender Name", required: true },
        ],
      },
      {
        code: "taxClass",
        name: "Tax Classes",
        columns: [
          { key: "taxClassName", label: "Tax Class Name", required: true },
        ],
      },
      {
        code: "productType",
        name: "Product Types",
        columns: [
          { key: "productTypeName", label: "Product Type Name", required: true },
        ],
      },
      {
        code: "currency",
        name: "Currencies",
        columns: [
          { key: "code", label: "Code", required: true },
          { key: "name", label: "Name", required: false },
          { key: "symbol", label: "Symbol", required: false },
          { key: "minorUnit", label: "Minor Unit", required: false },
          { key: "enabled", label: "Enabled", required: false },
        ],
      },
    ];
  }

  async importReferenceData(tableType: string, rows: any[]): Promise<{ inserted: number; updated: number; errors: string[] }> {
    let inserted = 0;
    let updated = 0;
    const errors: string[] = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2; // Row 1 is header

      try {
        switch (tableType) {
          case "club": {
            const name = String(row.name || "").trim();
            if (!name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            const [existing] = await db.select().from(club).where(eq(club.name, name)).limit(1);
            if (existing) {
              await db.update(club).set({
                country: row.country || null,
                foundedYear: row.foundedYear ? Number(row.foundedYear) : null,
              }).where(eq(club.clubId, existing.clubId));
              updated++;
            } else {
              await db.insert(club).values({
                name,
                country: row.country || null,
                foundedYear: row.foundedYear ? Number(row.foundedYear) : null,
              });
              inserted++;
            }
            break;
          }

          case "competition": {
            const name = String(row.name || "").trim();
            if (!name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            const [existing] = await db.select().from(competition).where(eq(competition.name, name)).limit(1);
            if (existing) {
              await db.update(competition).set({
                country: row.country || null,
              }).where(eq(competition.competitionId, existing.competitionId));
              updated++;
            } else {
              await db.insert(competition).values({
                name,
                country: row.country || null,
              });
              inserted++;
            }
            break;
          }

          case "season": {
            const code = String(row.code || "").trim();
            if (!code) {
              errors.push(`Row ${rowNum}: Code is required`);
              continue;
            }
            const [existing] = await db.select().from(season).where(eq(season.code, code)).limit(1);
            if (existing) {
              await db.update(season).set({
                yearStart: row.yearStart ? Number(row.yearStart) : null,
                yearEnd: row.yearEnd ? Number(row.yearEnd) : null,
              }).where(eq(season.seasonId, existing.seasonId));
              updated++;
            } else {
              await db.insert(season).values({
                code,
                yearStart: row.yearStart ? Number(row.yearStart) : null,
                yearEnd: row.yearEnd ? Number(row.yearEnd) : null,
              });
              inserted++;
            }
            break;
          }

          case "brand": {
            const brandName = String(row.brandName || "").trim();
            if (!brandName) {
              errors.push(`Row ${rowNum}: Brand Name is required`);
              continue;
            }
            const [existing] = await db.select().from(brands).where(eq(brands.brandName, brandName)).limit(1);
            if (existing) {
              await db.update(brands).set({
                brandGrouping: row.brandGrouping || null,
              }).where(eq(brands.brandId, existing.brandId));
              updated++;
            } else {
              await db.insert(brands).values({
                brandName,
                brandGrouping: row.brandGrouping || null,
              });
              inserted++;
            }
            break;
          }

          case "era": {
            const name = String(row.name || "").trim();
            const startYear = row.startYear ? Number(row.startYear) : null;
            const endYear = row.endYear ? Number(row.endYear) : null;
            if (!name || startYear === null || endYear === null) {
              errors.push(`Row ${rowNum}: Name, Start Year, and End Year are required`);
              continue;
            }
            const [existing] = await db.select().from(era).where(eq(era.name, name)).limit(1);
            if (existing) {
              await db.update(era).set({
                startYear,
                endYear,
              }).where(eq(era.eraId, existing.eraId));
              updated++;
            } else {
              await db.insert(era).values({
                name,
                startYear,
                endYear,
              });
              inserted++;
            }
            break;
          }

          case "department": {
            const name = String(row.name || "").trim();
            if (!name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            const [existing] = await db.select().from(department).where(eq(department.name, name)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(department).values({ name });
              inserted++;
            }
            break;
          }

          case "kitCategory": {
            const name = String(row.name || "").trim();
            if (!name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            const [existing] = await db.select().from(kitCategory).where(eq(kitCategory.name, name)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(kitCategory).values({ name });
              inserted++;
            }
            break;
          }

          case "kitClass": {
            const name = String(row.name || "").trim();
            if (!name) {
              errors.push(`Row ${rowNum}: Name is required`);
              continue;
            }
            const [existing] = await db.select().from(kitClass).where(eq(kitClass.name, name)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(kitClass).values({ name });
              inserted++;
            }
            break;
          }

          case "channel": {
            const code = String(row.code || "").trim();
            if (!code) {
              errors.push(`Row ${rowNum}: Code is required`);
              continue;
            }
            const [existing] = await db.select().from(channel).where(eq(channel.code, code)).limit(1);
            if (existing) {
              await db.update(channel).set({
                name: row.name || null,
              }).where(eq(channel.channelId, existing.channelId));
              updated++;
            } else {
              await db.insert(channel).values({
                code,
                name: row.name || null,
              });
              inserted++;
            }
            break;
          }

          case "gender": {
            const genderName = String(row.genderName || "").trim();
            if (!genderName) {
              errors.push(`Row ${rowNum}: Gender Name is required`);
              continue;
            }
            const [existing] = await db.select().from(gender).where(eq(gender.genderName, genderName)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(gender).values({ genderName });
              inserted++;
            }
            break;
          }

          case "taxClass": {
            const taxClassName = String(row.taxClassName || "").trim();
            if (!taxClassName) {
              errors.push(`Row ${rowNum}: Tax Class Name is required`);
              continue;
            }
            const [existing] = await db.select().from(taxClass).where(eq(taxClass.taxClassName, taxClassName)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(taxClass).values({ taxClassName });
              inserted++;
            }
            break;
          }

          case "productType": {
            const productTypeName = String(row.productTypeName || "").trim();
            if (!productTypeName) {
              errors.push(`Row ${rowNum}: Product Type Name is required`);
              continue;
            }
            const [existing] = await db.select().from(productType).where(eq(productType.productTypeName, productTypeName)).limit(1);
            if (existing) {
              updated++;
            } else {
              await db.insert(productType).values({ productTypeName });
              inserted++;
            }
            break;
          }

          case "currency": {
            const code = String(row.code || "").trim();
            if (!code) {
              errors.push(`Row ${rowNum}: Code is required`);
              continue;
            }
            const [existing] = await db.select().from(currency).where(eq(currency.code, code)).limit(1);
            if (existing) {
              await db.update(currency).set({
                name: row.name || null,
                symbol: row.symbol || null,
                minorUnit: row.minorUnit ? Number(row.minorUnit) : null,
                enabled: row.enabled !== undefined ? (String(row.enabled).toLowerCase() === "true" || row.enabled === "1") : null,
              }).where(eq(currency.currencyId, existing.currencyId));
              updated++;
            } else {
              await db.insert(currency).values({
                code,
                name: row.name || null,
                symbol: row.symbol || null,
                minorUnit: row.minorUnit ? Number(row.minorUnit) : null,
                enabled: row.enabled !== undefined ? (String(row.enabled).toLowerCase() === "true" || row.enabled === "1") : true,
              });
              inserted++;
            }
            break;
          }

          default:
            throw new Error(`Unsupported table type: ${tableType}`);
        }
      } catch (err: any) {
        errors.push(`Row ${rowNum}: ${err.message || "Unknown error"}`);
      }
    }

    return { inserted, updated, errors };
  }

  async getProductImages(productId: number): Promise<any[]> {
    const images = await db
      .select({
        imageId: imageAsset.imageId,
        productId: imageAsset.productId,
        role: imageAsset.role,
        url: imageAsset.url,
        label: imageAsset.label,
        sortOrder: imageAsset.sortOrder,
      })
      .from(imageAsset)
      .where(eq(imageAsset.productId, productId))
      .orderBy(asc(imageAsset.sortOrder));
    return images;
  }

  async getAllImages(options?: { limit?: number; offset?: number; search?: string; role?: string }): Promise<{ images: any[]; total: number }> {
    const limit = options?.limit ?? 50;
    const offset = options?.offset ?? 0;
    const search = options?.search?.trim() || "";
    const role = options?.role?.trim() || "";

    const conditions: any[] = [];
    if (search) {
      conditions.push(
        or(
          ilike(product.productSku, `%${search}%`),
          ilike(product.productDescription, `%${search}%`),
          ilike(imageAsset.url, `%${search}%`)
        )
      );
    }
    if (role) {
      conditions.push(eq(imageAsset.role, role));
    }

    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;

    const baseQuery = db
      .select({
        imageId: imageAsset.imageId,
        productId: imageAsset.productId,
        role: imageAsset.role,
        url: imageAsset.url,
        label: imageAsset.label,
        sortOrder: imageAsset.sortOrder,
        productSku: product.productSku,
        productDescription: product.productDescription,
      })
      .from(imageAsset)
      .leftJoin(product, eq(imageAsset.productId, product.productId));

    const images = whereCondition
      ? await baseQuery.where(whereCondition).orderBy(asc(imageAsset.sortOrder)).limit(limit).offset(offset)
      : await baseQuery.orderBy(asc(imageAsset.sortOrder)).limit(limit).offset(offset);

    const countQuery = db
      .select({ count: sql<number>`count(*)::int` })
      .from(imageAsset)
      .leftJoin(product, eq(imageAsset.productId, product.productId));

    const [countResult] = whereCondition
      ? await countQuery.where(whereCondition)
      : await countQuery;

    const distinctRoles = await db
      .selectDistinct({ role: imageAsset.role })
      .from(imageAsset)
      .orderBy(asc(imageAsset.role));

    return {
      images,
      total: countResult?.count ?? 0,
      roles: distinctRoles.map(r => r.role),
    } as any;
  }

  async importImagesCsv(rows: Array<Record<string, string>>): Promise<{ imported: number; skipped: number; errors: string[] }> {
    let imported = 0;
    let skipped = 0;
    const errors: string[] = [];

    const roleMappings: Array<{ key: string; role: string }> = [
      { key: "base_image", role: "base" },
      { key: "baseImage", role: "base" },
      { key: "small_image", role: "small" },
      { key: "smallImage", role: "small" },
      { key: "thumbnail_image", role: "thumbnail" },
      { key: "thumbnailImage", role: "thumbnail" },
    ];

    const additionalKeys = ["additional_images", "additionalImages"];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const sku = (row.product_sku || row.productSku || row["Product SKU"] || row.sku || row.SKU || "").trim();
      if (!sku) {
        skipped++;
        continue;
      }

      const [matchedProduct] = await db
        .select({ productId: product.productId })
        .from(product)
        .where(eq(product.productSku, sku))
        .limit(1);

      let productId: number | null = matchedProduct ? Number(matchedProduct.productId) : null;

      if (!productId) {
        errors.push(`Row ${i + 1}: No product found for product SKU "${sku}"`);
        skipped++;
        continue;
      }

      const rowLabel = (row.label || row.Label || row.image_label || row.imageLabel || "").trim() || null;
      const imageEntries: Array<{ url: string; role: string; label: string | null }> = [];

      for (const { key, role } of roleMappings) {
        const rawValue = row[key];
        if (!rawValue || !String(rawValue).trim()) continue;
        const urls = String(rawValue).split(",").map(u => u.trim()).filter(Boolean);
        for (const url of urls) {
          imageEntries.push({ url, role, label: rowLabel });
        }
      }

      for (const key of additionalKeys) {
        const rawValue = row[key];
        if (!rawValue || !String(rawValue).trim()) continue;
        const urls = String(rawValue).split(",").map(u => u.trim()).filter(Boolean);
        for (const url of urls) {
          imageEntries.push({ url, role: "additional", label: rowLabel });
        }
      }

      if (imageEntries.length === 0) {
        skipped++;
        continue;
      }

      const existingImages = await db
        .select({ sortOrder: imageAsset.sortOrder })
        .from(imageAsset)
        .where(eq(imageAsset.productId, productId))
        .orderBy(asc(imageAsset.sortOrder));
      const usedOrders = new Set(existingImages.map(img => img.sortOrder ?? 0));
      let nextOrder = 1;

      for (const entry of imageEntries) {
        while (usedOrders.has(nextOrder)) nextOrder++;

        const [existing] = await db
          .select({ imageId: imageAsset.imageId })
          .from(imageAsset)
          .where(and(eq(imageAsset.productId, productId), eq(imageAsset.url, entry.url), eq(imageAsset.role, entry.role)))
          .limit(1);

        if (existing) {
          await db.update(imageAsset).set({ sortOrder: nextOrder, label: entry.label }).where(eq(imageAsset.imageId, existing.imageId));
        } else {
          await db.insert(imageAsset).values({ productId, url: entry.url, role: entry.role, label: entry.label, sortOrder: nextOrder });
        }
        usedOrders.add(nextOrder);
        nextOrder++;
        imported++;
      }

      try {
        await this.insertSyncQueueEntry({
          productId: Number(productId),
          productVariantId: null,
          operationType: "image_update",
        });
      } catch (e) {
        console.error("Failed to insert sync queue entry for image import:", e);
      }
    }

    return { imported, skipped, errors };
  }

  async createImage(data: { productId: number; url: string; role: string; label?: string | null }): Promise<any> {
    const existingImages = await db
      .select({ sortOrder: imageAsset.sortOrder })
      .from(imageAsset)
      .where(eq(imageAsset.productId, data.productId))
      .orderBy(asc(imageAsset.sortOrder));
    const usedOrders = new Set(existingImages.map(img => img.sortOrder ?? 0));
    let nextOrder = 1;
    while (usedOrders.has(nextOrder)) nextOrder++;

    const [created] = await db.insert(imageAsset).values({
      productId: data.productId,
      url: data.url,
      role: data.role,
      label: data.label ?? null,
      sortOrder: nextOrder,
    }).returning();

    try {
      await this.insertSyncQueueEntry({
        productId: Number(data.productId),
        productVariantId: null,
        operationType: "image_update",
      });
    } catch (e) {
      console.error("Failed to insert sync queue entry for image create:", e);
    }

    return created;
  }

  async deleteImage(imageId: number): Promise<void> {
    const [image] = await db
      .select({ productId: imageAsset.productId })
      .from(imageAsset)
      .where(eq(imageAsset.imageId, imageId))
      .limit(1);

    await db.delete(imageAsset).where(eq(imageAsset.imageId, imageId));

    if (image?.productId) {
      try {
        await this.insertSyncQueueEntry({
          productId: Number(image.productId),
          productVariantId: null,
          operationType: "image_delete",
        });
      } catch (e) {
        console.error("Failed to insert sync queue entry for image delete:", e);
      }
    }
  }

  async createSyncLog(data: InsertAlumioSyncLog): Promise<AlumioSyncLog> {
    const [log] = await db.insert(alumioSyncLog).values(data).returning();
    return log;
  }

  async getSyncLogs(options?: {
    limit?: number;
    offset?: number;
    operationType?: string;
    statusFilter?: string;
    skuSearch?: string;
  }): Promise<{ logs: AlumioSyncLog[]; total: number }> {
    const limit = options?.limit ?? 50;
    const offset = options?.offset ?? 0;

    const conditions = [];

    if (options?.operationType) {
      conditions.push(sql`EXISTS (SELECT 1 FROM jsonb_array_elements(${alumioSyncLog.operationType}) AS elem WHERE elem->>'operationType' = ${options.operationType})`);
    }

    if (options?.statusFilter === "success") {
      conditions.push(sql`${alumioSyncLog.httpStatusCode} >= 200 AND ${alumioSyncLog.httpStatusCode} < 300`);
    } else if (options?.statusFilter === "error") {
      conditions.push(sql`${alumioSyncLog.httpStatusCode} < 200 OR ${alumioSyncLog.httpStatusCode} >= 300`);
    }

    if (options?.skuSearch) {
      conditions.push(sql`EXISTS (SELECT 1 FROM unnest(COALESCE(${alumioSyncLog.skus}, ARRAY[]::text[])) AS s WHERE s ILIKE ${'%' + options.skuSearch + '%'})`);
    }

    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;

    const baseQuery = db.select().from(alumioSyncLog);
    const logs = whereCondition
      ? await baseQuery.where(whereCondition).orderBy(desc(alumioSyncLog.createdAt)).limit(limit).offset(offset)
      : await baseQuery.orderBy(desc(alumioSyncLog.createdAt)).limit(limit).offset(offset);

    const countQuery = db.select({ count: sql<number>`count(*)::int` }).from(alumioSyncLog);
    const [countResult] = whereCondition
      ? await countQuery.where(whereCondition)
      : await countQuery;

    return {
      logs,
      total: countResult?.count ?? 0,
    };
  }

  async insertSyncQueueEntry(entry: { productId: number; productVariantId?: number | null; operationType: string }): Promise<AlumioSyncQueue> {
    const [prod] = await db
      .select({ sync: product.sync })
      .from(product)
      .where(eq(product.productId, entry.productId))
      .limit(1);

    if (!prod || prod.sync !== true) {
      return {} as AlumioSyncQueue;
    }

    const variantId = entry.productVariantId ?? null;

    const variantCondition = variantId !== null
      ? eq(alumioSyncQueue.productVariantId, variantId)
      : isNull(alumioSyncQueue.productVariantId);

    const [existing] = await db
      .select()
      .from(alumioSyncQueue)
      .where(
        and(
          eq(alumioSyncQueue.productId, entry.productId),
          variantCondition,
          eq(alumioSyncQueue.operationType, entry.operationType),
          inArray(alumioSyncQueue.status, ["pending", "failed"]),
        ),
      )
      .limit(1);

    if (existing) {
      return existing;
    }

    const [row] = await db.insert(alumioSyncQueue).values({
      productId: entry.productId,
      productVariantId: variantId,
      operationType: entry.operationType,
      status: "pending",
    }).returning();
    return row;
  }

  async resyncProductWithVariants(productId: number): Promise<{ productEntry: AlumioSyncQueue; variantEntries: AlumioSyncQueue[] }> {
    const [prod] = await db
      .select({ sync: product.sync })
      .from(product)
      .where(eq(product.productId, productId))
      .limit(1);

    if (!prod || prod.sync !== true) {
      return { productEntry: {} as AlumioSyncQueue, variantEntries: [] };
    }

    return await db.transaction(async (tx) => {
      const [existingProduct] = await tx
        .select()
        .from(alumioSyncQueue)
        .where(
          and(
            eq(alumioSyncQueue.productId, productId),
            isNull(alumioSyncQueue.productVariantId),
            inArray(alumioSyncQueue.status, ["pending", "failed"]),
          ),
        )
        .limit(1);

      let productEntry: AlumioSyncQueue;
      if (existingProduct) {
        productEntry = existingProduct;
      } else {
        const [row] = await tx.insert(alumioSyncQueue).values({
          productId,
          productVariantId: null,
          operationType: "product_update",
          status: "pending",
        }).returning();
        productEntry = row;
      }

      const variants = await tx
        .select({ productVariantId: productVariant.productVariantId })
        .from(productVariant)
        .where(eq(productVariant.productId, productId));

      const variantEntries: AlumioSyncQueue[] = [];
      for (const v of variants) {
        const [existingVariant] = await tx
          .select()
          .from(alumioSyncQueue)
          .where(
            and(
              eq(alumioSyncQueue.productId, productId),
              eq(alumioSyncQueue.productVariantId, v.productVariantId),
              inArray(alumioSyncQueue.status, ["pending", "failed"]),
            ),
          )
          .limit(1);

        if (existingVariant) {
          variantEntries.push(existingVariant);
        } else {
          const [variantEntry] = await tx.insert(alumioSyncQueue).values({
            productId,
            productVariantId: v.productVariantId,
            operationType: "variant_update",
            status: "pending",
          }).returning();
          variantEntries.push(variantEntry);
        }
      }

      return { productEntry, variantEntries };
    });
  }

  async getSyncQueueEntries(options?: { status?: string; limit?: number; offset?: number }): Promise<{ entries: AlumioSyncQueue[]; total: number }> {
    const limit = options?.limit ?? 100;
    const offset = options?.offset ?? 0;

    const conditions = [];
    if (options?.status) {
      conditions.push(eq(alumioSyncQueue.status, options.status));
    }

    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;

    const baseQuery = db.select().from(alumioSyncQueue);
    const entries = whereCondition
      ? await baseQuery.where(whereCondition).orderBy(asc(alumioSyncQueue.createdAt)).limit(limit).offset(offset)
      : await baseQuery.orderBy(asc(alumioSyncQueue.createdAt)).limit(limit).offset(offset);

    const countQuery = db.select({ count: sql<number>`count(*)::int` }).from(alumioSyncQueue);
    const [countResult] = whereCondition
      ? await countQuery.where(whereCondition)
      : await countQuery;

    return {
      entries,
      total: countResult?.count ?? 0,
    };
  }

  async updateSyncQueueStatus(ids: number[], status: string): Promise<void> {
    if (ids.length === 0) return;
    const processedAt = status === "sent" || status === "failed" ? new Date() : null;
    await db
      .update(alumioSyncQueue)
      .set({ status, processedAt })
      .where(inArray(alumioSyncQueue.id, ids));
  }

  async createScheduledChange(input: {
    name: string;
    description?: string | null;
    scheduledAt: Date;
    endsAt?: Date | null;
    scopeType: string;
    scopeGroupId?: number | null;
    productIds?: number[];
    items: Array<{
      entityType: string;
      fieldName: string;
      newValue?: string | null;
      oldValue?: string | null;
      changeMode?: string | null;
      productId?: number;
    }>;
    createdBy?: number | null;
  }): Promise<ScheduledChange> {
    const [change] = await db.insert(scheduledChange).values({
      name: input.name,
      description: input.description ?? null,
      scheduledAt: input.scheduledAt,
      endsAt: input.endsAt ?? null,
      status: "pending",
      scopeType: input.scopeType,
      scopeGroupId: input.scopeGroupId ?? null,
      createdBy: input.createdBy ?? null,
    }).returning();

    const productIds = input.productIds ?? [];

    const perProductItems = input.items.filter((item) => item.productId != null);
    const globalItems = input.items.filter((item) => item.productId == null);

    const itemRows: Array<{
      scheduledChangeId: number;
      productId: number | null;
      variantId: number | null;
      entityType: string;
      fieldName: string;
      newValue: string | null;
      oldValue: string | null;
      changeMode: string | null;
      status: string;
    }> = [];

    for (const item of perProductItems) {
      itemRows.push({
        scheduledChangeId: change.id,
        productId: item.productId!,
        variantId: null,
        entityType: item.entityType,
        fieldName: item.fieldName,
        newValue: item.newValue ?? null,
        oldValue: item.oldValue ?? null,
        changeMode: item.changeMode ?? "absolute",
        status: "pending",
      });
    }

    if (globalItems.length > 0 && productIds.length > 0) {
      for (const pid of productIds) {
        for (const item of globalItems) {
          itemRows.push({
            scheduledChangeId: change.id,
            productId: pid,
            variantId: null,
            entityType: item.entityType,
            fieldName: item.fieldName,
            newValue: item.newValue ?? null,
            oldValue: item.oldValue ?? null,
            changeMode: item.changeMode ?? "absolute",
            status: "pending",
          });
        }
      }
    } else if (globalItems.length > 0 && input.scopeType === "group") {
      for (const item of globalItems) {
        itemRows.push({
          scheduledChangeId: change.id,
          productId: null,
          variantId: null,
          entityType: item.entityType,
          fieldName: item.fieldName,
          newValue: item.newValue ?? null,
          oldValue: item.oldValue ?? null,
          changeMode: item.changeMode ?? "absolute",
          status: "pending",
        });
      }
    }

    if (itemRows.length > 0) {
      await db.insert(scheduledChangeItem).values(itemRows);
    }

    return change;
  }

  async getScheduledChanges(filters?: { status?: string }): Promise<any[]> {
    const conditions = [];
    if (filters?.status) {
      conditions.push(eq(scheduledChange.status, filters.status));
    }

    const whereCondition = conditions.length > 0 ? and(...conditions) : undefined;

    const baseQuery = db
      .select({
        id: scheduledChange.id,
        name: scheduledChange.name,
        description: scheduledChange.description,
        scheduledAt: scheduledChange.scheduledAt,
        endsAt: scheduledChange.endsAt,
        status: scheduledChange.status,
        scopeType: scheduledChange.scopeType,
        scopeGroupId: scheduledChange.scopeGroupId,
        createdBy: scheduledChange.createdBy,
        createdAt: scheduledChange.createdAt,
        appliedAt: scheduledChange.appliedAt,
        revertedAt: scheduledChange.revertedAt,
        errorMessage: scheduledChange.errorMessage,
        creatorName: appUser.displayName,
        groupName: productGroup.name,
        itemCount: sql<number>`count(${scheduledChangeItem.id})::int`,
      })
      .from(scheduledChange)
      .leftJoin(appUser, eq(scheduledChange.createdBy, appUser.appUserId))
      .leftJoin(productGroup, eq(scheduledChange.scopeGroupId, productGroup.productGroupId))
      .leftJoin(scheduledChangeItem, eq(scheduledChange.id, scheduledChangeItem.scheduledChangeId))
      .groupBy(
        scheduledChange.id,
        appUser.displayName,
        productGroup.name,
      )
      .orderBy(desc(scheduledChange.createdAt));

    if (whereCondition) {
      return await baseQuery.where(whereCondition);
    }
    return await baseQuery;
  }

  async getScheduledChange(id: number): Promise<any | null> {
    const [row] = await db
      .select({
        id: scheduledChange.id,
        name: scheduledChange.name,
        description: scheduledChange.description,
        scheduledAt: scheduledChange.scheduledAt,
        endsAt: scheduledChange.endsAt,
        status: scheduledChange.status,
        scopeType: scheduledChange.scopeType,
        scopeGroupId: scheduledChange.scopeGroupId,
        createdBy: scheduledChange.createdBy,
        createdAt: scheduledChange.createdAt,
        updatedAt: scheduledChange.updatedAt,
        appliedAt: scheduledChange.appliedAt,
        revertedAt: scheduledChange.revertedAt,
        errorMessage: scheduledChange.errorMessage,
        creatorName: appUser.displayName,
        groupName: productGroup.name,
      })
      .from(scheduledChange)
      .leftJoin(appUser, eq(scheduledChange.createdBy, appUser.appUserId))
      .leftJoin(productGroup, eq(scheduledChange.scopeGroupId, productGroup.productGroupId))
      .where(eq(scheduledChange.id, id));

    return row ?? null;
  }

  async getScheduledChangeItems(scheduledChangeId: number): Promise<any[]> {
    return await db
      .select({
        id: scheduledChangeItem.id,
        scheduledChangeId: scheduledChangeItem.scheduledChangeId,
        productId: scheduledChangeItem.productId,
        variantId: scheduledChangeItem.variantId,
        entityType: scheduledChangeItem.entityType,
        fieldName: scheduledChangeItem.fieldName,
        newValue: scheduledChangeItem.newValue,
        oldValue: scheduledChangeItem.oldValue,
        changeMode: scheduledChangeItem.changeMode,
        status: scheduledChangeItem.status,
        errorMessage: scheduledChangeItem.errorMessage,
        productSku: product.productSku,
        productDescription: product.productDescription,
      })
      .from(scheduledChangeItem)
      .leftJoin(product, eq(scheduledChangeItem.productId, product.productId))
      .where(eq(scheduledChangeItem.scheduledChangeId, scheduledChangeId))
      .orderBy(asc(scheduledChangeItem.id));
  }

  async updateScheduledChange(id: number, updates: { name?: string; description?: string | null; scheduledAt?: Date }): Promise<ScheduledChange | null> {
    const setValues: any = { updatedAt: new Date() };
    if (updates.name !== undefined) setValues.name = updates.name;
    if (updates.description !== undefined) setValues.description = updates.description;
    if (updates.scheduledAt !== undefined) setValues.scheduledAt = updates.scheduledAt;

    const [row] = await db
      .update(scheduledChange)
      .set(setValues)
      .where(and(eq(scheduledChange.id, id), eq(scheduledChange.status, "pending")))
      .returning();

    return row ?? null;
  }

  async cancelScheduledChange(id: number): Promise<boolean> {
    const [row] = await db
      .update(scheduledChange)
      .set({ status: "cancelled", updatedAt: new Date() })
      .where(and(eq(scheduledChange.id, id), eq(scheduledChange.status, "pending")))
      .returning();

    return !!row;
  }

  async getDueScheduledChanges(): Promise<ScheduledChange[]> {
    return await db
      .select()
      .from(scheduledChange)
      .where(and(
        eq(scheduledChange.status, "pending"),
        lte(scheduledChange.scheduledAt, new Date()),
      ))
      .orderBy(asc(scheduledChange.scheduledAt));
  }

  async applyScheduledChangeItem(itemId: number, status: string, errorMessage?: string | null): Promise<void> {
    await db
      .update(scheduledChangeItem)
      .set({ status, errorMessage: errorMessage ?? null })
      .where(eq(scheduledChangeItem.id, itemId));
  }

  async markScheduledChangeApplied(id: number): Promise<void> {
    await db
      .update(scheduledChange)
      .set({ status: "applied", appliedAt: new Date(), updatedAt: new Date() })
      .where(eq(scheduledChange.id, id));
  }

  async markScheduledChangeFailed(id: number, errorMessage: string): Promise<void> {
    await db
      .update(scheduledChange)
      .set({ status: "failed", errorMessage, updatedAt: new Date() })
      .where(eq(scheduledChange.id, id));
  }

  async getWorkspaceSetting(key: string): Promise<any> {
    const [row] = await db
      .select({ value: workspaceSetting.value })
      .from(workspaceSetting)
      .where(eq(workspaceSetting.key, key))
      .limit(1);
    return row?.value ?? null;
  }

  async setWorkspaceSetting(key: string, value: any): Promise<void> {
    await db
      .insert(workspaceSetting)
      .values({ key, value, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: workspaceSetting.key,
        set: { value, updatedAt: new Date() },
      });
  }

  async getApiKeys(): Promise<ApiKey[]> {
    return db.select().from(apiKey).orderBy(desc(apiKey.createdAt));
  }

  async getApiKeyByHash(keyHash: string): Promise<ApiKey | undefined> {
    const [row] = await db
      .select()
      .from(apiKey)
      .where(eq(apiKey.keyHash, keyHash))
      .limit(1);
    return row;
  }

  async createApiKey(input: { name: string; keyHash: string; keyPrefix: string; scopes: string[]; createdBy?: number | null }): Promise<ApiKey> {
    const [row] = await db
      .insert(apiKey)
      .values({
        name: input.name,
        keyHash: input.keyHash,
        keyPrefix: input.keyPrefix,
        scopes: input.scopes,
        createdBy: input.createdBy ?? null,
      })
      .returning();
    return row;
  }

  async updateApiKey(apiKeyId: number, updates: { name?: string; scopes?: string[]; active?: boolean }): Promise<ApiKey | undefined> {
    const [row] = await db
      .update(apiKey)
      .set(updates)
      .where(eq(apiKey.apiKeyId, apiKeyId))
      .returning();
    return row;
  }

  async deleteApiKey(apiKeyId: number): Promise<void> {
    await db.delete(apiKey).where(eq(apiKey.apiKeyId, apiKeyId));
  }

  async touchApiKeyLastUsed(apiKeyId: number): Promise<void> {
    await db
      .update(apiKey)
      .set({ lastUsedAt: new Date() })
      .where(eq(apiKey.apiKeyId, apiKeyId));
  }
}

export const storage = new DatabaseStorage();
