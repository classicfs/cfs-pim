import "dotenv/config";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import type { NodePgDatabase } from "drizzle-orm/node-postgres";
import { Connector } from "@google-cloud/cloud-sql-connector";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import * as schema from "@shared/schema_v2";

const { Pool } = pg;

let pool: pg.Pool;
let db: NodePgDatabase<typeof schema>;
let dbReady: Promise<NodePgDatabase<typeof schema>>;
let connector: Connector | undefined;

function getRequiredEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
  return value;
}

function ensureServiceAccountFile(): void {
  const raw = process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON;
  if (!raw || process.env.GOOGLE_APPLICATION_CREDENTIALS) return;

  const filePath = path.join(os.tmpdir(), "gcp-service-account.json");
  fs.writeFileSync(filePath, raw, { encoding: "utf8", mode: 0o600 });
  process.env.GOOGLE_APPLICATION_CREDENTIALS = filePath;
}

async function initializeDatabase() {
  const schemaName = (process.env.DB_SCHEMA ?? "pim").toLowerCase();
  const searchPath = `"${schemaName}"`;

  if (process.env.CLOUD_SQL_CONNECTION_NAME) {
    ensureServiceAccountFile();
    connector = new Connector();

    const clientOpts = await connector.getOptions({
      instanceConnectionName: getRequiredEnv("CLOUD_SQL_CONNECTION_NAME"),
      ipType: (process.env.CLOUD_SQL_IP_TYPE as "PUBLIC" | "PRIVATE" | undefined) ?? "PUBLIC",
    });

    pool = new Pool({
      ...clientOpts,
      user: getRequiredEnv("DB_USER"),
      password: getRequiredEnv("DB_PASSWORD"),
      database: getRequiredEnv("DB_NAME"),
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
      options: `-c search_path=${searchPath}`,
    });
  } else {
    const databaseUrl = getRequiredEnv("DATABASE_URL");
    // Allow SSL connections when the server uses a self-signed or untrusted cert.
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

    const isLocalhost = databaseUrl.includes("localhost") || databaseUrl.includes("127.0.0.1");

    pool = new Pool({
      connectionString: databaseUrl,
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
      options: `-c search_path=${searchPath}`,
      ...(isLocalhost ? {} : { ssl: { rejectUnauthorized: false } }),
    });
  }

  const client = await pool.connect();
  try {
    await client.query("SELECT 1");
    console.log("✓ Successfully connected to PostgreSQL");

    // Skip v1 schema migrations when running against pim_v2
    if (schemaName === "pim") {
    const constraintCheck = await client.query(
      `SELECT pg_get_constraintdef(oid) AS def FROM pg_constraint WHERE conname = 'import_job_status_check'`
    );
    if (constraintCheck.rows.length > 0 && !constraintCheck.rows[0].def.includes("processing")) {
      await client.query(`ALTER TABLE import_job DROP CONSTRAINT import_job_status_check`);
      await client.query(
        `ALTER TABLE import_job ADD CONSTRAINT import_job_status_check CHECK (status IN ('uploaded', 'validated', 'processing', 'applied', 'failed'))`
      );
      console.log("✓ Updated import_job_status_check constraint to include 'processing'");
    }

    const rowConstraintCheck = await client.query(
      `SELECT pg_get_constraintdef(oid) AS def FROM pg_constraint WHERE conname = 'import_row_row_status_check'`
    );
    if (rowConstraintCheck.rows.length > 0 && !rowConstraintCheck.rows[0].def.includes("error")) {
      await client.query(`ALTER TABLE import_row DROP CONSTRAINT import_row_row_status_check`);
      await client.query(
        `ALTER TABLE import_row ADD CONSTRAINT import_row_row_status_check CHECK (row_status IN ('pending', 'invalid', 'applied', 'error'))`
      );
      console.log("✓ Updated import_row_row_status_check constraint to include 'error'");
    }
    await client.query(
      `ALTER TABLE pim.product ADD COLUMN IF NOT EXISTS sync BOOLEAN DEFAULT false`
    );

    const styleColType = await client.query(
      `SELECT data_type FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'product' AND column_name = 'product_style'`
    );
    if (styleColType.rows.length > 0 && styleColType.rows[0].data_type === 'integer') {
      await client.query(`
        ALTER TABLE pim.product ALTER COLUMN product_style TYPE text
        USING CASE
          WHEN product_style = 1 THEN 'Home'
          WHEN product_style = 2 THEN 'Away'
          WHEN product_style = 3 THEN 'Third'
          WHEN product_style = 4 THEN 'Training'
          WHEN product_style = 5 THEN 'Goalkeeper'
          WHEN product_style = 6 THEN 'Special'
          WHEN product_style = 7 THEN 'Retro'
          WHEN product_style = 8 THEN 'Classic'
          WHEN product_style = 9 THEN 'Replica'
          WHEN product_style = 10 THEN 'Authentic'
          ELSE product_style::text
        END
      `);
      console.log("✓ Migrated product_style column from integer to text");
    }

    await client.query(
      `ALTER TABLE pim.attribute_def ADD COLUMN IF NOT EXISTS magento_sync BOOLEAN DEFAULT false`
    );

    await client.query(
      `ALTER TABLE pim.attribute_def ADD COLUMN IF NOT EXISTS magento_scope TEXT DEFAULT 'global'`
    );
    await client.query(
      `UPDATE pim.attribute_def SET magento_scope = 'global' WHERE magento_scope IS NULL OR btrim(magento_scope) = ''`
    );
    const magentoScopeNotNull = await client.query(
      `SELECT is_nullable FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'attribute_def' AND column_name = 'magento_scope'`
    );
    if (magentoScopeNotNull.rows.length > 0 && magentoScopeNotNull.rows[0].is_nullable === 'YES') {
      await client.query(`ALTER TABLE pim.attribute_def ALTER COLUMN magento_scope SET NOT NULL`);
    }
    const magentoScopeConstraint = await client.query(
      `SELECT 1 FROM pg_constraint WHERE conname = 'attribute_def_magento_scope_check'`
    );
    if (magentoScopeConstraint.rows.length === 0) {
      await client.query(
        `ALTER TABLE pim.attribute_def ADD CONSTRAINT attribute_def_magento_scope_check CHECK (lower(magento_scope) IN ('global', 'website', 'store_view'))`
      );
    }

    await client.query(
      `ALTER TABLE pim.image_asset ADD COLUMN IF NOT EXISTS label TEXT`
    );

    await client.query(
      `ALTER TABLE pim.scheduled_change ADD COLUMN IF NOT EXISTS ends_at TIMESTAMP`
    );
    await client.query(
      `ALTER TABLE pim.scheduled_change ADD COLUMN IF NOT EXISTS reverted_at TIMESTAMP`
    );
    await client.query(
      `ALTER TABLE pim.scheduled_change_item ADD COLUMN IF NOT EXISTS change_mode TEXT DEFAULT 'absolute'`
    );

    const imageRoleConstraint = await client.query(
      `SELECT pg_get_constraintdef(oid) AS def FROM pg_constraint WHERE conname = 'image_asset_role_check'`
    );
    if (imageRoleConstraint.rows.length > 0) {
      const currentDef = imageRoleConstraint.rows[0].def || "";
      if (!currentDef.includes("additional") || !currentDef.includes("base") || !currentDef.includes("small")) {
        await client.query(`ALTER TABLE image_asset DROP CONSTRAINT image_asset_role_check`);
        await client.query(
          `ALTER TABLE image_asset ADD CONSTRAINT image_asset_role_check CHECK (role IN ('base', 'small', 'thumbnail', 'additional', 'swatch'))`
        );
        console.log("✓ Updated image_asset_role_check constraint to include all image scopes");
      }
    }

    await client.query(`
      CREATE TABLE IF NOT EXISTS pim.scheduled_change (
        id BIGSERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        scheduled_at TIMESTAMP NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        scope_type TEXT NOT NULL,
        scope_group_id BIGINT REFERENCES pim.product_group(product_group_id),
        created_by BIGINT REFERENCES pim.app_user(app_user_id),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        applied_at TIMESTAMP,
        error_message TEXT
      )
    `);
    await client.query('CREATE INDEX IF NOT EXISTS scheduled_change_status_idx ON pim.scheduled_change(status)');
    await client.query('CREATE INDEX IF NOT EXISTS scheduled_change_scheduled_at_idx ON pim.scheduled_change(scheduled_at)');

    await client.query(`
      CREATE TABLE IF NOT EXISTS pim.scheduled_change_item (
        id BIGSERIAL PRIMARY KEY,
        scheduled_change_id BIGINT NOT NULL REFERENCES pim.scheduled_change(id),
        product_id BIGINT REFERENCES pim.product(product_id),
        variant_id BIGINT REFERENCES pim.product_variant(product_variant_id),
        entity_type TEXT NOT NULL,
        field_name TEXT NOT NULL,
        new_value TEXT,
        old_value TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        error_message TEXT
      )
    `);
    await client.query('CREATE INDEX IF NOT EXISTS scheduled_change_item_change_idx ON pim.scheduled_change_item(scheduled_change_id)');

    const scopeConstraint = await client.query(
      `SELECT 1 FROM pg_constraint WHERE conname = 'attribute_def_scope_check'`
    );
    if (scopeConstraint.rows.length === 0) {
      await client.query(
        `UPDATE pim.attribute_def SET scope = 'Parent' WHERE LOWER(scope) IN ('product', 'parent')`
      );
      await client.query(
        `UPDATE pim.attribute_def SET scope = 'Variant' WHERE LOWER(scope) IN ('variant', 'child')`
      );
      await client.query(
        `UPDATE pim.attribute_def SET scope = NULL WHERE scope IS NOT NULL AND scope NOT IN ('Parent', 'Variant')`
      );
      await client.query(
        `ALTER TABLE pim.attribute_def ADD CONSTRAINT attribute_def_scope_check CHECK (scope IN ('Parent', 'Variant'))`
      );
      console.log("✓ Added scope check constraint to attribute_def (Parent/Variant only)");
    }

    const pgmColCheck = await client.query(
      `SELECT 1 FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'product_group_member' AND column_name = 'product_group_member_id'`
    );
    if (pgmColCheck.rows.length === 0) {
      const pgmPkCheck = await client.query(
        `SELECT conname FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace WHERE n.nspname = 'pim' AND c.conrelid = 'pim.product_group_member'::regclass AND c.contype = 'p'`
      );
      if (pgmPkCheck.rows.length > 0) {
        const pkName = pgmPkCheck.rows[0].conname;
        await client.query(
          `ALTER TABLE pim.product_group_member DROP CONSTRAINT "${pkName}"`
        );
      }
      await client.query(
        `ALTER TABLE pim.product_group_member ADD COLUMN product_group_member_id bigserial PRIMARY KEY`
      );
      console.log("✓ Replaced composite PK with surrogate key on product_group_member");
    }
    await client.query(
      `ALTER TABLE pim.product_group_member ADD COLUMN IF NOT EXISTS start_date timestamp`
    );
    await client.query(
      `ALTER TABLE pim.product_group_member ADD COLUMN IF NOT EXISTS end_date timestamp`
    );
    await client.query(
      `ALTER TABLE pim.product_group_member ADD COLUMN IF NOT EXISTS live boolean NOT NULL DEFAULT true`
    );

    await client.query(`
      CREATE TABLE IF NOT EXISTS pim.workspace_setting (
        key TEXT PRIMARY KEY,
        value JSONB NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);
    await client.query(`
      INSERT INTO pim.workspace_setting (key, value) VALUES (
        'sync_required_fields',
        '["productDescription","brandId","productTypeId","genderId","productColourId"]'::jsonb
      ) ON CONFLICT (key) DO NOTHING
    `);

    // ── EAV store-scoped attributes migration ──────────────────────
    // 1. Drop scope column from attribute_def (no longer needed after flattening)
    const scopeColExists = await client.query(
      `SELECT 1 FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'attribute_def' AND column_name = 'scope'`
    );
    if (scopeColExists.rows.length > 0) {
      // Drop the scope check constraint first
      const scopeConstraintExists = await client.query(
        `SELECT 1 FROM pg_constraint WHERE conname = 'attribute_def_scope_check'`
      );
      if (scopeConstraintExists.rows.length > 0) {
        await client.query(`ALTER TABLE pim.attribute_def DROP CONSTRAINT attribute_def_scope_check`);
      }
      await client.query(`ALTER TABLE pim.attribute_def DROP COLUMN scope`);
      console.log("✓ Dropped scope column from attribute_def");
    }

    // 2. Add surrogate PK and store_id to product_attribute_val
    const pavSurrogatePk = await client.query(
      `SELECT 1 FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'product_attribute_val' AND column_name = 'product_attribute_val_id'`
    );
    if (pavSurrogatePk.rows.length === 0) {
      // Drop old composite PK
      const pavPkCheck = await client.query(
        `SELECT conname FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace WHERE n.nspname = 'pim' AND c.conrelid = 'pim.product_attribute_val'::regclass AND c.contype = 'p'`
      );
      if (pavPkCheck.rows.length > 0) {
        await client.query(`ALTER TABLE pim.product_attribute_val DROP CONSTRAINT "${pavPkCheck.rows[0].conname}"`);
      }
      // Add surrogate PK
      await client.query(`ALTER TABLE pim.product_attribute_val ADD COLUMN product_attribute_val_id BIGSERIAL PRIMARY KEY`);
      // Add store_id column (nullable — NULL means global/default)
      await client.query(`ALTER TABLE pim.product_attribute_val ADD COLUMN store_id BIGINT REFERENCES pim.store(store_id)`);
      // Create unique index to enforce one value per product+attribute+store (treating NULL store_id as 0)
      await client.query(`CREATE UNIQUE INDEX uq_pav_product_attribute_store ON pim.product_attribute_val (product_id, attribute_id, COALESCE(store_id, 0))`);
      // Add supporting indexes
      await client.query(`CREATE INDEX IF NOT EXISTS idx_product_attribute_val_store_id ON pim.product_attribute_val (store_id) WHERE store_id IS NOT NULL`);
      console.log("✓ Migrated product_attribute_val: added surrogate PK, store_id, and unique index");
    }

    // ── End EAV store-scoped migration ───────────────────────────

    // Seed Classic import EAV attribute definitions (idempotent — runs every startup)
    const classicAttrs = [
      { code: 'url_key', label: 'URL Key', dataType: 'text', magentoScope: 'store_view' },
      { code: 'meta_description', label: 'Meta Description', dataType: 'text', magentoScope: 'store_view' },
      { code: 'item', label: 'Item (Group SKU Prefix)', dataType: 'text', magentoScope: 'global' },
      { code: 'msi_source_code', label: 'MSI Source Code', dataType: 'text', magentoScope: 'global' },
      { code: 'description_classic_size_info', label: 'Classic Size Info', dataType: 'text', magentoScope: 'global' },
      { code: 'features_data', label: 'Features Data', dataType: 'json', magentoScope: 'global' },
      { code: 'b2c_pc_code', label: 'B2C PC Code', dataType: 'text', magentoScope: 'global' },
      { code: 'b2b_pc_code', label: 'B2B PC Code', dataType: 'text', magentoScope: 'global' },
      { code: 'barcode_new', label: 'Barcode New', dataType: 'text', magentoScope: 'global' },
      { code: 'kidsoradults', label: 'Kids or Adults', dataType: 'text', magentoScope: 'global' },
      { code: 'listeradd', label: 'Lister Add', dataType: 'text', magentoScope: 'global' },
      { code: 'packaging', label: 'Packaging', dataType: 'text', magentoScope: 'global' },
      { code: 'product_buying_status', label: 'Product Buying Status', dataType: 'text', magentoScope: 'global' },
      { code: 'source', label: 'Source', dataType: 'text', magentoScope: 'global' },
      { code: 'internal_comments', label: 'Internal Comments', dataType: 'text', magentoScope: 'global' },
      { code: 'version', label: 'Version', dataType: 'text', magentoScope: 'global' },
      { code: 'sleeve_length', label: 'Sleeve Length', dataType: 'text', magentoScope: 'global' },
      { code: 'features', label: 'Features', dataType: 'text', magentoScope: 'global' },
      { code: 'usedprintadded', label: 'Used Print Added', dataType: 'text', magentoScope: 'global' },
      { code: 'productcomment', label: 'Product Comment', dataType: 'text', magentoScope: 'global' },
      { code: 'purchasedate', label: 'Purchase Date', dataType: 'text', magentoScope: 'global' },
      { code: 'commodity_description', label: 'Commodity Description', dataType: 'text', magentoScope: 'global' },
      { code: 'description_notes', label: 'Description Notes', dataType: 'text', magentoScope: 'global' },
      { code: 'tax_class_name', label: 'Tax Class Name', dataType: 'text', magentoScope: 'store_view' },
    ];
    for (const attr of classicAttrs) {
      await client.query(
        `INSERT INTO pim.attribute_def (code, label, data_type, magento_sync, magento_scope) VALUES ($1, $2, $3, false, $4) ON CONFLICT (code) DO NOTHING`,
        [attr.code, attr.label, attr.dataType, attr.magentoScope]
      );
    }
    console.log("✓ Seeded Classic import EAV attribute definitions");

    const websiteCodeCol = await client.query(
      `SELECT 1 FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'store' AND column_name = 'website_code'`
    );
    if (websiteCodeCol.rows.length === 0) {
      await client.query(`ALTER TABLE pim.store ADD COLUMN website_code TEXT`);
      console.log("✓ Added website_code column to store table");
    }
    await client.query(`UPDATE pim.store SET website_code = CASE code WHEN 'LDN' THEN 'LDN_SHOP' WHEN 'MCR' THEN 'MCRSHOP' WHEN 'NYC' THEN 'RETAIL' WHEN 'MMI' THEN 'RETAIL' WHEN 'LAX' THEN 'PLACEHOLDER' WHEN 'LDN2' THEN 'PLACEHOLDER' WHEN 'US' THEN 'US' WHEN 'EU' THEN 'EU' WHEN 'DEFAULT' THEN 'BASE' ELSE 'PLACEHOLDER' END WHERE website_code IS NULL`);
    const notNullCheck = await client.query(
      `SELECT is_nullable FROM information_schema.columns WHERE table_schema = 'pim' AND table_name = 'store' AND column_name = 'website_code'`
    );
    if (notNullCheck.rows.length > 0 && notNullCheck.rows[0].is_nullable === 'YES') {
      await client.query(`ALTER TABLE pim.store ALTER COLUMN website_code SET NOT NULL`);
      console.log("✓ Set NOT NULL constraint on store.website_code");
    }

    await client.query(
      `ALTER TABLE pim.product ADD COLUMN IF NOT EXISTS tax_class_id integer REFERENCES pim.tax_class(tax_class_id)`
    );

    await client.query(`
      CREATE TABLE IF NOT EXISTS pim.api_key (
        api_key_id BIGSERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        key_hash TEXT NOT NULL UNIQUE,
        key_prefix TEXT NOT NULL,
        scopes TEXT[] NOT NULL DEFAULT '{}',
        active BOOLEAN NOT NULL DEFAULT true,
        last_used_at TIMESTAMP,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        created_by BIGINT REFERENCES pim.app_user(app_user_id)
      )
    `);

    } // end if (schemaName === "pim")

  } finally {
    client.release();
  }

  db = drizzle(pool, { schema });
  return db;
}

// Initialize database connection
dbReady = initializeDatabase();

export { db, pool, dbReady };

process.on("SIGINT", async () => {
  if (pool) await pool.end();
  if (connector) await connector.close();
  process.exit();
});

process.on("SIGTERM", async () => {
  if (pool) await pool.end();
  if (connector) await connector.close();
  process.exit();
});
