/**
 * processImport_v2.ts
 *
 * Rewritten processImport() for the flattened product schema.
 * Replaces the current ~1000 line function in storage.ts with a much simpler single-path flow.
 *
 * Key change: ONE code path for all rows. Every CSV row = one product row in the flat table.
 * No branching on hasProductSku vs hasVariantSku. No auto-creation of parent products.
 * No scope inference for attributes.
 *
 * TODO: Import the following from storage utils:
 *   - normalizeAttributeCode, inferAttributeValue, normalizeDataValues, removeNullishValues, normalizeNumberValue
 *   - parseAdditionalAttributes, labelizeAttributeCode
 *   - normalizeBooleanValue
 *   - importProgressTracker
 */

import {
  brands,
  category,
  attributeDef,
  productAttributeVal,
  appUser,
  importJob,
  importError,
  importRow,
  productCategory,
  productColour,
  productSizes,
  productTeamMeta,
  productType,
  condition,
  gender,
  currency,
  currencyConversionRate,
  store,
  storeCurrency,
  productStore,
  product,
  productPrice,
  productStock,
  warehouse,
  club,
  imageAsset,
  alumioSyncQueue,
  era,
} from "@shared/schema_v2";

import { db, dbReady } from "./db";
import { importProgressTracker } from "./storage";
import { and, asc, eq, sql, ne, or } from "drizzle-orm";

/**
 * MERGED field set: product + variant fields in flat table
 */
const PRODUCT_FIELDS = new Set([
  "productSku",
  "sku",
  "parentSku",
  "parent_sku",
  "productType",
  "product_type",
  "articleNumber",
  "article_number",
  "name",
  "productDescription",
  "product_description",
  "productColourId",
  "product_colour_id",
  "genderId",
  "gender_id",
  "brandId",
  "brand_id",
  "productTypeId",
  "product_type_id",
  "productStyle",
  "product_style",
  "sizeId",
  "size_id",
  "conditionId",
  "condition_id",
  "conditionDetail",
  "condition_detail",
  "barcode",
  "widthCm",
  "width_cm",
  "lengthCm",
  "length_cm",
  "weight",
  "depth",
  "costPrice",
  "cost_price",
  "averageCostPrice",
  "average_cost_price",
  "customerPrice",
  "customer_price",
  "printed",
  "magentoProductId",
  "magento_product_id",
  "composition",
  "countryOfManufacture",
  "country_of_manufacture",
  "commodityCode",
  "commodity_code",
  "imageCode",
  "image_code",
  "enabled",
  "sync",
  "eraId",
  "era_id",
  "taxClassId",
  "tax_class_id",
]);

const ATTRIBUTE_IGNORE_FIELDS = new Set([
  ...PRODUCT_FIELDS,
  "additionalAttributes",
  "additional_attributes",
  "club",
  "clubId",
  "club_id",
  "clubName",
  "club_name",
  "team",
  "teamId",
  "team_id",
  "teamName",
  "team_name",
  "brand",
  "brandName",
  "brand_name",
  "productType",
  "product_type",
  "productTypeName",
  "product_type_name",
  "colour",
  "color",
  "productColourName",
  "product_colour_name",
  "productColour",
  "product_colour",
  "gender",
  "genderName",
  "gender_name",
  "size",
  "sizeName",
  "size_name",
  "sizeShortName",
  "size_short_name",
  "sizeLongName",
  "size_long_name",
  "magentoSizeId",
  "magento_size_id",
  "era",
  "eraName",
  "era_name",
  "eraId",
  "productStyleName",
  "product_style_name",
  "productWebsites",
  "product_websites",
  "imageUrl",
  "image_url",
  "imageRole",
  "image_role",
  "imageSortOrder",
  "image_sort_order",
  "baseImage",
  "base_image",
  "smallImage",
  "small_image",
  "thumbnailImage",
  "thumbnail_image",
  "additionalImages",
  "additional_images",
  "categories",
  "category",
  "_imageFormat",
  "label",
  "Label",
  "image_label",
  "imageLabel",
  "configurableVariations",
  "configurable_variations",
  "qty",
  "stock",
  "stockQty",
  "stock_qty",
  "quantity",
  "season",
  "seasonId",
  "season_id",
  "seasonName",
  "season_name",
  "condition",
  "conditionName",
  "condition_name",
  "taxClassName",
  "tax_class_name",
  "productVariantSku",
  "product_variant_sku",
  "enabled",
  "printed",
  "sync",
  "storeViewCode",
  "store_view_code",
]);

const INTEGER_FIELDS = new Set([
  "productColourId",
  "genderId",
  "brandId",
  "productTypeId",
  "sizeId",
  "conditionId",
  "widthCm",
  "lengthCm",
  "magentoProductId",
  "eraId",
  "taxClassId",
]);

const DECIMAL_FIELDS = new Set([
  "weight",
  "depth",
  "costPrice",
  "averageCostPrice",
  "customerPrice",
]);

const BOOLEAN_FIELDS = new Set(["enabled", "printed", "sync"]);

const PRICE_COLUMN_REGEX = /^(price|retailPrice|retail_price|specialPrice|costPrice|special_price|cost_price|specialRetailPrice|special_retail_price)[-_]?[a-zA-Z]{3}$/i;

function shouldIgnoreAsAttribute(key: string): boolean {
  if (ATTRIBUTE_IGNORE_FIELDS.has(key)) return true;
  if (PRICE_COLUMN_REGEX.test(key)) return true;
  return false;
}

/**
 * PRODUCT_STYLE mapping (hardcoded reference)
 */
const PRODUCT_STYLE_ID_TO_NAME: Record<number, string> = {
  1: "Home",
  2: "Away",
  3: "Third",
  4: "Training",
  5: "Goalkeeper",
  6: "Special",
  7: "Retro",
  8: "Classic",
  9: "Replica",
  10: "Authentic",
};

const PRODUCT_STYLE_VALID_NAMES = new Set(
  Object.values(PRODUCT_STYLE_ID_TO_NAME).map((n) => n.toLowerCase())
);

function parseImportJobId(batchId: string): number | null {
  const id = Number(batchId);
  return isNaN(id) ? null : id;
}

/**
 * Main import function for v2 flattened schema
 */
export async function processImportV2(batchId: string): Promise<void> {
  console.log(`[ImportV2] Starting processImportV2 for batchId=${batchId}`);
  await dbReady; // ensure DB is initialised before any queries
  const importJobId = parseImportJobId(batchId);
  if (!importJobId) {
    console.log(`[ImportV2] Invalid importJobId from batchId=${batchId}`);
    return;
  }

  try {
    // Load attribute definitions
    const attributeDefs = await db
      .select({
        attributeId: attributeDef.attributeId,
        code: attributeDef.code,
        dataType: attributeDef.dataType,
        label: attributeDef.label,
      })
      .from(attributeDef);

    const attributeDefMap = new Map<
      string,
      (typeof attributeDefs[number]) & { attributeId: number }
    >();
    const attributeDefById = new Map<
      number,
      (typeof attributeDefs[number]) & { attributeId: number }
    >();

    for (const def of attributeDefs) {
      const normalizedCode = def.code
        ? normalizeAttributeCode(def.code)
        : "";
      const normalizedKey = normalizedCode
        ? normalizedCode.toLowerCase()
        : "";
      if (!normalizedKey) continue;
      const normalizedDef = {
        ...def,
        attributeId: Number(def.attributeId),
        code: normalizedCode,
      };
      attributeDefMap.set(normalizedKey, normalizedDef);
      attributeDefById.set(Number(def.attributeId), normalizedDef);
    }

    // Query pending import rows for the batch
    const rows = await db
      .select({
        importRowId: importRow.importRowId,
        rowNumber: importRow.rowNumber,
        rowStatus: importRow.rowStatus,
        rowRaw: importRow.rowRaw,
      })
      .from(importRow)
      .where(
        and(
          eq(importRow.importJobId, importJobId),
          eq(importRow.rowStatus, "pending")
        )
      )
      .orderBy(asc(importRow.rowNumber));

    let appliedRows = 0;
    let errorRows = 0;
    const now = new Date();

    // Count validation-phase invalid rows
    const [invalidRowCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(importRow)
      .where(
        and(
          eq(importRow.importJobId, importJobId),
          eq(importRow.rowStatus, "invalid")
        )
      );
    const validationInvalidRows = invalidRowCount?.count ?? 0;

    /**
     * Resolve helper functions (reused from current implementation)
     */

    const resolveGenderId = async (value: any): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const [existing] = await db
        .select({ genderId: gender.genderId })
        .from(gender)
        .where(eq(gender.genderName, String(value).trim()))
        .limit(1);
      if (existing) return Number(existing.genderId);
      const [created] = await db
        .insert(gender)
        .values({ genderName: String(value).trim() })
        .returning({ genderId: gender.genderId });
      return created ? Number(created.genderId) : null;
    };

    const resolveProductStyle = (value: any): string | null => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        const name = PRODUCT_STYLE_ID_TO_NAME[Number(value)];
        return name ?? null;
      }
      const trimmed = String(value).trim();
      if (PRODUCT_STYLE_VALID_NAMES.has(trimmed.toLowerCase())) {
        const entry = Object.values(PRODUCT_STYLE_ID_TO_NAME).find(
          (n) => n.toLowerCase() === trimmed.toLowerCase()
        );
        return entry ?? trimmed;
      }
      return trimmed;
    };

    const resolveEraId = async (value: any): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ eraId: era.eraId })
        .from(era)
        .where(sql`lower(${era.name}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.eraId);
      return null;
    };

    const resolveBrandId = async (value: any): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ brandId: brands.brandId })
        .from(brands)
        .where(sql`lower(${brands.brandName}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.brandId);
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${brands.brandId})::int` })
        .from(brands);
      const nextId = (row?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(brands)
        .values({ brandId: nextId, brandName: trimmed })
        .returning({ brandId: brands.brandId });
      return created ? Number(created.brandId) : null;
    };

    const resolveProductTypeId = async (
      value: any
    ): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ productTypeId: productType.productTypeId })
        .from(productType)
        .where(
          sql`lower(${productType.productTypeName}) = lower(${trimmed})`
        )
        .limit(1);
      if (existing) return Number(existing.productTypeId);
      const [row] = await db
        .select({ maxId: sql<number>`MAX(${productType.productTypeId})::int` })
        .from(productType);
      const nextId = (row?.maxId ?? 0) + 1;
      const [created] = await db
        .insert(productType)
        .values({ productTypeId: nextId, productTypeName: trimmed })
        .returning({ productTypeId: productType.productTypeId });
      return created ? Number(created.productTypeId) : null;
    };

    const resolveProductColourId = async (
      value: any,
      brandId?: number | null
    ): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const nameMatch = sql`lower(${productColour.magentoColourName}) = lower(${trimmed})`;
      const brandMatch =
        brandId !== null && brandId !== undefined
          ? sql`${productColour.brandId} = ${brandId}`
          : undefined;
      const [existing] = await db
        .select({ productColourId: productColour.productColourId })
        .from(productColour)
        .where(brandMatch ? and(nameMatch, brandMatch) : nameMatch)
        .limit(1);
      if (existing) return Number(existing.productColourId);
      let brandColourId: number | null = null;
      if (brandId !== null && brandId !== undefined) {
        const [row] = await db
          .select({ maxId: sql<number>`MAX(${productColour.brandColourId})::int` })
          .from(productColour)
          .where(eq(productColour.brandId, brandId));
        brandColourId = (row?.maxId ?? 0) + 1;
      }
      const [created] = await db
        .insert(productColour)
        .values({
          magentoColourName: trimmed,
          brandId: brandId ?? null,
          brandColourId,
        })
        .returning({ productColourId: productColour.productColourId });
      return created ? Number(created.productColourId) : null;
    };

    const resolveSizeId = async (
      value: any,
      sizeNames: { shortName?: string | null; longName?: string | null }
    ): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }

      const raw = String(value).trim();
      const numeric = /^\d+$/.test(raw) ? Number(raw) : null;

      if (numeric !== null) {
        const [existingById] = await db
          .select({ sizeId: productSizes.sizeId })
          .from(productSizes)
          .where(eq(productSizes.sizeId, numeric))
          .limit(1);
        if (existingById) return Number(existingById.sizeId);

        const [existingByMagento] = await db
          .select({ sizeId: productSizes.sizeId })
          .from(productSizes)
          .where(eq(productSizes.magentoSizeId, numeric))
          .limit(1);
        if (existingByMagento) return Number(existingByMagento.sizeId);

        const [created] = await db
          .insert(productSizes)
          .values({
            magentoSizeId: numeric,
            magentoSizeShortName: sizeNames.shortName ?? null,
            magentoSizeLongName: sizeNames.longName ?? null,
          })
          .returning({ sizeId: productSizes.sizeId });
        return created ? Number(created.sizeId) : null;
      }

      const trimmed = raw;
      const [existingByName] = await db
        .select({ sizeId: productSizes.sizeId })
        .from(productSizes)
        .where(
          or(
            sql`lower(${productSizes.magentoSizeShortName}) = lower(${trimmed})`,
            sql`lower(${productSizes.magentoSizeLongName}) = lower(${trimmed})`
          )
        )
        .limit(1);
      if (existingByName) return Number(existingByName.sizeId);

      const [created] = await db
        .insert(productSizes)
        .values({
          magentoSizeShortName: sizeNames.shortName ?? trimmed,
          magentoSizeLongName: sizeNames.longName ?? trimmed,
        })
        .returning({ sizeId: productSizes.sizeId });
      return created ? Number(created.sizeId) : null;
    };

    const resolveClubId = async (value: any): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ clubId: club.clubId })
        .from(club)
        .where(sql`lower(${club.name}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.clubId);
      const [created] = await db
        .insert(club)
        .values({ name: trimmed })
        .returning({ clubId: club.clubId });
      return created ? Number(created.clubId) : null;
    };

    const resolveConditionId = async (value: any): Promise<number | null> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return null;
      }
      if (typeof value === "number" || /^\d+$/.test(String(value))) {
        return Number(value);
      }
      const trimmed = String(value).trim();
      const [existing] = await db
        .select({ conditionId: condition.conditionId })
        .from(condition)
        .where(sql`lower(${condition.conditionName}) = lower(${trimmed})`)
        .limit(1);
      if (existing) return Number(existing.conditionId);
      // Create the condition if it doesn't exist
      // condition_id is a plain integer PK (no auto-increment), so we need to generate the next ID
      const [maxId] = await db
        .select({ max: sql<number>`COALESCE(MAX(${condition.conditionId}), 0)` })
        .from(condition);
      const nextId = (maxId?.max ?? 0) + 1;
      const [created] = await db
        .insert(condition)
        .values({ conditionId: nextId, conditionName: trimmed })
        .returning({ conditionId: condition.conditionId });
      return created ? Number(created.conditionId) : null;
    };

    const resolveStoreIds = async (value: any): Promise<number[]> => {
      if (
        value === null ||
        value === undefined ||
        String(value).trim() === ""
      ) {
        return [];
      }
      const codes = String(value)
        .split(",")
        .map((c) => c.trim())
        .filter((c) => c.length > 0);
      if (codes.length === 0) return [];

      const storeIds: number[] = [];
      for (const code of codes) {
        // First try matching by store code
        const [existing] = await db
          .select({ storeId: store.storeId })
          .from(store)
          .where(sql`lower(${store.code}) = lower(${code})`)
          .limit(1);
        if (existing) {
          storeIds.push(Number(existing.storeId));
        } else {
          // Fall back to matching by website code
          const matchingStores = await db
            .select({ storeId: store.storeId })
            .from(store)
            .where(sql`lower(${store.websiteCode}) = lower(${code})`);
          for (const s of matchingStores) {
            storeIds.push(Number(s.storeId));
          }
          if (matchingStores.length === 0) {
            console.log(`[Import] Store/website code "${code}" not found - skipping`);
          }
        }
      }
      return Array.from(new Set(storeIds)); // deduplicate
    };

    // ── Store-scoped import helpers ──────────────────────────────────
    const storeCache = new Map<string, { storeId: number; defaultCurrencyCode: string | null }>();

    const resolveStoreByViewCode = async (viewCode: string): Promise<{ storeId: number; defaultCurrencyCode: string | null } | null> => {
      const trimmed = viewCode.trim().toUpperCase();
      if (storeCache.has(trimmed)) return storeCache.get(trimmed)!;
      const [storeRow] = await db
        .select({ storeId: store.storeId, code: store.code })
        .from(store)
        .where(sql`upper(${store.code}) = ${trimmed}`)
        .limit(1);
      if (!storeRow) return null;
      const [sc] = await db
        .select({ currencyCode: currency.code })
        .from(storeCurrency)
        .innerJoin(currency, eq(storeCurrency.currencyId, currency.currencyId))
        .where(and(eq(storeCurrency.storeId, storeRow.storeId), eq(storeCurrency.isDefault, true)))
        .limit(1);
      const result = { storeId: Number(storeRow.storeId), defaultCurrencyCode: sc?.currencyCode ?? null };
      storeCache.set(trimmed, result);
      return result;
    };

    const upsertProductAttributeVal = async (
      productId: number,
      attributeId: number,
      storeId: number | null,
      values: { valueText?: string | null; valueNum?: string | number | null; valueBool?: boolean | null; valueJson?: any },
    ) => {
      const pool = (db as any)._.session?.client;
      if (pool) {
        await pool.query(
          `INSERT INTO pim.product_attribute_val (product_id, attribute_id, store_id, value_text, value_num, value_bool, value_json)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (product_id, attribute_id, COALESCE(store_id, 0))
           DO UPDATE SET value_text = $4, value_num = $5, value_bool = $6, value_json = $7`,
          [
            productId,
            attributeId,
            storeId,
            values.valueText ?? null,
            values.valueNum ?? null,
            values.valueBool ?? null,
            values.valueJson ? JSON.stringify(values.valueJson) : null,
          ],
        );
      }
    };

    const STORE_SCOPED_ATTR_CODES = new Set(["meta_description", "url_key", "tax_class_name"]);
    // ── End store-scoped import helpers ───────────────────────────────

    const resolveCurrencyId = async (code: string): Promise<number | null> => {
      if (!code || code.trim() === "") return null;
      const trimmed = code.trim().toUpperCase();
      const [existing] = await db
        .select({ currencyId: currency.currencyId })
        .from(currency)
        .where(sql`upper(${currency.code}) = ${trimmed}`)
        .limit(1);
      return existing ? Number(existing.currencyId) : null;
    };

    const extractCurrencyPrices = (
      data: Record<string, any>
    ): Array<{
      currencyCode: string;
      retailPrice: string | null;
      specialRetailPrice: string | null;
      costPrice: string | null;
    }> => {
      const foundCurrencies = new Map<
        string,
        {
          retailPrice: string | null;
          specialRetailPrice: string | null;
          costPrice: string | null;
        }
      >();

      const priceRegex = /^(price|retailPrice|retail_price|specialPrice|costPrice|special_price|cost_price|specialRetailPrice|special_retail_price)[-_]?([a-zA-Z]{3})$/i;

      for (const [key, val] of Object.entries(data)) {
        if (val === undefined || val === null || String(val).trim() === "")
          continue;
        const match = key.match(priceRegex);
        if (!match) continue;
        const prefix = match[1].toLowerCase().replace(/_/g, "");
        const code = match[2].toUpperCase();
        if (!foundCurrencies.has(code)) {
          foundCurrencies.set(code, {
            retailPrice: null,
            specialRetailPrice: null,
            costPrice: null,
          });
        }
        const entry = foundCurrencies.get(code)!;
        const trimmedVal = String(val).trim();
        if (
          trimmedVal === "" ||
          trimmedVal === "__EMPTY__VALUE__" ||
          isNaN(Number(trimmedVal))
        )
          continue;
        if (prefix === "price" || prefix === "retailprice") {
          entry.retailPrice = trimmedVal;
        } else if (prefix === "specialprice" || prefix === "specialretailprice") {
          entry.specialRetailPrice = trimmedVal;
        } else if (prefix === "costprice") {
          entry.costPrice = trimmedVal;
        }
      }

      return Array.from(foundCurrencies.entries()).map(([code, prices]) => ({
        currencyCode: code,
        ...prices,
      }));
    };

    const resolveAttributeDef = async (
      rawKey: string,
      label: string,
      inferredDataType: "text" | "number" | "boolean" | "json"
    ): Promise<{
      attributeId: number;
      dataType: string | null;
    } | null> => {
      const normalizedKey = normalizeAttributeCode(rawKey).toLowerCase();
      const existing = attributeDefMap.get(normalizedKey);
      if (!existing) {
        console.log(
          `[Import] resolveAttributeDef: No match found for rawKey="${rawKey}", normalizedKey="${normalizedKey}"`
        );
        return null;
      }
      console.log(
        `[Import] resolveAttributeDef: Found match for rawKey="${rawKey}" -> attributeId=${existing.attributeId}`
      );
      if (!existing.dataType || !existing.label) {
        const nextDataType = existing.dataType ?? inferredDataType;
        const nextLabel = existing.label ?? label;
        await db
          .update(attributeDef)
          .set({
            dataType: nextDataType,
            label: nextLabel,
          })
          .where(eq(attributeDef.attributeId, existing.attributeId));
        const updated = {
          ...existing,
          dataType: nextDataType,
          label: nextLabel,
        };
        attributeDefMap.set(normalizedKey, updated);
        return updated;
      }
      return existing;
    };

    const autoConvertPricesFromBase = async (
      productId: number,
      baseCurrencyId: number,
      baseRetailPrice: number | null,
      baseSpecialRetailPrice: number | null,
      baseCostPrice: number | null
    ): Promise<void> => {
      if (
        baseRetailPrice === null &&
        baseSpecialRetailPrice === null &&
        baseCostPrice === null
      ) {
        return;
      }

      const conversionRates = await db
        .select({
          fromCurrencyId: currencyConversionRate.fromCurrencyId,
          toCurrencyId: currencyConversionRate.toCurrencyId,
          rate: currencyConversionRate.rate,
        })
        .from(currencyConversionRate)
        .where(eq(currencyConversionRate.fromCurrencyId, baseCurrencyId));

      for (const convRate of conversionRates) {
        const targetCurrencyId = Number(convRate.toCurrencyId);
        const rate = Number(convRate.rate);

        const [existing] = await db
          .select({ productPriceId: productPrice.productPriceId })
          .from(productPrice)
          .where(
            and(
              eq(productPrice.productId, productId),
              eq(productPrice.currencyId, targetCurrencyId)
            )
          )
          .limit(1);

        if (!existing) {
          const convertedRetailPrice =
            baseRetailPrice !== null ? baseRetailPrice * rate : null;
          const convertedSpecialRetailPrice =
            baseSpecialRetailPrice !== null
              ? baseSpecialRetailPrice * rate
              : null;
          const convertedCostPrice =
            baseCostPrice !== null ? baseCostPrice * rate : null;

          await db.insert(productPrice).values({
            productId,
            currencyId: targetCurrencyId,
            retailPrice: convertedRetailPrice
              ? String(convertedRetailPrice)
              : null,
            specialRetailPrice: convertedSpecialRetailPrice
              ? String(convertedSpecialRetailPrice)
              : null,
            costPrice: convertedCostPrice ? String(convertedCostPrice) : null,
            isManualOverride: false,
          });
        }
      }
    };

    // Track image sort orders assigned during this import run (per product)
    const importImageSortOrders = new Map<number, Set<number>>();

    /**
     * MAIN LOOP: Process each row with single linear path
     */
    console.log(`[ImportV2] Processing ${rows.length} rows for batch ${batchId}`);
    importProgressTracker.start(batchId, rows.length);

    for (const row of rows) {
      const currentRowId = Number(row.importRowId);

      try {
        const data = (row.rowRaw as any)?.data ?? {};
        if (appliedRows === 0 && errorRows === 0) {
          console.log(`[ImportV2] First row data keys:`, Object.keys(data));
          console.log(`[ImportV2] First row SKU candidates: sku=${data.sku}, productVariantSku=${data.productVariantSku}, productSku=${data.productSku}`);
        }

        // Handle _imageFormat rows
        if (data._imageFormat === "true") {
          const imgSku =
            data.sku || data.productVariantSku || data.productSku || "";
          const trimmedImgSku = String(imgSku).trim();
          if (!trimmedImgSku) {
            await db
              .update(importRow)
              .set({ rowStatus: "applied", updatedAt: now })
              .where(eq(importRow.importRowId, currentRowId));
            appliedRows += 1;
            continue;
          }

          // Look up product by SKU
          const [imgProduct] = await db
            .select({ productId: product.productId })
            .from(product)
            .where(eq(product.sku, trimmedImgSku))
            .limit(1);

          const imgProductId = imgProduct
            ? Number(imgProduct.productId)
            : null;

          if (!imgProductId) {
            await db
              .update(importRow)
              .set({ rowStatus: "applied", updatedAt: now })
              .where(eq(importRow.importRowId, currentRowId));
            appliedRows += 1;
            continue;
          }

          // Process images (baseImage, smallImage, thumbnailImage, additionalImages)
          const imgRoleMappings: Array<{ key: string; role: string }> = [
            { key: "baseImage", role: "base" },
            { key: "smallImage", role: "small" },
            { key: "thumbnailImage", role: "thumbnail" },
          ];
          const imgLabel =
            (
              data.label ||
              data.Label ||
              data.image_label ||
              data.imageLabel ||
              ""
            ).toString().trim() || null;
          const imageEntries: Array<{
            url: string;
            role: string;
            label: string | null;
          }> = [];

          for (const { key, role } of imgRoleMappings) {
            const url = data[key];
            if (url && String(url).trim()) {
              imageEntries.push({
                url: String(url).trim(),
                role,
                label: imgLabel,
              });
            }
          }

          const additionalRaw = data.additionalImages;
          if (additionalRaw && String(additionalRaw).trim()) {
            const additionalUrls = String(additionalRaw)
              .split(",")
              .map((u: string) => u.trim())
              .filter(Boolean);
            for (const url of additionalUrls) {
              imageEntries.push({ url, role: "additional", label: imgLabel });
            }
          }

          for (const entry of imageEntries) {
            const existingImages = await db
              .select({ sortOrder: imageAsset.sortOrder })
              .from(imageAsset)
              .where(eq(imageAsset.productId, imgProductId))
              .orderBy(asc(imageAsset.sortOrder));

            const dbOrders = new Set(existingImages.map((img) => img.sortOrder ?? 0));
            const importOrders =
              importImageSortOrders.get(imgProductId) ?? new Set<number>();
            const allAssignedOrders = new Set([...dbOrders, ...importOrders]);
            let validSortOrder = 1;
            while (allAssignedOrders.has(validSortOrder)) validSortOrder++;
            if (!importImageSortOrders.has(imgProductId)) {
              importImageSortOrders.set(imgProductId, new Set());
            }
            importImageSortOrders.get(imgProductId)!.add(validSortOrder);

            const [existingImage] = await db
              .select({ imageId: imageAsset.imageId })
              .from(imageAsset)
              .where(
                and(
                  eq(imageAsset.productId, imgProductId),
                  eq(imageAsset.url, entry.url),
                  eq(imageAsset.role, entry.role)
                )
              )
              .limit(1);

            if (existingImage) {
              await db
                .update(imageAsset)
                .set({ sortOrder: validSortOrder, label: entry.label })
                .where(eq(imageAsset.imageId, existingImage.imageId));
            } else {
              await db.insert(imageAsset).values({
                productId: imgProductId,
                url: entry.url,
                role: entry.role,
                label: entry.label,
                sortOrder: validSortOrder,
              });
            }
          }

          await db
            .update(importRow)
            .set({ rowStatus: "applied", updatedAt: now })
            .where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          continue;
        }

        // ===== MAIN PATH: Process single product row =====

        const lowerKeyMap = new Map<string, any>(
          Object.entries(data).map(([key, value]) => [key.toLowerCase(), value])
        );

        const getDataValue = (keys: string[]): any => {
          for (const key of keys) {
            if (key in data) return data[key];
            const lowerFirst = key
              ? key.charAt(0).toLowerCase() + key.slice(1)
              : key;
            if (lowerFirst && lowerFirst in data) return data[lowerFirst];
            const lowerKey = key.toLowerCase();
            if (lowerKeyMap.has(lowerKey))
              return lowerKeyMap.get(lowerKey);
          }
          return null;
        };

        // ── Store-scoped override row (e.g. US sheet) ──────────────────
        const storeViewCodeValue = getDataValue(["storeViewCode", "store_view_code"]);
        if (storeViewCodeValue && String(storeViewCodeValue).trim() !== "") {
          const storeInfo = await resolveStoreByViewCode(String(storeViewCodeValue));
          if (!storeInfo) {
            console.log(`[ImportV2] Store-scoped row skipped: unknown store_view_code="${storeViewCodeValue}"`);
            await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
            importProgressTracker.addEntry(batchId, { sku: String(data.productSku || data.sku || ""), status: "error", message: `Unknown store view code: ${storeViewCodeValue}`, timestamp: Date.now() });
            continue;
          }

          const lookupSku = String(data.productVariantSku || data.productSku || data.sku || "").trim();
          if (!lookupSku) {
            await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
            importProgressTracker.addEntry(batchId, { sku: "", status: "error", message: "SKU is required for store-scoped override rows", timestamp: Date.now() });
            continue;
          }

          const [existingProduct] = await db
            .select({ productId: product.productId })
            .from(product)
            .where(eq(product.sku, lookupSku))
            .limit(1);

          if (!existingProduct) {
            console.log(`[ImportV2] Store-scoped row skipped: product not found for SKU="${lookupSku}"`);
            await db.update(importRow).set({ rowStatus: "invalid", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
            importProgressTracker.addEntry(batchId, { sku: lookupSku, status: "error", message: `Product not found for SKU: ${lookupSku}. Import the DATA sheet first.`, timestamp: Date.now() });
            continue;
          }

          const storeProductId = Number(existingProduct.productId);
          const { storeId, defaultCurrencyCode } = storeInfo;

          // 1. Store-scoped EAV attributes (meta_description, url_key, tax_class_name)
          const storeScopedFields: Array<{ code: string; keys: string[] }> = [
            { code: "meta_description", keys: ["metaDescription", "meta_description"] },
            { code: "url_key", keys: ["urlKey", "url_key"] },
            { code: "tax_class_name", keys: ["taxClassName", "tax_class_name"] },
          ];
          for (const field of storeScopedFields) {
            const value = getDataValue(field.keys);
            if (value === null || value === undefined || String(value).trim() === "") continue;
            const normalizedCode = field.code.toLowerCase();
            const attrDef = attributeDefMap.get(normalizedCode);
            if (!attrDef) {
              console.log(`[ImportV2] Store-scoped attribute "${field.code}" skipped: no attribute_def found`);
              continue;
            }
            await upsertProductAttributeVal(storeProductId, attrDef.attributeId, storeId, {
              valueText: String(value).trim(),
            });
          }

          // 2. Store-scoped prices (price → retailPrice, cost → costPrice in the store's default currency)
          const priceValue = getDataValue(["price"]);
          const costValue = getDataValue(["cost"]);
          if ((priceValue || costValue) && defaultCurrencyCode) {
            const currencyId = await resolveCurrencyId(defaultCurrencyCode);
            if (currencyId) {
              const retailStr = priceValue != null && String(priceValue).trim() !== "" ? String(priceValue).trim() : null;
              const costStr = costValue != null && String(costValue).trim() !== "" ? String(costValue).trim() : null;

              const [existingPrice] = await db
                .select({ productPriceId: productPrice.productPriceId })
                .from(productPrice)
                .where(
                  and(
                    eq(productPrice.productId, storeProductId),
                    eq(productPrice.currencyId, currencyId),
                    sql`${productPrice.validFrom} IS NULL`,
                    sql`${productPrice.validTo} IS NULL`
                  )
                )
                .limit(1);

              if (existingPrice) {
                const updateData: any = {};
                if (retailStr !== null) updateData.retailPrice = retailStr;
                if (costStr !== null) updateData.costPrice = costStr;
                if (Object.keys(updateData).length > 0) {
                  await db.update(productPrice).set(updateData).where(eq(productPrice.productPriceId, existingPrice.productPriceId));
                }
              } else {
                await db.insert(productPrice).values({
                  productId: storeProductId,
                  currencyId,
                  retailPrice: retailStr,
                  costPrice: costStr,
                  isManualOverride: true,
                });
              }
            }
          }

          // 3. Assign product to store
          await db
            .insert(productStore)
            .values({
              productId: storeProductId,
              storeId,
              enabled: true,
            })
            .onConflictDoNothing();

          // 4. Process remaining attributes as store-scoped EAV
          for (const [key, value] of Object.entries(data)) {
            const canonicalKey = key ? key.charAt(0).toLowerCase() + key.slice(1) : key;
            if (shouldIgnoreAsAttribute(canonicalKey)) continue;
            const normalizedKey = normalizeAttributeCode(canonicalKey);
            if (!normalizedKey) continue;
            if (STORE_SCOPED_ATTR_CODES.has(normalizedKey.toLowerCase())) continue;

            const attrDef = attributeDefMap.get(normalizedKey.toLowerCase());
            if (!attrDef) continue;
            const inferred = inferAttributeValue(value);
            if (!inferred) continue;
            await upsertProductAttributeVal(storeProductId, attrDef.attributeId, storeId, inferred);
          }

          await db.update(importRow).set({ rowStatus: "applied", updatedAt: now }).where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          importProgressTracker.addEntry(batchId, { sku: lookupSku, status: "success", message: `Store-scoped overrides applied (store: ${storeViewCodeValue})`, timestamp: Date.now() });
          continue;
        }
        // ── End store-scoped override handling ──────────────────────────

        // a) Determine the SKU (priority: sku > productVariantSku > productSku)
        const sku =
          data.sku || data.productVariantSku || data.productSku || "";
        const trimmedSku = String(sku).trim();

        if (!trimmedSku) {
          // No SKU found, mark as applied and skip
          await db
            .update(importRow)
            .set({ rowStatus: "applied", updatedAt: now })
            .where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          continue;
        }

        // b) Resolve references
        const genderValue = getDataValue(["gender", "genderName"]);
        const resolvedGenderId =
          data.genderId ?? (await resolveGenderId(genderValue));

        const eraValue = getDataValue(["era", "eraName", "eraId"]);
        const resolvedEraId = data.eraId ?? (await resolveEraId(eraValue));

        const productStyleValue = getDataValue([
          "productStyle",
          "productStyleName",
        ]);
        const resolvedProductStyle = resolveProductStyle(productStyleValue);

        const brandValue = getDataValue(["brandName", "brand"]);
        const parsedBrandId = normalizeNumberValue(data.brandId, true);
        const resolvedBrandId =
          parsedBrandId ?? (await resolveBrandId(brandValue));

        const colourValue = getDataValue([
          "productColourName",
          "productColour",
          "colour",
          "color",
        ]);
        const parsedColourId = normalizeNumberValue(
          data.productColourId,
          true
        );
        const resolvedProductColourId =
          parsedColourId ??
          (await resolveProductColourId(colourValue, resolvedBrandId));

        const productTypeNameValue = getDataValue(["productTypeName"]);
        const productTypeValue = getDataValue(["productType"]);
        const parsedProductTypeId = normalizeNumberValue(
          data.productTypeId,
          true
        );
        const resolvedProductTypeId =
          parsedProductTypeId ??
          (await resolveProductTypeId(
            productTypeNameValue ?? productTypeValue
          ));

        const sizeValue = getDataValue([
          "size",
          "sizeName",
          "sizeShortName",
          "sizeLongName",
        ]);
        const parsedSizeId = normalizeNumberValue(data.sizeId, true);
        const parsedMagentoSizeId = normalizeNumberValue(
          data.magentoSizeId,
          true
        );
        const resolvedSizeId = await resolveSizeId(
          parsedSizeId ?? parsedMagentoSizeId ?? sizeValue,
          {
            shortName: getDataValue(["sizeShortName"]),
            longName: getDataValue([
              "sizeLongName",
              "sizeName",
              "size",
            ]),
          }
        );

        const conditionValue = getDataValue([
          "condition",
          "conditionName",
        ]);
        const resolvedConditionId = await resolveConditionId(conditionValue);

        const clubValue = getDataValue([
          "clubName",
          "club",
          "team",
          "teamName",
        ]);
        const resolvedClubId = await resolveClubId(clubValue);

        const productWebsitesValue = getDataValue([
          "productWebsites",
          "product_websites",
        ]);
        const resolvedStoreIds = await resolveStoreIds(productWebsitesValue);

        // c) Determine parentSku: look for data.parentSku || data.parent_sku || data.productSku
        // BUT ONLY if it's different from SKU itself
        let parentSku: string | null = null;
        const parentSkuCandidate =
          data.parentSku || data.parent_sku || data.productSku || null;
        if (parentSkuCandidate) {
          const trimmedParentSku = String(parentSkuCandidate).trim();
          if (trimmedParentSku && trimmedParentSku !== trimmedSku) {
            parentSku = trimmedParentSku;
          }
        }

        // d) Build merged product data object
        const buildProductData = (
          forType: "simple" | "configurable" = "simple",
          forParentSku?: string | null
        ): Record<string, any> => {
          const productData: Record<string, any> = {
            sku: forParentSku ?? trimmedSku,
            parentSku: forParentSku ? null : parentSku,
            productType: forType,
          };

          // Name: for configurable parents, strip the size suffix e.g. "(S)", "(XL)", "(12-13Y)", "(Women's XS)"
          // Child products keep the full name with suffix as provided in the CSV.
          if (data.name && String(data.name).trim()) {
            let nameValue = String(data.name).trim();
            if (forType === "configurable") {
              // Strip trailing parenthesised size suffix: matches "(S)", "(XL)", "(3XL)", "(12-13Y)", "(Women's XS)", "(M.Kids)", "(L.Kids)", "(One Size)" etc.
              nameValue = nameValue.replace(/\s*\([^)]*\)\s*$/, "").trim();
              // Strip trailing hyphen-size suffix: matches "-S", "-XL", "-3XL", "-XXL", "-164CM", "-uk 20-22", "-uk 8-10" etc.
              // Only strip if what follows the last hyphen looks like a size token
              nameValue = nameValue.replace(/[-–](?:XXS|XS|S|M|L|XL|XXL|2XL|3XL|4XL|5XL|6XL|One Size|\d+(?:[-–]\d+)?(?:CM|Y)?|uk\s*\d+[-–]?\d*|Women's\s*\w+|Men's\s*\w+|[ML]\.?Kids?)$/i, "").trim();
              // Clean up any trailing punctuation left behind, e.g. "Shirt # - As New -" → "Shirt # - As New"
              nameValue = nameValue.replace(/[\s\-–—]+$/, "").trim();
            }
            productData.name = nameValue;
          }

          // Product fields
          if (data.productDescription) {
            productData.productDescription = data.productDescription;
          }
          if (data.articleNumber) {
            productData.articleNumber = data.articleNumber;
          }

          // Resolved FKs (shared attributes — apply to both parent and child)
          if (resolvedBrandId) productData.brandId = resolvedBrandId;
          if (resolvedGenderId) productData.genderId = resolvedGenderId;
          if (resolvedProductColourId)
            productData.productColourId = resolvedProductColourId;
          if (resolvedProductTypeId)
            productData.productTypeId = resolvedProductTypeId;
          if (resolvedEraId) productData.eraId = resolvedEraId;
          // Size only applies to simple products (children/standalone), not configurable parents
          if (forType === "simple" && resolvedSizeId) productData.sizeId = resolvedSizeId;

          // Product style
          if (resolvedProductStyle) {
            productData.productStyle = resolvedProductStyle;
          }

          // Variant-level fields (now merged)
          // Only include variant-level fields for simple products, not configurable parents
          if (forType === "simple") {
            // Condition: use resolved ID from name lookup, or fall back to raw conditionId
            const finalConditionId = resolvedConditionId ?? normalizeNumberValue(data.conditionId, true);
            if (finalConditionId !== null && finalConditionId !== undefined) {
              productData.conditionId = finalConditionId;
            }
            if (data.conditionDetail) {
              productData.conditionDetail = data.conditionDetail;
            }
            if (data.barcode) {
              productData.barcode = data.barcode;
            }

            // Dimensions
            const widthVal = normalizeNumberValue(data.widthCm, true);
            if (widthVal !== null) productData.widthCm = widthVal;
            const lengthVal = normalizeNumberValue(data.lengthCm, true);
            if (lengthVal !== null) productData.lengthCm = lengthVal;
            const weightVal = normalizeNumberValue(data.weight, true);
            if (weightVal !== null) productData.weight = weightVal;
            const depthVal = normalizeNumberValue(data.depth, true);
            if (depthVal !== null) productData.depth = depthVal;

            // Prices (for upsert, not for productPrice table)
            const costPriceVal = normalizeNumberValue(data.costPrice, true);
            if (costPriceVal !== null) productData.costPrice = costPriceVal;
            const avgCostPriceVal = normalizeNumberValue(data.averageCostPrice, true);
            if (avgCostPriceVal !== null) productData.averageCostPrice = avgCostPriceVal;
            const customerPriceVal = normalizeNumberValue(data.customerPrice, true);
            if (customerPriceVal !== null) productData.customerPrice = customerPriceVal;
          }

          // Tax & composition (shared, apply to both parent and child)
          if (data.taxClassId !== undefined && data.taxClassId !== null) {
            productData.taxClassId = normalizeNumberValue(
              data.taxClassId,
              true
            );
          }
          if (data.composition) {
            productData.composition = data.composition;
          }
          if (data.countryOfManufacture) {
            productData.countryOfManufacture = data.countryOfManufacture;
          }
          if (data.commodityCode) {
            productData.commodityCode = data.commodityCode;
          }
          if (data.imageCode) {
            productData.imageCode = data.imageCode;
          }

          // Flags
          const printedValue = normalizeBooleanValue(data.printed);
          if (printedValue !== null) productData.printed = printedValue;

          const enabledValue = normalizeBooleanValue(data.enabled);
          if (enabledValue !== null) productData.enabled = enabledValue;

          const syncValue = normalizeBooleanValue(data.sync);
          if (syncValue !== null) productData.sync = syncValue;

          if (data.magentoProductId) {
            productData.magentoProductId = normalizeNumberValue(
              data.magentoProductId,
              true
            );
          }

          // Audit fields
          productData.updatedAt = now;

          return productData;
        };

        // g) If row has parentSku, ensure configurable parent exists first
        let resolvedProductId: number | null = null;
        let parentProductId: number | null = null;

        if (parentSku) {
          // Create configurable parent row if it doesn't exist.
          // Uses onConflictDoNothing: the first child in the batch creates the parent
          // with shared attributes. Subsequent children skip (parent already exists).
          const parentProductData = buildProductData("configurable", parentSku);
          await db
            .insert(product)
            .values(parentProductData)
            .onConflictDoNothing({ target: [product.sku] });

          // Retrieve the parent's product_id (whether just created or already existed)
          const [parentProduct] = await db
            .select({ productId: product.productId })
            .from(product)
            .where(eq(product.sku, parentSku))
            .limit(1);

          parentProductId = parentProduct
            ? Number(parentProduct.productId)
            : null;

          if (!parentProductId) {
            await db
              .update(importRow)
              .set({ rowStatus: "applied", updatedAt: now })
              .where(eq(importRow.importRowId, currentRowId));
            appliedRows += 1;
            continue;
          }

          // Now upsert the child (simple) product
          const childProductData = buildProductData("simple");
          try {
            const [upsertedProduct] = await db
              .insert(product)
              .values(childProductData)
              .onConflictDoUpdate({
                target: [product.sku],
                set: childProductData,
              })
              .returning({ productId: product.productId });

            resolvedProductId = upsertedProduct
              ? Number(upsertedProduct.productId)
              : null;
          } catch (upsertErr: any) {
            if (upsertErr?.constraint === "product_barcode_key" && childProductData.barcode) {
              const { barcode, ...dataWithoutBarcode } = childProductData;
              const [upsertedProduct] = await db
                .insert(product)
                .values(dataWithoutBarcode)
                .onConflictDoUpdate({
                  target: [product.sku],
                  set: dataWithoutBarcode,
                })
                .returning({ productId: product.productId });

              resolvedProductId = upsertedProduct
                ? Number(upsertedProduct.productId)
                : null;
            } else {
              throw upsertErr;
            }
          }
        } else {
          // No parent SKU: determine if this is a configurable parent or standalone simple.
          // A row is a configurable parent if it has configurable_variations data,
          // or if its product_type column explicitly says "configurable".
          const configVarValue = getDataValue(["configurableVariations", "configurable_variations"]);
          const hasConfigVariations = configVarValue && String(configVarValue).trim() !== "";
          const productTypeRaw = getDataValue(["productType", "product_type"]);
          const isExplicitConfigurable = productTypeRaw && String(productTypeRaw).trim().toLowerCase() === "configurable";
          const effectiveType = (hasConfigVariations || isExplicitConfigurable) ? "configurable" : "simple";
          const productDataToUpsert = buildProductData(effectiveType);
          try {
            const [upsertedProduct] = await db
              .insert(product)
              .values(productDataToUpsert)
              .onConflictDoUpdate({
                target: [product.sku],
                set: productDataToUpsert,
              })
              .returning({ productId: product.productId });

            resolvedProductId = upsertedProduct
              ? Number(upsertedProduct.productId)
              : null;
          } catch (upsertErr: any) {
            // If barcode unique constraint fails, retry without barcode
            if (upsertErr?.constraint === "product_barcode_key" && productDataToUpsert.barcode) {
              const { barcode, ...dataWithoutBarcode } = productDataToUpsert;
              const [upsertedProduct] = await db
                .insert(product)
                .values(dataWithoutBarcode)
                .onConflictDoUpdate({
                  target: [product.sku],
                  set: dataWithoutBarcode,
                })
                .returning({ productId: product.productId });

              resolvedProductId = upsertedProduct
                ? Number(upsertedProduct.productId)
                : null;
            } else {
              throw upsertErr;
            }
          }
        }

        if (!resolvedProductId) {
          await db
            .update(importRow)
            .set({ rowStatus: "applied", updatedAt: now })
            .where(eq(importRow.importRowId, currentRowId));
          appliedRows += 1;
          continue;
        }

        // h) Determine the product ID for categories:
        //    If the row has a parent_sku, attach categories to the configurable parent.
        //    Otherwise, attach to the standalone simple product.
        const categoryProductId = (parentSku && parentProductId) ? parentProductId : resolvedProductId;

        // Process multi-currency prices
        // Handle plain "price" and "cost" columns as GBP (base currency)
        const plainPrice = data.price != null && String(data.price).trim() !== "" ? String(data.price).trim() : null;
        const plainCost = data.cost != null && String(data.cost).trim() !== "" ? String(data.cost).trim() : null;
        if (plainPrice || plainCost) {
          const gbpCurrencyId = await resolveCurrencyId("GBP");
          if (gbpCurrencyId) {
            const retailPrice = plainPrice && !isNaN(Number(plainPrice)) ? Number(plainPrice) : null;
            const costPrice = plainCost && !isNaN(Number(plainCost)) ? Number(plainCost) : null;

            const [existingGbpPrice] = await db
              .select({ productPriceId: productPrice.productPriceId })
              .from(productPrice)
              .where(
                and(
                  eq(productPrice.productId, resolvedProductId),
                  eq(productPrice.currencyId, gbpCurrencyId),
                  sql`${productPrice.validFrom} IS NULL`,
                  sql`${productPrice.validTo} IS NULL`
                )
              )
              .limit(1);

            if (existingGbpPrice) {
              const updateData: any = {};
              if (retailPrice !== null) updateData.retailPrice = String(retailPrice);
              if (costPrice !== null) updateData.costPrice = String(costPrice);
              if (Object.keys(updateData).length > 0) {
                await db.update(productPrice).set(updateData).where(eq(productPrice.productPriceId, existingGbpPrice.productPriceId));
              }
            } else {
              await db.insert(productPrice).values({
                productId: resolvedProductId,
                currencyId: gbpCurrencyId,
                retailPrice: retailPrice ? String(retailPrice) : null,
                costPrice: costPrice ? String(costPrice) : null,
                isManualOverride: false,
              });
            }

            // Auto-convert from GBP to other currencies
            if (retailPrice || costPrice) {
              await autoConvertPricesFromBase(resolvedProductId, gbpCurrencyId, retailPrice, null, costPrice);
            }
          }
        }

        // Process explicitly suffixed currency prices (e.g. priceUsd, costPriceEur)
        const currencyPrices = extractCurrencyPrices(data);
        for (const currPrice of currencyPrices) {
          const currencyId = await resolveCurrencyId(currPrice.currencyCode);
          if (!currencyId) continue;

          const retailPrice = currPrice.retailPrice
            ? Number(currPrice.retailPrice)
            : null;
          const specialRetailPrice = currPrice.specialRetailPrice
            ? Number(currPrice.specialRetailPrice)
            : null;
          const costPrice = currPrice.costPrice
            ? Number(currPrice.costPrice)
            : null;

          // Upsert price: unique index includes validFrom/validTo which are nullable,
          // and ON CONFLICT doesn't match NULLs, so use select-then-insert/update pattern.
          const [existingPrice] = await db
            .select({ productPriceId: productPrice.productPriceId })
            .from(productPrice)
            .where(
              and(
                eq(productPrice.productId, resolvedProductId),
                eq(productPrice.currencyId, currencyId),
                sql`${productPrice.validFrom} IS NULL`,
                sql`${productPrice.validTo} IS NULL`
              )
            )
            .limit(1);

          if (existingPrice) {
            await db
              .update(productPrice)
              .set({
                retailPrice: retailPrice ? String(retailPrice) : null,
                specialRetailPrice: specialRetailPrice
                  ? String(specialRetailPrice)
                  : null,
                costPrice: costPrice ? String(costPrice) : null,
              })
              .where(eq(productPrice.productPriceId, existingPrice.productPriceId));
          } else {
            await db.insert(productPrice).values({
              productId: resolvedProductId,
              currencyId,
              retailPrice: retailPrice ? String(retailPrice) : null,
              specialRetailPrice: specialRetailPrice
                ? String(specialRetailPrice)
                : null,
              costPrice: costPrice ? String(costPrice) : null,
              isManualOverride: false,
            });
          }

          // Auto-convert prices from this currency to other currencies if rates exist
          if (retailPrice || specialRetailPrice || costPrice) {
            await autoConvertPricesFromBase(
              resolvedProductId,
              currencyId,
              retailPrice,
              specialRetailPrice,
              costPrice
            );
          }
        }

        // i) Process stock: if qty provided, upsert into productStock (warehouseId=1)
        const qtyValue = getDataValue([
          "qty",
          "stock",
          "stockQty",
          "quantity",
        ]);
        if (qtyValue !== null && String(qtyValue).trim() !== "") {
          const qty = Number(qtyValue);
          if (!isNaN(qty)) {
            await db
              .insert(productStock)
              .values({
                productId: resolvedProductId,
                warehouseId: 1, // Default to warehouse 1
                qty,
              })
              .onConflictDoUpdate({
                target: [
                  productStock.productId,
                  productStock.warehouseId,
                ],
                set: { qty },
              });
          }
        }

        // j) Process categories
        //    For rows with a parent_sku, attach categories to the configurable parent's productId.
        //    For standalone products, attach to resolvedProductId.
        const categoriesValue = getDataValue(["categories", "category"]);
        if (
          categoriesValue &&
          String(categoriesValue).trim() !== ""
        ) {
          const categoryPaths = String(categoriesValue)
            .split(",")
            .map((p) => p.trim())
            .filter((p) => p !== "");

          // categoryProductId is already set above (uses parent for configurable products)

          for (const path of categoryPaths) {
            try {
              const cat = await getOrCreateCategoryByPath(path);
              await db
                .insert(productCategory)
                .values({
                  productId: categoryProductId,
                  categoryId: cat.categoryId,
                })
                .onConflictDoNothing();
            } catch (err) {
              console.error(
                `[Import] Failed to create/find category for path "${path}":`,
                err
              );
            }
          }
        }

        // k) Process stores
        if (resolvedStoreIds.length > 0) {
          for (const storeId of resolvedStoreIds) {
            await db
              .insert(productStore)
              .values({
                productId: resolvedProductId,
                storeId,
                enabled: true,
              })
              .onConflictDoNothing();
          }
        }

        // k) Process images (baseImage, smallImage, thumbnailImage, additionalImages)
        // Always assign images to the current product (the actual row being processed).
        // For BNIB/configurable imports, each child row has its own images.
        const imgProcessProductId = resolvedProductId;

        const imgRoleMappings: Array<{ key: string; role: string }> = [
          { key: "baseImage", role: "base" },
          { key: "smallImage", role: "small" },
          { key: "thumbnailImage", role: "thumbnail" },
        ];

        const imgLabel =
          (
            data.label ||
            data.Label ||
            data.image_label ||
            data.imageLabel ||
            ""
          ).toString().trim() || null;

        const imageEntries: Array<{
          url: string;
          role: string;
          label: string | null;
        }> = [];

        // Collect role-mapped images
        for (const { key, role } of imgRoleMappings) {
          const url = data[key];
          if (url && String(url).trim()) {
            imageEntries.push({
              url: String(url).trim(),
              role,
              label: imgLabel,
            });
          }
        }

        // Collect additional images
        const additionalRaw = data.additionalImages;
        if (additionalRaw && String(additionalRaw).trim()) {
          const additionalUrls = String(additionalRaw)
            .split(",")
            .map((u: string) => u.trim())
            .filter(Boolean);
          for (const url of additionalUrls) {
            imageEntries.push({ url, role: "additional", label: imgLabel });
          }
        }

        // Process each image entry
        for (const entry of imageEntries) {
          const existingImages = await db
            .select({ sortOrder: imageAsset.sortOrder })
            .from(imageAsset)
            .where(eq(imageAsset.productId, imgProcessProductId))
            .orderBy(asc(imageAsset.sortOrder));

          const dbOrders = new Set(existingImages.map((img) => img.sortOrder ?? 0));
          const importOrders =
            importImageSortOrders.get(imgProcessProductId) ?? new Set<number>();
          const allAssignedOrders = new Set(Array.from(dbOrders).concat(Array.from(importOrders)));
          let validSortOrder = 1;
          while (allAssignedOrders.has(validSortOrder)) validSortOrder++;
          if (!importImageSortOrders.has(imgProcessProductId)) {
            importImageSortOrders.set(imgProcessProductId, new Set());
          }
          importImageSortOrders.get(imgProcessProductId)!.add(validSortOrder);

          const [existingImage] = await db
            .select({ imageId: imageAsset.imageId })
            .from(imageAsset)
            .where(
              and(
                eq(imageAsset.productId, imgProcessProductId),
                eq(imageAsset.url, entry.url),
                eq(imageAsset.role, entry.role)
              )
            )
            .limit(1);

          if (existingImage) {
            await db
              .update(imageAsset)
              .set({ sortOrder: validSortOrder, label: entry.label })
              .where(eq(imageAsset.imageId, existingImage.imageId));
          } else {
            await db.insert(imageAsset).values({
              productId: imgProcessProductId,
              url: entry.url,
              role: entry.role,
              label: entry.label,
              sortOrder: validSortOrder,
            });
          }
        }

        // l) Process team metadata: if clubId resolved, call setProductPrimaryTeam
        if (resolvedClubId !== null) {
          await setProductPrimaryTeam(resolvedProductId, resolvedClubId);
        }

        // m) Process custom attributes: iterate attributeValues, resolve attribute definitions,
        //    upsert ALL into productAttributeVal (no scope inference)
        const attributeValues = new Map<
          string,
          { rawKey: string; value: any }
        >();

        for (const [key, value] of Object.entries(data)) {
          let canonicalKey = key
            ? key.charAt(0).toLowerCase() + key.slice(1)
            : key;
          if (!shouldIgnoreAsAttribute(canonicalKey)) {
            const normalizedKey = normalizeAttributeCode(canonicalKey);
            if (normalizedKey) {
              attributeValues.set(normalizedKey.toLowerCase(), {
                rawKey: canonicalKey,
                value,
              });
            }
          }
        }

        const additionalAttributes = parseAdditionalAttributes(
          data.additionalAttributes
        );
        for (const [key, value] of Object.entries(additionalAttributes)) {
          const normalizedKey = normalizeAttributeCode(key);
          const normalizedKeyLower = normalizedKey
            ? normalizedKey.toLowerCase()
            : "";
          if (
            !normalizedKeyLower ||
            attributeValues.has(normalizedKeyLower) ||
            shouldIgnoreAsAttribute(normalizedKey)
          ) {
            continue;
          }
          attributeValues.set(normalizedKeyLower, { rawKey: key, value });
        }

        for (const entry of attributeValues.values()) {
          const inferred = inferAttributeValue(entry.value);
          if (!inferred) continue;

          let def: {
            attributeId: number;
            dataType: string | null;
          } | null = null;

          if (/^\d+$/.test(entry.rawKey)) {
            const attrById = attributeDefById.get(Number(entry.rawKey));
            def = attrById ?? null;
          } else {
            const label = labelizeAttributeCode(entry.rawKey);
            def = await resolveAttributeDef(
              entry.rawKey,
              label,
              inferred.dataType
            );
          }

          if (!def) {
            console.log(
              `[Import] Skipping attribute "${entry.rawKey}" - no definition found`
            );
            continue;
          }

          console.log(
            `[Import] Upserting product attribute: productId=${resolvedProductId}, attributeId=${def.attributeId}, rawKey="${entry.rawKey}"`
          );

          // Use raw SQL for upsert — the unique index uses COALESCE(store_id, 0)
          const pool = (db as any)._.session?.client;
          if (pool) {
            await pool.query(
              `INSERT INTO pim.product_attribute_val (product_id, attribute_id, store_id, value_text, value_num, value_bool, value_json)
               VALUES ($1, $2, NULL, $3, $4, $5, $6)
               ON CONFLICT (product_id, attribute_id, COALESCE(store_id, 0))
               DO UPDATE SET value_text = $3, value_num = $4, value_bool = $5, value_json = $6`,
              [
                resolvedProductId,
                def.attributeId,
                inferred.valueText ?? null,
                inferred.valueNum ?? null,
                inferred.valueBool ?? null,
                inferred.valueJson ? JSON.stringify(inferred.valueJson) : null,
              ],
            );
          }
        }

        // n) Queue sync: if product.sync is true, insert into alumioSyncQueue (productId only)
        const [productSync] = await db
          .select({ sync: product.sync })
          .from(product)
          .where(eq(product.productId, resolvedProductId))
          .limit(1);

        if (productSync?.sync) {
          try {
            await db
              .insert(alumioSyncQueue)
              .values({
                productId: resolvedProductId,
                operationType: "product_update",
              })
              .onConflictDoNothing();
          } catch (e) {
            console.error("Failed to insert sync queue entry:", e);
          }
        }

        // o) Mark row as applied
        await db
          .update(importRow)
          .set({ rowStatus: "applied", updatedAt: now })
          .where(eq(importRow.importRowId, currentRowId));

        appliedRows += 1;
        importProgressTracker.addEntry(batchId, {
          sku: trimmedSku,
          status: "success",
          message: "Applied",
          timestamp: Date.now(),
        });
        console.log(
          `[Import] Successfully processed row ${row.rowNumber}: sku="${trimmedSku}"`
        );
      } catch (rowError) {
        errorRows += 1;
        importProgressTracker.addEntry(batchId, {
          sku: `Row ${row.rowNumber}`,
          status: "error",
          message: rowError instanceof Error ? rowError.message : String(rowError),
          timestamp: Date.now(),
        });
        console.error(`[Import] Error processing row ${row.rowNumber}:`, rowError);

        try {
          await db
            .update(importRow)
            .set({ rowStatus: "applied", updatedAt: now })
            .where(eq(importRow.importRowId, currentRowId));
        } catch (updateErr) {
          console.error(
            `[Import] Failed to mark row ${row.rowNumber} as applied:`,
            updateErr
          );
        }
      }
    }

    // 4. Update import job with final counts
    const totalProcessed = appliedRows + errorRows;
    const totalInvalid = validationInvalidRows;
    const totalRows = totalProcessed + totalInvalid;

    await db
      .update(importJob)
      .set({
        appliedRows,
        validRows: totalProcessed,
        invalidRows: totalInvalid,
        status: "completed",
        updatedAt: now,
        appliedAt: now,
      })
      .where(eq(importJob.importJobId, importJobId));

    const finalStatus = errorRows > 0 && appliedRows === 0 ? "failed" : "completed";
    importProgressTracker.complete(batchId, finalStatus);
    setTimeout(() => importProgressTracker.remove(batchId), 60000);

    console.log(
      `[Import] Job ${importJobId} complete: ${appliedRows} applied, ${errorRows} errors, ${validationInvalidRows} invalid`
    );

    // 5. Clear staging rows (no cleanup of staging data in v2)
  } catch (fatalError) {
    importProgressTracker.complete(batchId, "failed");
    setTimeout(() => importProgressTracker.remove(batchId), 60000);
    console.error("[Import] Fatal error in processImportV2:", fatalError);
    throw fatalError;
  }
}

/**
 * Helper function stubs (imported from storage.ts or utilities)
 * These need to be implemented or imported from existing utils
 */

function normalizeAttributeCode(code: string): string {
  const trimmed = code.trim().replace(/\*+$/g, "");
  if (!trimmed) return trimmed;
  // Insert underscores between camelCase boundaries: "urlKey" → "url_Key" → "url_key"
  const withUnderscores = trimmed
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")  // camelCase boundary
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2"); // consecutive caps
  return withUnderscores.replace(/[^\w]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
}

function labelizeAttributeCode(code: string): string {
  return code
    .replace(/_/g, " ")
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function normalizeNumberValue(value: any, nullable: boolean): number | null {
  if (value === null || value === undefined) return nullable ? null : 0;
  const str = String(value).trim();
  if (str === "") return nullable ? null : 0;
  const num = Number(str);
  return isNaN(num) ? (nullable ? null : 0) : num;
}

function normalizeBooleanValue(value: any): boolean | null {
  if (value === null || value === undefined) return null;
  const str = String(value).toLowerCase().trim();
  if (
    str === "true" ||
    str === "1" ||
    str === "yes" ||
    str === "y" ||
    str === "on"
  )
    return true;
  if (
    str === "false" ||
    str === "0" ||
    str === "no" ||
    str === "n" ||
    str === "off"
  )
    return false;
  return null;
}

function parseAdditionalAttributes(value: any): Record<string, string> {
  if (value === null || value === undefined) return {};
  if (typeof value !== "string") return {};
  const raw = value.trim();
  if (!raw) return {};
  const entries = raw.split(",");
  const parsed: Record<string, string> = {};
  for (const entry of entries) {
    const trimmed = entry.trim();
    if (!trimmed) continue;
    const equalsIndex = trimmed.indexOf("=");
    if (equalsIndex === -1) continue;
    const key = trimmed.slice(0, equalsIndex).trim();
    const val = trimmed.slice(equalsIndex + 1).trim();
    if (!key) continue;
    parsed[key] = val;
  }
  return parsed;
}

function inferAttributeValue(value: any): {
  dataType: "text" | "number" | "boolean" | "json";
  valueText: string | null;
  valueNum: number | null;
  valueBool: boolean | null;
  valueJson: any | null;
} | null {
  if (value === null || value === undefined) return null;

  if (typeof value === "object") {
    return {
      dataType: "json",
      valueText: null,
      valueNum: null,
      valueBool: null,
      valueJson: value,
    };
  }

  const raw = String(value).trim();
  if (raw === "") return null;

  const boolValue = normalizeBooleanValue(raw);
  if (boolValue !== null) {
    return {
      dataType: "boolean",
      valueText: null,
      valueNum: null,
      valueBool: boolValue,
      valueJson: null,
    };
  }

  const numericValue = normalizeNumberValue(raw, true);
  if (numericValue !== null) {
    return {
      dataType: "number",
      valueText: null,
      valueNum: numericValue,
      valueBool: null,
      valueJson: null,
    };
  }

  if (
    (raw.startsWith("{") && raw.endsWith("}")) ||
    (raw.startsWith("[") && raw.endsWith("]"))
  ) {
    try {
      const parsed = JSON.parse(raw);
      return {
        dataType: "json",
        valueText: null,
        valueNum: null,
        valueBool: null,
        valueJson: parsed,
      };
    } catch {
      // fall through to text
    }
  }

  return {
    dataType: "text",
    valueText: raw,
    valueNum: null,
    valueBool: null,
    valueJson: null,
  };
}

async function getOrCreateCategoryByPath(path: string): Promise<{
  categoryId: number;
}> {
  const parts = path.split("/").map((p) => p.trim());
  let parentId: number | null = null;

  for (let i = 0; i < parts.length; i++) {
    const name = parts[i];
    const pathKey = parts.slice(0, i + 1).join("/").toLowerCase();

    const [existing] = await db
      .select({ categoryId: category.categoryId })
      .from(category)
      .where(eq(category.pathKey, pathKey))
      .limit(1);

    if (existing) {
      parentId = Number(existing.categoryId);
    } else {
      const [created] = await db
        .insert(category)
        .values({
          parentId,
          name,
          pathKey,
        })
        .returning({ categoryId: category.categoryId });
      parentId = created ? Number(created.categoryId) : parentId;
    }
  }

  if (parentId === null) {
    throw new Error(`Failed to create or find category for path: ${path}`);
  }

  return { categoryId: parentId };
}

async function setProductPrimaryTeam(
  productId: number,
  clubId: number
): Promise<void> {
  const [existing] = await db
    .select({ productTeamMetaId: productTeamMeta.productTeamMetaId })
    .from(productTeamMeta)
    .where(eq(productTeamMeta.productId, productId))
    .limit(1);

  if (existing) {
    await db
      .update(productTeamMeta)
      .set({ clubId })
      .where(eq(productTeamMeta.productTeamMetaId, existing.productTeamMetaId));
  } else {
    await db.insert(productTeamMeta).values({
      productId,
      clubId,
    });
  }
}

// Note: Import currencyConversionRate from schema_v2
