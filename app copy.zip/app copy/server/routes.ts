import type { Express } from "express";
import { storage, importProgressTracker } from "./storage";
import { processImportV2 } from "./processImport_v2";
import multer from "multer";
import Papa from "papaparse";
import { randomBytes, createHash } from "crypto";
import { VALID_SCOPES } from "./publicApi";
import { db } from "./db";
import { sql } from "drizzle-orm";
import {
  product,
  club,
  brands,
  productType,
  productGroup,
  gender,
  productColour
} from "@shared/schema_v2";

// Configure multer for CSV file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit per file
});

// Helper function to convert snake_case or "Title Case" to camelCase
function snakeToCamel(str: string): string {
  // First handle spaces (e.g., "Tax Class" -> "taxClass", "Founded Year" -> "foundedYear")
  let result = str
    .replace(/\s+([a-zA-Z])/g, (_, letter) => letter.toUpperCase())
    .replace(/\s+/g, "");
  // Then handle underscores (both lowercase and uppercase letters after _)
  result = result.replace(/_([a-zA-Z])/g, (_, letter) => letter.toUpperCase());
  // Normalize runs of uppercase after a camelCase boundary so "productSKU" becomes "productSku"
  result = result.replace(/([a-z])([A-Z]+)/g, (_, lower, upper) =>
    lower + upper.charAt(0) + upper.slice(1).toLowerCase()
  );
  // Ensure first character is lowercase
  if (result.length > 0) {
    result = result.charAt(0).toLowerCase() + result.slice(1);
  }
  return result;
}

function normalizeSkuValue(value: any): any {
  if (value === null || value === undefined) return value;
  const raw = String(value).trim();
  if (raw === "" || !/[eE]/.test(raw)) return value;

  const match = raw.match(/^([+-]?)(\d+)(?:\.(\d+))?[eE]([+-]?\d+)$/);
  if (!match) return value;

  const sign = match[1] ?? "";
  const integerPart = match[2] ?? "";
  const fractionalPart = match[3] ?? "";
  const exponent = Number(match[4]);

  if (!Number.isFinite(exponent)) return value;

  const shift = exponent - fractionalPart.length;
  if (shift < 0) return value;

  const digits = `${integerPart}${fractionalPart}`;
  const expanded = `${digits}${"0".repeat(shift)}`;

  return `${sign}${expanded}`;
}

const BUILTIN_SYNC_FIELD_OPTIONS: Array<{ field: string; label: string; type: "text" | "ref" }> = [
  { field: "productDescription", label: "Description", type: "text" },
  { field: "articleNumber", label: "Article Number", type: "text" },
  { field: "brandId", label: "Brand", type: "ref" },
  { field: "productTypeId", label: "Product Type", type: "ref" },
  { field: "genderId", label: "Gender", type: "ref" },
  { field: "productColourId", label: "Colour", type: "ref" },
  { field: "eraId", label: "Era", type: "ref" },
  { field: "productStyle", label: "Style", type: "text" },
  { field: "composition", label: "Composition", type: "text" },
  { field: "countryOfManufacture", label: "Country of Manufacture", type: "text" },
  { field: "commodityCode", label: "Commodity Code", type: "text" },
  { field: "imageCode", label: "Image Code", type: "text" },
];

const CUSTOM_ATTR_PREFIX = "custom_attr:";

function isCustomAttrKey(key: string): boolean {
  return key.startsWith(CUSTOM_ATTR_PREFIX);
}

function getCustomAttrCode(key: string): string {
  return key.slice(CUSTOM_ATTR_PREFIX.length);
}

function getSyncRequiredMissingFieldsFromConfig(
  product: Record<string, any>,
  requiredFieldKeys: string[],
  productAttributes?: Array<{ code: string; label: string | null; valueText: string | null; valueNum: string | null; valueBool: boolean | null; valueJson: unknown }>,
  customAttrLabelMap?: Map<string, string>,
): string[] {
  const missing: string[] = [];
  for (const key of requiredFieldKeys) {
    if (isCustomAttrKey(key)) {
      const attrCode = getCustomAttrCode(key);
      const attr = productAttributes?.find((a) => a.code === attrCode);
      const hasValue = attr && (
        (attr.valueText !== null && attr.valueText !== undefined && String(attr.valueText).trim() !== "") ||
        attr.valueNum !== null ||
        attr.valueBool !== null ||
        attr.valueJson !== null
      );
      if (!hasValue) {
        const label = attr?.label || customAttrLabelMap?.get(attrCode) || attrCode;
        missing.push(label);
      }
    } else {
      const def = BUILTIN_SYNC_FIELD_OPTIONS.find((f) => f.field === key);
      if (!def) continue;
      const val = product[def.field];
      if (val === null || val === undefined) {
        missing.push(def.label);
      } else if (def.type === "text" && String(val).trim() === "") {
        missing.push(def.label);
      }
    }
  }
  return missing;
}

async function getCustomAttrLabelsForMissing(requiredKeys: string[]): Promise<Map<string, string>> {
  const customCodes = requiredKeys.filter(isCustomAttrKey).map(getCustomAttrCode);
  if (customCodes.length === 0) return new Map();
  const allAttrs = await storage.getAttributeDefs();
  const map = new Map<string, string>();
  for (const attr of allAttrs) {
    if (customCodes.includes(attr.code)) {
      map.set(attr.code, attr.label || attr.code);
    }
  }
  return map;
}

let cachedSyncRequiredFields: string[] | null = null;

async function getSyncRequiredFieldKeys(): Promise<string[]> {
  if (cachedSyncRequiredFields) return cachedSyncRequiredFields;
  const val = await storage.getWorkspaceSetting("sync_required_fields");
  if (Array.isArray(val)) {
    cachedSyncRequiredFields = val as string[];
    return cachedSyncRequiredFields;
  }
  return ["productDescription", "brandId", "productTypeId", "genderId", "productColourId"];
}

function invalidateSyncRequiredFieldsCache() {
  cachedSyncRequiredFields = null;
}

function isRowEmpty(row: Record<string, any>): boolean {
  return Object.values(row).every((value) => {
    if (value === null || value === undefined) return true;
    return String(value).trim() === "";
  });
}

const CASE_SENSITIVE_HEADER_MAP: Record<string, string> = {
  "Description": "productDescription",
};

function convertHeadersToCamelCase(data: any[]): any[] {
  const retailPricePattern = /^Retail\s+Price\s+([A-Za-z]{3})$/i;
  const specialRetailPricePattern = /^Special\s+Retail\s+Price\s+([A-Za-z]{3})$/i;

  return data.map(row => {
    const newRow: any = {};
    for (const key in row) {
      const normalizedKey = key.trim().replace(/\*+$/g, "");
      if (normalizedKey in CASE_SENSITIVE_HEADER_MAP) {
        newRow[CASE_SENSITIVE_HEADER_MAP[normalizedKey]] = row[key];
      } else {
        const specialMatch = normalizedKey.match(specialRetailPricePattern);
        if (specialMatch) {
          const code = specialMatch[1].toUpperCase();
          newRow[`specialPrice${code.charAt(0)}${code.slice(1).toLowerCase()}`] = row[key];
          continue;
        }
        const retailMatch = normalizedKey.match(retailPricePattern);
        if (retailMatch) {
          const code = retailMatch[1].toUpperCase();
          newRow[`price${code.charAt(0)}${code.slice(1).toLowerCase()}`] = row[key];
          continue;
        }
        const camelKey = snakeToCamel(normalizedKey);
        newRow[camelKey] = row[key];
      }
    }
    return newRow;
  });
}

export async function registerRoutes(app: Express): Promise<Express> {
  // Dashboard metrics
  app.get("/api/dashboard", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  // Global search endpoint
  app.get("/api/search", async (req, res) => {
    try {
      const query = typeof req.query.q === "string" ? req.query.q.trim() : "";
      if (!query) {
        return res.json({
          products: [],
          clubs: [],
          brands: [],
          productTypes: [],
          groups: [],
          genders: [],
          colours: [],
        });
      }

      const searchPattern = `%${query}%`;
      const LIMIT = 5;

      const [products, clubsResult, brandsResult, typesResult, groupsResult, gendersResult, coloursResult] =
        await Promise.all([
          // Search products by SKU, name, or description
          db
            .select({
              id: product.productId,
              name: product.name,
              sku: product.sku,
            })
            .from(product)
            .where(
              sql`${product.sku} ILIKE ${searchPattern}
                OR ${product.name} ILIKE ${searchPattern}
                OR ${product.productDescription} ILIKE ${searchPattern}`
            )
            .limit(LIMIT),

          // Search clubs by name
          db
            .select({
              id: club.clubId,
              name: club.name,
            })
            .from(club)
            .where(sql`${club.name} ILIKE ${searchPattern}`)
            .limit(LIMIT),

          // Search brands by name
          db
            .select({
              id: brands.brandId,
              name: brands.brandName,
            })
            .from(brands)
            .where(sql`${brands.brandName} ILIKE ${searchPattern}`)
            .limit(LIMIT),

          // Search product types by name
          db
            .select({
              id: productType.productTypeId,
              name: productType.productTypeName,
            })
            .from(productType)
            .where(sql`${productType.productTypeName} ILIKE ${searchPattern}`)
            .limit(LIMIT),

          // Search product groups by name
          db
            .select({
              id: productGroup.productGroupId,
              name: productGroup.name,
            })
            .from(productGroup)
            .where(sql`${productGroup.name} ILIKE ${searchPattern}`)
            .limit(LIMIT),

          // Search genders by name
          db
            .select({
              id: gender.genderId,
              name: gender.genderName,
            })
            .from(gender)
            .where(sql`${gender.genderName} ILIKE ${searchPattern}`)
            .limit(LIMIT),

          // Search product colours by name
          db
            .select({
              id: productColour.productColourId,
              name: productColour.magentoColourName,
            })
            .from(productColour)
            .where(sql`${productColour.magentoColourName} ILIKE ${searchPattern}`)
            .limit(LIMIT),
        ]);

      // Format results with type and URL
      const results = {
        products: products.map((p) => ({
          id: p.id,
          name: p.sku ? `${p.sku} - ${p.name}` : p.name,
          type: "Product",
          url: `/product/${p.id}`,
        })),
        clubs: clubsResult.map((c) => ({
          id: c.id,
          name: c.name,
          type: "Team",
          url: "/attributes",
        })),
        brands: brandsResult.map((b) => ({
          id: b.id,
          name: b.name,
          type: "Brand",
          url: "/attributes",
        })),
        productTypes: typesResult.map((t) => ({
          id: t.id,
          name: t.name,
          type: "Product Type",
          url: "/attributes",
        })),
        groups: groupsResult.map((g) => ({
          id: g.id,
          name: g.name,
          type: "Group",
          url: "/groups",
        })),
        genders: gendersResult.map((g) => ({
          id: g.id,
          name: g.name,
          type: "Gender",
          url: "/attributes",
        })),
        colours: coloursResult.map((c) => ({
          id: c.id,
          name: c.name,
          type: "Colour",
          url: "/attributes",
        })),
      };

      res.json(results);
    } catch (error) {
      console.error("Error in global search:", error);
      res.status(500).json({ error: "Failed to perform search" });
    }
  });

  app.get("/api/dashboard/insights", async (req, res) => {
    try {
      const activityRange = typeof req.query.activityRange === "string"
        ? req.query.activityRange
        : "last_30_days";
      const assetField = typeof req.query.assetField === "string"
        ? req.query.assetField
        : "images";

      const allowedAssets = new Set([
        "images",
        "brand",
        "description",
        "composition",
        "country",
        "productType",
      ]);
      const normalizedAssetField = allowedAssets.has(assetField) ? assetField : "images";

      const now = new Date();
      let startDate: Date;
      let endDate: Date = now;

      if (activityRange === "custom") {
        const startParam = typeof req.query.startDate === "string" ? req.query.startDate : "";
        const endParam = typeof req.query.endDate === "string" ? req.query.endDate : "";
        const parsedStart = startParam ? new Date(startParam) : null;
        const parsedEnd = endParam ? new Date(endParam) : null;

        if (parsedStart && parsedEnd && !Number.isNaN(parsedStart.getTime()) && !Number.isNaN(parsedEnd.getTime())) {
          startDate = parsedStart;
          endDate = parsedEnd;
        } else {
          startDate = new Date(now);
          startDate.setDate(startDate.getDate() - 30);
        }
      } else {
        startDate = new Date(now);
        if (activityRange === "last_day") {
          startDate.setDate(startDate.getDate() - 1);
        } else if (activityRange === "last_week") {
          startDate.setDate(startDate.getDate() - 7);
        } else {
          startDate.setDate(startDate.getDate() - 30);
        }
      }

      const [status, activity, assets] = await Promise.all([
        storage.getProductStatusCounts(),
        storage.getProductActivityCounts(startDate, endDate),
        storage.getProductMissingAttributeCounts(normalizedAssetField),
      ]);

      res.json({
        status,
        activity: {
          ...activity,
          range: {
            start: startDate.toISOString(),
            end: endDate.toISOString(),
          },
        },
        assets: {
          ...assets,
          attribute: normalizedAssetField,
        },
      });
    } catch (error) {
      console.error("Error fetching dashboard insights:", error);
      res.status(500).json({ error: "Failed to fetch dashboard insights" });
    }
  });

  // Product catalog with filters
  app.get("/api/catalog/products", async (req, res) => {
    try {
      const filters: any = {};
      
      if (req.query.search) filters.search = req.query.search as string;
      if (req.query.brandId) filters.brandId = parseInt(req.query.brandId as string);
      if (req.query.categoryId) filters.categoryId = parseInt(req.query.categoryId as string);
      if (req.query.clubId) filters.clubId = parseInt(req.query.clubId as string);
      if (req.query.seasonId) filters.seasonId = parseInt(req.query.seasonId as string);
      if (req.query.departmentId) filters.departmentId = parseInt(req.query.departmentId as string);
      if (req.query.enabled !== undefined) filters.enabled = req.query.enabled === 'true';
      if (req.query.filters) {
        try {
          const parsed = JSON.parse(req.query.filters as string);
          if (Array.isArray(parsed)) {
            filters.attributeFilters = parsed;
          }
        } catch (error) {
          console.warn("Failed to parse catalog filters", error);
        }
      }
      if (req.query.sortBy) filters.sortBy = req.query.sortBy as string;
      if (req.query.order) filters.order = req.query.order as string;
      if (req.query.limit) filters.limit = parseInt(req.query.limit as string);
      if (req.query.offset) filters.offset = parseInt(req.query.offset as string);

      const [products, count] = await Promise.all([
        storage.getProductsWithFilters(filters),
        storage.getProductsCount(filters)
      ]);

      res.json({ products, count });
    } catch (error) {
      console.error("Error fetching catalog products:", error);
      res.status(500).json({ error: "Failed to fetch catalog products" });
    }
  });

  // Products
  app.get("/api/products", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const products = await storage.getProducts(limit);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const sku = String(req.body?.productSku ?? "").trim();
      const description = String(req.body?.productDescription ?? "").trim();

      const parseNumberOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const parsed = Number(value);
        if (Number.isNaN(parsed)) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return parsed;
      };

      if (!sku) {
        return res.status(400).json({ error: "SKU is required" });
      }

      if (!description) {
        return res.status(400).json({ error: "Description is required" });
      }

      const categoryId = parseNumberOrNull(req.body?.categoryId, "category");
      const categoryIds = Array.isArray(req.body?.categoryIds) ? req.body.categoryIds.map(Number).filter((n: number) => !isNaN(n)) : null;
      const productColourId = parseNumberOrNull(req.body?.productColourId, "product colour");
      const genderId = parseNumberOrNull(req.body?.genderId, "gender");
      const brandId = parseNumberOrNull(req.body?.brandId, "brand");
      const productTypeId = parseNumberOrNull(req.body?.productTypeId, "product type");
      const productStyle = req.body?.productStyle != null && String(req.body.productStyle).trim() !== "" ? String(req.body.productStyle).trim() : null;
      const clubId = parseNumberOrNull(req.body?.clubId, "team");

      // Simple product variant fields
      const sizeId = parseNumberOrNull(req.body?.sizeId, "size");
      const taxClassId = parseNumberOrNull(req.body?.taxClassId, "tax class");
      const conditionId = parseNumberOrNull(req.body?.conditionId, "condition");
      const weight = parseNumberOrNull(req.body?.weight, "weight");
      const costPrice = parseNumberOrNull(req.body?.costPrice, "cost price");
      const retailPrice = parseNumberOrNull(req.body?.retailPrice, "retail price");
      const specialRetailPrice = parseNumberOrNull(req.body?.specialRetailPrice, "special retail price");
      const stockQty = parseNumberOrNull(req.body?.stockQty, "stock quantity");
      const warehouseId = parseNumberOrNull(req.body?.warehouseId, "warehouse");

      const enabled = req.body?.enabled === false ? false : true;
      const sync = req.body?.sync === false ? false : true;

      const result = await storage.createProduct({
        productSku: sku,
        articleNumber: String(req.body?.articleNumber ?? "").trim() || null,
        productDescription: description,
        productColourId,
        genderId,
        brandId,
        productTypeId,
        productStyle,
        clubId,
        composition: String(req.body?.composition ?? "").trim() || null,
        countryOfManufacture: String(req.body?.countryOfManufacture ?? "").trim() || null,
        commodityCode: String(req.body?.commodityCode ?? "").trim() || null,
        imageCode: String(req.body?.imageCode ?? "").trim() || null,
        categoryId,
        categoryIds,
        enabled,
        sync,
        // Simple product variant fields (empty string treated as null to use productSku)
        variantSku: String(req.body?.variantSku ?? "").trim() || null,
        sizeId,
        taxClassId,
        conditionId,
        barcode: String(req.body?.barcode ?? "").trim() || null,
        weight,
        costPrice,
        retailPrice,
        specialRetailPrice,
        stockQty,
        warehouseId,
      });

      res.status(201).json(result);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to create product";
      if (message.includes("already exists")) {
        return res.status(409).json({ error: message });
      }
      if (message.includes("not found")) {
        return res.status(400).json({ error: message });
      }
      if (message.startsWith("Invalid ")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error creating product:", error);
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const productId = Number(req.params.id);
      if (!productId || Number.isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const existing = await storage.getProduct(productId);
      if (!existing) {
        return res.status(404).json({ error: "Product not found" });
      }
      await storage.deleteProduct(productId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  const handleBulkDeleteProducts = async (req: any, res: any) => {
    try {
      const productIds = Array.isArray(req.body?.productIds)
        ? req.body.productIds.map((id: any) => Number(id)).filter((id: number) => Number.isFinite(id))
        : [];
      if (productIds.length === 0) {
        return res.status(400).json({ error: "No product IDs provided" });
      }
      await storage.deleteProducts(productIds);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting products:", error);
      res.status(500).json({ error: "Failed to delete products" });
    }
  };

  app.post("/api/products/bulk-delete", handleBulkDeleteProducts);
  app.delete("/api/products/bulk-delete", handleBulkDeleteProducts);

  app.post("/api/products/bulk-sync", async (req, res) => {
    try {
      const { productIds, sync } = req.body;
      if (!Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: "productIds must be a non-empty array" });
      }
      if (typeof sync !== "boolean") {
        return res.status(400).json({ error: "sync must be a boolean" });
      }
      const validIds = Array.from(new Set(productIds.map(Number).filter((id: number) => Number.isFinite(id) && id > 0)));

      if (sync === true) {
        const skipped: Array<{ productId: number; sku: string | null; missingFields: string[] }> = [];
        const enabledIds: number[] = [];
        const requiredKeys = await getSyncRequiredFieldKeys();
        const hasCustomKeys = requiredKeys.some(isCustomAttrKey);
        const customAttrLabels = hasCustomKeys ? await getCustomAttrLabelsForMissing(requiredKeys) : new Map<string, string>();
        for (const id of validIds) {
          const prod = await storage.getProduct(id);
          if (!prod) continue;
          const prodAttrs = hasCustomKeys ? await storage.getProductAttributes(id) : undefined;
          const missing = getSyncRequiredMissingFieldsFromConfig(prod, requiredKeys, prodAttrs, customAttrLabels);
          if (missing.length > 0) {
            skipped.push({ productId: id, sku: prod.productSku, missingFields: missing });
          } else {
            enabledIds.push(id);
          }
        }
        for (const id of enabledIds) {
          await storage.updateProduct(id, { sync: true });
        }
        res.json({ updated: enabledIds.length, sync: true, skipped });
      } else {
        for (const id of validIds) {
          await storage.updateProduct(id, { sync: false });
        }
        res.json({ updated: validIds.length, sync: false, skipped: [] });
      }
    } catch (error) {
      console.error("Error bulk updating sync:", error);
      res.status(500).json({ error: "Failed to bulk update sync" });
    }
  });

  app.post("/api/products/:id/duplicate", async (req, res) => {
    try {
      const productId = Number(req.params.id);
      if (!productId || Number.isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const result = await storage.duplicateProduct(productId);
      res.status(201).json(result);
    } catch (error: any) {
      console.error("Error duplicating product:", error);
      if (error.message === "Product not found") {
        return res.status(404).json({ error: "Product not found" });
      }
      res.status(500).json({ error: "Failed to duplicate product" });
    }
  });

  // Get product with full details including attribution
  app.get("/api/products/:id/details", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      
      const storeId = req.query?.storeId != null ? Number(req.query.storeId) : undefined;
      const [product, variants, teamMeta, productAttributes, allCurrencies] = await Promise.all([
        storage.getProductWithAttribution(productId),
        storage.getProductVariants(productId),
        storage.getProductTeamMeta(productId),
        storage.getProductAttributes(productId, storeId),
        storage.getCurrencies(),
      ]);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const productSku = product.productSku;
      const filteredVariants = variants.filter((v: any) => v.productVariantSku !== productSku);

      const gbpCurrency = allCurrencies.find((c: any) => c.code === "GBP");
      let enrichedVariants = filteredVariants;
      if (gbpCurrency) {
        const gbpCurrencyId = Number(gbpCurrency.currencyId);
        enrichedVariants = await Promise.all(
          filteredVariants.map(async (v: any) => {
            const prices = await storage.getVariantPrices(v.productVariantId);
            const gbpPrice = prices.find((p: any) => Number(p.currencyId) === gbpCurrencyId);
            return {
              ...v,
              gbpRetailPrice: gbpPrice?.retailPrice ?? null,
              gbpSpecialPrice: gbpPrice?.specialRetailPrice ?? null,
              gbpCostPrice: gbpPrice?.costPrice ?? null,
            };
          })
        );
      }

      const requiredKeys = await getSyncRequiredFieldKeys();
      const hasCustomKeys = requiredKeys.some(isCustomAttrKey);
      const customAttrLabels = hasCustomKeys ? await getCustomAttrLabelsForMissing(requiredKeys) : new Map<string, string>();
      const syncRequiredMissing = getSyncRequiredMissingFieldsFromConfig(product, requiredKeys, productAttributes, customAttrLabels);

      res.json({
        ...product,
        variants: enrichedVariants,
        teamMeta,
        productAttributes,
        syncRequiredMissing,
      });
    } catch (error) {
      console.error("Error fetching product details:", error);
      res.status(500).json({ error: "Failed to fetch product details" });
    }
  });

  app.post("/api/products/:id/variants", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (!productId) {
        return res.status(400).json({ error: "Invalid product ID" });
      }

      const variantSku = String(req.body?.productVariantSku ?? "").trim();
      if (!variantSku) {
        return res.status(400).json({ error: "Variant SKU is required" });
      }

      const parseNumberOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const parsed = Number(value);
        if (Number.isNaN(parsed)) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return parsed;
      };

      const sizeId = parseNumberOrNull(req.body?.sizeId, "size");
      const taxClassId = parseNumberOrNull(req.body?.taxClassId, "tax class");
      const conditionId = parseNumberOrNull(req.body?.conditionId, "condition");
      const conditionDetail = req.body?.conditionDetail ? String(req.body.conditionDetail).trim() : null;
      const barcode = req.body?.barcode ? String(req.body.barcode).trim() : null;
      const magentoProductId = parseNumberOrNull(req.body?.magentoProductId, "magento product ID");
      const widthCm = parseNumberOrNull(req.body?.widthCm, "width");
      const lengthCm = parseNumberOrNull(req.body?.lengthCm, "length");
      const weight = parseNumberOrNull(req.body?.weight, "weight");
      const depth = parseNumberOrNull(req.body?.depth, "depth");
      const costPrice = parseNumberOrNull(req.body?.costPrice, "cost price");
      const averageCostPrice = parseNumberOrNull(req.body?.averageCostPrice, "average cost price");
      const customerPrice = parseNumberOrNull(req.body?.customerPrice, "customer price");
      const printed = req.body?.printed === true ? true : false;
      const enabled = req.body?.enabled === false ? false : true;

      const result = await storage.createProductVariant({
        productId,
        productVariantSku: variantSku,
        sizeId,
        taxClassId,
        conditionId,
        conditionDetail,
        barcode,
        magentoProductId,
        widthCm,
        lengthCm,
        weight,
        depth,
        costPrice,
        averageCostPrice,
        customerPrice,
        printed,
        enabled,
      });

      res.status(201).json(result);
    } catch (error) {
      const dbError = error as { code?: string; constraint?: string; detail?: string };
      const message = error instanceof Error ? error.message : "Failed to create product variant";
      if (dbError?.code === "23505") {
        return res.status(409).json({ error: "Variant SKU or barcode already exists" });
      }
      if (dbError?.code === "23503") {
        return res.status(400).json({ error: "Invalid product or attribute reference" });
      }
      if (message.includes("already exists")) {
        return res.status(409).json({ error: message });
      }
      if (message.includes("not found")) {
        return res.status(400).json({ error: message });
      }
      if (message.startsWith("Invalid ")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error creating product variant:", error);
      res.status(500).json({ error: message });
    }
  });

  // Product variants
  app.get("/api/products/:id/variants", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const variants = await storage.getProductVariants(productId);
      res.json(variants);
    } catch (error) {
      console.error("Error fetching variants:", error);
      res.status(500).json({ error: "Failed to fetch variants" });
    }
  });

  // Variant details
  app.get("/api/variants/:id", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const [variant, attributes] = await Promise.all([
        storage.getVariant(variantId),
        storage.getVariantAttributes(variantId),
      ]);
      if (!variant) {
        return res.status(404).json({ error: "Variant not found" });
      }
      res.json({ ...variant, attributes });
    } catch (error) {
      console.error("Error fetching variant:", error);
      res.status(500).json({ error: "Failed to fetch variant" });
    }
  });

  app.patch("/api/products/:id/variants/bulk-update", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (!productId) {
        return res.status(400).json({ error: "Invalid product ID" });
      }

      const { variantIds, updates, gbpPricing } = req.body;
      const hasUpdates = updates && typeof updates === "object" && Object.keys(updates).length > 0;
      const hasGbpPricing = gbpPricing && typeof gbpPricing === "object" && Object.keys(gbpPricing).length > 0;
      if (!hasUpdates && !hasGbpPricing) {
        return res.status(400).json({ error: "No updates provided" });
      }

      const allowedFields = [
        "sizeId", "taxClassId", "conditionId", "conditionDetail",
        "barcode", "widthCm", "lengthCm", "weight", "depth",
        "printed", "magentoProductId", "enabled",
      ];

      const sanitized: Record<string, any> = {};
      if (hasUpdates) {
        for (const field of allowedFields) {
          if (updates[field] !== undefined) {
            sanitized[field] = updates[field];
          }
        }
      }

      const allVariants = await storage.getProductVariants(productId);
      if (!allVariants || allVariants.length === 0) {
        return res.status(404).json({ error: "Product has no variants" });
      }

      const productVariantIds = new Set(allVariants.map((v: any) => Number(v.productVariantId)));
      let targetIds: number[];
      if (variantIds && Array.isArray(variantIds) && variantIds.length > 0) {
        targetIds = variantIds.map(Number).filter(id => productVariantIds.has(id));
        if (targetIds.length === 0) {
          return res.status(400).json({ error: "None of the provided variant IDs belong to this product" });
        }
      } else {
        targetIds = Array.from(productVariantIds);
      }

      const numericFields = ["sizeId", "taxClassId", "conditionId", "magentoProductId", "widthCm", "lengthCm", "weight", "depth"];
      for (const field of numericFields) {
        if (sanitized[field] !== undefined) {
          if (sanitized[field] === null || sanitized[field] === "" || sanitized[field] === "none") {
            sanitized[field] = null;
          } else {
            const parsed = parseFloat(String(sanitized[field]));
            if (isNaN(parsed)) {
              return res.status(400).json({ error: `Invalid numeric value for ${field}` });
            }
            sanitized[field] = ["sizeId", "taxClassId", "conditionId", "magentoProductId"].includes(field) ? Math.floor(parsed) : String(parsed);
          }
        }
      }

      let updatedCount = 0;
      if (Object.keys(sanitized).length > 0) {
        for (const vid of targetIds) {
          try {
            await storage.updateVariant(vid, sanitized);
            updatedCount++;
          } catch (e) {
            console.error(`Error updating variant ${vid}:`, e);
          }
        }
      }

      let pricesUpdated = 0;
      if (hasGbpPricing) {
        const allCurrencies = await storage.getCurrencies();
        const gbpCurrency = allCurrencies.find((c: any) => c.code === "GBP");
        if (gbpCurrency) {
          const gbpCurrencyId = Number(gbpCurrency.currencyId);
          const pricingData: Record<string, string | null> = {};
          for (const field of ["retailPrice", "specialRetailPrice", "costPrice"]) {
            if (gbpPricing[field] !== undefined) {
              if (gbpPricing[field] === null || gbpPricing[field] === "") {
                pricingData[field] = null;
              } else {
                const parsed = parseFloat(String(gbpPricing[field]));
                if (isNaN(parsed)) {
                  return res.status(400).json({ error: `Invalid numeric value for GBP ${field}` });
                }
                pricingData[field] = String(parsed);
              }
            }
          }
          for (const vid of targetIds) {
            try {
              const existingPrices = await storage.getVariantPrices(vid);
              const existingGbp = existingPrices.find((p: any) => Number(p.currencyId) === gbpCurrencyId);
              await storage.upsertVariantPrice({
                productVariantId: vid,
                currencyId: gbpCurrencyId,
                retailPrice: pricingData.retailPrice !== undefined ? pricingData.retailPrice : (existingGbp?.retailPrice ?? null),
                specialRetailPrice: pricingData.specialRetailPrice !== undefined ? pricingData.specialRetailPrice : (existingGbp?.specialRetailPrice ?? null),
                costPrice: pricingData.costPrice !== undefined ? pricingData.costPrice : (existingGbp?.costPrice ?? null),
                isManualOverride: false,
              });
              await storage.autoConvertPricesFromBase(vid, "GBP");
              pricesUpdated++;
            } catch (e) {
              console.error(`Error updating GBP price for variant ${vid}:`, e);
            }
          }
        }
      }

      res.json({ success: true, updatedCount, pricesUpdated });
    } catch (error) {
      console.error("Error bulk updating variants:", error);
      const message = error instanceof Error ? error.message : "Failed to bulk update variants";
      res.status(500).json({ error: message });
    }
  });

  app.patch("/api/variants/:id", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      if (!variantId) {
        return res.status(400).json({ error: "Invalid variant ID" });
      }

      const allowedFields = [
        "sizeId",
        "taxClassId",
        "conditionId",
        "conditionDetail",
        "barcode",
        "widthCm",
        "lengthCm",
        "weight",
        "depth",
        "costPrice",
        "averageCostPrice",
        "retailPrice",
        "specialRetailPrice",
        "customerPrice",
        "printed",
        "magentoProductId",
        "enabled",
      ] as const;

      const updates: Record<string, any> = {};
      for (const field of allowedFields) {
        if (req.body?.[field] !== undefined) {
          updates[field] = req.body[field];
        }
      }

      await storage.updateVariant(variantId, updates);
      res.json({ success: true });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update variant";
      if (message.includes("not found")) {
        return res.status(404).json({ error: message });
      }
      if (message.includes("already exists")) {
        return res.status(409).json({ error: message });
      }
      if (message.startsWith("Invalid ") || message.endsWith("not found")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error updating variant:", error);
      res.status(500).json({ error: message });
    }
  });

  app.post("/api/variants/:id/attributes", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      if (!variantId) {
        return res.status(400).json({ error: "Invalid variant ID" });
      }
      const attributeId = Number(req.body?.attributeId);
      if (!attributeId || Number.isNaN(attributeId)) {
        return res.status(400).json({ error: "Invalid attribute id" });
      }
      const value = req.body?.value;
      await storage.setVariantAttributeValue({ variantId, attributeId, value });
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to set attribute";
      if (message.includes("not found") || message.includes("scope")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error setting variant attribute:", error);
      res.status(500).json({ error: "Failed to set attribute" });
    }
  });

  app.delete("/api/variants/:id/attributes/:attributeId", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const attributeId = parseInt(req.params.attributeId);
      if (!variantId || !attributeId) {
        return res.status(400).json({ error: "Invalid variant or attribute ID" });
      }
      await storage.deleteVariantAttributeValue({ variantId, attributeId });
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting variant attribute:", error);
      res.status(500).json({ error: "Failed to delete attribute" });
    }
  });

  // Variant stock
  app.get("/api/variants/:id/stock", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const stock = await storage.getVariantStock(variantId);
      res.json(stock);
    } catch (error) {
      console.error("Error fetching stock:", error);
      res.status(500).json({ error: "Failed to fetch stock" });
    }
  });

  // Product prices with store info
  app.get("/api/products/:id/prices", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const prices = await storage.getProductPricesWithStores(productId);
      res.json(prices);
    } catch (error) {
      console.error("Error fetching product prices:", error);
      res.status(500).json({ error: "Failed to fetch product prices" });
    }
  });

  // Variant prices
  app.get("/api/variants/:id/prices", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const prices = await storage.getVariantPrices(variantId);
      res.json(prices);
    } catch (error) {
      console.error("Error fetching prices:", error);
      res.status(500).json({ error: "Failed to fetch prices" });
    }
  });

  // Variant prices with currency details
  app.get("/api/variants/:id/prices-with-currency", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const prices = await storage.getVariantPricesWithCurrency(variantId);
      res.json(prices);
    } catch (error) {
      console.error("Error fetching prices with currency:", error);
      res.status(500).json({ error: "Failed to fetch prices" });
    }
  });

  // Update variant price for a currency
  app.put("/api/variants/:id/prices/:currencyId", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const currencyId = parseInt(req.params.currencyId);
      const { retailPrice, specialRetailPrice, costPrice, isManualOverride } = req.body;

      await storage.upsertVariantPrice({
        productVariantId: variantId,
        currencyId,
        retailPrice: retailPrice ?? null,
        specialRetailPrice: specialRetailPrice ?? null,
        costPrice: costPrice ?? null,
        isManualOverride: isManualOverride ?? true,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error updating variant price:", error);
      res.status(500).json({ error: "Failed to update price" });
    }
  });

  // Trigger auto-conversion from base currency for a variant
  app.post("/api/variants/:id/prices/auto-convert", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const baseCurrency = typeof req.body?.baseCurrencyCode === "string" ? req.body.baseCurrencyCode : "GBP";
      await storage.autoConvertPricesFromBase(variantId, baseCurrency);
      res.json({ success: true });
    } catch (error) {
      console.error("Error auto-converting prices:", error);
      res.status(500).json({ error: "Failed to auto-convert prices" });
    }
  });

  // Bulk recalculate prices for selected products
  app.post("/api/products/bulk-recalculate-prices", async (req, res) => {
    try {
      const productIds = req.body?.productIds;
      if (!Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: "productIds must be a non-empty array" });
      }
      const baseCurrency = typeof req.body?.baseCurrencyCode === "string" ? req.body.baseCurrencyCode : "GBP";
      let productsProcessed = 0;
      let recalculated = 0;
      const validIds = [...new Set(productIds.map(Number).filter(id => Number.isFinite(id) && id > 0))];
      for (const pid of validIds) {
        const variants = await storage.getProductVariants(pid);
        if (variants.length > 0) {
          productsProcessed++;
          for (const v of variants) {
            await storage.autoConvertPricesFromBase(v.productVariantId, baseCurrency);
            recalculated++;
          }
        }
      }
      res.json({ success: true, productsProcessed, variantsRecalculated: recalculated });
    } catch (error) {
      console.error("Error bulk recalculating prices:", error);
      res.status(500).json({ error: "Failed to recalculate prices" });
    }
  });

  app.post("/api/products/:id/attach-simple-products", async (req, res) => {
    try {
      const configurableProductId = parseInt(req.params.id);
      if (isNaN(configurableProductId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const { productIds } = req.body;
      if (!Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: "productIds must be a non-empty array" });
      }
      const validIds = productIds.map(Number).filter((id) => Number.isFinite(id) && id > 0);
      const result = await storage.attachSimpleProductsToConfigurable(configurableProductId, validIds);
      res.json({ success: true, ...result });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to attach products";
      console.error("Error attaching simple products:", error);
      res.status(500).json({ error: message });
    }
  });

  app.post("/api/products/:id/variants/:variantId/detach", async (req, res) => {
    try {
      const configurableProductId = parseInt(req.params.id);
      const variantId = parseInt(req.params.variantId);
      if (isNaN(configurableProductId) || isNaN(variantId)) {
        return res.status(400).json({ error: "Invalid product or variant ID" });
      }
      const result = await storage.detachVariantToNewProduct(configurableProductId, variantId);
      res.json({ success: true, ...result });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to detach variant";
      console.error("Error detaching variant:", error);
      const validationErrors = [
        "Parent product not found",
        "Variant not found on this product",
        "Can only detach variants from configurable products",
        "Cannot detach the last variant from a product",
        "Configurable product type not found in system",
        "Variant has no SKU",
      ];
      if (validationErrors.some((e) => message.includes(e))) {
        return res.status(400).json({ error: message });
      }
      if (message.includes("already exists")) {
        return res.status(409).json({ error: message });
      }
      res.status(500).json({ error: message });
    }
  });

  // Reset manual override on a variant price (clear override flag, then re-run auto-conversion)
  app.patch("/api/variants/:id/prices/:currencyId/reset-override", async (req, res) => {
    try {
      const variantId = parseInt(req.params.id);
      const currencyId = parseInt(req.params.currencyId);
      if (isNaN(variantId) || isNaN(currencyId)) {
        return res.status(400).json({ error: "Invalid variant or currency ID" });
      }
      const existingPrices = await storage.getVariantPricesWithCurrency(variantId);
      const existingPrice = existingPrices.find((p: any) => p.currencyId === currencyId);
      if (!existingPrice) {
        return res.status(404).json({ error: "Price not found for this currency" });
      }
      await storage.upsertVariantPrice({
        productVariantId: variantId,
        currencyId,
        retailPrice: existingPrice.retailPrice,
        specialRetailPrice: existingPrice.specialRetailPrice,
        costPrice: existingPrice.costPrice,
        isManualOverride: false,
      });
      await storage.autoConvertPricesFromBase(variantId);
      const prices = await storage.getVariantPricesWithCurrency(variantId);
      res.json(prices);
    } catch (error) {
      console.error("Error resetting price override:", error);
      res.status(500).json({ error: "Failed to reset price override" });
    }
  });

  // Currency conversion rates
  app.get("/api/conversion-rates", async (req, res) => {
    try {
      const rates = await storage.getConversionRates();
      res.json(rates);
    } catch (error) {
      console.error("Error fetching conversion rates:", error);
      res.status(500).json({ error: "Failed to fetch conversion rates" });
    }
  });

  app.put("/api/conversion-rates", async (req, res) => {
    try {
      const rates = req.body?.rates;
      if (!Array.isArray(rates)) {
        return res.status(400).json({ error: "rates must be an array" });
      }
      const errors: string[] = [];
      for (let i = 0; i < rates.length; i++) {
        const entry = rates[i];
        const fromCurrencyId = Number(entry?.fromCurrencyId);
        const toCurrencyId = Number(entry?.toCurrencyId);
        const rateStr = String(entry?.rate ?? "").trim();
        const rateNum = Number(rateStr);
        if (!fromCurrencyId || isNaN(fromCurrencyId)) {
          errors.push(`Entry ${i}: invalid fromCurrencyId`);
          continue;
        }
        if (!toCurrencyId || isNaN(toCurrencyId)) {
          errors.push(`Entry ${i}: invalid toCurrencyId`);
          continue;
        }
        if (!rateStr || isNaN(rateNum) || rateNum <= 0) {
          errors.push(`Entry ${i}: rate must be a positive number`);
          continue;
        }
        await storage.upsertConversionRate({ fromCurrencyId, toCurrencyId, rate: rateStr });
      }
      const updated = await storage.getConversionRates();
      if (errors.length > 0) {
        res.json({ rates: updated, warnings: errors });
      } else {
        res.json(updated);
      }
    } catch (error) {
      console.error("Error updating conversion rates:", error);
      res.status(500).json({ error: "Failed to update conversion rates" });
    }
  });

  // Reference data
  app.get("/api/stores", async (req, res) => {
    try {
      const stores = await storage.getStores();
      res.json(stores);
    } catch (error) {
      console.error("Error fetching stores:", error);
      res.status(500).json({ error: "Failed to fetch stores" });
    }
  });

  app.get("/api/stores/product-counts", async (req, res) => {
    try {
      const counts = await storage.getStoreProductCounts();
      res.json(counts);
    } catch (error) {
      console.error("Error fetching store product counts:", error);
      res.status(500).json({ error: "Failed to fetch store product counts" });
    }
  });

  app.post("/api/stores", async (req, res) => {
    try {
      const code = String(req.body?.code ?? "").trim();
      const name = String(req.body?.name ?? "").trim() || null;
      const websiteCode = String(req.body?.websiteCode ?? "").trim();

      if (!code) {
        return res.status(400).json({ error: "Store code is required" });
      }

      if (!websiteCode) {
        return res.status(400).json({ error: "Website code is required" });
      }

      const created = await storage.createStore({ code, name, websiteCode });
      res.status(201).json(created);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to create store";
      if (message.toLowerCase().includes("exists")) {
        return res.status(409).json({ error: message });
      }
      console.error("Error creating store:", error);
      res.status(500).json({ error: "Failed to create store" });
    }
  });

  app.patch("/api/stores/:id", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      if (isNaN(storeId)) {
        return res.status(400).json({ error: "Invalid store ID" });
      }

      const code = req.body?.code !== undefined ? String(req.body.code).trim() : undefined;
      const name = req.body?.name !== undefined ? (String(req.body.name).trim() || null) : undefined;
      const websiteCode = req.body?.websiteCode !== undefined ? String(req.body.websiteCode).trim() : undefined;

      const updated = await storage.updateStore(storeId, { code, name, websiteCode });
      res.json(updated);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update store";
      if (message.toLowerCase().includes("not found")) {
        return res.status(404).json({ error: message });
      }
      if (message.toLowerCase().includes("exists")) {
        return res.status(409).json({ error: message });
      }
      console.error("Error updating store:", error);
      res.status(500).json({ error: "Failed to update store" });
    }
  });

  app.get("/api/products/:id/stores", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const stores = await storage.getProductStores(productId);
      res.json(stores);
    } catch (error) {
      console.error("Error fetching product stores:", error);
      res.status(500).json({ error: "Failed to fetch product stores" });
    }
  });

  app.put("/api/products/:id/stores", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const { storeIds } = req.body;
      if (!Array.isArray(storeIds)) {
        return res.status(400).json({ error: "storeIds must be an array" });
      }
      await storage.setProductStores(productId, storeIds);
      res.json({ success: true });
    } catch (error) {
      console.error("Error setting product stores:", error);
      res.status(500).json({ error: "Failed to set product stores" });
    }
  });

  app.get("/api/products/:id/categories", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const categories = await storage.getCategoriesForProduct(productId);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching product categories:", error);
      res.status(500).json({ error: "Failed to fetch product categories" });
    }
  });

  app.put("/api/products/:id/categories", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const { categoryIds } = req.body;
      if (!Array.isArray(categoryIds)) {
        return res.status(400).json({ error: "categoryIds must be an array" });
      }
      await storage.assignProductToCategories(productId, categoryIds);
      res.json({ success: true });
    } catch (error) {
      console.error("Error setting product categories:", error);
      res.status(500).json({ error: "Failed to set product categories" });
    }
  });

  app.get("/api/currencies", async (req, res) => {
    try {
      const currencies = await storage.getCurrencies();
      res.json(currencies);
    } catch (error) {
      console.error("Error fetching currencies:", error);
      res.status(500).json({ error: "Failed to fetch currencies" });
    }
  });

  app.get("/api/store-currencies", async (req, res) => {
    try {
      const storeCurrencies = await storage.getStoreCurrencies();
      res.json(storeCurrencies);
    } catch (error) {
      console.error("Error fetching store currencies:", error);
      res.status(500).json({ error: "Failed to fetch store currencies" });
    }
  });

  app.patch("/api/stores/:id/currency", async (req, res) => {
    try {
      const storeId = Number(req.params.id);
      const currencyId = Number(req.body?.currencyId);

      if (!storeId || Number.isNaN(storeId)) {
        return res.status(400).json({ error: "Invalid store id" });
      }
      if (!currencyId || Number.isNaN(currencyId)) {
        return res.status(400).json({ error: "Invalid currency id" });
      }

      await storage.setStoreDefaultCurrency(storeId, currencyId);
      res.json({ storeId, currencyId });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update store currency";
      if (message.toLowerCase().includes("not found")) {
        return res.status(404).json({ error: message });
      }
      console.error("Error updating store currency:", error);
      res.status(500).json({ error: "Failed to update store currency" });
    }
  });

  app.get("/api/warehouses", async (req, res) => {
    try {
      const warehouses = await storage.getWarehouses();
      res.json(warehouses);
    } catch (error) {
      console.error("Error fetching warehouses:", error);
      res.status(500).json({ error: "Failed to fetch warehouses" });
    }
  });

  app.get("/api/brands", async (req, res) => {
    try {
      const brands = await storage.getBrands();
      res.json(brands);
    } catch (error) {
      console.error("Error fetching brands:", error);
      res.status(500).json({ error: "Failed to fetch brands" });
    }
  });

  app.post("/api/brands", async (req, res) => {
    try {
      const brandName = String(req.body?.brandName ?? "").trim();
      const brandGrouping = String(req.body?.brandGrouping ?? "").trim() || null;
      const brandId = req.body?.brandId ? Number(req.body?.brandId) : null;

      if (!brandName) {
        return res.status(400).json({ error: "Brand name is required" });
      }
      if (brandId !== null && Number.isNaN(brandId)) {
        return res.status(400).json({ error: "Invalid brand id" });
      }

      const created = await storage.createBrand({ brandId, brandName, brandGrouping });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating brand:", error);
      res.status(500).json({ error: "Failed to create brand" });
    }
  });

  const handleUpdateBrand = async (req: any, res: any) => {
    try {
      const brandId = Number(req.params.id);
      const brandName = String(req.body?.brandName ?? "").trim();
      const brandGrouping = String(req.body?.brandGrouping ?? "").trim() || null;
      if (!brandId || Number.isNaN(brandId)) {
        return res.status(400).json({ error: "Invalid brand id" });
      }
      if (!brandName) {
        return res.status(400).json({ error: "Brand name is required" });
      }
      const updated = await storage.updateBrand({ brandId, brandName, brandGrouping });
      res.json(updated);
    } catch (error) {
      console.error("Error updating brand:", error);
      res.status(500).json({ error: "Failed to update brand" });
    }
  };

  app.patch("/api/brands/:id", handleUpdateBrand);
  app.put("/api/brands/:id", handleUpdateBrand);

  app.delete("/api/brands/:id", async (req, res) => {
    try {
      const brandId = Number(req.params.id);
      if (!brandId || Number.isNaN(brandId)) {
        return res.status(400).json({ error: "Invalid brand id" });
      }
      await storage.deleteBrand(brandId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete brand";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete brand in use" });
      }
      console.error("Error deleting brand:", error);
      res.status(500).json({ error: "Failed to delete brand" });
    }
  });

  app.get("/api/product-types", async (req, res) => {
    try {
      const types = await storage.getProductTypes();
      res.json(types);
    } catch (error) {
      console.error("Error fetching product types:", error);
      res.status(500).json({ error: "Failed to fetch product types" });
    }
  });

  app.post("/api/product-types", async (req, res) => {
    try {
      const productTypeName = String(req.body?.productTypeName ?? "").trim();
      const productTypeId = req.body?.productTypeId ? Number(req.body?.productTypeId) : null;
      if (!productTypeName) {
        return res.status(400).json({ error: "Product type name is required" });
      }
      if (productTypeId !== null && Number.isNaN(productTypeId)) {
        return res.status(400).json({ error: "Invalid product type id" });
      }
      const created = await storage.createProductType({ productTypeId, productTypeName });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating product type:", error);
      res.status(500).json({ error: "Failed to create product type" });
    }
  });

  const handleUpdateProductType = async (req: any, res: any) => {
    try {
      const productTypeId = Number(req.params.id);
      const productTypeName = String(req.body?.productTypeName ?? "").trim();
      if (!productTypeId || Number.isNaN(productTypeId)) {
        return res.status(400).json({ error: "Invalid product type id" });
      }
      if (!productTypeName) {
        return res.status(400).json({ error: "Product type name is required" });
      }
      const updated = await storage.updateProductType({ productTypeId, productTypeName });
      res.json(updated);
    } catch (error) {
      console.error("Error updating product type:", error);
      res.status(500).json({ error: "Failed to update product type" });
    }
  };

  app.patch("/api/product-types/:id", handleUpdateProductType);
  app.put("/api/product-types/:id", handleUpdateProductType);

  app.delete("/api/product-types/:id", async (req, res) => {
    try {
      const productTypeId = Number(req.params.id);
      if (!productTypeId || Number.isNaN(productTypeId)) {
        return res.status(400).json({ error: "Invalid product type id" });
      }
      await storage.deleteProductType(productTypeId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete product type";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete product type in use" });
      }
      console.error("Error deleting product type:", error);
      res.status(500).json({ error: "Failed to delete product type" });
    }
  });

  app.get("/api/product-colours", async (req, res) => {
    try {
      const colours = await storage.getProductColours();
      res.json(colours);
    } catch (error) {
      console.error("Error fetching product colours:", error);
      res.status(500).json({ error: "Failed to fetch product colours" });
    }
  });

  app.get("/api/product-styles", async (req, res) => {
    try {
      const styles = await storage.getProductStyles();
      res.json(styles);
    } catch (error) {
      console.error("Error fetching product styles:", error);
      res.status(500).json({ error: "Failed to fetch product styles" });
    }
  });

  app.get("/api/product-styles/counts", async (req, res) => {
    try {
      const styles = await storage.getProductStylesWithCounts();
      res.json(styles);
    } catch (error) {
      console.error("Error fetching product styles with counts:", error);
      res.status(500).json({ error: "Failed to fetch product styles" });
    }
  });

  app.post("/api/product-colours", async (req, res) => {
    try {
      const magentoColourName = String(req.body?.magentoColourName ?? "").trim() || null;
      const magentoColourId = String(req.body?.magentoColourId ?? "").trim() || null;
      const brandColourName = String(req.body?.brandColourName ?? "").trim() || null;
      const brandId = req.body?.brandId ? Number(req.body?.brandId) : null;
      const brandColourId = req.body?.brandColourId ? Number(req.body?.brandColourId) : null;

      if (!magentoColourName && !brandColourName) {
        return res.status(400).json({ error: "Colour name is required" });
      }
      if (brandId !== null && Number.isNaN(brandId)) {
        return res.status(400).json({ error: "Invalid brand id" });
      }
      if (brandColourId !== null && Number.isNaN(brandColourId)) {
        return res.status(400).json({ error: "Invalid brand colour id" });
      }

      const created = await storage.createProductColour({
        magentoColourName,
        magentoColourId,
        brandId,
        brandColourId,
        brandColourName,
      });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating product colour:", error);
      res.status(500).json({ error: "Failed to create product colour" });
    }
  });

  const handleUpdateProductColour = async (req: any, res: any) => {
    try {
      const productColourId = Number(req.params.id);
      const magentoColourName = String(req.body?.magentoColourName ?? "").trim() || null;
      const magentoColourId = String(req.body?.magentoColourId ?? "").trim() || null;
      const brandColourName = String(req.body?.brandColourName ?? "").trim() || null;
      const brandId = req.body?.brandId ? Number(req.body?.brandId) : null;
      const brandColourId = req.body?.brandColourId ? Number(req.body?.brandColourId) : null;

      if (!productColourId || Number.isNaN(productColourId)) {
        return res.status(400).json({ error: "Invalid product colour id" });
      }
      if (!magentoColourName && !brandColourName) {
        return res.status(400).json({ error: "Colour name is required" });
      }
      if (brandId !== null && Number.isNaN(brandId)) {
        return res.status(400).json({ error: "Invalid brand id" });
      }
      if (brandColourId !== null && Number.isNaN(brandColourId)) {
        return res.status(400).json({ error: "Invalid brand colour id" });
      }

      const updated = await storage.updateProductColour({
        productColourId,
        magentoColourName,
        magentoColourId,
        brandId,
        brandColourId,
        brandColourName,
      });
      res.json(updated);
    } catch (error) {
      console.error("Error updating product colour:", error);
      res.status(500).json({ error: "Failed to update product colour" });
    }
  };

  app.patch("/api/product-colours/:id", handleUpdateProductColour);
  app.put("/api/product-colours/:id", handleUpdateProductColour);

  app.delete("/api/product-colours/:id", async (req, res) => {
    try {
      const productColourId = Number(req.params.id);
      if (!productColourId || Number.isNaN(productColourId)) {
        return res.status(400).json({ error: "Invalid product colour id" });
      }
      await storage.deleteProductColour(productColourId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete product colour";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete product colour in use" });
      }
      console.error("Error deleting product colour:", error);
      res.status(500).json({ error: "Failed to delete product colour" });
    }
  });

  app.get("/api/genders", async (req, res) => {
    try {
      const genders = await storage.getGenders();
      res.json(genders);
    } catch (error) {
      console.error("Error fetching genders:", error);
      res.status(500).json({ error: "Failed to fetch genders" });
    }
  });

  app.post("/api/genders", async (req, res) => {
    try {
      const genderName = String(req.body?.genderName ?? "").trim();
      if (!genderName) {
        return res.status(400).json({ error: "Gender name is required" });
      }
      const created = await storage.createGender({ genderName });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating gender:", error);
      res.status(500).json({ error: "Failed to create gender" });
    }
  });

  const handleUpdateGender = async (req: any, res: any) => {
    try {
      const genderId = Number(req.params.id);
      const genderName = String(req.body?.genderName ?? "").trim();
      if (!genderId || Number.isNaN(genderId)) {
        return res.status(400).json({ error: "Invalid gender id" });
      }
      if (!genderName) {
        return res.status(400).json({ error: "Gender name is required" });
      }
      const updated = await storage.updateGender({ genderId, genderName });
      res.json(updated);
    } catch (error) {
      console.error("Error updating gender:", error);
      res.status(500).json({ error: "Failed to update gender" });
    }
  };

  app.patch("/api/genders/:id", handleUpdateGender);
  app.put("/api/genders/:id", handleUpdateGender);

  app.delete("/api/genders/:id", async (req, res) => {
    try {
      const genderId = Number(req.params.id);
      if (!genderId || Number.isNaN(genderId)) {
        return res.status(400).json({ error: "Invalid gender id" });
      }
      await storage.deleteGender(genderId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete gender";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete gender in use" });
      }
      console.error("Error deleting gender:", error);
      res.status(500).json({ error: "Failed to delete gender" });
    }
  });

  app.get("/api/sizes", async (req, res) => {
    try {
      const sizes = await storage.getSizes();
      res.json(sizes);
    } catch (error) {
      console.error("Error fetching sizes:", error);
      res.status(500).json({ error: "Failed to fetch sizes" });
    }
  });

  app.post("/api/sizes", async (req, res) => {
    try {
      const magentoSizeId = req.body?.magentoSizeId ? Number(req.body?.magentoSizeId) : null;
      const magentoSizeShortName = String(req.body?.magentoSizeShortName ?? "").trim() || null;
      const magentoSizeLongName = String(req.body?.magentoSizeLongName ?? "").trim() || null;
      const configOptions = String(req.body?.configOptions ?? "").trim() || null;
      const sizingCategory = String(req.body?.sizingCategory ?? "").trim() || null;

      if (!magentoSizeShortName && !magentoSizeLongName) {
        return res.status(400).json({ error: "Size name is required" });
      }
      if (magentoSizeId !== null && Number.isNaN(magentoSizeId)) {
        return res.status(400).json({ error: "Invalid magento size id" });
      }

      const created = await storage.createSize({
        magentoSizeId,
        magentoSizeShortName,
        magentoSizeLongName,
        configOptions,
        sizingCategory,
      });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating size:", error);
      res.status(500).json({ error: "Failed to create size" });
    }
  });

  const handleUpdateSize = async (req: any, res: any) => {
    try {
      const sizeId = Number(req.params.id);
      const magentoSizeId = req.body?.magentoSizeId ? Number(req.body?.magentoSizeId) : null;
      const magentoSizeShortName = String(req.body?.magentoSizeShortName ?? "").trim() || null;
      const magentoSizeLongName = String(req.body?.magentoSizeLongName ?? "").trim() || null;
      const configOptions = String(req.body?.configOptions ?? "").trim() || null;
      const sizingCategory = String(req.body?.sizingCategory ?? "").trim() || null;

      if (!sizeId || Number.isNaN(sizeId)) {
        return res.status(400).json({ error: "Invalid size id" });
      }
      if (!magentoSizeShortName && !magentoSizeLongName) {
        return res.status(400).json({ error: "Size name is required" });
      }
      if (magentoSizeId !== null && Number.isNaN(magentoSizeId)) {
        return res.status(400).json({ error: "Invalid magento size id" });
      }

      const updated = await storage.updateSize({
        sizeId,
        magentoSizeId,
        magentoSizeShortName,
        magentoSizeLongName,
        configOptions,
        sizingCategory,
      });
      res.json(updated);
    } catch (error) {
      console.error("Error updating size:", error);
      res.status(500).json({ error: "Failed to update size" });
    }
  };

  app.patch("/api/sizes/:id", handleUpdateSize);
  app.put("/api/sizes/:id", handleUpdateSize);

  app.delete("/api/sizes/:id", async (req, res) => {
    try {
      const sizeId = Number(req.params.id);
      if (!sizeId || Number.isNaN(sizeId)) {
        return res.status(400).json({ error: "Invalid size id" });
      }
      await storage.deleteSize(sizeId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete size";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete size in use" });
      }
      console.error("Error deleting size:", error);
      res.status(500).json({ error: "Failed to delete size" });
    }
  });

  app.get("/api/tax-classes", async (req, res) => {
    try {
      const taxClasses = await storage.getTaxClasses();
      res.json(taxClasses);
    } catch (error) {
      console.error("Error fetching tax classes:", error);
      res.status(500).json({ error: "Failed to fetch tax classes" });
    }
  });

  app.post("/api/tax-classes", async (req, res) => {
    try {
      const taxClassName = String(req.body?.taxClassName ?? "").trim();
      if (!taxClassName) {
        return res.status(400).json({ error: "Tax class name is required" });
      }
      const created = await storage.createTaxClass({ taxClassName });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating tax class:", error);
      res.status(500).json({ error: "Failed to create tax class" });
    }
  });

  const handleUpdateTaxClass = async (req: any, res: any) => {
    try {
      const taxClassId = Number(req.params.id);
      const taxClassName = String(req.body?.taxClassName ?? "").trim();
      if (!taxClassId || Number.isNaN(taxClassId)) {
        return res.status(400).json({ error: "Invalid tax class id" });
      }
      if (!taxClassName) {
        return res.status(400).json({ error: "Tax class name is required" });
      }
      const updated = await storage.updateTaxClass({ taxClassId, taxClassName });
      res.json(updated);
    } catch (error) {
      console.error("Error updating tax class:", error);
      res.status(500).json({ error: "Failed to update tax class" });
    }
  };

  app.patch("/api/tax-classes/:id", handleUpdateTaxClass);
  app.put("/api/tax-classes/:id", handleUpdateTaxClass);

  app.delete("/api/tax-classes/:id", async (req, res) => {
    try {
      const taxClassId = Number(req.params.id);
      if (!taxClassId || Number.isNaN(taxClassId)) {
        return res.status(400).json({ error: "Invalid tax class id" });
      }
      await storage.deleteTaxClass(taxClassId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete tax class";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete tax class in use" });
      }
      console.error("Error deleting tax class:", error);
      res.status(500).json({ error: "Failed to delete tax class" });
    }
  });

  app.get("/api/conditions", async (req, res) => {
    try {
      const conditions = await storage.getConditions();
      res.json(conditions);
    } catch (error) {
      console.error("Error fetching conditions:", error);
      res.status(500).json({ error: "Failed to fetch conditions" });
    }
  });

  app.post("/api/conditions", async (req, res) => {
    try {
      const conditionName = String(req.body?.conditionName ?? "").trim();
      const conditionId = req.body?.conditionId ? Number(req.body?.conditionId) : null;
      if (!conditionName) {
        return res.status(400).json({ error: "Condition name is required" });
      }
      if (conditionId !== null && Number.isNaN(conditionId)) {
        return res.status(400).json({ error: "Invalid condition id" });
      }
      const created = await storage.createCondition({ conditionId, conditionName });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating condition:", error);
      res.status(500).json({ error: "Failed to create condition" });
    }
  });

  const handleUpdateCondition = async (req: any, res: any) => {
    try {
      const conditionId = Number(req.params.id);
      const conditionName = String(req.body?.conditionName ?? "").trim();
      if (!conditionId || Number.isNaN(conditionId)) {
        return res.status(400).json({ error: "Invalid condition id" });
      }
      if (!conditionName) {
        return res.status(400).json({ error: "Condition name is required" });
      }
      const updated = await storage.updateCondition({ conditionId, conditionName });
      res.json(updated);
    } catch (error) {
      console.error("Error updating condition:", error);
      res.status(500).json({ error: "Failed to update condition" });
    }
  };

  app.patch("/api/conditions/:id", handleUpdateCondition);
  app.put("/api/conditions/:id", handleUpdateCondition);

  app.delete("/api/conditions/:id", async (req, res) => {
    try {
      const conditionId = Number(req.params.id);
      if (!conditionId || Number.isNaN(conditionId)) {
        return res.status(400).json({ error: "Invalid condition id" });
      }
      await storage.deleteCondition(conditionId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete condition";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete condition in use" });
      }
      console.error("Error deleting condition:", error);
      res.status(500).json({ error: "Failed to delete condition" });
    }
  });

  app.get("/api/attribute-defs", async (_req, res) => {
    try {
      const attributeDefs = await storage.getAttributeDefs();
      res.json(attributeDefs);
    } catch (error) {
      console.error("Error fetching attribute definitions:", error);
      res.status(500).json({ error: "Failed to fetch attribute definitions" });
    }
  });

  app.post("/api/attribute-defs", async (req, res) => {
    try {
      const code = String(req.body?.code ?? "").trim();
      const label = String(req.body?.label ?? "").trim() || null;
      const dataType = String(req.body?.dataType ?? "").trim() || null;
      if (!code) {
        return res.status(400).json({ error: "Attribute code is required" });
      }

      const allowedDataTypes = new Set(["text", "number", "boolean", "json"]);
      if (dataType && !allowedDataTypes.has(dataType)) {
        return res.status(400).json({ error: "Invalid attribute data type" });
      }

      const magentoSync = req.body?.magentoSync === true;
      const magentoScope = req.body?.magentoScope ? String(req.body.magentoScope).trim().toLowerCase() : null;
      const allowedMagentoScopes = new Set(["global", "website", "store_view"]);
      if (magentoScope && !allowedMagentoScopes.has(magentoScope)) {
        return res.status(400).json({ error: "Invalid magento scope. Must be one of: global, website, store_view" });
      }
      const created = await storage.createAttributeDef({
        code,
        label,
        dataType,
        magentoSync,
        magentoScope,
      });
      res.status(201).json(created);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to create attribute";
      if (message.includes("already exists")) {
        return res.status(409).json({ error: message });
      }
      if (message.includes("required")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error creating attribute:", error);
      res.status(500).json({ error: "Failed to create attribute" });
    }
  });

  app.patch("/api/attribute-defs/:id", async (req, res) => {
    try {
      const attributeId = Number(req.params.id);
      if (!attributeId || Number.isNaN(attributeId)) {
        return res.status(400).json({ error: "Invalid attribute id" });
      }
      const updates: Record<string, any> = {};
      if (typeof req.body?.magentoSync === "boolean") {
        updates.magentoSync = req.body.magentoSync;
      }
      if (typeof req.body?.label === "string") {
        updates.label = req.body.label.trim() || null;
      }
      if (req.body?.magentoScope !== undefined) {
        const ms = String(req.body.magentoScope).trim().toLowerCase();
        const allowedMagentoScopes = new Set(["global", "website", "store_view"]);
        if (!allowedMagentoScopes.has(ms)) {
          return res.status(400).json({ error: "Invalid magento scope. Must be one of: global, website, store_view" });
        }
        updates.magentoScope = ms;
      }
      const updated = await storage.updateAttributeDef(attributeId, updates);
      res.json(updated);
    } catch (error) {
      console.error("Error updating attribute:", error);
      res.status(500).json({ error: "Failed to update attribute" });
    }
  });

  app.delete("/api/attribute-defs/:id", async (req, res) => {
    try {
      const attributeId = Number(req.params.id);
      if (!attributeId || Number.isNaN(attributeId)) {
        return res.status(400).json({ error: "Invalid attribute id" });
      }
      await storage.deleteAttributeDef(attributeId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting attribute:", error);
      res.status(500).json({ error: "Failed to delete attribute" });
    }
  });

  app.get("/api/eras", async (_req, res) => {
    try {
      const eras = await storage.getEras();
      res.json(eras);
    } catch (error) {
      console.error("Error fetching eras:", error);
      res.status(500).json({ error: "Failed to fetch eras" });
    }
  });

  app.post("/api/eras", async (req, res) => {
    try {
      const name = String(req.body?.name ?? "").trim();
      const startYear = Number(req.body?.startYear);
      const endYear = Number(req.body?.endYear);

      if (!name) {
        return res.status(400).json({ error: "Era name is required" });
      }
      if (!startYear || Number.isNaN(startYear)) {
        return res.status(400).json({ error: "Invalid start year" });
      }
      if (!endYear || Number.isNaN(endYear)) {
        return res.status(400).json({ error: "Invalid end year" });
      }

      const created = await storage.createEra({ name, startYear, endYear });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating era:", error);
      res.status(500).json({ error: "Failed to create era" });
    }
  });

  const handleUpdateEra = async (req: any, res: any) => {
    try {
      const eraId = Number(req.params.id);
      const name = String(req.body?.name ?? "").trim();
      const startYear = Number(req.body?.startYear);
      const endYear = Number(req.body?.endYear);

      if (!eraId || Number.isNaN(eraId)) {
        return res.status(400).json({ error: "Invalid era id" });
      }
      if (!name) {
        return res.status(400).json({ error: "Era name is required" });
      }
      if (!startYear || Number.isNaN(startYear)) {
        return res.status(400).json({ error: "Invalid start year" });
      }
      if (!endYear || Number.isNaN(endYear)) {
        return res.status(400).json({ error: "Invalid end year" });
      }

      const updated = await storage.updateEra({ eraId, name, startYear, endYear });
      res.json(updated);
    } catch (error) {
      console.error("Error updating era:", error);
      res.status(500).json({ error: "Failed to update era" });
    }
  };

  app.patch("/api/eras/:id", handleUpdateEra);
  app.put("/api/eras/:id", handleUpdateEra);

  app.delete("/api/eras/:id", async (req, res) => {
    try {
      const eraId = Number(req.params.id);
      if (!eraId || Number.isNaN(eraId)) {
        return res.status(400).json({ error: "Invalid era id" });
      }
      await storage.deleteEra(eraId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete era";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete era in use" });
      }
      console.error("Error deleting era:", error);
      res.status(500).json({ error: "Failed to delete era" });
    }
  });

  app.get("/api/clubs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      if (limit !== undefined && Number.isNaN(limit)) {
        return res.status(400).json({ error: "Invalid limit" });
      }
      const clubs = await storage.getClubs(limit);
      res.json(clubs);
    } catch (error) {
      console.error("Error fetching clubs:", error);
      res.status(500).json({ error: "Failed to fetch clubs" });
    }
  });

  app.get("/api/rivalry-types", async (_req, res) => {
    try {
      const types = await storage.getRivalryTypes();
      res.json(types);
    } catch (error) {
      console.error("Error fetching rivalry types:", error);
      res.status(500).json({ error: "Failed to fetch rivalry types" });
    }
  });

  app.post("/api/rivalry-types", async (req, res) => {
    try {
      const code = String(req.body?.code ?? "").trim();
      const name = String(req.body?.name ?? "").trim();
      const description = String(req.body?.description ?? "").trim() || null;

      if (!code) {
        return res.status(400).json({ error: "Rivalry type code is required" });
      }
      if (!name) {
        return res.status(400).json({ error: "Rivalry type name is required" });
      }

      const created = await storage.createRivalryType({ code, name, description });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating rivalry type:", error);
      res.status(500).json({ error: "Failed to create rivalry type" });
    }
  });

  const handleUpdateRivalryType = async (req: any, res: any) => {
    try {
      const rivalryTypeId = Number(req.params.id);
      const code = String(req.body?.code ?? "").trim();
      const name = String(req.body?.name ?? "").trim();
      const description = String(req.body?.description ?? "").trim() || null;

      if (!rivalryTypeId || Number.isNaN(rivalryTypeId)) {
        return res.status(400).json({ error: "Invalid rivalry type id" });
      }
      if (!code) {
        return res.status(400).json({ error: "Rivalry type code is required" });
      }
      if (!name) {
        return res.status(400).json({ error: "Rivalry type name is required" });
      }

      const updated = await storage.updateRivalryType({
        rivalryTypeId,
        code,
        name,
        description,
      });

      if (!updated) {
        return res.status(404).json({ error: "Rivalry type not found" });
      }

      res.json(updated);
    } catch (error) {
      console.error("Error updating rivalry type:", error);
      res.status(500).json({ error: "Failed to update rivalry type" });
    }
  };

  app.patch("/api/rivalry-types/:id", handleUpdateRivalryType);
  app.put("/api/rivalry-types/:id", handleUpdateRivalryType);

  app.get("/api/rivalries/:clubId", async (req, res) => {
    try {
      const clubId = Number(req.params.clubId);
      if (!clubId || Number.isNaN(clubId)) {
        return res.status(400).json({ error: "Invalid club id" });
      }

      const rivalryData = await storage.getClubRivalries(clubId);
      if (!rivalryData) {
        return res.status(404).json({ error: "Club not found" });
      }

      res.json(rivalryData);
    } catch (error) {
      console.error("Error fetching rivalries:", error);
      res.status(500).json({ error: "Failed to fetch rivalries" });
    }
  });

  app.patch("/api/club-rivalries/:id", async (req, res) => {
    try {
      const clubRivalryId = Number(req.params.id);
      if (!clubRivalryId || Number.isNaN(clubRivalryId)) {
        return res.status(400).json({ error: "Invalid rivalry id" });
      }

      const parseNumberOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const parsed = Number(value);
        if (Number.isNaN(parsed)) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return parsed;
      };

      const parseDateOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const date = new Date(String(value));
        if (Number.isNaN(date.valueOf())) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return date;
      };

      let rivalryTypeId: number | null | undefined = undefined;
      if ("rivalryTypeId" in req.body) {
        rivalryTypeId = parseNumberOrNull(req.body?.rivalryTypeId, "rivalry type");
      }

      let intensity: number | null | undefined = undefined;
      if ("intensity" in req.body) {
        intensity = parseNumberOrNull(req.body?.intensity, "intensity");
      }

      let periodStart: Date | null | undefined = undefined;
      if ("periodStart" in req.body) {
        periodStart = parseDateOrNull(req.body?.periodStart, "period start");
      }

      let periodEnd: Date | null | undefined = undefined;
      if ("periodEnd" in req.body) {
        periodEnd = parseDateOrNull(req.body?.periodEnd, "period end");
      }

      let isPrimary: boolean | null | undefined = undefined;
      if ("isPrimary" in req.body) {
        isPrimary = Boolean(req.body?.isPrimary);
      }

      let knownAs: string | null | undefined = undefined;
      if ("knownAs" in req.body) {
        knownAs = String(req.body?.knownAs ?? "").trim() || null;
      }

      let notes: string | null | undefined = undefined;
      if ("notes" in req.body) {
        notes = String(req.body?.notes ?? "").trim() || null;
      }

      const updated = await storage.updateClubRivalry({
        clubRivalryId,
        rivalryTypeId,
        intensity,
        periodStart,
        periodEnd,
        isPrimary,
        knownAs,
        notes,
      });

      if (!updated) {
        return res.status(404).json({ error: "Rivalry not found" });
      }

      res.json(updated);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update rivalry";
      if (message.startsWith("Invalid ")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error updating rivalry:", error);
      res.status(500).json({ error: "Failed to update rivalry" });
    }
  });

  app.post("/api/club-rivalries", async (req, res) => {
    try {
      const clubIdA = Number(req.body?.clubIdA);
      const clubIdB = Number(req.body?.clubIdB);
      const rivalryTypeId = Number(req.body?.rivalryTypeId);

      if (!clubIdA || Number.isNaN(clubIdA)) {
        return res.status(400).json({ error: "Invalid club A id" });
      }
      if (!clubIdB || Number.isNaN(clubIdB)) {
        return res.status(400).json({ error: "Invalid club B id" });
      }
      if (clubIdA === clubIdB) {
        return res.status(400).json({ error: "Rival club must be different" });
      }
      if (!rivalryTypeId || Number.isNaN(rivalryTypeId)) {
        return res.status(400).json({ error: "Invalid rivalry type" });
      }

      const parseNumberOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const parsed = Number(value);
        if (Number.isNaN(parsed)) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return parsed;
      };

      const parseDateOrNull = (value: any, fieldLabel: string) => {
        if (value === null || value === undefined || value === "") return null;
        const date = new Date(String(value));
        if (Number.isNaN(date.valueOf())) {
          throw new Error(`Invalid ${fieldLabel}`);
        }
        return date;
      };

      const intensity = parseNumberOrNull(req.body?.intensity, "intensity");
      const periodStart = parseDateOrNull(req.body?.periodStart, "period start");
      const periodEnd = parseDateOrNull(req.body?.periodEnd, "period end");
      const knownAs = String(req.body?.knownAs ?? "").trim() || null;
      const notes = String(req.body?.notes ?? "").trim() || null;
      const isPrimary = Boolean(req.body?.isPrimary);

      const created = await storage.createClubRivalry({
        clubIdA,
        clubIdB,
        rivalryTypeId,
        intensity,
        periodStart,
        periodEnd,
        knownAs,
        notes,
        isPrimary,
      });

      res.status(201).json(created);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to create rivalry";
      if (message.startsWith("Invalid ")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error creating rivalry:", error);
      res.status(500).json({ error: "Failed to create rivalry" });
    }
  });

  app.post("/api/clubs", async (req, res) => {
    try {
      const name = String(req.body?.name ?? "").trim();
      const country = String(req.body?.country ?? "").trim() || null;
      const foundedYear = req.body?.foundedYear ? Number(req.body?.foundedYear) : null;

      if (!name) {
        return res.status(400).json({ error: "Team name is required" });
      }
      if (foundedYear !== null && Number.isNaN(foundedYear)) {
        return res.status(400).json({ error: "Invalid founded year" });
      }

      const existing = await storage.getClubByName(name);
      if (existing) {
        return res.status(409).json({ error: "Team already exists" });
      }

      const created = await storage.createClub({ name, country, foundedYear });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating team:", error);
      res.status(500).json({ error: "Failed to create team" });
    }
  });

  const handleUpdateClub = async (req: any, res: any) => {
    try {
      const clubId = Number(req.params.id);
      const name = String(req.body?.name ?? "").trim();
      const country = String(req.body?.country ?? "").trim() || null;
      const foundedYear = req.body?.foundedYear ? Number(req.body?.foundedYear) : null;

      if (!clubId || Number.isNaN(clubId)) {
        return res.status(400).json({ error: "Invalid team id" });
      }
      if (!name) {
        return res.status(400).json({ error: "Team name is required" });
      }
      if (foundedYear !== null && Number.isNaN(foundedYear)) {
        return res.status(400).json({ error: "Invalid founded year" });
      }

      const updated = await storage.updateClub({ clubId, name, country, foundedYear });
      res.json(updated);
    } catch (error) {
      console.error("Error updating team:", error);
      res.status(500).json({ error: "Failed to update team" });
    }
  };

  app.patch("/api/clubs/:id", handleUpdateClub);
  app.put("/api/clubs/:id", handleUpdateClub);

  app.delete("/api/clubs/:id", async (req, res) => {
    try {
      const clubId = Number(req.params.id);
      if (!clubId || Number.isNaN(clubId)) {
        return res.status(400).json({ error: "Invalid team id" });
      }
      await storage.deleteClub(clubId);
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to delete team";
      if (message.includes("violates foreign key")) {
        return res.status(409).json({ error: "Cannot delete team in use" });
      }
      console.error("Error deleting team:", error);
      res.status(500).json({ error: "Failed to delete team" });
    }
  });

  app.get("/api/seasons", async (req, res) => {
    try {
      const seasons = await storage.getSeasons();
      res.json(seasons);
    } catch (error) {
      console.error("Error fetching seasons:", error);
      res.status(500).json({ error: "Failed to fetch seasons" });
    }
  });

  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      if (isNaN(categoryId)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const cat = await storage.getCategoryById(categoryId);
      if (!cat) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(cat);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ error: "Failed to fetch category" });
    }
  });

  app.get("/api/categories/:id/products", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      if (isNaN(categoryId)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const products = await storage.getProductsByCategory(categoryId);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const { name, parentId } = req.body;
      if (!name || typeof name !== "string") {
        return res.status(400).json({ error: "Name is required" });
      }

      let pathKey = name;
      if (parentId) {
        const parent = await storage.getCategoryById(parentId);
        if (!parent) {
          return res.status(400).json({ error: "Parent category not found" });
        }
        pathKey = `${parent.pathKey}/${name}`;
      }

      const existing = await storage.getCategoryByPathKey(pathKey);
      if (existing) {
        return res.status(400).json({ error: "Category with this path already exists" });
      }

      const created = await storage.createCategory({
        name,
        pathKey,
        parentId: parentId ?? null,
      });
      res.status(201).json(created);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ error: "Failed to create category" });
    }
  });

  app.patch("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      if (isNaN(categoryId)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      const { name, parentId } = req.body;
      const updated = await storage.updateCategory(categoryId, { name, parentId });
      if (!updated) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating category:", error);
      res.status(500).json({ error: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      if (isNaN(categoryId)) {
        return res.status(400).json({ error: "Invalid category ID" });
      }
      await storage.deleteCategory(categoryId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting category:", error);
      res.status(500).json({ error: "Failed to delete category" });
    }
  });

  app.get("/api/departments", async (req, res) => {
    try {
      const departments = await storage.getDepartments();
      res.json(departments);
    } catch (error) {
      console.error("Error fetching departments:", error);
      res.status(500).json({ error: "Failed to fetch departments" });
    }
  });

  // Listing sheet import
  app.get("/api/imports/attribute-options", async (_req, res) => {
    try {
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      const options = await storage.getImportAttributeOptions();
      res.json(options);
    } catch (error) {
      console.error("Error fetching import attribute options:", error);
      res.status(500).json({ error: "Failed to fetch import attribute options" });
    }
  });

  app.post(
    "/api/imports/upload-listing-sheets",
    upload.single("file"),
    async (req, res) => {
      try {
        const file = req.file;

        if (!file) {
          return res.status(400).json({ error: "No file uploaded" });
        }

        const loadedAt = new Date();

        const parseCSV = (inputFile: Express.Multer.File): Promise<any[]> => {
          return new Promise((resolve, reject) => {
            const csvContent = inputFile.buffer.toString("utf-8");
            Papa.parse(csvContent, {
              header: true,
              skipEmptyLines: true,
              complete: (results) => {
                if (results.errors.length > 0) {
                  console.warn(`CSV parsing warnings for ${inputFile.originalname}:`, results.errors);
                }
                resolve(convertHeadersToCamelCase(results.data as any[]));
              },
              error: (error: Error) => reject(error),
            });
          });
        };

        let rows = await parseCSV(file);
        // Capture the column order from the first row before any JSONB operations
        // This preserves the original CSV column order which JSONB would lose
        const columnOrder = rows.length > 0 ? Object.keys(rows[0]) : [];
        if (rows.length > 0) {
          console.log("[Import] First row keys after camelCase conversion:", Object.keys(rows[0]));
          console.log("[Import] Column order captured:", columnOrder);
          console.log("[Import] First row sample values:", JSON.stringify(rows[0]).substring(0, 500));
        }

        const firstRowKeys = columnOrder;
        const imageColumnNames = ["baseImage", "smallImage", "thumbnailImage", "additionalImages"];
        const hasImageColumns = imageColumnNames.some(col => firstRowKeys.includes(col));
        // Only treat as image-only format if it has image columns but NO product data columns.
        // A CSV with both product data and image columns should be processed as a full product import
        // (images will be handled inline by processImportV2).
        const productDataColumns = ["name", "brand", "brandName", "condition", "productDescription", "parentSku", "parent_sku", "costPrice", "cost_price", "customerPrice", "customer_price"];
        const hasProductData = productDataColumns.some(col => firstRowKeys.includes(col));
        const isImageFormat = hasImageColumns && !hasProductData;

        if (isImageFormat) {
          console.log("[Import] Detected image-only CSV (no product data columns), marking rows with _imageFormat flag");
          rows = rows.map(row => ({ ...row, _imageFormat: "true" }));
        } else if (hasImageColumns) {
          console.log("[Import] CSV has both product data and image columns — processing as full product import (images handled inline)");
        }

        const normalizedRows = rows.map((row) => {
          if (!row || typeof row !== "object") {
            return row;
          }
          const skuKeys = ["productVariantSku", "productSku", "sku"];
          const normalizedRow = { ...row };
          for (const key of skuKeys) {
            if (normalizedRow[key] !== undefined && normalizedRow[key] !== null) {
              normalizedRow[key] = normalizeSkuValue(normalizedRow[key]);
            }
          }
          const hasVariantSku =
            normalizedRow.productVariantSku !== undefined &&
            normalizedRow.productVariantSku !== null &&
            String(normalizedRow.productVariantSku).trim() !== "";
          const hasSku =
            normalizedRow.sku !== undefined &&
            normalizedRow.sku !== null &&
            String(normalizedRow.sku).trim() !== "";

          const hasProductSku =
            normalizedRow.productSku !== undefined &&
            normalizedRow.productSku !== null &&
            String(normalizedRow.productSku).trim() !== "";

          if (!hasVariantSku && !hasProductSku && hasSku) {
            const hasCategories =
              normalizedRow.categories !== undefined &&
              normalizedRow.categories !== null &&
              String(normalizedRow.categories).trim() !== "";
            const rowKeys = Object.keys(normalizedRow).filter(
              (k) => k !== "sku" && normalizedRow[k] !== undefined && normalizedRow[k] !== null && String(normalizedRow[k]).trim() !== ""
            );
            const isCategoryOnly = hasCategories && rowKeys.length === 1 && rowKeys[0] === "categories";

            if (isCategoryOnly) {
              return {
                ...normalizedRow,
                productSku: normalizedRow.sku,
              };
            }

            return {
              ...normalizedRow,
              productSku: normalizedRow.sku,
              productVariantSku: normalizedRow.sku,
            };
          }

          if (!hasVariantSku && hasSku) {
            return {
              ...normalizedRow,
              productVariantSku: normalizedRow.sku,
            };
          }

          return normalizedRow;
        });

        const stagedRows = normalizedRows
          .filter((row) => (row && typeof row === "object" ? !isRowEmpty(row) : true))
          .map((row) => {
          const sku = row.productVariantSku;
          const productSku = row.productSku;
          const hasSku = sku !== undefined && sku !== null && String(sku).trim() !== "";
          const hasProductSku =
            productSku !== undefined && productSku !== null && String(productSku).trim() !== "";
          if (hasSku) {
            return { data: row, status: "pending" as const };
          }
          if (hasProductSku) {
            return { data: row, status: "pending" as const };
          }
          return {
            data: row,
            status: "invalid" as const,
            errors: [
              {
                fieldKey: "productVariantSku",
                errorCode: "required",
                errorMessage: "product_variant_sku or product_sku is required",
              },
            ],
          };
        });

        const fileNamesList = file.originalname || "Listing sheet";
        const userId = req.user?.id;

        const importJob = await storage.createImportBatch("", fileNamesList, stagedRows.length, userId);

        // Store columnOrder in the first staged row's data as metadata for later retrieval
        // Must be inside row.data because insertStagingRows wraps as { data: row.data }
        const stagedRowsWithColumnOrder = stagedRows.map((row, idx) => {
          if (idx === 0) {
            return { ...row, data: { ...row.data, _columnOrder: columnOrder } };
          }
          return row;
        });

        await storage.insertStagingRows(importJob.importJobId, loadedAt, file.originalname, stagedRowsWithColumnOrder);
        const summary = await storage.getStagingSummary(String(importJob.importJobId));

        res.status(201).json({
          batchId: String(importJob.importJobId),
          columnOrder,
          counts: summary?.counts ?? {
            totalRows: stagedRows.length,
            validRows: stagedRows.filter((row) => row.status === "pending").length,
            invalidRows: stagedRows.filter((row) => row.status === "invalid").length,
            newRows: 0,
            updatedRows: 0,
          },
          fileNames: fileNamesList,
        });
      } catch (error) {
        console.error("Error processing listing sheet upload:", error);
        res.status(500).json({
          error: "Failed to process listing sheet upload",
          details: error instanceof Error ? error.message : String(error),
        });
      }
    },
  );

  // Get staging summary
  app.get("/api/imports/:batchId/summary", async (req, res) => {
    try {
      const { batchId } = req.params;
      const summary = await storage.getStagingSummary(batchId);
      
      if (!summary) {
        return res.status(404).json({ error: "Batch not found" });
      }

      res.json(summary);
    } catch (error) {
      console.error("Error fetching staging summary:", error);
      res.status(500).json({ error: "Failed to fetch staging summary" });
    }
  });

  // Get staging rows for preview/editing
  app.get("/api/imports/:batchId/rows", async (req, res) => {
    try {
      const { batchId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 200;
      const offset = req.query.offset ? parseInt(req.query.offset as string, 10) : 0;
      const rows = await storage.getStagingRows(batchId, limit, offset);

      if (!rows) {
        return res.status(404).json({ error: "Batch not found" });
      }

      res.json(rows);
    } catch (error) {
      console.error("Error fetching staging rows:", error);
      res.status(500).json({ error: "Failed to fetch staging rows" });
    }
  });

  // Update staging row data
  app.patch("/api/imports/:batchId/rows/:rowNumber", async (req, res) => {
    try {
      const { batchId, rowNumber } = req.params;
      const data = req.body?.data;
      const rawData = req.body?.rawData;
      if (!data || typeof data !== "object") {
        return res.status(400).json({ error: "Row data is required" });
      }

      await storage.updateStagingRow(batchId, Number(rowNumber), data, rawData);
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating staging row:", error);
      res.status(500).json({ error: "Failed to update staging row" });
    }
  });

  app.post("/api/imports/:batchId/column-mapping", async (req, res) => {
    try {
      const { batchId } = req.params;
      const mapping = req.body?.mapping;
      if (!mapping || typeof mapping !== "object") {
        return res.status(400).json({ error: "Mapping payload is required" });
      }

      await storage.applyImportColumnMapping(batchId, mapping);
      res.json({ success: true });
    } catch (error) {
      console.error("Error applying import column mapping:", error);
      res.status(500).json({ error: "Failed to apply column mapping" });
    }
  });

  // Confirm import - updates status and processes immediately
  app.post("/api/imports/:batchId/confirm", async (req, res) => {
    try {
      const { batchId } = req.params;
      
      const summary = await storage.getStagingSummary(batchId);
      if (!summary) {
        return res.status(404).json({ error: "Batch not found in staging" });
      }
      if (summary.counts?.invalidRows > 0) {
        return res.status(400).json({
          error: "Validation failed",
          details: "All rows must include product_variant_sku before committing.",
        });
      }

      await storage.confirmImport(batchId);
      await storage.setImportJobStatus(batchId, "processing");

      const totalRows = summary.counts?.totalRows || 0;
      importProgressTracker.start(batchId, totalRows);

      res.json({
        message: "Import queued for processing",
        batchId,
        status: "processing",
      });

      processImportV2(batchId).catch((error) => {
        console.error("Background import processing failed:", error);
      });
    } catch (error) {
      console.error("Error confirming import:", error);
      const message = error instanceof Error ? error.message : String(error);
      res.status(500).json({ 
        error: message || "Failed to confirm import",
        details: message
      });
    }
  });

  app.get("/api/imports/progress", async (_req, res) => {
    try {
      const active = importProgressTracker.getActive().map(p => p.batchId);
      const allArr = importProgressTracker.getAll();
      const all: Record<string, any> = {};
      for (const p of allArr) {
        all[p.batchId] = p;
      }
      res.json({ active, all });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch import progress" });
    }
  });

  app.get("/api/imports/:batchId/progress", async (req, res) => {
    try {
      const { batchId } = req.params;
      const progress = importProgressTracker.get(batchId);
      if (!progress) {
        return res.status(404).json({ error: "No active progress for this batch" });
      }
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch import progress" });
    }
  });

  // Process import endpoint (can be called manually or by background job)
  app.post("/api/imports/:batchId/process", async (req, res) => {
    try {
      const { batchId } = req.params;
      
      const batch = await storage.getImportBatch(batchId);
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }

      const summary = await storage.getStagingSummary(batchId);
      if (summary?.counts?.invalidRows > 0) {
        return res.status(400).json({
          error: "Validation failed",
          details: "All rows must include product_variant_sku before processing.",
        });
      }

      if (batch.status !== 'uploaded' && batch.status !== 'validated' && batch.status !== 'failed') {
        return res.status(400).json({ error: `Cannot process batch with status: ${batch.status}` });
      }

      await processImportV2(batchId);

      res.json({ message: "Import processed successfully", batchId });
    } catch (error) {
      console.error("Error processing import:", error);
      res.status(500).json({ 
        error: "Failed to process import",
        details: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Cancel/delete import
  app.delete("/api/imports/:batchId/staging", async (req, res) => {
    try {
      const { batchId } = req.params;
      
      await storage.clearStaging(batchId);

      res.json({ message: "Staging data cleared successfully", batchId });
    } catch (error) {
      console.error("Error clearing staging data:", error);
      res.status(500).json({ error: "Failed to clear staging data" });
    }
  });

  // Team metadata
  app.get("/api/products/:id/team-meta", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const teamMeta = await storage.getProductTeamMeta(productId);
      res.json(teamMeta);
    } catch (error) {
      console.error("Error fetching team metadata:", error);
      res.status(500).json({ error: "Failed to fetch team metadata" });
    }
  });

  app.patch("/api/products/:id/team-meta", async (req, res) => {
    try {
      const productId = Number(req.params.id);
      if (!productId || Number.isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }

      const rawClubId = req.body?.clubId;
      let clubId: number | null = null;
      if (rawClubId !== null && rawClubId !== undefined && rawClubId !== "") {
        const parsed = Number(rawClubId);
        if (!Number.isFinite(parsed)) {
          return res.status(400).json({ error: "Invalid team id" });
        }
        clubId = parsed;
      }

      await storage.setProductPrimaryTeam(productId, clubId);
      const teamMeta = await storage.getProductTeamMeta(productId);
      res.json(teamMeta);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to update team";
      if (message.includes("not found")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error updating team metadata:", error);
      res.status(500).json({ error: "Failed to update team metadata" });
    }
  });

  // Update product
  app.patch("/api/products/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const updates = req.body;

      const existing = await storage.getProduct(productId);
      const requiredKeys = await getSyncRequiredFieldKeys();
      const hasCustomKeys = requiredKeys.some(isCustomAttrKey);
      const prodAttrs = hasCustomKeys ? await storage.getProductAttributes(productId) : undefined;
      const customAttrLabels = hasCustomKeys ? await getCustomAttrLabelsForMissing(requiredKeys) : new Map<string, string>();
      if (existing && updates.sync === true) {
        const merged = { ...existing, ...updates };
        const missing = getSyncRequiredMissingFieldsFromConfig(merged, requiredKeys, prodAttrs, customAttrLabels);
        if (missing.length > 0) {
          if (!existing.sync) {
            return res.status(400).json({
              error: `Cannot enable sync. Missing required fields: ${missing.join(", ")}`,
              missingFields: missing,
            });
          }
          updates.sync = false;
        }
      } else if (existing?.sync && updates.sync !== false) {
        const merged = { ...existing, ...updates };
        const missing = getSyncRequiredMissingFieldsFromConfig(merged, requiredKeys, prodAttrs, customAttrLabels);
        if (missing.length > 0) {
          updates.sync = false;
        }
      }
      
      await storage.updateProduct(productId, updates);
      const updatedProduct = await storage.getProductWithAttribution(productId);
      
      res.json(updatedProduct);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.post("/api/products/:id/attributes", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (!productId) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const attributeId = Number(req.body?.attributeId);
      if (!attributeId || Number.isNaN(attributeId)) {
        return res.status(400).json({ error: "Invalid attribute id" });
      }
      const value = req.body?.value;
      const storeId = req.body?.storeId != null ? Number(req.body.storeId) : null;
      await storage.setProductAttributeValue({ productId, attributeId, value, storeId });
      res.status(204).send();
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to set attribute";
      if (message.includes("not found")) {
        return res.status(400).json({ error: message });
      }
      console.error("Error setting product attribute:", error);
      res.status(500).json({ error: "Failed to set attribute" });
    }
  });

  app.delete("/api/products/:id/attributes/:attributeId", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const attributeId = parseInt(req.params.attributeId);
      if (!productId || !attributeId) {
        return res.status(400).json({ error: "Invalid product or attribute ID" });
      }
      const storeId = req.query?.storeId != null ? Number(req.query.storeId) : null;
      await storage.deleteProductAttributeValue({ productId, attributeId, storeId });
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product attribute:", error);
      res.status(500).json({ error: "Failed to delete attribute" });
    }
  });

  const escapeCSVValue = (value: any): string => {
    if (value === null || value === undefined) return '';
    const str = String(value);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const COLUMN_LABELS: Record<string, string> = {
    productId: "Product ID",
    productSku: "SKU",
    articleNumber: "Article Number",
    productDescription: "Description",
    brandName: "Brand",
    genderName: "Gender",
    productTypeName: "Product Type",
    colourName: "Colour",
    productStyle: "Style",
    composition: "Composition",
    countryOfManufacture: "Country of Manufacture",
    commodityCode: "Commodity Code",
    imageCode: "Image Code",
    enabled: "Status",
    sync: "Sync",
    dataAttribution: "Data Attribution %",
    variantCount: "Variant Count",
    totalStock: "Total Stock",
    createdAt: "Created Date",
    updatedAt: "Updated Date",
  };

  const getAttributeDisplayValue = (attr: any): string => {
    if (attr.valueBool !== null && attr.valueBool !== undefined) return String(attr.valueBool);
    if (attr.valueNum !== null && attr.valueNum !== undefined) return String(attr.valueNum);
    if (attr.valueJson !== null && attr.valueJson !== undefined) return JSON.stringify(attr.valueJson);
    if (attr.valueText !== null && attr.valueText !== undefined) return attr.valueText;
    return '';
  };

  const validateAndFilterAttributeColumns = async (attributeColumns: number[]): Promise<number[]> => {
    if (attributeColumns.length === 0) return [];
    const allDefs = await storage.getAttributeDefs();
    const validAttrIds = new Set(allDefs.map((d: any) => d.attributeId));
    return attributeColumns.filter((id: number) => validAttrIds.has(id));
  };

  const buildExportRows = async (products: any[], selectedColumns: string[], attributeColumns: number[]) => {
    let attrMap: Map<string, string> = new Map();
    if (attributeColumns.length > 0) {
      const productIds = products.map((p: any) => p.productId);
      const attrValues = await storage.getBulkProductAttributes(productIds, attributeColumns);
      for (const attr of attrValues) {
        attrMap.set(`${attr.productId}:${attr.attributeId}`, getAttributeDisplayValue(attr));
      }
    }

    return products.map((product: any) => {
      const row: Record<string, string> = {};
      for (const col of selectedColumns) {
        if (col.startsWith('attr:')) {
          const attrId = parseInt(col.replace('attr:', ''));
          row[col] = attrMap.get(`${product.productId}:${attrId}`) || '';
        } else {
          row[col] = product[col] !== null && product[col] !== undefined ? String(product[col]) : '';
        }
      }
      return row;
    });
  };

  const getColumnHeaderLabels = (allColumns: string[], attrDefs: any[]): string[] => {
    return allColumns.map((col: string) => {
      if (col.startsWith('attr:')) {
        const attrId = parseInt(col.replace('attr:', ''));
        const def = attrDefs.find((d: any) => d.attributeId === attrId);
        return def ? (def.label || def.code) : col;
      }
      return COLUMN_LABELS[col] || col;
    });
  };

  // Export preview
  app.post("/api/export/preview", async (req, res) => {
    try {
      const { filters, columns, attributeColumns: rawAttrCols = [] } = req.body;

      const selectedColumns = columns && columns.length > 0
        ? columns
        : [];

      const attributeColumns = await validateAndFilterAttributeColumns(rawAttrCols);
      const allColumns = [...selectedColumns, ...attributeColumns.map((id: number) => `attr:${id}`)];

      if (allColumns.length === 0) {
        return res.json({ rows: [], columns: [], totalCount: 0 });
      }

      const products = await storage.getProductsWithFilters({
        ...filters,
        limit: 5,
        offset: 0
      });

      let attrDefs: any[] = [];
      if (attributeColumns.length > 0) {
        const allDefs = await storage.getAttributeDefs();
        attrDefs = allDefs.filter((d: any) => attributeColumns.includes(d.attributeId));
      }

      const [rows, totalCount] = await Promise.all([
        buildExportRows(products, allColumns, attributeColumns),
        storage.getProductsCount(filters),
      ]);

      const columnLabels = getColumnHeaderLabels(allColumns, attrDefs);

      res.json({
        rows,
        columns: allColumns,
        columnLabels,
        totalCount,
      });
    } catch (error) {
      console.error("Error generating export preview:", error);
      res.status(500).json({ error: "Failed to generate preview" });
    }
  });

  // Export products with filters
  app.post("/api/export/products", async (req, res) => {
    try {
      const { filters, columns, attributeColumns: rawAttrCols = [] } = req.body;

      const selectedColumns = columns && columns.length > 0
        ? columns
        : ['productSku', 'productDescription', 'brandName', 'enabled', 'dataAttribution'];

      const attributeColumns = await validateAndFilterAttributeColumns(rawAttrCols);
      const allColumns = [...selectedColumns, ...attributeColumns.map((id: number) => `attr:${id}`)];

      const products = await storage.getProductsWithFilters({
        ...filters,
        limit: 10000,
        offset: 0
      });

      let attrDefs: any[] = [];
      if (attributeColumns.length > 0) {
        const allDefs = await storage.getAttributeDefs();
        attrDefs = allDefs.filter((d: any) => attributeColumns.includes(d.attributeId));
      }

      const rows = await buildExportRows(products, allColumns, attributeColumns);

      const headerLabels = getColumnHeaderLabels(allColumns, attrDefs);

      const csvHeader = headerLabels.map(escapeCSVValue).join(',');
      const csvRows = rows.map((row: Record<string, string>) =>
        allColumns.map((col: string) => escapeCSVValue(row[col])).join(',')
      );

      const csv = [csvHeader, ...csvRows].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="products_export_${Date.now()}.csv"`);
      res.send(csv);
    } catch (error) {
      console.error("Error exporting products:", error);
      res.status(500).json({ error: "Failed to export products" });
    }
  });

  const mapImportJob = (job: any) => ({
    batchId: String(job.importJobId),
    fileNames: job.originalFilename || "",
    uploadedAt: job.createdAt,
    status: job.status,
    totalRows: job.totalRows || 0,
    appliedRows: job.appliedRows || 0,
    invalidRows: job.invalidRows || 0,
    errorMessage: null,
    startedAt: null,
    completedAt: job.appliedAt || null,
    uploadedBy: job.uploadedByName || null,
  });

  // Import Feed - List all import batches
  app.get("/api/import-feed", async (req, res) => {
    try {
      const batches = await storage.getImportBatchesWithUser();
      res.json(batches.map(mapImportJob));
    } catch (error) {
      console.error("Error fetching import batches:", error);
      res.status(500).json({ error: "Failed to fetch import batches" });
    }
  });

  // Get specific import batch details
  app.get("/api/import-feed/:batchId", async (req, res) => {
    try {
      const { batchId } = req.params;
      const batch = await storage.getImportBatch(batchId);
      
      if (!batch) {
        return res.status(404).json({ error: "Batch not found" });
      }

      res.json(mapImportJob(batch));
    } catch (error) {
      console.error("Error fetching import batch:", error);
      res.status(500).json({ error: "Failed to fetch import batch" });
    }
  });

  // Product Groups
  app.post("/api/groups", async (req, res) => {
    try {
      const { name, description, productIds } = req.body;

      if (!name || !name.trim()) {
        return res.status(400).json({ error: "Group name is required" });
      }

      if (!productIds || !Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: "At least one product must be selected" });
      }

      const group = await storage.createProductGroup(
        name.trim(), 
        description?.trim() || null, 
        productIds
      );

      res.status(201).json(group);
    } catch (error) {
      console.error("Error creating product group:", error);
      res.status(500).json({ error: "Failed to create product group" });
    }
  });

  app.get("/api/groups", async (req, res) => {
    try {
      const groups = await storage.getProductGroups();
      res.json(groups);
    } catch (error) {
      console.error("Error fetching product groups:", error);
      res.status(500).json({ error: "Failed to fetch product groups" });
    }
  });

  app.get("/api/groups/:id", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      const group = await storage.getProductGroup(groupId);
      if (!group) {
        return res.status(404).json({ error: "Group not found" });
      }
      res.json(group);
    } catch (error) {
      console.error("Error fetching product group:", error);
      res.status(500).json({ error: "Failed to fetch product group" });
    }
  });

  app.get("/api/groups/:id/products", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      const products = await storage.getProductGroupProducts(groupId);
      res.json(products);
    } catch (error) {
      console.error("Error fetching group products:", error);
      res.status(500).json({ error: "Failed to fetch group products" });
    }
  });

  const handleUpdateGroup = async (req: any, res: any) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }

      const name = String(req.body?.name ?? "").trim();
      const description = String(req.body?.description ?? "").trim() || null;
      const status = String(req.body?.status ?? "").trim() || null;

      if (!name) {
        return res.status(400).json({ error: "Group name is required" });
      }

      const updated = await storage.updateProductGroup({
        groupId,
        name,
        description,
        status,
      });
      if (!updated) {
        return res.status(404).json({ error: "Group not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating product group:", error);
      res.status(500).json({ error: "Failed to update product group" });
    }
  };

  app.patch("/api/groups/:id", handleUpdateGroup);
  app.put("/api/groups/:id", handleUpdateGroup);

  app.delete("/api/groups/:id", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      await storage.deleteProductGroup(groupId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting product group:", error);
      res.status(500).json({ error: "Failed to delete product group" });
    }
  });

  app.post("/api/groups/:id/members", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      const { productIds, endDate } = req.body;
      if (!Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: "productIds must be a non-empty array" });
      }
      const parsedEndDate = endDate ? new Date(endDate) : null;
      const members = await storage.addProductsToGroup(groupId, productIds, parsedEndDate);
      res.status(201).json(members);
    } catch (error) {
      console.error("Error adding products to group:", error);
      res.status(500).json({ error: "Failed to add products to group" });
    }
  });

  app.delete("/api/groups/:id/members", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      const { memberIds } = req.body;
      if (!Array.isArray(memberIds) || memberIds.length === 0) {
        return res.status(400).json({ error: "memberIds must be a non-empty array" });
      }
      const count = await storage.deleteProductGroupMembers(groupId, memberIds);
      res.json({ deleted: count });
    } catch (error) {
      console.error("Error deleting group members:", error);
      res.status(500).json({ error: "Failed to delete group members" });
    }
  });

  app.patch("/api/groups/:id/members/bulk-end-date", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      const { memberIds, endDate } = req.body;
      if (!Array.isArray(memberIds) || memberIds.length === 0) {
        return res.status(400).json({ error: "memberIds must be a non-empty array" });
      }
      const parsedEndDate = endDate ? new Date(endDate) : null;
      const count = await storage.updateProductGroupMembersEndDate(groupId, memberIds, parsedEndDate);
      res.json({ updated: count });
    } catch (error) {
      console.error("Error bulk-updating end dates:", error);
      res.status(500).json({ error: "Failed to update end dates" });
    }
  });

  app.patch("/api/groups/:id/members/:memberId", async (req, res) => {
    try {
      const groupId = Number(req.params.id);
      const memberId = Number(req.params.memberId);
      if (!groupId || Number.isNaN(groupId)) {
        return res.status(400).json({ error: "Invalid group id" });
      }
      if (!memberId || Number.isNaN(memberId)) {
        return res.status(400).json({ error: "Invalid member id" });
      }

      if (typeof req.body.live === "boolean" && req.body.live === true) {
        const newMember = await storage.reactivateProductGroupMember(groupId, memberId);
        if (!newMember) {
          return res.status(404).json({ error: "Member not found in this group" });
        }
        return res.json(newMember);
      }

      const updates: { live?: boolean; endDate?: Date | null } = {};

      if (typeof req.body.live === "boolean") {
        updates.live = req.body.live;
        if (!req.body.live) {
          updates.endDate = new Date();
        }
      }

      if (req.body.endDate !== undefined) {
        updates.endDate = req.body.endDate ? new Date(req.body.endDate) : null;
      }

      const updated = await storage.updateProductGroupMember(groupId, memberId, updates);
      if (!updated) {
        return res.status(404).json({ error: "Member not found in this group" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating group member:", error);
      res.status(500).json({ error: "Failed to update group member" });
    }
  });

  app.get("/api/workspace/users", async (_req, res) => {
    try {
      const users = await storage.getWorkspaceUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching workspace users:", error);
      res.status(500).json({ error: "Failed to fetch workspace users" });
    }
  });

  app.get("/api/workspace/roles", async (_req, res) => {
    try {
      const roles = await storage.getWorkspaceRoles();
      res.json(roles);
    } catch (error) {
      console.error("Error fetching workspace roles:", error);
      res.status(500).json({ error: "Failed to fetch workspace roles" });
    }
  });

  app.get("/api/workspace/permissions", async (_req, res) => {
    try {
      const permissions = await storage.getWorkspacePermissions();
      res.json(permissions);
    } catch (error) {
      console.error("Error fetching workspace permissions:", error);
      res.status(500).json({ error: "Failed to fetch workspace permissions" });
    }
  });

  app.post("/api/workspace/roles", async (req, res) => {
    try {
      const { code, name, description, permissionIds } = req.body ?? {};

      if (!code || !name) {
        return res.status(400).json({ error: "Role code and name are required" });
      }

      const role = await storage.createWorkspaceRole({
        code: String(code).toUpperCase().trim(),
        name: String(name).trim(),
        description: description ? String(description).trim() : null,
        permissionIds: Array.isArray(permissionIds)
          ? permissionIds.map((id) => Number(id)).filter((id) => Number.isFinite(id))
          : [],
      });

      res.status(201).json(role);
    } catch (error) {
      console.error("Error creating workspace role:", error);
      res.status(500).json({ error: "Failed to create workspace role" });
    }
  });

  app.put("/api/workspace/roles/:code", async (req, res) => {
    try {
      const { name, description, permissionIds } = req.body ?? {};
      const { code } = req.params;

      if (!code || !name) {
        return res.status(400).json({ error: "Role code and name are required" });
      }

      const role = await storage.updateWorkspaceRole({
        code: String(code).toUpperCase().trim(),
        name: String(name).trim(),
        description: description ? String(description).trim() : null,
        permissionIds: Array.isArray(permissionIds)
          ? permissionIds.map((id) => Number(id)).filter((id) => Number.isFinite(id))
          : [],
      });

      res.status(200).json(role);
    } catch (error) {
      console.error("Error updating workspace role:", error);
      res.status(500).json({ error: "Failed to update workspace role" });
    }
  });

  app.post("/api/workspace/users/:userId/roles", async (req, res) => {
    try {
      const { roleCode } = req.body ?? {};
      const userId = Number(req.params.userId);

      if (!Number.isFinite(userId) || !roleCode) {
        return res.status(400).json({ error: "User and role are required" });
      }

      const result = await storage.assignWorkspaceUserRole({
        userId,
        roleCode: String(roleCode).toUpperCase().trim(),
      });

      res.status(200).json(result);
    } catch (error) {
      console.error("Error assigning workspace role:", error);
      res.status(500).json({ error: "Failed to assign workspace role" });
    }
  });

  // Reference data import endpoint
  app.post("/api/reference-data/import", upload.single("file"), async (req, res) => {
    try {
      const tableType = req.body?.tableType;
      const file = req.file;

      if (!tableType) {
        return res.status(400).json({ error: "Table type is required" });
      }

      if (!file) {
        return res.status(400).json({ error: "CSV file is required" });
      }

      // Parse CSV
      const csvContent = file.buffer.toString("utf-8");
      const parsed = Papa.parse(csvContent, {
        header: true,
        skipEmptyLines: true,
        transformHeader: (header) => header.trim(),
      });

      if (parsed.errors.length > 0) {
        return res.status(400).json({ 
          error: "CSV parsing error", 
          details: parsed.errors 
        });
      }

      const rows = convertHeadersToCamelCase(parsed.data as any[]).filter(
        (row) => !isRowEmpty(row)
      );

      if (rows.length === 0) {
        return res.status(400).json({ error: "No data rows found in CSV" });
      }

      const result = await storage.importReferenceData(tableType, rows);
      res.json(result);
    } catch (error: any) {
      console.error("Error importing reference data:", error);
      res.status(500).json({ error: error.message || "Failed to import reference data" });
    }
  });

  // Get supported reference table types
  app.get("/api/reference-data/tables", async (req, res) => {
    try {
      const tables = await storage.getReferenceTableTypes();
      res.json(tables);
    } catch (error) {
      console.error("Error fetching reference table types:", error);
      res.status(500).json({ error: "Failed to fetch reference table types" });
    }
  });

  // Image management endpoints
  app.get("/api/images", async (req, res) => {
    try {
      const limit = parseInt(String(req.query.limit || "50"), 10);
      const offset = parseInt(String(req.query.offset || "0"), 10);
      const search = req.query.search ? String(req.query.search) : undefined;
      const role = req.query.role ? String(req.query.role) : undefined;

      const result = await storage.getAllImages({ limit, offset, search, role });
      res.json(result);
    } catch (error) {
      console.error("Error fetching images:", error);
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  app.post("/api/images/import", upload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const csvText = file.buffer.toString("utf-8");
      const parsed = Papa.parse(csvText, { header: true, skipEmptyLines: true });
      if (parsed.errors.length > 0) {
        return res.status(400).json({ error: "Failed to parse CSV", details: parsed.errors.slice(0, 5) });
      }

      const rows = parsed.data as Array<Record<string, string>>;
      if (rows.length === 0) {
        return res.status(400).json({ error: "CSV file has no data rows" });
      }

      const result = await storage.importImagesCsv(rows);
      res.json(result);
    } catch (error) {
      console.error("Error importing images:", error);
      res.status(500).json({ error: "Failed to import images" });
    }
  });

  app.get("/api/products/:id/images", async (req, res) => {
    try {
      const productId = parseInt(req.params.id, 10);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }
      const images = await storage.getProductImages(productId);
      res.json(images);
    } catch (error) {
      console.error("Error fetching product images:", error);
      res.status(500).json({ error: "Failed to fetch product images" });
    }
  });

  app.post("/api/images", async (req, res) => {
    try {
      const { productId, url, role, label } = req.body;
      if (!productId || !url || !role) {
        return res.status(400).json({ error: "productId, url, and role are required" });
      }
      const validRoles = ["base", "small", "thumbnail", "additional", "swatch"];
      if (!validRoles.includes(String(role).trim())) {
        return res.status(400).json({ error: `Invalid role. Must be one of: ${validRoles.join(", ")}` });
      }
      const image = await storage.createImage({
        productId: Number(productId),
        url: String(url).trim(),
        role: String(role).trim(),
        label: label ? String(label).trim() : null,
      });
      res.json(image);
    } catch (error) {
      console.error("Error creating image:", error);
      res.status(500).json({ error: "Failed to create image" });
    }
  });

  app.delete("/api/images/:id", async (req, res) => {
    try {
      const imageId = parseInt(req.params.id, 10);
      if (isNaN(imageId)) {
        return res.status(400).json({ error: "Invalid image ID" });
      }
      await storage.deleteImage(imageId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting image:", error);
      res.status(500).json({ error: "Failed to delete image" });
    }
  });

  app.post("/api/alumio/sync-log", async (req, res) => {
    try {
      const apiKey = req.headers["x-api-key"] as string;
      const expectedKey = process.env.ALUMIO_API_KEY;
      if (!expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const body = req.body;

      if (typeof body.httpStatusCode !== "number" || !Number.isInteger(body.httpStatusCode)) {
        return res.status(400).json({ error: "httpStatusCode must be an integer" });
      }

      let operationType: { sku: string; operationType: string }[] | null = null;
      if (body.operationType !== undefined && body.operationType !== null) {
        if (typeof body.operationType === "string") {
          const skus = Array.isArray(body.skus) ? body.skus.map(String) : body.skus ? [String(body.skus)] : [];
          operationType = skus.map((sku: string) => ({ sku, operationType: body.operationType }));
        } else if (Array.isArray(body.operationType)) {
          for (const entry of body.operationType) {
            if (typeof entry.sku !== "string" || typeof entry.operationType !== "string") {
              return res.status(400).json({ error: "Each operationType entry must have string fields 'sku' and 'operationType'" });
            }
          }
          operationType = body.operationType;
        } else {
          return res.status(400).json({ error: "operationType must be a string or an array of { sku, operationType } objects" });
        }
      }

      const skus = Array.isArray(body.skus) ? body.skus.map(String) : body.skus ? [String(body.skus)] : null;

      if (body.errorSource && body.errorSource !== "Alumio" && body.errorSource !== "Magento") {
        return res.status(400).json({ error: "errorSource must be 'Alumio' or 'Magento'" });
      }

      const log = await storage.createSyncLog({
        requestData: body.requestData ?? null,
        responseData: body.responseData ?? null,
        httpStatusCode: body.httpStatusCode,
        responseMessage: body.responseMessage ? String(body.responseMessage) : null,
        skus,
        operationType,
        errorSource: body.errorSource ? String(body.errorSource) : null,
        taskId: body.taskId ? String(body.taskId) : null,
        duration: typeof body.duration === "number" ? body.duration : null,
        retryNumber: typeof body.retryNumber === "number" && Number.isInteger(body.retryNumber) ? body.retryNumber : null,
        createdAt: body.createdAt ? new Date(body.createdAt) : new Date(),
      });

      res.status(201).json(log);
    } catch (error) {
      console.error("Error creating sync log:", error);
      res.status(500).json({ error: "Failed to create sync log" });
    }
  });

  app.get("/api/alumio/sync-logs", async (req, res) => {
    try {
      const limit = Math.max(1, Math.min(100, parseInt(req.query.limit as string) || 50));
      const offset = Math.max(0, parseInt(req.query.offset as string) || 0);
      const operationType = req.query.operationType as string | undefined;
      const statusFilter = req.query.statusFilter as string | undefined;
      const skuSearch = req.query.skuSearch as string | undefined;

      const result = await storage.getSyncLogs({
        limit,
        offset,
        operationType: operationType || undefined,
        statusFilter: statusFilter || undefined,
        skuSearch: skuSearch || undefined,
      });

      res.json(result);
    } catch (error) {
      console.error("Error fetching sync logs:", error);
      res.status(500).json({ error: "Failed to fetch sync logs" });
    }
  });

  app.post("/api/products/:id/resync", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ error: "Invalid product ID" });
      }

      const result = await storage.resyncProductWithVariants(productId);
      res.json({ success: true, entry: result.productEntry, variantEntries: result.variantEntries });
    } catch (error) {
      console.error("Error adding product to sync queue:", error);
      res.status(500).json({ error: "Failed to add product to sync queue" });
    }
  });

  app.get("/api/workspace/sync-required-fields", async (_req, res) => {
    try {
      const [fields, customAttrs] = await Promise.all([
        storage.getWorkspaceSetting("sync_required_fields"),
        storage.getAttributeDefs(),
      ]);
      const builtinOptions = BUILTIN_SYNC_FIELD_OPTIONS.map(({ field, label }) => ({
        field,
        label,
        group: "product",
      }));
      const customOptions = customAttrs.map((attr: any) => ({
        field: `${CUSTOM_ATTR_PREFIX}${attr.code}`,
        label: attr.label || attr.code,
        group: "custom_attribute",
      }));
      res.json({
        selectedFields: Array.isArray(fields) ? fields : [],
        availableFields: [...builtinOptions, ...customOptions],
      });
    } catch (error) {
      console.error("Error fetching sync required fields:", error);
      res.status(500).json({ error: "Failed to fetch sync required fields" });
    }
  });

  app.put("/api/workspace/sync-required-fields", async (req, res) => {
    try {
      const { fields } = req.body;
      if (!Array.isArray(fields)) {
        return res.status(400).json({ error: "fields must be an array" });
      }
      const customAttrs = await storage.getAttributeDefs();
      const validCustomCodes = new Set(customAttrs.map((a: any) => `${CUSTOM_ATTR_PREFIX}${a.code}`));
      const validFields = fields.filter((f: string) =>
        BUILTIN_SYNC_FIELD_OPTIONS.some((opt) => opt.field === f) || validCustomCodes.has(f)
      );
      await storage.setWorkspaceSetting("sync_required_fields", validFields);
      invalidateSyncRequiredFieldsCache();
      res.json({ success: true, selectedFields: validFields });
    } catch (error) {
      console.error("Error updating sync required fields:", error);
      res.status(500).json({ error: "Failed to update sync required fields" });
    }
  });

  app.get("/api/alumio/sync-queue", async (req, res) => {
    try {
      const apiKey = req.headers["x-api-key"] as string;
      const expectedKey = process.env.ALUMIO_API_KEY;
      if (!expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const limit = Math.max(1, Math.min(500, parseInt(req.query.limit as string) || 100));
      const offset = Math.max(0, parseInt(req.query.offset as string) || 0);
      const status = (req.query.status as string) || "pending";

      const result = await storage.getSyncQueueEntries({ status, limit, offset });
      res.json(result);
    } catch (error) {
      console.error("Error fetching sync queue entries:", error);
      res.status(500).json({ error: "Failed to fetch sync queue entries" });
    }
  });

  app.patch("/api/alumio/sync-queue/status", async (req, res) => {
    try {
      const apiKey = req.headers["x-api-key"] as string;
      const expectedKey = process.env.ALUMIO_API_KEY;
      if (!expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const { ids, status } = req.body;

      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ error: "ids must be a non-empty array" });
      }

      const validStatuses = ["pending", "processing", "sent", "failed"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ error: `status must be one of: ${validStatuses.join(", ")}` });
      }

      const numericIds = ids.map(Number).filter((id: number) => Number.isFinite(id));
      if (numericIds.length === 0) {
        return res.status(400).json({ error: "No valid IDs provided" });
      }

      await storage.updateSyncQueueStatus(numericIds, status);
      res.json({ updated: numericIds.length });
    } catch (error) {
      console.error("Error updating sync queue status:", error);
      res.status(500).json({ error: "Failed to update sync queue status" });
    }
  });

  app.post("/api/scheduled-changes", async (req, res) => {
    try {
      const { name, description, scheduledAt, endsAt, scopeType, scopeGroupId, productIds, items } = req.body;

      if (!name || !name.trim()) {
        return res.status(400).json({ error: "Name is required" });
      }
      if (!scheduledAt) {
        return res.status(400).json({ error: "Scheduled date/time is required" });
      }
      const parsedDate = new Date(scheduledAt);
      if (isNaN(parsedDate.getTime())) {
        return res.status(400).json({ error: "Invalid scheduled date" });
      }
      if (parsedDate <= new Date()) {
        return res.status(400).json({ error: "Scheduled date must be in the future" });
      }
      let parsedEndsAt: Date | null = null;
      if (endsAt) {
        parsedEndsAt = new Date(endsAt);
        if (isNaN(parsedEndsAt.getTime())) {
          return res.status(400).json({ error: "Invalid end date" });
        }
        if (parsedEndsAt <= parsedDate) {
          return res.status(400).json({ error: "End date must be after the scheduled date" });
        }
      }
      if (!scopeType || !["products", "group", "add_to_group"].includes(scopeType)) {
        return res.status(400).json({ error: "Scope type must be 'products', 'group', or 'add_to_group'" });
      }
      if ((scopeType === "products" || scopeType === "add_to_group") && (!productIds || !Array.isArray(productIds) || productIds.length === 0)) {
        return res.status(400).json({ error: "At least one product must be selected" });
      }
      if ((scopeType === "group" || scopeType === "add_to_group") && !scopeGroupId) {
        return res.status(400).json({ error: "A product group must be selected" });
      }
      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: "At least one change item must be defined" });
      }

      const allowedProductFields = new Set([
        "productDescription", "enabled", "sync", "productStyle",
        "composition", "countryOfManufacture", "commodityCode",
        "imageCode", "articleNumber",
      ]);
      const allowedEntityTypes = new Set(["product", "variant_price", "group_membership"]);
      for (const item of items) {
        if (!item.entityType || !allowedEntityTypes.has(item.entityType)) {
          return res.status(400).json({ error: `Invalid entity type: ${item.entityType}` });
        }
        if (!item.fieldName) {
          return res.status(400).json({ error: "Field name is required for each item" });
        }
        if (item.entityType === "product" && !allowedProductFields.has(item.fieldName)) {
          return res.status(400).json({ error: `Invalid product field name: ${item.fieldName}` });
        }
        if (item.entityType === "variant_price") {
          const pricePattern = /^(retailPrice|specialRetailPrice)_[A-Z]{3}$/;
          if (!pricePattern.test(item.fieldName)) {
            return res.status(400).json({ error: `Invalid price field name: ${item.fieldName}. Expected format: retailPrice_GBP or specialRetailPrice_USD` });
          }
          if (item.changeMode && !["absolute", "percentage"].includes(item.changeMode)) {
            return res.status(400).json({ error: `Invalid change mode: ${item.changeMode}. Must be 'absolute' or 'percentage'` });
          }
          if (item.changeMode === "percentage" && !item.fieldName.startsWith("specialRetailPrice_")) {
            return res.status(400).json({ error: "Percentage mode is only supported for special price fields" });
          }
          if (item.changeMode === "percentage" && item.newValue) {
            const pct = Number(item.newValue);
            if (isNaN(pct)) {
              return res.status(400).json({ error: `Percentage value must be a number, got: ${item.newValue}` });
            }
            if (pct < 0 || pct > 100) {
              return res.status(400).json({ error: `Discount percentage must be between 0 and 100, got: ${pct}` });
            }
          }
        }
        if (item.entityType === "group_membership" && item.fieldName !== "add_to_group") {
          return res.status(400).json({ error: `Invalid group_membership field: ${item.fieldName}` });
        }
      }

      let resolvedProductIds: number[] = [];
      if (scopeType === "products") {
        resolvedProductIds = productIds.map(Number);
      } else if (scopeType === "group") {
        const groupProducts = await storage.getProductGroupProducts(Number(scopeGroupId));
        resolvedProductIds = groupProducts.filter((p: any) => p.live).map((p: any) => p.productId);
        if (resolvedProductIds.length === 0) {
          return res.status(400).json({ error: "Selected group has no products" });
        }
      } else if (scopeType === "add_to_group") {
        resolvedProductIds = productIds.map(Number);
      }

      const change = await storage.createScheduledChange({
        name: name.trim(),
        description: description?.trim() || null,
        scheduledAt: parsedDate,
        endsAt: parsedEndsAt,
        scopeType,
        scopeGroupId: scopeGroupId ? Number(scopeGroupId) : null,
        productIds: resolvedProductIds,
        items,
      });

      res.status(201).json(change);
    } catch (error) {
      console.error("Error creating scheduled change:", error);
      res.status(500).json({ error: "Failed to create scheduled change" });
    }
  });

  app.get("/api/scheduled-changes", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const changes = await storage.getScheduledChanges(status ? { status } : undefined);
      res.json(changes);
    } catch (error) {
      console.error("Error fetching scheduled changes:", error);
      res.status(500).json({ error: "Failed to fetch scheduled changes" });
    }
  });

  app.get("/api/scheduled-changes/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id)) {
        return res.status(400).json({ error: "Invalid id" });
      }
      const change = await storage.getScheduledChange(id);
      if (!change) {
        return res.status(404).json({ error: "Scheduled change not found" });
      }
      const items = await storage.getScheduledChangeItems(id);
      res.json({ ...change, items });
    } catch (error) {
      console.error("Error fetching scheduled change:", error);
      res.status(500).json({ error: "Failed to fetch scheduled change" });
    }
  });

  app.put("/api/scheduled-changes/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id)) {
        return res.status(400).json({ error: "Invalid id" });
      }

      const { name, description, scheduledAt } = req.body;
      const updates: any = {};
      if (name !== undefined) updates.name = name.trim();
      if (description !== undefined) updates.description = description?.trim() || null;
      if (scheduledAt !== undefined) {
        const parsedDate = new Date(scheduledAt);
        if (isNaN(parsedDate.getTime())) {
          return res.status(400).json({ error: "Invalid scheduled date" });
        }
        if (parsedDate <= new Date()) {
          return res.status(400).json({ error: "Scheduled date must be in the future" });
        }
        updates.scheduledAt = parsedDate;
      }

      const updated = await storage.updateScheduledChange(id, updates);
      if (!updated) {
        return res.status(404).json({ error: "Scheduled change not found or not pending" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error updating scheduled change:", error);
      res.status(500).json({ error: "Failed to update scheduled change" });
    }
  });

  app.post("/api/scheduled-changes/:id/cancel", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id)) {
        return res.status(400).json({ error: "Invalid id" });
      }
      const cancelled = await storage.cancelScheduledChange(id);
      if (!cancelled) {
        return res.status(404).json({ error: "Scheduled change not found or not pending" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error cancelling scheduled change:", error);
      res.status(500).json({ error: "Failed to cancel scheduled change" });
    }
  });

  app.get("/api/api-keys", async (_req, res) => {
    try {
      const keys = await storage.getApiKeys();
      const sanitized = keys.map(({ keyHash, ...rest }) => rest);
      res.json(sanitized);
    } catch (error) {
      console.error("Error fetching API keys:", error);
      res.status(500).json({ error: "Failed to fetch API keys" });
    }
  });

  app.post("/api/api-keys", async (req, res) => {
    try {
      const { name, scopes } = req.body;
      if (!name || typeof name !== "string" || !name.trim()) {
        return res.status(400).json({ error: "Name is required" });
      }
      if (!Array.isArray(scopes) || scopes.length === 0) {
        return res.status(400).json({ error: "At least one scope is required" });
      }
      const invalidScopes = scopes.filter((s: string) => s !== "*" && !(VALID_SCOPES as readonly string[]).includes(s));
      if (invalidScopes.length > 0) {
        return res.status(400).json({ error: `Invalid scopes: ${invalidScopes.join(", ")}` });
      }

      const rawKey = `pim_${randomBytes(32).toString("hex")}`;
      const keyHash = createHash("sha256").update(rawKey).digest("hex");
      const keyPrefix = rawKey.slice(0, 12);

      const userId = (req as any).user?.id ?? null;

      const created = await storage.createApiKey({
        name: name.trim(),
        keyHash,
        keyPrefix,
        scopes,
        createdBy: userId,
      });

      const { keyHash: _, ...safe } = created;
      res.json({ ...safe, key: rawKey });
    } catch (error) {
      console.error("Error creating API key:", error);
      res.status(500).json({ error: "Failed to create API key" });
    }
  });

  app.patch("/api/api-keys/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

      const { name, scopes, active } = req.body;
      const updates: any = {};
      if (name !== undefined) {
        if (typeof name !== "string" || !name.trim()) {
          return res.status(400).json({ error: "Name must be a non-empty string" });
        }
        updates.name = name.trim();
      }
      if (scopes !== undefined) {
        if (!Array.isArray(scopes) || scopes.length === 0) {
          return res.status(400).json({ error: "Scopes must be a non-empty array" });
        }
        const invalidScopes = scopes.filter((s: string) => s !== "*" && !(VALID_SCOPES as readonly string[]).includes(s));
        if (invalidScopes.length > 0) {
          return res.status(400).json({ error: `Invalid scopes: ${invalidScopes.join(", ")}` });
        }
        updates.scopes = scopes;
      }
      if (active !== undefined) {
        if (typeof active !== "boolean") {
          return res.status(400).json({ error: "Active must be a boolean" });
        }
        updates.active = active;
      }

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ error: "No valid fields to update" });
      }

      const updated = await storage.updateApiKey(id, updates);
      if (!updated) return res.status(404).json({ error: "API key not found" });

      const { keyHash, ...safe } = updated;
      res.json(safe);
    } catch (error) {
      console.error("Error updating API key:", error);
      res.status(500).json({ error: "Failed to update API key" });
    }
  });

  app.delete("/api/api-keys/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (!id || isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

      await storage.deleteApiKey(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting API key:", error);
      res.status(500).json({ error: "Failed to delete API key" });
    }
  });

  app.get("/api/api-keys/scopes", async (_req, res) => {
    res.json(VALID_SCOPES);
  });

  return app;
}
