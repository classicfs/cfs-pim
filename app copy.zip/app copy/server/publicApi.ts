import type { Express, Request, Response, NextFunction } from "express";
import { createHash } from "crypto";
import { storage } from "./storage";

function hashKey(raw: string): string {
  return createHash("sha256").update(raw).digest("hex");
}

const VALID_SCOPES = [
  "products",
  "variants",
  "pricing",
  "stock",
  "categories",
  "brands",
  "reference-data",
  "images",
] as const;

type Scope = (typeof VALID_SCOPES)[number];

async function authenticateApiKey(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  try {
    const raw = req.headers["x-api-key"] as string | undefined;
    if (!raw) {
      return res.status(401).json({ error: "Missing x-api-key header" });
    }

    const hash = hashKey(raw);
    const key = await storage.getApiKeyByHash(hash);
    if (!key || !key.active) {
      return res.status(401).json({ error: "Invalid or inactive API key" });
    }

    (req as any).apiKeyRecord = key;

    storage.touchApiKeyLastUsed(key.apiKeyId).catch(() => {});

    next();
  } catch (error) {
    console.error("Public API auth error:", error);
    return res.status(500).json({ error: "Authentication service error" });
  }
}

function requireScope(scope: Scope) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = (req as any).apiKeyRecord;
    if (!key) return res.status(401).json({ error: "Unauthorized" });
    const scopes: string[] = key.scopes ?? [];
    if (!scopes.includes(scope) && !scopes.includes("*")) {
      return res
        .status(403)
        .json({ error: `API key lacks required scope: ${scope}` });
    }
    next();
  };
}

function parsePagination(query: any) {
  const page = Math.max(1, parseInt(query.page as string) || 1);
  const limit = Math.max(1, Math.min(250, parseInt(query.limit as string) || 50));
  const offset = (page - 1) * limit;
  return { page, limit, offset };
}

export function registerPublicApiRoutes(app: Express) {
  app.get(
    "/api/public/products",
    authenticateApiKey,
    requireScope("products"),
    async (req: Request, res: Response) => {
      try {
        const { page, limit, offset } = parsePagination(req.query);
        const search = (req.query.search as string) || undefined;
        const brandId = req.query.brandId
          ? Number(req.query.brandId)
          : undefined;
        const categoryId = req.query.categoryId
          ? Number(req.query.categoryId)
          : undefined;
        const enabled = req.query.enabled !== undefined
          ? req.query.enabled === "true"
          : undefined;

        const filters: any = {
          search,
          brandId,
          categoryId,
          enabled,
          limit,
          offset,
        };

        const [products, total] = await Promise.all([
          storage.getProductsWithFilters(filters),
          storage.getProductsCount(filters),
        ]);

        res.json({
          data: products,
          pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
        });
      } catch (error) {
        console.error("Public API - products error:", error);
        res.status(500).json({ error: "Failed to fetch products" });
      }
    },
  );

  app.get(
    "/api/public/products/:id",
    authenticateApiKey,
    requireScope("products"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid product ID" });

        const product = await storage.getProductWithAttribution(id);
        if (!product)
          return res.status(404).json({ error: "Product not found" });

        const [variants, categories, images, teamMeta, productAttributes] = await Promise.all([
          storage.getProductVariants(id),
          storage.getCategoriesForProduct(id),
          storage.getProductImages(id),
          storage.getProductTeamMeta(id),
          storage.getProductAttributes(id),
        ]);

        const variantAttributes: Record<number, any[]> = {};
        for (const v of variants) {
          const vId = v.productVariantId ?? v.product_variant_id;
          if (vId) {
            variantAttributes[vId] = await storage.getVariantAttributes(vId);
          }
        }

        res.json({
          ...product,
          variants: variants.map((v: any) => {
            const vId = v.productVariantId ?? v.product_variant_id;
            return { ...v, attributes: variantAttributes[vId] || [] };
          }),
          categories,
          images,
          teamMeta,
          attributes: productAttributes,
        });
      } catch (error) {
        console.error("Public API - product detail error:", error);
        res.status(500).json({ error: "Failed to fetch product" });
      }
    },
  );

  app.get(
    "/api/public/products/:id/variants",
    authenticateApiKey,
    requireScope("variants"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid product ID" });

        const variants = await storage.getProductVariants(id);
        res.json({ data: variants });
      } catch (error) {
        console.error("Public API - variants error:", error);
        res.status(500).json({ error: "Failed to fetch variants" });
      }
    },
  );

  app.get(
    "/api/public/products/:id/attributes",
    authenticateApiKey,
    requireScope("products"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid product ID" });

        const attributes = await storage.getProductAttributes(id);
        res.json({ data: attributes });
      } catch (error) {
        console.error("Public API - product attributes error:", error);
        res.status(500).json({ error: "Failed to fetch product attributes" });
      }
    },
  );

  app.get(
    "/api/public/variants/:id/attributes",
    authenticateApiKey,
    requireScope("variants"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid variant ID" });

        const attributes = await storage.getVariantAttributes(id);
        res.json({ data: attributes });
      } catch (error) {
        console.error("Public API - variant attributes error:", error);
        res.status(500).json({ error: "Failed to fetch variant attributes" });
      }
    },
  );

  app.get(
    "/api/public/variants/:id/prices",
    authenticateApiKey,
    requireScope("pricing"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid variant ID" });

        const prices = await storage.getVariantPricesWithCurrency(id);
        res.json({ data: prices });
      } catch (error) {
        console.error("Public API - prices error:", error);
        res.status(500).json({ error: "Failed to fetch prices" });
      }
    },
  );

  app.get(
    "/api/public/variants/:id/stock",
    authenticateApiKey,
    requireScope("stock"),
    async (req: Request, res: Response) => {
      try {
        const id = Number(req.params.id);
        if (!id || isNaN(id))
          return res.status(400).json({ error: "Invalid variant ID" });

        const stock = await storage.getVariantStock(id);
        res.json({ data: stock });
      } catch (error) {
        console.error("Public API - stock error:", error);
        res.status(500).json({ error: "Failed to fetch stock" });
      }
    },
  );

  app.get(
    "/api/public/categories",
    authenticateApiKey,
    requireScope("categories"),
    async (_req: Request, res: Response) => {
      try {
        const categories = await storage.getCategories();
        res.json({ data: categories });
      } catch (error) {
        console.error("Public API - categories error:", error);
        res.status(500).json({ error: "Failed to fetch categories" });
      }
    },
  );

  app.get(
    "/api/public/brands",
    authenticateApiKey,
    requireScope("brands"),
    async (_req: Request, res: Response) => {
      try {
        const brandsList = await storage.getBrands();
        res.json({ data: brandsList });
      } catch (error) {
        console.error("Public API - brands error:", error);
        res.status(500).json({ error: "Failed to fetch brands" });
      }
    },
  );

  app.get(
    "/api/public/reference/genders",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getGenders();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch genders" });
      }
    },
  );

  app.get(
    "/api/public/reference/product-types",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getProductTypes();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch product types" });
      }
    },
  );

  app.get(
    "/api/public/reference/conditions",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getConditions();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch conditions" });
      }
    },
  );

  app.get(
    "/api/public/reference/sizes",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getSizes();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch sizes" });
      }
    },
  );

  app.get(
    "/api/public/reference/colours",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getProductColours();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch colours" });
      }
    },
  );

  app.get(
    "/api/public/reference/eras",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getEras();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch eras" });
      }
    },
  );

  app.get(
    "/api/public/reference/warehouses",
    authenticateApiKey,
    requireScope("stock"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getWarehouses();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch warehouses" });
      }
    },
  );

  app.get(
    "/api/public/reference/currencies",
    authenticateApiKey,
    requireScope("pricing"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getCurrencies();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch currencies" });
      }
    },
  );

  app.get(
    "/api/public/images",
    authenticateApiKey,
    requireScope("images"),
    async (req: Request, res: Response) => {
      try {
        const { limit, offset } = parsePagination(req.query);
        const role = (req.query.role as string) || undefined;
        const search = (req.query.search as string) || undefined;
        const result = await storage.getAllImages({ limit, offset, role, search });
        res.json({
          data: result.images,
          pagination: {
            page: Math.floor(offset / limit) + 1,
            limit,
            total: result.total,
            totalPages: Math.ceil(result.total / limit),
          },
        });
      } catch (error) {
        console.error("Public API - images error:", error);
        res.status(500).json({ error: "Failed to fetch images" });
      }
    },
  );

  app.get(
    "/api/public/clubs",
    authenticateApiKey,
    requireScope("reference-data"),
    async (req: Request, res: Response) => {
      try {
        const limit = Math.max(1, Math.min(500, parseInt(req.query.limit as string) || 100));
        const data = await storage.getClubs(limit);
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch clubs" });
      }
    },
  );

  app.get(
    "/api/public/stores",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getStores();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch stores" });
      }
    },
  );

  app.get(
    "/api/public/attributes",
    authenticateApiKey,
    requireScope("reference-data"),
    async (_req: Request, res: Response) => {
      try {
        const data = await storage.getAttributeDefs();
        res.json({ data });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch attributes" });
      }
    },
  );
}

export { hashKey, VALID_SCOPES };
